// SPDX-FileCopyrightText: © 2026 Tenstorrent USA, Inc.
//
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include "api/compute/compute_kernel_api.h"
#include "api/compute/common.h"
#include "api/compute/eltwise_binary.h"
#include "api/compute/bcast.h"
#include "sanitizer/api.h"

#ifdef TRISC_MATH
#include "llk_math_binary_api.h"
#ifdef ARCH_BLACKHOLE
#include "experimental/llk_math_eltwise_mul_scalar_block.h"
#endif
#endif
#ifdef TRISC_UNPACK
#include "llk_unpack_AB_api.h"
#ifdef ARCH_BLACKHOLE
#include "experimental/llk_unpack_AB_scalar_block_api.h"
#endif
#endif

namespace ckernel {

// Blackhole-only: the scalar-block math/unpack LLKs live only in the Blackhole trees.
#if defined(ARCH_BLACKHOLE)

// ============================================================================
// Scalar broadcast multiply
// ============================================================================

/**
 * Short init for scalar broadcast multiply (assumes hw already configured)
 */
ALWI void deepseek_mul_bcast_scalar_init(uint32_t icb0, uint32_t icb1, uint32_t call_line = __builtin_LINE()) {
    state_configure(icb0, icb1, call_line);
    MATH((llk_math_eltwise_binary_init<EltwiseBinaryType::ELWMUL, BroadcastType::SCALAR, MATH_FIDELITY>(icb0, icb1)));
    UNPACK((llk_unpack_AB_init<BroadcastType::SCALAR>(icb0, icb1)));
}

/**
 * Scalar broadcast multiply with configurable fp32 accumulation
 */
template <bool fp32_dest_acc_en = DST_ACCUM_MODE>
ALWI void deepseek_mul_tiles_bcast_scalar(
    uint32_t icb0, uint32_t icb1, uint32_t itile0, uint32_t itile1, uint32_t idst) {
    MATH((llk_math_eltwise_binary<
          EltwiseBinaryType::ELWMUL,
          BroadcastType::SCALAR,
          fp32_dest_acc_en,
          MATH_FIDELITY,
          EltwiseBinaryReuseDestType::NONE>(icb0, icb1, idst, true)));
    UNPACK((llk_unpack_AB<BroadcastType::SCALAR>(icb0, icb1, itile0, itile1)));
}

// Reuse one scalar SrcB across a block of full 32x32 tiles. The caller owns
// destination acquisition and must keep the block within that allocation.
ALWI void mul_tiles_bcast_scalar_block_init(uint32_t icb0, uint32_t icb1, uint32_t call_line = __builtin_LINE()) {
    state_configure(icb0, icb1, call_line);
    MATH(SAN_HOOK(unsupported()));
    MATH((_llk_math_eltwise_mul_scalar_block_init_()));
    UNPACK((llk_unpack_AB_scalar_block_init(icb0, icb1)));
}

ALWI void mul_tiles_bcast_scalar_block(
    uint32_t icb0, uint32_t icb1, uint32_t itile0, uint32_t itile1, uint32_t idst, uint32_t block_size) {
    MATH(SAN_HOOK(unsupported()));
    MATH((_llk_math_eltwise_mul_scalar_block_(idst, block_size)));
    UNPACK((llk_unpack_AB_scalar_block(icb0, icb1, itile0, itile1, block_size)));
}

// Source-compatible spelling for callers already using the short initializer.
ALWI void deepseek_mul_tiles_bcast_scalar_init_short(
    uint32_t icb0, uint32_t icb1, uint32_t call_line = __builtin_LINE()) {
    deepseek_mul_bcast_scalar_init(icb0, icb1, call_line);
}

// ============================================================================
// Binary dest reuse multiply
// ============================================================================

/**
 * Init for binary dest reuse multiply
 */
template <EltwiseBinaryReuseDestType binary_reuse_dest = EltwiseBinaryReuseDestType::DEST_TO_SRCA>
ALWI void deepseek_binary_dest_reuse_tiles_init(uint32_t icb0, uint32_t call_line = __builtin_LINE()) {
    state_configure(icb0, call_line);
    UNPACK((llk_unpack_A_init<BroadcastType::NONE, true, binary_reuse_dest>(false, false, icb0)));
    // Init and execute must use the same face height: the HiFi partial-face
    // path advances DEST separately after each face (tt-metal#50658).
    MATH(
        (llk_math_eltwise_binary_init<EltwiseBinaryType::ELWMUL, BroadcastType::NONE, MATH_FIDELITY, binary_reuse_dest>(
            icb0, icb0, false /*acc_to_dest*/)));
}

/**
 * Binary dest reuse multiply
 * dest[idst] = dest[idst] * cb[in_tile_index]
 */
template <
    bool fp32_dest_acc_en = DST_ACCUM_MODE,
    EltwiseBinaryReuseDestType binary_reuse_dest = EltwiseBinaryReuseDestType::DEST_TO_SRCA>
ALWI void deepseek_binary_dest_reuse_tiles(uint32_t icb, uint32_t in_tile_index, uint32_t idst) {
    UNPACK((llk_unpack_A<BroadcastType::NONE, true, binary_reuse_dest>(icb, in_tile_index)));
    MATH((llk_math_eltwise_binary<
          EltwiseBinaryType::ELWMUL,
          BroadcastType::NONE,
          fp32_dest_acc_en,
          MATH_FIDELITY,
          binary_reuse_dest>(icb, icb, idst, true /*clear_fp32_dst_acc*/)));
}

#endif  // ARCH_BLACKHOLE

}  // namespace ckernel
