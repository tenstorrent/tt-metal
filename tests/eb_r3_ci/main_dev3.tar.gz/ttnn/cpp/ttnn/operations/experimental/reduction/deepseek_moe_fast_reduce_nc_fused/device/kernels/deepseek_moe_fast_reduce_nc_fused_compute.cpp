// SPDX-FileCopyrightText: © 2026 Tenstorrent USA, Inc.
//
// SPDX-License-Identifier: Apache-2.0

// Fused compute kernel: multiply-accumulate using hardware MAC.
//
// For each output tile we iterate over reduction_dim_size experts and sum:
//   dst0 += act_tile[e] * score_col[row_tile][e]   (hardware MAC with col-broadcast)
//
// The reader pre-loads one score tile per (row tile, expert) before signalling compute_scores: tile
// r * reduction_dim_size + e holds in column 0 the scores of token rows 32 * r .. 32 * r + 31 for expert e
// (broadcast to all columns).  An output tile at row tile r is scaled with the r-th group of score tiles.
// Score tiles are kept resident and accessed by index throughout the loop.
//
// Initialization:
//   compute_kernel_hw_startup + bcast_init<ELWMUL, COL> handle PACK + UNPACK + hw_configure.
//   We then override the MATH init with acc_to_dest=1 so that every
//   mul_tiles_bcast_cols call accumulates into dst rather than replacing it.
//
// After tile_regs_acquire(), dst0 is zero-initialized by hardware, so the
// first MAC (expert 0) correctly seeds the accumulator.

#include "api/compute/bcast.h"
#include "api/dataflow/circular_buffer.h"

using namespace ckernel;

constexpr uint32_t num_output_tiles = get_compile_time_arg_val(0);
constexpr uint32_t reduction_dim_size = get_compile_time_arg_val(1);
constexpr uint32_t input_granularity = get_compile_time_arg_val(2);
constexpr uint32_t compute_input_cb_id_0 = get_compile_time_arg_val(3);
constexpr uint32_t compute_input_cb_id_1 = get_compile_time_arg_val(4);
constexpr uint32_t compute_output_cb_id = get_compile_time_arg_val(5);
// Output tile ids handled by this core: start_tile (runtime arg 0), then every num_cores-th tile.  A tile's row
// tile within its [.., tokens, hidden] slab is (tile_id / Wt) % Ht.
constexpr uint32_t num_cores_to_be_used = get_compile_time_arg_val(6);
constexpr uint32_t input_tensor_Wt = get_compile_time_arg_val(7);
constexpr uint32_t num_row_tiles = get_compile_time_arg_val(8);

void kernel_main() {
    CircularBuffer cb_in0(compute_input_cb_id_0);
    CircularBuffer cb_in1(compute_input_cb_id_1);
    CircularBuffer cb_out(compute_output_cb_id);

    constexpr uint32_t dst0 = 0;
    constexpr uint32_t one_tile = 1;
    constexpr uint32_t num_input_tiles_iter = reduction_dim_size / input_granularity;
    constexpr uint32_t num_score_tiles = num_row_tiles * reduction_dim_size;

    // Full PACK + UNPACK + hw_configure init for ELWMUL + COL-broadcast
    compute_kernel_hw_startup(compute_input_cb_id_0, compute_input_cb_id_1, compute_output_cb_id);
    bcast_init<EltwiseBinaryType::ELWMUL, BroadcastType::COL>(compute_input_cb_id_0, compute_input_cb_id_1);

    // Override MATH init to enable acc_to_dest=1 (hardware accumulate mode)
    // This makes each mul_tiles_bcast_cols call do: dst0 += act * score  (MAC)
    MATH((llk_math_eltwise_binary_init<EltwiseBinaryType::ELWMUL, BroadcastType::COL, MATH_FIDELITY>(
        compute_input_cb_id_0, compute_input_cb_id_1, 1 /*acc_to_dest*/)));

    reconfig_data_format(compute_input_cb_id_0, compute_input_cb_id_1);

    // Wait for all score tiles — they are pre-loaded once by the reader prologue
    // and remain resident for the entire kernel invocation.
    cb_in1.wait_front(num_score_tiles);
    uint32_t tile_id = get_arg_val<uint32_t>(0);  // this core's first output tile id
    for (uint32_t i = 0; i < num_output_tiles; ++i) {
        const uint32_t row_tile = (tile_id / input_tensor_Wt) % num_row_tiles;
        const uint32_t score_tile_base = row_tile * reduction_dim_size;
        tile_regs_acquire();

        for (uint32_t j = 0; j < num_input_tiles_iter; ++j) {
            cb_in0.wait_front(input_granularity);

            for (uint32_t k = 0; k < input_granularity; ++k) {
                // expert_tile = linear expert index for this tile
                const uint32_t expert_tile = j * input_granularity + k;
                // dst0 += act_tile[k] * score_col[row_tile][expert_tile]  (single MAC)
                mul_tiles_bcast_cols(
                    compute_input_cb_id_0, compute_input_cb_id_1, k, score_tile_base + expert_tile, dst0);
            }
            cb_in0.pop_front(input_granularity);
        }

        tile_regs_commit();
        cb_out.reserve_back(one_tile);
        pack_reconfig_data_format(compute_output_cb_id);
        tile_regs_wait();
        pack_tile(dst0, compute_output_cb_id);
        tile_regs_release();
        cb_out.push_back(one_tile);
        tile_id += num_cores_to_be_used;
    }

    // Release all score tiles
    cb_in1.pop_front(num_score_tiles);
}
