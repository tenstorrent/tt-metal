// SPDX-FileCopyrightText: © 2023 Tenstorrent USA, Inc.
//
// SPDX-License-Identifier: Apache-2.0

// Implemented based on bmm.cpp
#include <cstdint>
#include "api/compute/matmul.h"
#include "api/compute/compute_kernel_hw_startup.h"
#include "api/compute/transpose.h"
#include "ttnn/kernel/compute/moreh_common.hpp"
#include "api/dataflow/dataflow_buffer.h"
#include "experimental/kernel_args.h"

////////////////////
// global variables
////////////////////
constexpr std::int32_t MAX_NUM_DIMENSIONS = 8;
constexpr std::uint32_t onetile = 1;
constexpr std::uint32_t num_mask_tiles = 3;
constexpr std::uint32_t MASK_TILE_H_IDX = 0;
constexpr std::uint32_t MASK_TILE_W_IDX = 1;
constexpr std::uint32_t MASK_TILE_HW_IDX = 2;
constexpr std::uint32_t cb_in0 = dfb::in0;
constexpr std::uint32_t cb_in1 = dfb::in1;
constexpr std::uint32_t cb_in2 = dfb::in2;
constexpr std::uint32_t cb_in3 = dfb::in3;
constexpr std::uint32_t bias_cb_id = dfb::in4;
constexpr std::uint32_t cb_out0 = dfb::out0;
constexpr std::uint32_t cb_intermed0 = dfb::im0;
constexpr std::uint32_t cb_intermed1 = dfb::im1;
constexpr std::uint32_t cb_intermed2 = dfb::im2;
constexpr std::uint32_t cb_intermed3 = dfb::im3;

////////////////////
// inline functions
////////////////////
FORCE_INLINE void unravel_output_tidx(
    std::uint32_t output_tidx, std::uint32_t* output_idxes, std::uint32_t* output_stride) {
    for (std::int32_t i = MAX_NUM_DIMENSIONS - 1; i >= 0; --i) {
        std::uint32_t dim = output_tidx / output_stride[i];
        output_idxes[i] = dim;
        output_tidx -= (output_idxes[i] * output_stride[i]);
    }
}

// TODO: move it to moreh_common.hpp if more use cases.
FORCE_INLINE void transpose_tile_to_cb(
    std::uint32_t icb, std::uint32_t ocb, std::uint32_t itile = 0, std::uint32_t idst = 0) {
    DataflowBuffer ocb_obj(ocb);
#if defined FP32_DEST_ACC_EN
    reconfig_data_format_srca(icb);
#endif
    transpose_init(icb);
    tile_regs_acquire();
    transpose_tile(icb, itile, idst);
    tile_regs_commit();
    ocb_obj.reserve_back(onetile);
    tile_regs_wait();
#if defined FP32_DEST_ACC_EN
    pack_reconfig_data_format(ocb);
#endif
    pack_tile(idst, ocb);
    tile_regs_release();
    ocb_obj.push_back(onetile);
}

FORCE_INLINE void transpose_src_tile(std::uint32_t& mm_src, bool transpose, bool need_mask, bool is_input) {
    if (!transpose) {
        return;
    }

    if (need_mask) {
        DataflowBuffer mm_src_obj(mm_src);
        mm_src_obj.wait_front(onetile);
        transpose_tile_to_cb(mm_src, mm_src);
        mm_src_obj.pop_front(onetile);
    } else {
        std::uint32_t trans_src = (is_input) ? (cb_in0) : (cb_in1);
        mm_src = (is_input) ? (cb_intermed1) : (cb_intermed2);
        transpose_tile_to_cb(trans_src, mm_src);
    }
}

FORCE_INLINE void pack_onetile_to_cb(std::uint32_t ocb = dfb::out0, std::uint32_t idst = 0) {
    DataflowBuffer ocb_obj(ocb);
    ocb_obj.reserve_back(onetile);
    tile_regs_wait();
#if defined FP32_DEST_ACC_EN
    pack_reconfig_data_format(ocb);
#endif
    pack_tile(idst, ocb);
    tile_regs_release();
    ocb_obj.push_back(onetile);
}

FORCE_INLINE void mask_tile_to_cb(
    std::uint32_t& mm_src,
    bool& need_mask,
    bool need_mask_h,
    bool need_mask_w,
    bool last_out,
    bool last_line,
    bool transpose,
    bool is_input) {
    bool need_mask_last_line_and_out = (last_line && last_out);
    bool need_mask_last_line = false;
    bool need_mask_last_out = false;

    if (!(need_mask_w || need_mask_h)) {
        return;
    }

    if (is_input) {
        need_mask_last_line = last_line && ((transpose) ? (need_mask_w) : (need_mask_h));
        need_mask_last_out = last_out && ((transpose) ? (need_mask_h) : (need_mask_w));
    } else {
        need_mask_last_line = last_line && ((transpose) ? (need_mask_h) : (need_mask_w));
        need_mask_last_out = last_out && ((transpose) ? (need_mask_w) : (need_mask_h));
    }

    if (need_mask_last_line_and_out || need_mask_last_line || need_mask_last_out) {
        std::uint32_t cb_in = (is_input) ? (cb_in0) : (cb_in1);
        std::uint32_t cb_mask = (is_input) ? (cb_in2) : (cb_in3);
        std::uint32_t cb_intermed = (is_input) ? (cb_intermed1) : (cb_intermed2);
        std::uint32_t mask_tidx = MASK_TILE_H_IDX;
        if (need_mask_last_line_and_out) {
            mask_tidx = MASK_TILE_HW_IDX;
        } else if (need_mask_last_line) {
            if (is_input) {
                mask_tidx = (transpose) ? (MASK_TILE_W_IDX) : (MASK_TILE_H_IDX);
            } else {
                mask_tidx = (transpose) ? (MASK_TILE_H_IDX) : (MASK_TILE_W_IDX);
            }
        } else {
            if (is_input) {
                mask_tidx = (transpose) ? (MASK_TILE_H_IDX) : (MASK_TILE_W_IDX);
            } else {
                mask_tidx = (transpose) ? (MASK_TILE_W_IDX) : (MASK_TILE_H_IDX);
            }
        }

        // mul input tile with mask tile
        tile_regs_acquire();
#if defined FP32_DEST_ACC_EN
        reconfig_data_format(cb_in0, cb_mask);
#endif
        mul_init(cb_in, cb_mask);
        mul_tiles(cb_in, cb_mask, 0, mask_tidx, 0);
        tile_regs_commit();

        pack_onetile_to_cb(cb_intermed);
        mm_src = cb_intermed;
        need_mask = true;
    }
}

#ifdef FUSE_BIAS
template <bool is_scalar_bias>
FORCE_INLINE void bias_add() {
    DataflowBuffer dfb_intermed3_obj(cb_intermed3);
    DataflowBuffer bias_cb_id_obj(bias_cb_id);
    pack_onetile_to_cb(cb_intermed3);
    dfb_intermed3_obj.wait_front(onetile);
    bias_cb_id_obj.wait_front(onetile);
    tile_regs_acquire();
    if (is_scalar_bias) {
#if defined FP32_DEST_ACC_EN
        reconfig_data_format(cb_intermed3, bias_cb_id);
#endif
        add_bcast_scalar_init(cb_intermed3, bias_cb_id);
        add_tiles_bcast_scalar(cb_intermed3, bias_cb_id, 0, 0, 0);
    } else {
#if defined FP32_DEST_ACC_EN
        reconfig_data_format(cb_intermed3, bias_cb_id);
#endif
        add_bcast_rows_init(cb_intermed3, bias_cb_id);
        add_tiles_bcast_rows(cb_intermed3, bias_cb_id, 0, 0, 0);
    }
    tile_regs_commit();

    dfb_intermed3_obj.pop_front(onetile);
    if constexpr (!is_scalar_bias) {
        bias_cb_id_obj.pop_front(onetile);
    }
}
#endif

template <bool is_scalar_bias>
FORCE_INLINE void matmul_with_transpose_and_mask(
    std::uint32_t output_tidx,
    std::uint32_t num_output_tiles,
    std::uint32_t Kt,
    bool transpose_input,
    bool transpose_other,
    bool need_input_mask_h,
    bool need_input_mask_w,
    std::uint32_t* output_stride,
    std::uint32_t Mt,
    std::uint32_t Nt,
    bool need_other_mask_h,
    bool need_other_mask_w) {
    DataflowBuffer dfb_in0_obj(cb_in0);
    DataflowBuffer dfb_in1_obj(cb_in1);
    DataflowBuffer dfb_in2_obj(cb_in2);
    DataflowBuffer dfb_in3_obj(cb_in3);
    DataflowBuffer dfb_intermed0_obj(cb_intermed0);
    // TODO: checking required when the input cb format and intermediate cb format are different.
    matmul_init(cb_in0, cb_in1);
    if (transpose_input || transpose_other) {
        transpose_init(cb_in0);
    }

    if (need_input_mask_h || need_input_mask_w) {
        dfb_in2_obj.wait_front(num_mask_tiles);
    }

    if (need_other_mask_h || need_other_mask_w) {
        dfb_in3_obj.wait_front(num_mask_tiles);
    }

#pragma GCC unroll 0
    for (std::uint32_t i = 0; i < num_output_tiles; ++i) {
        bool spill = Kt > 1;
        bool enable_reload = false;

        // get row and column positions of input and other based on output tile indexes.
        std::uint32_t output_idxes[MAX_NUM_DIMENSIONS];
        unravel_output_tidx(output_tidx, output_idxes, output_stride);
        bool input_last_row = (output_idxes[1] == Mt - 1) ? (true) : (false);
        bool other_last_col = (output_idxes[0] == Nt - 1) ? (true) : (false);

#pragma GCC unroll 0
        for (std::uint32_t kt = 0; kt < Kt; kt++) {
            bool last_out = kt == (Kt - 1);
            bool need_input_mask = false;
            bool need_other_mask = false;

            std::uint32_t mm_src0 = cb_in0;
            std::uint32_t mm_src1 = cb_in0;

            dfb_in0_obj.wait_front(onetile);
            dfb_in1_obj.wait_front(onetile);

            mm_src0 = cb_in0;
            mm_src1 = cb_in1;

            ////////////////////
            // mask: the first two arguments (mm_src0, need_input_mask) are passed by reference.
            // transpose: the first argument (mm_src0) is passed by reference.
            ////////////////////
            mask_tile_to_cb(
                mm_src0,
                need_input_mask,
                need_input_mask_h,
                need_input_mask_w,
                last_out,
                input_last_row,
                transpose_input,
                true);
            transpose_src_tile(mm_src0, transpose_input, need_input_mask, true);

            mask_tile_to_cb(
                mm_src1,
                need_other_mask,
                need_other_mask_h,
                need_other_mask_w,
                last_out,
                other_last_col,
                transpose_other,
                false);
            transpose_src_tile(mm_src1, transpose_other, need_other_mask, false);

            ////////////////////
            // matmul
            ////////////////////
            tile_regs_acquire();
            if (enable_reload) {
                dfb_intermed0_obj.wait_front(onetile);
#if defined FP32_DEST_ACC_EN
                reconfig_data_format_srca(cb_intermed0);
#endif
                copy_init(cb_intermed0);
                copy_tile(cb_intermed0, 0, 0);
                dfb_intermed0_obj.pop_front(onetile);
            }

            DataflowBuffer mm_src0_obj(mm_src0);
            DataflowBuffer mm_src1_obj(mm_src1);
            if (transpose_input || need_input_mask) {
                mm_src0_obj.wait_front(onetile);
            }

            if (transpose_other || need_other_mask) {
                mm_src1_obj.wait_front(onetile);
            }

#if defined FP32_DEST_ACC_EN
            reconfig_data_format(mm_src0, mm_src1);
#endif
            matmul_init(mm_src0, mm_src1);
            matmul_tiles(mm_src0, mm_src1, 0, 0, 0);
            tile_regs_commit();

            dfb_in0_obj.pop_front(onetile);
            dfb_in1_obj.pop_front(onetile);

            if (transpose_input || need_input_mask) {
                mm_src0_obj.pop_front(onetile);
            }
            if (transpose_other || need_other_mask) {
                mm_src1_obj.pop_front(onetile);
            }

            if (last_out) {
////////////////////
// bias add
////////////////////
#ifdef FUSE_BIAS
                bias_add<is_scalar_bias>();
#endif
                pack_onetile_to_cb(cb_out0);
            } else {
                pack_onetile_to_cb(cb_intermed0);
            }

            if (spill) {
                enable_reload = true;
            }
        }
        output_tidx++;
    }
}

FORCE_INLINE void matmul(std::uint32_t num_output_tiles, std::uint32_t Kt) {
    DataflowBuffer dfb_in0_obj(cb_in0);
    DataflowBuffer dfb_in1_obj(cb_in1);
    matmul_init(cb_in0, cb_in1);
    for (std::uint32_t i = 0; i < num_output_tiles; ++i) {
        tile_regs_acquire();
        for (std::uint32_t kt = 0; kt < Kt; kt++) {
            dfb_in0_obj.wait_front(onetile);
            dfb_in1_obj.wait_front(onetile);
            matmul_tiles(cb_in0, cb_in1, 0, 0, 0);
            dfb_in0_obj.pop_front(onetile);
            dfb_in1_obj.pop_front(onetile);
        }
        tile_regs_commit();
        pack_onetile_to_cb(cb_out0);
    }
}

void kernel_main() {
    // compile-time args
    constexpr std::uint32_t num_output_tiles = get_arg(args::num_output_tiles);
    constexpr std::uint32_t Mt = get_arg(args::Mt);
    constexpr std::uint32_t Nt = get_arg(args::Nt);
    constexpr std::uint32_t Kt = get_arg(args::Kt);
    constexpr bool transpose_input = (get_arg(args::transpose_input) == 1);
    constexpr bool transpose_other = (get_arg(args::transpose_other) == 1);
    constexpr std::uint32_t input_mask_h = get_arg(args::input_mask_h);
    constexpr std::uint32_t input_mask_w = get_arg(args::input_mask_w);
    constexpr std::uint32_t other_mask_h = get_arg(args::other_mask_h);
    constexpr std::uint32_t other_mask_w = get_arg(args::other_mask_w);
#ifdef FUSE_BIAS
    constexpr bool is_scalar_bias = (get_arg(args::is_scalar_bias) == 1);
    constexpr bool need_bias_add = true;
#else
    constexpr bool is_scalar_bias = false;
    constexpr bool need_bias_add = false;
#endif
    constexpr bool need_input_mask_h = (input_mask_h != 32);
    constexpr bool need_input_mask_w = (input_mask_w != 32);
    constexpr bool need_other_mask_h = (other_mask_h != 32);
    constexpr bool need_other_mask_w = (other_mask_w != 32);
    constexpr bool need_mask = (need_input_mask_h || need_input_mask_w || need_other_mask_h || need_other_mask_w);
    constexpr bool need_transpose = (transpose_input || transpose_other);

    // runtime args
    std::uint32_t output_tile_start_idx = get_arg(args::output_tile_start_idx);
    // output_stride is a homogeneous, index-addressed collection -> runtime varargs.
    std::uint32_t output_stride[MAX_NUM_DIMENSIONS];
    for (std::int32_t i = 0; i < MAX_NUM_DIMENSIONS; ++i) {
        output_stride[i] = get_vararg(i);
    }

    compute_kernel_hw_startup<SrcOrder::Reverse>(cb_in0, cb_in1, cb_out0);

    if (need_transpose || need_mask || need_bias_add) {
        matmul_with_transpose_and_mask<is_scalar_bias>(
            output_tile_start_idx,
            num_output_tiles,
            Kt,
            transpose_input,
            transpose_other,
            need_input_mask_h,
            need_input_mask_w,
            output_stride,
            Mt,
            Nt,
            need_other_mask_h,
            need_other_mask_w);
    } else {
        matmul(num_output_tiles, Kt);
    }
}
