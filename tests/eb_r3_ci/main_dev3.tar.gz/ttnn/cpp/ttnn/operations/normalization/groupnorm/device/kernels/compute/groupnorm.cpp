// SPDX-FileCopyrightText: © 2023 Tenstorrent USA, Inc.
//
// SPDX-License-Identifier: Apache-2.0

#include <cstdint>

#define BCAST_LLKOP EltwiseBinaryType::ELWMUL
#define BCAST_DIM BroadcastType::COL

#include "api/compute/reduce.h"
#include "api/compute/bcast.h"
#include "api/compute/eltwise_binary.h"
#include "api/compute/eltwise_unary/fill.h"
#include "api/compute/layernorm.h"
#include "api/compute/tile_move_copy.h"
#include "api/compute/tilize.h"
#include "api/compute/matmul.h"
#include "ttnn/cpp/ttnn/kernel_lib/tilize_helpers.hpp"
#include "ttnn/cpp/ttnn/kernel_lib/untilize_helpers.hpp"
#include "ttnn/cpp/ttnn/kernel_lib/reduce_helpers_compute.hpp"
#include "ttnn/cpp/ttnn/kernel_lib/eltwise/api/chain.hpp"
#include "ttnn/cpp/ttnn/kernel_lib/eltwise/api/convenience.hpp"
#include "ttnn/cpp/ttnn/kernel_lib/eltwise/unary/math.hpp"
#include "ttnn/cpp/ttnn/operations/normalization/groupnorm/device/kernels/groupnorm_constants.hpp"
#include "api/dataflow/dataflow_buffer.h"

namespace ckl = compute_kernel_lib;

template <uint32_t input_id, uint32_t scaler_id, uint32_t output_id>
ALWI void reduce_partial_statistics(uint32_t rows, uint32_t cols) {
    if (rows == 0) {
        // The reader gathers one partial per scheduled block, even for an empty tail.
        // Publish the sum identity without asking the reduction helper to read zero rows.
        DataflowBuffer output(output_id);
        output.reserve_back(1);
        fill_tile_init();
        tile_regs_acquire();
        fill_tile(0, 0.0f);
        tile_regs_commit();
        tile_regs_wait();
        pack_tile(0, output_id);
        tile_regs_release();
        output.push_back(1);
    } else {
        ckl::reduce<
            PoolType::SUM,
            ReduceDim::REDUCE_SCALAR,
            input_id,
            scaler_id,
            output_id,
            ckl::ReduceInputPolicy::NoWaitNoPop,
            ckl::ReduceDataFormatReconfigMode::NONE>(ckl::ReduceInputBlockShape::of(rows, cols));
    }
}

void kernel_main() {
    // clang-format off
    // Definitions
    //   block_h: This the length of the row we wish to processes in terms of tiles
    //
    //   out_block_...: This is the length of our Circular Buffer, sometimes the length of out tensors(block_h) are larger than L1 space, so we
    //   have to process chunks of this data at a time
    //   this chunk is called an out_block
    //
    //   num_out_blocks: This is the number of chunks specified by the use, such that a CBs (length defined by out_block) fit in L1
    //   (Users should minimize the number of num_out_blocks for better perf)
    //
    //   ...normal:  If num_out_blocks evenly divides block_h, then all chunks are the size normal
    //
    //   ...last: If num_out_blocks does not divides block_h, the leftovers are put into a chunk of length last
    //
    //   sender: This refers to a core that does aggregation calculations
    //   for the group of cores
    //
    //   receiver: This the cores that receive the aggregated results from sender, they only do
    //   local computations that they send to the sender for final aggregation
    //
    // This is a high level description of the stages of this kernel, tags will be added to show where in the code each
    // stage starts and ends
    //
    // Batch Loop:
    //   Group Loop:
    //     This is the process which repeats for every group
    //     Average Calc: E[x]
    //       Local Reduce:
    //           First we apply an input mask
    //           This is where we sum up our core's subtensor
    //           After summing up, we pass our scalar tile to cb_ex_partial_id
    //           The reader kernels then aggregate all of the local scalars into a single tile
    //       Global Reduce:
    //           This single tile (cb_ex_external_id) is a tile that contains each partial reduce from all the other cores
    //           Only the core designated as the sender reduces this tile to produce the global scalar reduce value.
    //           The reader core then sends this data out to all other cores as cb_ex_global_id
    //
    //     Variance Calc: ∑(x-E[x])^2
    //     This follows the same pattern as the average calculation
    //       Local Reduce:
    //           First we subtract each value from our core's subtensor by the average value
    //           We next apply our input mask to zero our the values we wish to ignore
    //           Next we square our residuals to obtain the squared residuals
    //           After summing up, we pass our scalar tile to cb_ex2_partial_id
    //           The reader kernels then aggregate all of the local scalars into a single tile
    //       Global Reduce:
    //           This single tile (cb_ex_external_id) is a tile that contains each partial reduce from all the other cores
    //           Only the core designated as the sender reduces this tile to produce the global scalar reduce value.
    //           The reader core then sends this data out to all other cores as cb_ex2_global_id
    //
    //     cb_ex2pe_id Calculation:
    //       First we add cb_ex2_global_id with cb_eps_id
    //       Then we take the sqrt
    //       Lastly we take the reciprocal and he have the denominator of our calculation
    //     Final Val Calc:
    //       First we subtract each value from our core's subtensor by the average value
    //       We next apply our input mask to zero our the values we wish to ignore
    //       Next we multiply our residual with our denominator
    //       Optional Gamma:
    //           We multiply this value to gamma
    //       Optional Beta:
    //           We add beta to this value
    //
    // We are now done! Nice
    //   To look at where the code starts and stops search for
    //   Start LABEL or End Label
    //   Ex: Start Local Reduce or End Local Reduce
    // clang-format on
    constexpr bool is_mcast_sender = get_named_compile_time_arg_val("is_mcast_sender") == 1;
    constexpr bool do_gamma = get_named_compile_time_arg_val("do_gamma") == 1;
    constexpr bool do_beta = get_named_compile_time_arg_val("do_beta") == 1;
    constexpr std::uint32_t num_cores_per_mcast_group = get_named_compile_time_arg_val("num_cores_per_mcast_group");
    // True when a reconfig-relevant operand is fp32: the per-group reconfig_data_format calls below
    // are then required. All-bf16 compiles them out (no-ops). See program factory.
    constexpr bool enable_fp32_reconfig = get_named_compile_time_arg_val("enable_fp32_reconfig") != 0;

    constexpr std::uint32_t batch = get_named_compile_time_arg_val("batch");
    constexpr std::uint32_t group = get_named_compile_time_arg_val("group");

    constexpr std::uint32_t block_h = get_named_compile_time_arg_val("block_h");
    constexpr std::uint32_t block_w = get_named_compile_time_arg_val("block_w");
    constexpr std::uint32_t block_hw = get_named_compile_time_arg_val("block_hw");

    constexpr std::uint32_t subblock_w = get_named_compile_time_arg_val("subblock_w");
    constexpr std::uint32_t num_subblocks_w = get_named_compile_time_arg_val("num_subblocks_w");

    constexpr std::uint32_t per_core_M = get_named_compile_time_arg_val("per_core_M");
    constexpr std::uint32_t per_core_N = get_named_compile_time_arg_val("per_core_N");
    constexpr std::uint32_t per_core_MN = get_named_compile_time_arg_val("per_core_MN");

    constexpr std::uint32_t per_core_N_tile_bytes = get_named_compile_time_arg_val("per_core_N_tile_bytes");
    constexpr std::uint32_t num_groups_per_reset = get_named_compile_time_arg_val("num_groups_per_reset");

    constexpr std::uint32_t single_tile_size_bytes = get_named_compile_time_arg_val("single_tile_size_bytes");

    constexpr std::uint32_t num_tiles_input_mask = get_named_compile_time_arg_val("num_tiles_input_mask");
    constexpr std::uint32_t num_cols_per_group = get_named_compile_time_arg_val("num_cols_per_group");

    constexpr std::uint32_t block_w_last = get_named_compile_time_arg_val("block_w_last");
    constexpr bool GROUP_SIZE_IS_POWER_OF_2 = get_named_compile_time_arg_val("GROUP_SIZE_IS_POWER_OF_2") == 1;
    constexpr bool GROUP_SIZE_SMALLER_THAN_TILE_W =
        get_named_compile_time_arg_val("GROUP_SIZE_SMALLER_THAN_TILE_W") == 1;
    constexpr std::uint32_t group_row_offset = get_named_compile_time_arg_val("group_row_offset");
    constexpr std::uint32_t num_out_blocks = get_named_compile_time_arg_val("num_out_blocks");
    constexpr std::uint32_t tile_width = get_named_compile_time_arg_val("TILE_WIDTH");

    // Non-tile-aligned H*W: the tile-padding rows are excluded from both accumulation passes by
    // switching to a second, row-masked set of mask tiles on the batch's final row-tile. The writer
    // gives cores that do not hold that row-tile a copy of the normal set, so the switch here is
    // unconditional. The divisor is corrected separately, in the reduce scaler.
    // logical_hw / padded_hw are carried only so two shapes padding to the same size cannot share a
    // cached program; has_row_mask is what this kernel branches on.
    constexpr std::uint32_t logical_hw [[maybe_unused]] = get_named_compile_time_arg_val("logical_hw");
    constexpr std::uint32_t padded_hw [[maybe_unused]] = get_named_compile_time_arg_val("padded_hw");
    constexpr bool has_row_mask = get_named_compile_time_arg_val("has_row_mask") == 1;
    constexpr std::uint32_t mask_tiles_per_group = has_row_mask ? 2 * block_w : block_w;
    constexpr std::uint32_t last_row_tile = block_h - 1;

    constexpr std::uint32_t block_w_minus_one = block_w - 1;
    constexpr std::uint32_t block_w_minus_two = block_w - 2;
    constexpr std::uint32_t tile_w_minux_group_size = tile_width - num_cols_per_group;

    // dst regs
    constexpr std::uint32_t dst0 = 0;
    constexpr std::uint32_t scaler0 = 0;

    // input cbs
    constexpr std::uint32_t dfb_in0_id = tt::CBIndex::c_0;
    constexpr std::uint32_t dfb_in_id = tt::CBIndex::c_29;
#ifdef TILIZE_IN
    // Holds the whole per-core group, tilized once and kept in L1 for all three passes.
    constexpr std::uint32_t dfb_in_resident_id = tt::CBIndex::c_17;
#endif
    constexpr std::uint32_t dfb_scaler_id = tt::CBIndex::c_2;
    constexpr std::uint32_t dfb_scaler_global_id = tt::CBIndex::c_4;
    constexpr std::uint32_t dfb_eps_id = tt::CBIndex::c_3;
    constexpr std::uint32_t dfb_gamma_id = tt::CBIndex::c_5;
    constexpr std::uint32_t dfb_beta_id = tt::CBIndex::c_6;
    constexpr std::uint32_t dfb_input_mask_id = tt::CBIndex::c_28;

    // interm cbs
    constexpr std::uint32_t dfb_repack_id = tt::CBIndex::c_26;
    constexpr std::uint32_t dfb_repack_out_id = tt::CBIndex::c_31;
    constexpr std::uint32_t dfb_x_id = tt::CBIndex::c_24;
    constexpr std::uint32_t dfb_xmm_id = tt::CBIndex::c_25;
    constexpr std::uint32_t dfb_ex_partial_id = tt::CBIndex::c_8;
    constexpr std::uint32_t dfb_ex2_partial_id = tt::CBIndex::c_21;
    constexpr std::uint32_t dfb_ex_id = tt::CBIndex::c_9;
    constexpr std::uint32_t dfb_ex2_id = tt::CBIndex::c_13;
    constexpr std::uint32_t dfb_ex_external_id = tt::CBIndex::c_10;
    constexpr std::uint32_t dfb_ex_global_id = tt::CBIndex::c_15;
    constexpr std::uint32_t dfb_ex2_global_id = tt::CBIndex::c_14;
    constexpr std::uint32_t dfb_ex2pe_id = tt::CBIndex::c_27;

    // interm cbs reuse
    constexpr std::uint32_t dfb_fusion_id = dfb_xmm_id;
    constexpr std::uint32_t dfb_reread_out_id = tt::CBIndex::c_23;
    constexpr std::uint32_t dfb_reread_write_out_id = tt::CBIndex::c_22;
#ifdef UNTILIZE_OUT
    // Scratch for the row-major output reread; tilized into c_23 below.
    constexpr std::uint32_t dfb_reread_rm_id = tt::CBIndex::c_20;
#endif

    // output cb
    constexpr std::uint32_t dfb_out0_id = tt::CBIndex::c_16;
#ifdef UNTILIZE_OUT
    constexpr std::uint32_t dfb_out_id = tt::CBIndex::c_30;
#else
    constexpr std::uint32_t dfb_out_id = (do_gamma or do_beta) ? dfb_out0_id : dfb_reread_write_out_id;
#endif

    // tile offset
    const std::uint32_t index_w_offset = 0;
    std::uint32_t index_g_offset = 0;
    std::uint32_t row_offset = num_cols_per_group;
    // data offset
    const std::uint32_t num_datum_per_row_offeset = 0;
    // inplace out cbs
    bool copy_or_add = true;
    std::uint32_t group_reset_index = 0;
    std::uint32_t index_block_w = 0;
    // tile offset
    std::uint32_t index_subblock_w_offset = 0;
    std::uint32_t index_h_offset = 0;
    bool apply_gamma_beta[block_w];
    constexpr std::uint32_t data_per_core_N_per_group = (per_core_N * tile_width / group);

    constexpr int dfb_outgamma_id = do_beta ? dfb_in_id : dfb_out0_id;
    constexpr int dfb_inbeta_id = do_gamma ? dfb_outgamma_id : dfb_reread_write_out_id;
    constexpr int dfb_outbeta_id = dfb_out0_id;
#ifdef UNTILIZE_OUT
    // Untilize the tiled result into the row-major output c_30.
    constexpr int dfb_untilize_in_id = (do_gamma or do_beta) ? dfb_out0_id : dfb_reread_write_out_id;
    constexpr int dfb_untilize_out_id =
#ifdef READER_REPACK
        dfb_repack_out_id;
#else
        dfb_out_id;
#endif
#endif

    DataflowBuffer dfb_beta(dfb_beta_id);
    DataflowBuffer dfb_eps(dfb_eps_id);
    DataflowBuffer dfb_ex(dfb_ex_id);
    DataflowBuffer dfb_ex2(dfb_ex2_id);
    DataflowBuffer dfb_ex2pe(dfb_ex2pe_id);
    DataflowBuffer dfb_ex_global(dfb_ex_global_id);
    DataflowBuffer dfb_ex_partial(dfb_ex_partial_id);
    DataflowBuffer dfb_gamma(dfb_gamma_id);
#ifdef TILIZE_IN
    DataflowBuffer dfb_in_resident(dfb_in_resident_id);
#endif
    DataflowBuffer dfb_in0(dfb_in0_id);
    DataflowBuffer dfb_inbeta(dfb_inbeta_id);
    DataflowBuffer dfb_input_mask(dfb_input_mask_id);
    DataflowBuffer dfb_outbeta(dfb_outbeta_id);
    DataflowBuffer dfb_outgamma(dfb_outgamma_id);
    DataflowBuffer dfb_reread_out(dfb_reread_out_id);
    DataflowBuffer dfb_reread_write_out(dfb_reread_write_out_id);
    DataflowBuffer dfb_x(dfb_x_id);
    DataflowBuffer dfb_xmm(dfb_xmm_id);

#ifdef TILIZE_IN
#ifdef READER_REPACK
    constexpr std::uint32_t dfb_in_rm_id = dfb_repack_id;
#else
    constexpr std::uint32_t dfb_in_rm_id = dfb_in0_id;
#endif
    // Tilize the whole group once and reuse it for all three passes.
    compute_kernel_hw_startup(dfb_in0_id, dfb_in0_id, dfb_in_resident_id);
    constexpr std::uint32_t dfb_input_id = dfb_in_resident_id;
#else
    // Already tiled, so feed compute directly.
    compute_kernel_hw_startup(dfb_in0_id, dfb_input_mask_id, dfb_x_id);
    constexpr std::uint32_t dfb_input_id = dfb_in0_id;
#endif
    constexpr auto input_strided_block_input = ckl::input(
        dfb_input_id,
        ckl::WaitPolicy::None,
        ckl::PopPolicy::None,
        ckl::InputTileMapping::Block,
        ckl::DataFormatReconfig::Disabled,
        ckl::TileAddressing::Strided);
    constexpr auto xmm_strided_col_input = ckl::input(
        dfb_xmm_id,
        ckl::WaitPolicy::None,
        ckl::PopPolicy::None,
        ckl::InputTileMapping::Col,
        ckl::DataFormatReconfig::Disabled,
        ckl::TileAddressing::Strided);
    constexpr auto reread_out_strided_col_input = ckl::input(
        dfb_reread_out_id,
        ckl::WaitPolicy::None,
        ckl::PopPolicy::None,
        ckl::InputTileMapping::Col,
        ckl::DataFormatReconfig::Disabled,
        ckl::TileAddressing::Strided);
    constexpr auto reread_write_out_strided_col_input = ckl::input(
        dfb_reread_write_out_id,
        ckl::WaitPolicy::None,
        ckl::PopPolicy::None,
        ckl::InputTileMapping::Col,
        ckl::DataFormatReconfig::Disabled,
        ckl::TileAddressing::Strided);
    constexpr auto inbeta_strided_col_input = ckl::input(
        dfb_inbeta_id,
        ckl::WaitPolicy::None,
        ckl::PopPolicy::None,
        ckl::InputTileMapping::Col,
        ckl::DataFormatReconfig::Disabled,
        ckl::TileAddressing::Strided);
    constexpr auto gamma_scalar_offset_input = ckl::input(
        dfb_gamma_id,
        ckl::WaitPolicy::None,
        ckl::PopPolicy::None,
        ckl::InputTileMapping::Scalar,
        ckl::DataFormatReconfig::Disabled,
        ckl::TileAddressing::Offset);
    constexpr auto beta_scalar_offset_input = ckl::input(
        dfb_beta_id,
        ckl::WaitPolicy::None,
        ckl::PopPolicy::None,
        ckl::InputTileMapping::Scalar,
        ckl::DataFormatReconfig::Disabled,
        ckl::TileAddressing::Offset);
    constexpr auto reread_write_out_strided_output = ckl::output(
        dfb_reread_write_out_id,
        ckl::ReservePolicy::None,
        ckl::PushPolicy::None,
        ckl::DataFormatReconfig::Disabled,
        ckl::TileAddressing::Strided);
    constexpr auto outgamma_strided_output = ckl::output(
        dfb_outgamma_id,
        ckl::ReservePolicy::None,
        ckl::PushPolicy::None,
        ckl::DataFormatReconfig::Disabled,
        ckl::TileAddressing::Strided);
    constexpr auto outbeta_strided_output = ckl::output(
        dfb_outbeta_id,
        ckl::ReservePolicy::None,
        ckl::PushPolicy::None,
        ckl::DataFormatReconfig::Disabled,
        ckl::TileAddressing::Strided);

    constexpr std::uint32_t out_block_h_normal = block_h / num_out_blocks;
    const std::uint32_t out_block_hw_normal = out_block_h_normal * block_w;
    std::uint32_t num_out_blocks_padded = num_out_blocks;
    bool extra_out_block = false;
    std::uint32_t out_block_h_last = out_block_h_normal;
    std::uint32_t out_block_hw_last = out_block_hw_normal;
    if constexpr (block_h % num_out_blocks != 0) {
        extra_out_block = true;
        const std::uint32_t residual = block_h - (num_out_blocks * out_block_h_normal);
        num_out_blocks_padded += (residual / out_block_h_normal + 1);
        out_block_h_last = residual % out_block_h_normal;
        out_block_hw_last = out_block_h_last * block_w;
    }
    std::uint32_t dfb_ex_external_tiles_required =
        num_out_blocks_padded * num_cores_per_mcast_group * dfb_ex_external_slot_pitch_bytes / single_tile_size_bytes;
    if (((num_out_blocks_padded * num_cores_per_mcast_group * dfb_ex_external_slot_pitch_bytes) %
         single_tile_size_bytes) != 0) {
        dfb_ex_external_tiles_required++;
    }

    // Start Batch Loop
    for (std::uint32_t b = 0; b < batch; ++b) {
        index_g_offset = 0;

        row_offset = num_cols_per_group;
        copy_or_add = true;
        group_reset_index = 0;
        index_block_w = 0;

        // Start Group Loop
        for (std::uint32_t g = 0; g < group; ++g) {
            // Start Average Calc
            // Start Local Reduce
            dfb_input_mask.wait_front(mask_tiles_per_group);
            for (uint32_t out_block_index = 0; out_block_index < num_out_blocks_padded; out_block_index++) {
                uint32_t out_block_h_actual;
                if (extra_out_block && (out_block_index == (num_out_blocks_padded - 1))) {
                    out_block_h_actual = out_block_h_last;
                } else {
                    out_block_h_actual = out_block_h_normal;
                }
#ifdef TILIZE_IN
                // Append this out-block; no pop, so the whole group stays available.
                compute_kernel_lib::tilize<
                    block_w,
                    dfb_in_rm_id,
                    dfb_in_resident_id,
                    compute_kernel_lib::tilize_config::InitUninitMode::InitAndUninit,
                    compute_kernel_lib::tilize_config::WaitMode::WaitBlock,
                    compute_kernel_lib::tilize_config::ReconfigureRegisterDatatypeMode::NoReconfigure>(
                    out_block_h_normal);
                dfb_in_resident.wait_front((out_block_index + 1) * out_block_hw_normal);
                std::uint32_t out_block_base = out_block_index * out_block_hw_normal;
#else
                dfb_in0.wait_front(static_cast<uint16_t>(out_block_hw_normal));
                constexpr std::uint32_t out_block_base = 0;
#endif

                index_h_offset = 0;
                // Row-tile index within the batch; derived from out_block_index because the final
                // out-block can be empty when num_out_blocks does not divide block_h.
                const std::uint32_t row_tile_base = out_block_index * out_block_h_normal;
                reconfig_data_format_srcb(dfb_in0_id, dfb_input_mask_id);
                // mask input
                // The row-masked set varies down the rows of a tile, so it can only be consumed by
                // a full-tile multiply. Row-0-only synthesis and the row broadcast are therefore
                // available exactly when there is no row mask, i.e. on tile-aligned H*W.
                if constexpr (has_row_mask) {
                    mul_init(dfb_input_id, dfb_input_mask_id);
                } else {
                    mul_bcast_rows_init(dfb_input_id, dfb_input_mask_id);
                }
                dfb_x.reserve_back(static_cast<uint16_t>(out_block_hw_normal));
                for (std::uint32_t i = 0; i < out_block_h_actual; ++i) {
                    // Row-masked set on the batch's final row-tile, so the padding contributes
                    // nothing to E[x]. if constexpr keeps tile-aligned codegen unchanged.
                    std::uint32_t mask_set_offset = 0;
                    if constexpr (has_row_mask) {
                        mask_set_offset = ((row_tile_base + i) == last_row_tile) ? block_w : 0;
                    }
                    index_subblock_w_offset = 0;
                    for (std::uint32_t j = 0; j < num_subblocks_w; ++j) {
                        tile_regs_acquire();
                        for (std::uint32_t w = 0; w < subblock_w; ++w) {
                            const std::uint32_t index = w + index_subblock_w_offset + index_h_offset + out_block_base;
                            if constexpr (has_row_mask) {
                                mul_tiles(
                                    dfb_input_id,
                                    dfb_input_mask_id,
                                    index,
                                    w + index_subblock_w_offset + mask_set_offset,
                                    w);
                            } else {
                                mul_tiles_bcast_rows(
                                    dfb_input_id, dfb_input_mask_id, index, w + index_subblock_w_offset, w);
                            }
                        }
                        tile_regs_commit();
                        tile_regs_wait();
                        for (std::uint32_t dst_i = 0; dst_i < subblock_w; ++dst_i) {
                            pack_tile(dst_i, dfb_x_id);
                        }
                        tile_regs_release();
                        index_subblock_w_offset += subblock_w;
                    }
                    index_h_offset += block_w;
                }
                // Only the tiled path pops here; the row-major group stays resident.
#ifndef TILIZE_IN
                dfb_in0.pop_front(static_cast<uint16_t>(out_block_hw_normal));
#endif
                dfb_x.push_back(static_cast<uint16_t>(out_block_hw_normal));
                reconfig_data_format_srcb(dfb_input_mask_id, dfb_scaler_id);

                // Partial/E[x]
                dfb_x.wait_front(static_cast<uint16_t>(out_block_hw_normal));
                reduce_partial_statistics<dfb_x_id, dfb_scaler_id, dfb_ex_partial_id>(out_block_h_actual, block_w);
                dfb_x.pop_front(static_cast<uint16_t>(out_block_hw_normal));
            }
            // End Local Redcue
            // Start Global Reduce
            if constexpr (is_mcast_sender) {
                compute_kernel_lib::reduce<
                    PoolType::SUM,
                    ReduceDim::REDUCE_SCALAR,
                    dfb_ex_external_id,
                    dfb_scaler_global_id,
                    dfb_ex_global_id,
                    compute_kernel_lib::ReduceInputPolicy::WaitAndPopPerTile,
                    compute_kernel_lib::ReduceDataFormatReconfigMode::NONE>(
                    compute_kernel_lib::ReduceInputBlockShape::col(dfb_ex_external_tiles_required));
                if constexpr (num_cores_per_mcast_group > 1) {
                    dfb_ex.reserve_back(1);
                    dfb_ex.push_back(1);
                }
            }
            // End Global Reduce
            // End Average Calc

            // Start Variance Calc
            // Start Local Reduce
            for (uint32_t out_block_index = 0; out_block_index < num_out_blocks_padded; out_block_index++) {
                uint32_t out_block_h_actual;
                if (extra_out_block && (out_block_index == (num_out_blocks_padded - 1))) {
                    out_block_h_actual = out_block_h_last;
                } else {
                    out_block_h_actual = out_block_h_normal;
                }
                const std::uint32_t row_tile_base = out_block_index * out_block_h_normal;

                // The resident group is already there; only the tiled path waits on new rows.
#ifndef TILIZE_IN
                dfb_in0.wait_front(static_cast<uint16_t>(out_block_hw_normal));
#endif
                dfb_ex_global.wait_front(1);
                // fp32: reset both srcs so fp32 input/mean aren't read through the stale bf16 scaler format.
                // The reconfig has to precede the init: the init's LLK assert checks that the unpack config
                // registers already describe these operands. (The MOP is built from the init's static
                // arguments; the registers themselves are consumed later, by UNPACR.)
                if constexpr (enable_fp32_reconfig) {
                    reconfig_data_format_srca(dfb_input_id);
                    reconfig_data_format_srcb(dfb_ex_global_id);
                }
#ifdef TILIZE_IN
                ckl::eltwise_chain(
                    ckl::IterationShape::grid(out_block_h_actual, block_w).block_size(subblock_w),
                    ckl::BinaryFpu<
                        ckl::BinaryFpuOp::Sub,
                        input_strided_block_input,
                        ckl::input(
                            dfb_ex_global_id,
                            ckl::BroadcastDim::Scalar,
                            ckl::WaitPolicy::None,
                            ckl::PopPolicy::None,
                            ckl::DataFormatReconfig::Disabled)>{
                        ckl::StridedTileRange{out_block_index * out_block_hw_normal, block_w}},
                    ckl::PackTile<ckl::output(
                        dfb_xmm_id,
                        ckl::ReservePolicy::Upfront,
                        ckl::PushPolicy::AtEnd,
                        ckl::DataFormatReconfig::Disabled)>{});
#else
                ckl::sub<
                    ckl::input(
                        dfb_in0_id,
                        ckl::WaitPolicy::PerTile,
                        ckl::PopPolicy::PerTile,
                        ckl::DataFormatReconfig::Disabled),
                    ckl::input(
                        dfb_ex_global_id,
                        ckl::BroadcastDim::Scalar,
                        ckl::WaitPolicy::None,
                        ckl::PopPolicy::None,
                        ckl::DataFormatReconfig::Disabled),
                    ckl::output(
                        dfb_xmm_id,
                        ckl::ReservePolicy::Upfront,
                        ckl::PushPolicy::AtEnd,
                        ckl::DataFormatReconfig::Disabled)>(
                    ckl::IterationShape::grid(out_block_h_actual, block_w).block_size(subblock_w));
#endif
                if (extra_out_block && (out_block_index == (num_out_blocks_padded - 1))) {
#ifndef TILIZE_IN
                    dfb_in0.pop_front(static_cast<uint16_t>(out_block_hw_normal - out_block_hw_last));
#endif
                    dfb_xmm.reserve_back(out_block_hw_normal - out_block_hw_last);
                    dfb_xmm.push_back(out_block_hw_normal - out_block_hw_last);
                }

                // zero out the garbage values by mult mask again
                reconfig_data_format_srcb(dfb_ex_global_id, dfb_input_mask_id);
                if constexpr (has_row_mask) {
                    mul_init(dfb_xmm_id, dfb_input_mask_id);
                } else {
                    mul_bcast_rows_init(dfb_xmm_id, dfb_input_mask_id);
                }
                dfb_x.reserve_back(static_cast<uint16_t>(out_block_hw_normal));
                dfb_xmm.wait_front(static_cast<uint16_t>(out_block_hw_normal));
                for (std::uint32_t i = 0; i < out_block_h_actual; i++) {
                    // Same switch as pass 1; otherwise each padding row is centered to
                    // (garbage - E[x]) and squared into the variance.
                    std::uint32_t mask_set_offset = 0;
                    if constexpr (has_row_mask) {
                        mask_set_offset = ((row_tile_base + i) == last_row_tile) ? block_w : 0;
                    }
                    index_subblock_w_offset = 0;
                    for (std::uint32_t j = 0; j < num_subblocks_w; ++j) {
                        tile_regs_acquire();
                        for (std::uint32_t w = 0; w < subblock_w; ++w) {
                            const std::uint32_t index = w + index_subblock_w_offset;
                            if constexpr (has_row_mask) {
                                mul_tiles(dfb_xmm_id, dfb_input_mask_id, index, index + mask_set_offset, w);
                            } else {
                                mul_tiles_bcast_rows(dfb_xmm_id, dfb_input_mask_id, index, index, w);
                            }
                        }
                        tile_regs_commit();
                        tile_regs_wait();
                        for (std::uint32_t dst_i = 0; dst_i < subblock_w; ++dst_i) {
                            pack_tile(dst_i, dfb_x_id);
                        }
                        tile_regs_release();
                        index_subblock_w_offset += subblock_w;
                    }
                    dfb_xmm.pop_front(block_w);
                }
                if (extra_out_block && (out_block_index == (num_out_blocks_padded - 1))) {
                    dfb_xmm.pop_front(static_cast<uint16_t>(out_block_hw_normal - out_block_hw_last));
                }
                dfb_x.push_back(static_cast<uint16_t>(out_block_hw_normal));

                reconfig_data_format_srcb(dfb_input_mask_id, dfb_x_id);
                ckl::square<
                    ckl::input(
                        dfb_x_id,
                        ckl::WaitPolicy::Upfront,
                        ckl::PopPolicy::AtEnd,
                        ckl::InputTileMapping::Block,
                        ckl::DataFormatReconfig::Disabled),
                    ckl::output(
                        dfb_xmm_id,
                        ckl::ReservePolicy::Upfront,
                        ckl::PushPolicy::AtEnd,
                        ckl::DataFormatReconfig::Disabled)>(
                    ckl::IterationShape::grid(out_block_h_actual, block_w).block_size(subblock_w));
                if (extra_out_block && (out_block_index == (num_out_blocks_padded - 1))) {
                    dfb_x.pop_front(out_block_hw_normal - out_block_hw_last);
                    dfb_xmm.reserve_back(out_block_hw_normal - out_block_hw_last);
                    dfb_xmm.push_back(out_block_hw_normal - out_block_hw_last);
                }

                // Partial-Var(x)
                dfb_xmm.wait_front(static_cast<uint16_t>(out_block_hw_normal));
                reduce_partial_statistics<dfb_xmm_id, dfb_scaler_id, dfb_ex2_partial_id>(out_block_h_actual, block_w);
                dfb_xmm.pop_front(static_cast<uint16_t>(out_block_hw_normal));
            }
            // End Local Reduce
            // Start Global Reduce
            if constexpr (is_mcast_sender) {
                compute_kernel_lib::reduce<
                    PoolType::SUM,
                    ReduceDim::REDUCE_SCALAR,
                    dfb_ex_external_id,
                    dfb_scaler_global_id,
                    dfb_ex2_global_id,
                    compute_kernel_lib::ReduceInputPolicy::WaitAndPopPerTile,
                    compute_kernel_lib::ReduceDataFormatReconfigMode::NONE>(
                    compute_kernel_lib::ReduceInputBlockShape::col(dfb_ex_external_tiles_required));
                if constexpr (num_cores_per_mcast_group > 1) {
                    dfb_ex2.reserve_back(1);
                    dfb_ex2.push_back(1);
                }
            }
            // End Global Reduce

            // Start Variance Calc
            //  global reduce results
            dfb_eps.wait_front(1);

            // fp32: reset both srcs so fp32 variance / bf16 eps aren't read through the stale square/reduce format.
            if constexpr (enable_fp32_reconfig) {
                reconfig_data_format_srca(dfb_ex2_global_id);
                reconfig_data_format_srcb(dfb_eps_id);
            }
            // The row mask keeps the padding out of both sums, so this is already the variance over
            // the real rows; no back-correction needed.
            // (Var + eps)
            ckl::eltwise_chain(
                ckl::IterationShape::one_tile(),
                ckl::BinaryFpu<
                    ckl::BinaryFpuOp::Add,
                    ckl::input(
                        dfb_ex2_global_id,
                        ckl::WaitPolicy::PerTile,
                        ckl::PopPolicy::PerTile,
                        ckl::DataFormatReconfig::Disabled),
                    ckl::input(
                        dfb_eps_id, ckl::WaitPolicy::None, ckl::PopPolicy::None, ckl::DataFormatReconfig::Disabled)>{},
                ckl::Rsqrt<ckl::Approx::Exact, ckl::Dst::D0>{},
                ckl::PackTile<ckl::output(
                    dfb_ex2pe_id,
                    ckl::ReservePolicy::PerTile,
                    ckl::PushPolicy::PerTile,
                    ckl::DataFormatReconfig::Disabled)>{});
            // End Variance Calc

            const bool start_copy_or_add = copy_or_add;
            const std::uint32_t start_group_reset_index = group_reset_index;
            const std::uint32_t start_index_block_w = index_block_w;

            const std::uint32_t out_block_h_offset = 0;
            // Start Final Val Calc
            for (uint32_t out_block_index = 0; out_block_index < num_out_blocks_padded; out_block_index++) {
                uint32_t out_block_h_actual;
                if (extra_out_block && (out_block_index == (num_out_blocks_padded - 1))) {
                    out_block_h_actual = out_block_h_last;
                } else {
                    out_block_h_actual = out_block_h_normal;
                }

#ifndef TILIZE_IN
                dfb_in0.wait_front(static_cast<uint16_t>(out_block_hw_normal));
#endif
                dfb_ex_global.wait_front(1);
                // fp32: reset both srcs so fp32 input/mean aren't read through the stale rsqrt/eps format.
                if constexpr (enable_fp32_reconfig) {
                    reconfig_data_format_srca(dfb_input_id);
                    reconfig_data_format_srcb(dfb_ex_global_id);
                }
#ifdef TILIZE_IN
                ckl::eltwise_chain(
                    ckl::IterationShape::grid(out_block_h_actual, block_w).block_size(subblock_w),
                    ckl::BinaryFpu<
                        ckl::BinaryFpuOp::Sub,
                        input_strided_block_input,
                        ckl::input(
                            dfb_ex_global_id,
                            ckl::BroadcastDim::Scalar,
                            ckl::WaitPolicy::None,
                            ckl::PopPolicy::None,
                            ckl::DataFormatReconfig::Disabled)>{
                        ckl::StridedTileRange{out_block_index * out_block_hw_normal, block_w}},
                    ckl::PackTile<ckl::output(
                        dfb_xmm_id,
                        ckl::ReservePolicy::Upfront,
                        ckl::PushPolicy::AtEnd,
                        ckl::DataFormatReconfig::Disabled)>{});
#else
                ckl::sub<
                    ckl::input(
                        dfb_in0_id,
                        ckl::WaitPolicy::PerTile,
                        ckl::PopPolicy::PerTile,
                        ckl::DataFormatReconfig::Disabled),
                    ckl::input(
                        dfb_ex_global_id,
                        ckl::BroadcastDim::Scalar,
                        ckl::WaitPolicy::None,
                        ckl::PopPolicy::None,
                        ckl::DataFormatReconfig::Disabled),
                    ckl::output(
                        dfb_xmm_id,
                        ckl::ReservePolicy::Upfront,
                        ckl::PushPolicy::AtEnd,
                        ckl::DataFormatReconfig::Disabled)>(
                    ckl::IterationShape::grid(out_block_h_actual, block_w).block_size(subblock_w));
#endif
                if (extra_out_block && (out_block_index == (num_out_blocks_padded - 1))) {
#ifndef TILIZE_IN
                    dfb_in0.pop_front(static_cast<uint16_t>(out_block_hw_normal - out_block_hw_last));
#endif
                    dfb_xmm.reserve_back(out_block_hw_normal - out_block_hw_last);
                    dfb_xmm.push_back(out_block_hw_normal - out_block_hw_last);
                }

                // zero out the garbage values by mult mask again
                reconfig_data_format_srcb(dfb_ex_global_id, dfb_input_mask_id);
                ckl::mul<
                    ckl::input(
                        dfb_xmm_id,
                        ckl::WaitPolicy::Upfront,
                        ckl::PopPolicy::AtEnd,
                        ckl::InputTileMapping::Block,
                        ckl::DataFormatReconfig::Disabled),
                    ckl::input(
                        dfb_input_mask_id,
                        ckl::BroadcastDim::Row,
                        ckl::WaitPolicy::None,
                        ckl::PopPolicy::None,
                        ckl::InputTileMapping::Row,
                        ckl::DataFormatReconfig::Disabled),
                    ckl::output(
                        dfb_x_id,
                        ckl::ReservePolicy::Upfront,
                        ckl::PushPolicy::AtEnd,
                        ckl::DataFormatReconfig::Disabled)>(
                    ckl::IterationShape::grid(out_block_h_actual, block_w).block_size(subblock_w));
                if (extra_out_block && (out_block_index == (num_out_blocks_padded - 1))) {
                    dfb_xmm.wait_front(out_block_hw_normal - out_block_hw_last);
                    dfb_xmm.pop_front(static_cast<uint16_t>(out_block_hw_normal - out_block_hw_last));
                    dfb_x.reserve_back(out_block_hw_normal - out_block_hw_last);
                    dfb_x.push_back(out_block_hw_normal - out_block_hw_last);
                }

                dfb_ex2pe.wait_front(1);
                reconfig_data_format_srcb(dfb_input_mask_id, dfb_x_id);
                // fp32: reset both srcs so fp32 x/rstd aren't read through the stale mask/eps format.
                if constexpr (enable_fp32_reconfig) {
                    reconfig_data_format_srca(dfb_x_id);
                    reconfig_data_format_srcb(dfb_ex2pe_id);
                }
                // (x - Ex) * 1/[sqrt(Var + eps)]
                ckl::mul<
                    ckl::input(
                        dfb_x_id,
                        ckl::WaitPolicy::Upfront,
                        ckl::PopPolicy::AtEnd,
                        ckl::InputTileMapping::Block,
                        ckl::DataFormatReconfig::Disabled),
                    ckl::input(
                        dfb_ex2pe_id,
                        ckl::BroadcastDim::Scalar,
                        ckl::WaitPolicy::None,
                        ckl::PopPolicy::None,
                        ckl::DataFormatReconfig::Disabled),
                    ckl::output(
                        dfb_xmm_id,
                        ckl::ReservePolicy::Upfront,
                        ckl::PushPolicy::AtEnd,
                        ckl::DataFormatReconfig::Disabled)>(
                    ckl::IterationShape::grid(out_block_h_actual, block_w).block_size(subblock_w));
                if (extra_out_block && (out_block_index == (num_out_blocks_padded - 1))) {
                    dfb_x.wait_front(out_block_hw_normal - out_block_hw_last);
                    dfb_x.pop_front(out_block_hw_normal - out_block_hw_last);
                    dfb_xmm.reserve_back(out_block_hw_normal - out_block_hw_last);
                    dfb_xmm.push_back(out_block_hw_normal - out_block_hw_last);
                }
                dfb_xmm.wait_front(static_cast<uint16_t>(out_block_hw_normal));

                copy_or_add = start_copy_or_add;
                group_reset_index = start_group_reset_index;
                index_block_w = start_index_block_w;

                // add or copy with previous output results
                const std::uint32_t block_w_curr =
                    index_g_offset == (per_core_N - block_w_last) ? block_w_last : block_w;

#ifdef UNTILIZE_OUT
                // Tilize the reread rows so the accumulation below sees tiles.
                compute_kernel_lib::tilize<
                    block_w,
                    dfb_reread_rm_id,
                    dfb_reread_out_id,
                    compute_kernel_lib::tilize_config::InitUninitMode::InitAndUninit,
                    compute_kernel_lib::tilize_config::WaitMode::WaitBlock,
                    compute_kernel_lib::tilize_config::ReconfigureRegisterDatatypeMode::NoReconfigure>(
                    out_block_h_normal);
#endif

                dfb_reread_out.wait_front(static_cast<uint16_t>(out_block_hw_normal));
                dfb_reread_write_out.reserve_back(static_cast<uint16_t>(out_block_hw_normal));
                for (std::uint32_t w = 0; w < block_w_curr; ++w) {
                    const ckl::StridedTileRange input_range{w, block_w};
                    const ckl::StridedTileRange output_range{w, block_w_curr};
                    if (copy_or_add) {
                        ckl::eltwise_chain(
                            ckl::IterationShape::col(out_block_h_actual),
                            ckl::CopyTile<xmm_strided_col_input>{input_range},
                            ckl::PackTile<reread_write_out_strided_output>{output_range});
                    } else {
                        ckl::eltwise_chain(
                            ckl::IterationShape::col(out_block_h_actual),
                            ckl::BinaryFpu<ckl::BinaryFpuOp::Add, reread_out_strided_col_input, xmm_strided_col_input>{
                                output_range, input_range},
                            ckl::PackTile<reread_write_out_strided_output>{output_range});
                    }

                    // update group tile offset
                    if (index_block_w >= block_w_curr - 1) {
                        index_block_w = 0;

                        if (group_reset_index == num_groups_per_reset - 1) {
                            copy_or_add = true;

                            group_reset_index = 0;
                        } else {
                            copy_or_add = false;

                            group_reset_index += 1;
                        }
                    } else {
                        copy_or_add = true;
                        index_block_w += 1;
                    }

                    const bool is_past_end_of_group =
                        (((w + index_g_offset) + 1) * tile_width) > ((g + 1) * data_per_core_N_per_group);
                    apply_gamma_beta[w] = !is_past_end_of_group;
                }
                dfb_xmm.pop_front(static_cast<uint16_t>(out_block_hw_normal));
                dfb_reread_out.pop_front(static_cast<uint16_t>(out_block_hw_normal));
                dfb_reread_write_out.push_back(static_cast<uint16_t>(out_block_hw_normal));

                // Start Optional Gamma:
                if constexpr (do_gamma) {
                    dfb_outgamma.reserve_back(static_cast<uint16_t>(out_block_hw_normal));
                    dfb_gamma.wait_front(per_core_N);
                    dfb_reread_write_out.wait_front(static_cast<uint16_t>(out_block_hw_normal));
                    for (std::uint32_t j = 0; j < block_w_curr; ++j) {
                        if (apply_gamma_beta[j]) {
                            // fp32: reset both srcs so bf16 gamma isn't read through the reread stage's fp32 format.
                            if constexpr (enable_fp32_reconfig) {
                                reconfig_data_format_srca(dfb_reread_write_out_id);
                                reconfig_data_format_srcb(dfb_gamma_id);
                            }
                            ckl::eltwise_chain(
                                ckl::IterationShape::col(out_block_h_actual),
                                ckl::BinaryFpu<
                                    ckl::BinaryFpuOp::Mul,
                                    reread_write_out_strided_col_input,
                                    ckl::input(gamma_scalar_offset_input, ckl::BroadcastDim::Row)>{
                                    ckl::StridedTileRange{j, block_w_curr}, j + index_g_offset},
                                ckl::PackTile<outgamma_strided_output>{ckl::StridedTileRange{j, block_w_curr}});
                        } else {
                            ckl::eltwise_chain(
                                ckl::IterationShape::col(out_block_h_actual),
                                ckl::CopyTile<reread_write_out_strided_col_input>{
                                    ckl::StridedTileRange{j, block_w_curr}},
                                ckl::PackTile<outgamma_strided_output>{ckl::StridedTileRange{j, block_w_curr}});
                        }
                    }
                    dfb_outgamma.push_back(static_cast<uint16_t>(out_block_hw_normal));
                    dfb_reread_write_out.pop_front(static_cast<uint16_t>(out_block_hw_normal));
                }
                // End Optional Gamma
                //
                // Start Optional Beta
                if constexpr (do_beta) {
                    dfb_outbeta.reserve_back(static_cast<uint16_t>(out_block_hw_normal));
                    dfb_beta.wait_front(per_core_N);
                    // dfb_inbeta holds tiles this kernel packed earlier in the iteration: the gamma
                    // stage's result with gamma, the pre-gamma block without it. Either way the pack
                    // has to complete before the reads below, and this wait is what the pop at the end
                    // of this stage matches.
                    dfb_inbeta.wait_front(static_cast<uint16_t>(out_block_hw_normal));
                    for (std::uint32_t j = 0; j < block_w_curr; ++j) {
                        if (apply_gamma_beta[j]) {
                            // fp32: reset both srcs so bf16 beta isn't read through the fp32 dfb_inbeta format.
                            if constexpr (enable_fp32_reconfig) {
                                reconfig_data_format_srca(dfb_inbeta_id);
                                reconfig_data_format_srcb(dfb_beta_id);
                            }
                            ckl::eltwise_chain(
                                ckl::IterationShape::col(out_block_h_actual),
                                ckl::BinaryFpu<
                                    ckl::BinaryFpuOp::Add,
                                    inbeta_strided_col_input,
                                    ckl::input(beta_scalar_offset_input, ckl::BroadcastDim::Row)>{
                                    ckl::StridedTileRange{j, block_w_curr}, j + index_g_offset},
                                ckl::PackTile<outbeta_strided_output>{ckl::StridedTileRange{j, block_w_curr}});
                        } else {
                            ckl::eltwise_chain(
                                ckl::IterationShape::col(out_block_h_actual),
                                ckl::CopyTile<inbeta_strided_col_input>{ckl::StridedTileRange{j, block_w_curr}},
                                ckl::PackTile<outbeta_strided_output>{ckl::StridedTileRange{j, block_w_curr}});
                        }
                    }
                    dfb_outbeta.push_back(static_cast<uint16_t>(out_block_hw_normal));
                    dfb_inbeta.pop_front(static_cast<uint16_t>(out_block_hw_normal));
                }
                // End Optional Beta

#ifdef UNTILIZE_OUT
                // untilize - DEST capacity auto-detected.
                compute_kernel_lib::untilize<
                    block_w,
                    dfb_untilize_in_id,
                    dfb_untilize_out_id,
                    compute_kernel_lib::untilize_config::InitUninitMode::InitAndUninit,
                    compute_kernel_lib::untilize_config::WaitMode::WaitBlock,
                    compute_kernel_lib::untilize_config::ReconfigureRegisterDatatypeMode::UnpackAndPackReconfigure>(
                    out_block_h_normal);
#endif
            }
            // End Final Val Calc
#ifdef TILIZE_IN
            // All passes done with the group, resident group popped.
            dfb_in_resident.pop_front(num_out_blocks_padded * out_block_hw_normal);
#endif
            if constexpr (GROUP_SIZE_IS_POWER_OF_2) {
                if (row_offset == tile_width) {
                    index_g_offset += block_w;
                    row_offset = num_cols_per_group;

                } else {
                    index_g_offset += block_w_minus_one;
                    row_offset += num_cols_per_group;
                }
            } else if constexpr (GROUP_SIZE_SMALLER_THAN_TILE_W) {
                if (row_offset == tile_width) {
                    index_g_offset += block_w_minus_one;
                    row_offset = num_cols_per_group;

                } else if (row_offset > tile_width) {
                    index_g_offset += block_w_minus_one;
                    row_offset = row_offset + group_row_offset;

                } else {
                    row_offset += num_cols_per_group;
                }
            } else {
                if (row_offset > tile_width) {
                    index_g_offset += block_w_minus_one;
                    row_offset = row_offset - tile_w_minux_group_size;
                } else {
                    row_offset += num_cols_per_group;
                    index_g_offset += block_w_minus_two;
                }
            }
            dfb_ex_global.pop_front(1);
            dfb_ex2pe.pop_front(1);
            dfb_input_mask.pop_front(mask_tiles_per_group);
        }
        // End Group Loop
    }
    // End Batch Loop

    // Buffers holding a value reused for the whole core's work are never popped inside the loops
    // above; pop them here so they are left balanced. The scaler waits are not present in this
    // file: compute_kernel_lib::reduce waits one page on the buffer it is given as the scaler and
    // leaves it unpopped so that one pushed tile serves all of this kernel's reduce calls.
    DataflowBuffer(dfb_scaler_id).pop_front(1);
    if constexpr (is_mcast_sender) {
        // The global-reduce scaler is waited only by the global reductions on the mcast sender;
        // pop it under the same guard that gated those reductions.
        DataflowBuffer(dfb_scaler_global_id).pop_front(1);
    }
    // The epsilon tile is pushed once by the reader and re-waited on every group, so it is
    // popped once here to balance the buffer.
    dfb_eps.pop_front(1);
    // Gamma and beta are each one row of per_core_N tiles pushed once by the reader and re-waited on
    // every output block, so they are popped once here.
    if constexpr (do_gamma) {
        dfb_gamma.pop_front(per_core_N);
    }
    if constexpr (do_beta) {
        dfb_beta.pop_front(per_core_N);
    }
}
