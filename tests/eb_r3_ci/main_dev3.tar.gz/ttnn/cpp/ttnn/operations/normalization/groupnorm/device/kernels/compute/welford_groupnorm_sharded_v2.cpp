// SPDX-FileCopyrightText: © 2025 Tenstorrent USA, Inc.
//
// SPDX-License-Identifier: Apache-2.0

#include <cstdint>

#define BCAST_LLKOP EltwiseBinaryType::ELWMUL
#define BCAST_DIM BroadcastType::COL

#include "api/compute/reduce.h"
#include "api/compute/bcast.h"
#include "api/compute/eltwise_binary.h"
#include "api/compute/layernorm.h"
#include "api/compute/tile_move_copy.h"
#include "api/compute/tilize.h"
#include "api/compute/matmul.h"
#include "api/compute/transpose.h"
#include "api/compute/welford.h"
#include "api/compute/sfpu_binary_bcast.h"
#include "ttnn/cpp/ttnn/kernel_lib/tilize_helpers.hpp"
#include "ttnn/cpp/ttnn/kernel_lib/untilize_helpers.hpp"
#include "api/dataflow/dataflow_buffer.h"

void kernel_main() {
    constexpr bool do_gamma = get_compile_time_arg_val(1) == 1;
    constexpr bool do_beta = get_compile_time_arg_val(2) == 1;

    constexpr std::uint32_t num_batches = get_compile_time_arg_val(4);
    constexpr std::uint32_t num_groups = get_compile_time_arg_val(5);

    constexpr std::uint32_t block_h = get_compile_time_arg_val(7);
    constexpr std::uint32_t block_w = get_compile_time_arg_val(8);

    constexpr std::uint32_t per_core_M = get_compile_time_arg_val(12);
    constexpr std::uint32_t per_core_N = get_compile_time_arg_val(13);
    constexpr std::uint32_t per_core_MN = get_compile_time_arg_val(14);

    // Distance in tiles between the start of one batch and the start of the next batch within this
    // core's shard.
    constexpr std::uint32_t num_tiles_per_batch = get_compile_time_arg_val(18);

    constexpr std::uint32_t num_tiles_input_mask = get_compile_time_arg_val(19);
    constexpr std::uint32_t num_channels_per_group = get_compile_time_arg_val(24);
    constexpr std::uint32_t tile_width = get_compile_time_arg_val(25);

    // Welford-fp32 alias args. When the alias is active, cb_in0_welford_id points
    // to c_29 (shares SRAM with c_0) and cb_in_welford_id points to c_31 (shares SRAM with c_1).
    // Both alias indices are configured with unpack_to_dest_mode=UnpackToDestFp32 so
    // transpose_tile preserves FP32 precision for the SFPU Welford.
    // The final-stage sub_tiles_bcast_scalar reads c_0 / c_1 (Default SrcA path).
    //
    // Unlike the mcast / no_mcast groupnorm kernels, no separate
    // welford_unpack_fp32_active flag is needed here. Both the TILIZE_IN and
    // non-TILIZE_IN branches route the welford intake transpose through an alias
    // CB (cb_in_welford_id or cb_in0_welford_id), so the unpack-to-DEST fp32
    // path is active on both branches iff the alias is active. In the
    // mcast/no_mcast kernels the TILIZE_IN branch tilizes directly into the
    // unpack-fp32 CB without an alias, so those kernels need the unpack-fp32
    // state and the alias gating to be tracked independently.
    constexpr bool welford_fp32_alias = get_named_compile_time_arg_val("welford_fp32_alias") != 0;
    constexpr std::uint32_t dfb_in0_welford_id = get_named_compile_time_arg_val("cb_in0_welford");
    constexpr std::uint32_t dfb_in_welford_id = get_named_compile_time_arg_val("cb_in_welford");
    // True when a reconfig-relevant operand is fp32: the per-tile reconfig_data_format calls below
    // are then required. All-bf16 compiles them out (no-ops). See program factory.
    constexpr bool enable_fp32_reconfig = get_named_compile_time_arg_val("enable_fp32_reconfig") != 0;
    constexpr std::uint32_t sfpu_two_pass_reciprocal = get_named_compile_time_arg_val("sfpu_two_pass_reciprocal");
    constexpr bool fp32_sfpu_normalizer = get_named_compile_time_arg_val("fp32_sfpu_normalizer") != 0;
    constexpr std::uint32_t dfb_ex_global_fp32_id = get_named_compile_time_arg_val("cb_ex_global_fp32");
    constexpr std::uint32_t dfb_ex2pe_fp32_id = get_named_compile_time_arg_val("cb_ex2pe_fp32");

    // dst regs
    constexpr std::uint32_t dst0 = 0;
    constexpr std::uint32_t input_dst = 0;
    constexpr std::uint32_t mean_dst = 1;
    // Global statistics store each group's mean followed by its variance.
    constexpr std::uint32_t stats_tiles_per_group = 2;

    // input cbs
    constexpr std::uint32_t dfb_in0_id = tt::CBIndex::c_0;
    constexpr std::uint32_t dfb_in_id = tt::CBIndex::c_1;
    constexpr std::uint32_t dfb_eps_id = tt::CBIndex::c_3;
    constexpr std::uint32_t dfb_gamma_id = tt::CBIndex::c_5;
    constexpr std::uint32_t dfb_beta_id = tt::CBIndex::c_6;
    constexpr std::uint32_t dfb_input_mask_id = tt::CBIndex::c_7;

    // interm cbs
    constexpr std::uint32_t dfb_repack_id = tt::CBIndex::c_11;
    constexpr std::uint32_t dfb_repack_out_id = tt::CBIndex::c_12;
    constexpr std::uint32_t dfb_x_id = tt::CBIndex::c_13;
    constexpr std::uint32_t dfb_xmm_id = tt::CBIndex::c_2;
    constexpr std::uint32_t dfb_ex_partial_id = tt::CBIndex::c_8;
    constexpr std::uint32_t dfb_ex_global_id = tt::CBIndex::c_15;
    constexpr std::uint32_t dfb_ex2pe_id = tt::CBIndex::c_17;

    // output cb
    constexpr std::uint32_t dfb_out0_id = tt::CBIndex::c_16;
#ifdef UNTILIZE_OUT
    // The tilised input remains live throughout normalisation. Never use its
    // full FIFO as output staging, including gamma-only and beta-only calls.
    constexpr std::uint32_t dfb_untilize_in_id = tt::CBIndex::c_30;
    constexpr int dfb_untilize_out_id =
#ifdef READER_REPACK
        dfb_repack_out_id;
#else
        dfb_out0_id;
#endif
#endif

    DataflowBuffer dfb_beta(dfb_beta_id);
    DataflowBuffer dfb_eps(dfb_eps_id);
    DataflowBuffer dfb_ex2pe(dfb_ex2pe_id);
    DataflowBuffer dfb_ex2pe_fp32(dfb_ex2pe_fp32_id);
    DataflowBuffer dfb_ex_global(dfb_ex_global_id);
    DataflowBuffer dfb_ex_global_fp32(dfb_ex_global_fp32_id);
    DataflowBuffer dfb_ex_partial(dfb_ex_partial_id);
    DataflowBuffer dfb_gamma(dfb_gamma_id);
    DataflowBuffer dfb_in(dfb_in_id);
    DataflowBuffer dfb_in_welford(dfb_in_welford_id);
    const DataflowBuffer dfb_in0_welford(dfb_in0_welford_id);
    DataflowBuffer dfb_input_mask(dfb_input_mask_id);
    DataflowBuffer dfb_x(dfb_x_id);
    DataflowBuffer dfb_xmm(dfb_xmm_id);

// tilize input from RM to tile layout
#ifdef TILIZE_IN
    compute_kernel_hw_startup(dfb_in0_id, dfb_in0_id, dfb_in_id);
// Tilize in0 -> in (row-major to tiled)
#ifdef READER_REPACK
    constexpr std::uint32_t dfb_in_rm_id = dfb_repack_id;
    compute_kernel_lib::tilize<
        per_core_N,
        dfb_in_rm_id,
        dfb_in_id,
        compute_kernel_lib::tilize_config::InitUninitMode::InitAndUninit,
        compute_kernel_lib::tilize_config::WaitMode::WaitBlock,
        compute_kernel_lib::tilize_config::ReconfigureRegisterDatatypeMode::NoReconfigure>(per_core_M);
#else
    constexpr std::uint32_t dfb_in_rm_id = dfb_in0_id;
    compute_kernel_lib::tilize<
        per_core_N,
        dfb_in_rm_id,
        dfb_in_id,
        compute_kernel_lib::tilize_config::InitUninitMode::InitAndUninit,
        compute_kernel_lib::tilize_config::WaitMode::NoWait,
        compute_kernel_lib::tilize_config::ReconfigureRegisterDatatypeMode::NoReconfigure>(per_core_M);
#endif  // READER_REPACK
    dfb_in.wait_front(per_core_MN);
    if constexpr (welford_fp32_alias) {
        // Mirror the tilize push on the alias (c_31, shares SRAM with dfb_in / c_1) so it tracks
        // dfb_in's state. Must be done in compute: the producer of dfb_in is the
        // tilize call above (a compute op), not the reader; the reader never writes dfb_in.
        dfb_in_welford.reserve_back(per_core_MN);
        dfb_in_welford.push_back(per_core_MN);
        dfb_in_welford.wait_front(per_core_MN);
    }
#else   // !TILIZE_IN
    compute_kernel_hw_startup(dfb_in0_id, dfb_in0_id, dfb_in0_id);
#endif  // TILIZE_IN

    dfb_eps.wait_front(1);
    dfb_input_mask.wait_front(num_tiles_input_mask);

    if constexpr (do_gamma) {
        dfb_gamma.wait_front(per_core_N);
    }
    if constexpr (do_beta) {
        dfb_beta.wait_front(per_core_N);
    }

    for (std::uint32_t b = 0; b < num_batches; ++b) {
        std::uint32_t tile_id = b * num_tiles_per_batch;
        dfb_ex_partial.reserve_back(2);
        if constexpr (welford_fp32_alias) {
            // The alias carries UnpackToDestFp32 while c_0 / c_1 stay Default; transpose_init only
            // programs the MOP, so without the reconfig the fp32 intake is silently truncated to TF32.
#ifdef TILIZE_IN
            reconfig_data_format_srca(dfb_in_welford_id);
            transpose_init(dfb_in_welford_id);
#else
            reconfig_data_format_srca(dfb_in0_welford_id);
            transpose_init(dfb_in0_welford_id);
#endif
        } else {
            transpose_init(dfb_in0_id);
        }
        tile_regs_acquire();
        two_pass_stats_init_shifted();
        two_pass_stats_clear();

        std::uint32_t active_group = 0;
        // Group 0 starts directly from the cleared LREG state. Only the
        // other groups need an initialized state in DST before first use.
        // Two-pass reuses Welford's register save/restore layout for per-group
        // anchors and partial sums. Seed inactive groups with the cleared state.
        for (std::uint32_t g = 1; g < num_groups; ++g) {
            welford_save_state(mean_dst, g);
        }

        for (std::uint32_t i = 0; i < block_h; ++i) {
            if constexpr (num_groups > 1) {
                if (i > 0) {
                    two_pass_stats_switch_group<false /* dual_accumulator */>(mean_dst, active_group, 0);
                    active_group = 0;
                }
            }

            // This indicates the smallest group that is yet to be processed for this block
            // As we iterate over nt, some of the groups will be completed, and we will update
            // this variable
            std::uint32_t min_group = 0;

            // This indicates the number of channels left to be processed for the min_group
            // As we iterate over nt, some of the channels will be completed, and we will
            // update this variable
            // It is mainly used when we move from one tile to the next, if there are channels
            // left to be processed for the min_group, we will process them in the next tile
            std::uint32_t channels_left = num_channels_per_group;

            for (std::uint32_t nt = 0; nt < per_core_N; ++nt) {
#ifdef TILIZE_IN
                transpose_init(dfb_in_welford_id);
                transpose_tile(dfb_in_welford_id, tile_id, input_dst);
#else
                transpose_init(dfb_in0_welford_id);
                transpose_tile(dfb_in0_welford_id, tile_id, input_dst);
#endif

                std::uint32_t group_offset = 0;
                for (std::uint32_t g = min_group; g < num_groups; ++g) {
                    const std::uint32_t cols_available = tile_width - group_offset;
                    const std::uint32_t cols_consumed = std::min(cols_available, channels_left);

                    if (i == 0 && channels_left == num_channels_per_group) {
                        two_pass_stats_update_shifted_rows<
                            TwoPassAccumulation::ShiftedSum,
                            TwoPassAnchor::Initialise,
                            num_groups == 1 /* dual_accumulator */>(input_dst, group_offset, cols_consumed);
                    } else {
                        two_pass_stats_update_shifted_rows<
                            TwoPassAccumulation::ShiftedSum,
                            TwoPassAnchor::Reuse,
                            num_groups == 1 /* dual_accumulator */>(input_dst, group_offset, cols_consumed);
                    }

                    channels_left -= cols_consumed;
                    group_offset += cols_consumed;

                    // There are still channels left to be processed for the current group
                    // This can only be done in the next tile. So we don't do any more groups
                    // for this tile.
                    if (channels_left > 0) {
                        break;
                    }

                    // Since we know that channels_left is 0, it also means that we have
                    // processed all the channels for the current group.
                    // We update the min_group so we never revisit this group again.
                    ++min_group;
                    if (min_group < num_groups) {
                        two_pass_stats_switch_group<false /* dual_accumulator */>(mean_dst, active_group, min_group);
                        active_group = min_group;
                    }
                    channels_left = num_channels_per_group;

                    // All available columns have been used for this tile, so we don't do any
                    // more groups for this tile.
                    if (group_offset == tile_width) {
                        break;
                    }
                }
                ++tile_id;
            }
        }

        // Convert shifted sums to means, ending with group 0 resident in LREGs so
        // the second pass can begin without another save/restore pair.
        two_pass_stats_finish_shifted_mean<num_groups == 1 /* dual_sum */>(sfpu_two_pass_reciprocal);
        if constexpr (num_groups > 1) {
            welford_save_state(mean_dst, active_group);
        }
        for (std::uint32_t g = 1; g + 1 < num_groups; ++g) {
            welford_restore_state(mean_dst, g);
            two_pass_stats_finish_shifted_mean<num_groups == 1 /* dual_sum */>(sfpu_two_pass_reciprocal);
            welford_save_state(mean_dst, g);
        }
        if constexpr (num_groups > 1) {
            welford_restore_state(mean_dst, 0);
            two_pass_stats_finish_shifted_mean<num_groups == 1 /* dual_sum */>(sfpu_two_pass_reciprocal);
        }

        // Second pass: accumulate centered squared residuals in FP32 SFPU.
        tile_id = b * num_tiles_per_batch;
        active_group = 0;
        for (std::uint32_t i = 0; i < block_h; ++i) {
            if constexpr (num_groups > 1) {
                if (i > 0) {
                    two_pass_stats_switch_group<false /* dual_accumulator */>(mean_dst, active_group, 0);
                    active_group = 0;
                }
            }
            std::uint32_t min_group = 0;
            std::uint32_t channels_left = num_channels_per_group;
            for (std::uint32_t nt = 0; nt < per_core_N; ++nt) {
#ifdef TILIZE_IN
                transpose_init(dfb_in_welford_id);
                transpose_tile(dfb_in_welford_id, tile_id, input_dst);
#else
                transpose_init(dfb_in0_welford_id);
                transpose_tile(dfb_in0_welford_id, tile_id, input_dst);
#endif
                std::uint32_t group_offset = 0;
                for (std::uint32_t g = min_group; g < num_groups; ++g) {
                    const std::uint32_t cols_available = tile_width - group_offset;
                    const std::uint32_t cols_consumed = std::min(cols_available, channels_left);
                    two_pass_stats_update_rows<num_groups == 1 /* dual_m2 */>(input_dst, group_offset, cols_consumed);
                    channels_left -= cols_consumed;
                    group_offset += cols_consumed;
                    if (channels_left > 0) {
                        break;
                    }
                    ++min_group;
                    if (min_group < num_groups) {
                        two_pass_stats_switch_group<false /* dual_accumulator */>(mean_dst, active_group, min_group);
                        active_group = min_group;
                    }
                    channels_left = num_channels_per_group;
                    if (group_offset == tile_width) {
                        break;
                    }
                }
                ++tile_id;
            }
        }
        // Finalize the resident last group before loading the others.
#ifdef WELFORD_SFPU_LOCAL_COMBINE
        two_pass_stats_finalize_and_combine_to_face<num_groups == 1 /* dual_m2 */>(
            mean_dst, active_group, sfpu_two_pass_reciprocal);
#else
        two_pass_stats_finalize_to_face<num_groups == 1 /* dual_m2 */>(
            mean_dst, active_group, sfpu_two_pass_reciprocal);
#endif
        for (std::uint32_t g = 0; g + 1 < num_groups; ++g) {
            welford_restore_state(mean_dst, g);
#ifdef WELFORD_SFPU_LOCAL_COMBINE
            two_pass_stats_finalize_and_combine_to_face<false /* dual_m2 */>(mean_dst, g, sfpu_two_pass_reciprocal);
#else
            two_pass_stats_finalize_to_face<false /* dual_m2 */>(mean_dst, g, sfpu_two_pass_reciprocal);
#endif
        }

        tile_regs_commit();
        tile_regs_wait();
        pack_block(mean_dst, dfb_ex_partial_id, 2);
        tile_regs_release();
        dfb_ex_partial.push_back(2);

        // Start Variance Calc
        // Wait for final welford values in cb_ex_global_id
        dfb_ex_global.wait_front(2 * num_groups);
        if constexpr (fp32_sfpu_normalizer) {
            dfb_ex_global_fp32.reserve_back(2 * num_groups);
            dfb_ex_global_fp32.push_back(2 * num_groups);
        }
        dfb_ex2pe.reserve_back(num_groups);
        if constexpr (fp32_sfpu_normalizer) {
            dfb_ex2pe_fp32.reserve_back(num_groups);
        }
        // (Var + eps)
        // fp32: dfb_ex_global is fp32 (var), dfb_eps is bf16; the welford intake left SrcA on the fp32 input alias.
        if constexpr (enable_fp32_reconfig) {
            reconfig_data_format_srca(dfb_ex_global_id);
        }
        reconfig_data_format_srcb(dfb_eps_id);
        add_init(dfb_ex_global_id, dfb_eps_id);
        for (std::uint32_t g = 0; g < num_groups; ++g) {
            tile_regs_acquire();
            add_tiles(dfb_ex_global_id, dfb_eps_id, g * stats_tiles_per_group + 1, 0, dst0);

            // 1/[sqrt(Var + eps)]
            rsqrt_tile_init();
            rsqrt_tile(dst0);
            tile_regs_commit();
            tile_regs_wait();
            pack_tile(dst0, dfb_ex2pe_id);
            tile_regs_release();
        }
        dfb_ex2pe.push_back(num_groups);
        if constexpr (fp32_sfpu_normalizer) {
            dfb_ex2pe_fp32.push_back(num_groups);
        }
        // End Variance Calc

        dfb_ex2pe.wait_front(num_groups);
        if constexpr (fp32_sfpu_normalizer) {
            dfb_ex_global_fp32.wait_front(2 * num_groups);
            dfb_ex2pe_fp32.wait_front(num_groups);
        }

        // Start Final Val Calc
        if constexpr (fp32_sfpu_normalizer) {
            sfpu_normalize_bcast_scalar_init();
        }
        tile_id = b * num_tiles_per_batch;
        for (std::uint32_t i = 0; i < block_h; ++i) {
            // This indicates the smallest group that is yet to be processed for this block
            // As we iterate over nt, some of the groups will be completed, and we will update
            // this variable
            std::uint32_t min_group = 0;

            // This indicates the number of channels left to be processed for the min_group
            // As we iterate over nt, some of the channels will be completed, and we will
            // update this variable
            // It is mainly used when we move from one tile to the next, if there are channels
            // left to be processed for the min_group, we will process them in the next tile
            std::uint32_t channels_left = num_channels_per_group;

            // This tracks the correct index to use for the mask.
            // For each group, there are block_w number of mask tiles. As we iterate over nt,
            // we will update this variable to track the correct index to use for the mask.
            std::uint32_t block_w_index = 0;

            for (std::uint32_t nt = 0; nt < per_core_N; ++nt) {
                std::uint32_t group_offset = 0;
                for (std::uint32_t g = min_group; g < num_groups; ++g) {
                    dfb_xmm.reserve_back(1);

                    // // Now let us do the actual computation for the current group here
                    // // a/b. (x-u) * 1/[sqrt(Var + eps)]
                    if constexpr (fp32_sfpu_normalizer) {
                        constexpr std::uint32_t data_dst = 0;
                        constexpr std::uint32_t mean_dst = 1;
                        constexpr std::uint32_t inv_std_dst = 2;
                        tile_regs_acquire();
#ifdef TILIZE_IN
                        copy_init(dfb_in_welford_id);
                        copy_tile(dfb_in_welford_id, tile_id, data_dst);
#else
                        copy_init(dfb_in0_welford_id);
                        copy_tile(dfb_in0_welford_id, tile_id, data_dst);
#endif
                        reconfig_data_format_srca(dfb_in0_welford_id, dfb_ex_global_fp32_id);
                        copy_init(dfb_ex_global_fp32_id);
                        copy_tile(dfb_ex_global_fp32_id, g * stats_tiles_per_group, mean_dst);
                        reconfig_data_format_srca(dfb_ex_global_fp32_id, dfb_ex2pe_fp32_id);
                        copy_init(dfb_ex2pe_fp32_id);
                        copy_tile(dfb_ex2pe_fp32_id, g, inv_std_dst);
                        sfpu_normalize_bcast_scalar(data_dst, mean_dst, inv_std_dst);
                        tile_regs_commit();
                        tile_regs_wait();
                        pack_tile(data_dst, dfb_xmm_id);
                        tile_regs_release();
                        dfb_xmm.push_back(1);
                        reconfig_data_format_srca(dfb_ex2pe_fp32_id, dfb_in0_welford_id);
                        copy_init(dfb_in0_welford_id);
                    } else {
                        reconfig_data_format(dfb_in0_id, dfb_ex_global_id);
                        sub_bcast_scalar_init(dfb_in0_id, dfb_ex_global_id);

                        tile_regs_acquire();
#ifdef TILIZE_IN
                        sub_tiles_bcast_scalar(dfb_in_id, dfb_ex_global_id, tile_id, g * stats_tiles_per_group, dst0);
#else
                        sub_tiles_bcast_scalar(dfb_in0_id, dfb_ex_global_id, tile_id, g * stats_tiles_per_group, dst0);
#endif
                        tile_regs_commit();
                        tile_regs_wait();
                        pack_tile(dst0, dfb_xmm_id);
                        tile_regs_release();
                        dfb_xmm.push_back(1);

                        // // b. (x - u) * 1/[sqrt(Var + eps)]
                        dfb_xmm.wait_front(1);
                        reconfig_data_format(dfb_in0_id, dfb_xmm_id, dfb_ex_global_id, dfb_ex2pe_id);
                        mul_bcast_scalar_init(dfb_xmm_id, dfb_ex2pe_id);
                        tile_regs_acquire();
                        mul_tiles_bcast_scalar(dfb_xmm_id, dfb_ex2pe_id, 0, g, dst0);
                        tile_regs_commit();
                        dfb_xmm.pop_front(1);
                        dfb_xmm.reserve_back(1);
                        tile_regs_wait();
                        pack_tile(dst0, dfb_xmm_id);
                        tile_regs_release();
                        dfb_xmm.push_back(1);
                    }

                    // // c. [(x - u) * rsqrt] * mask
                    const std::uint32_t mask_offset = g * block_w;
                    const std::uint32_t mask_index = mask_offset + block_w_index;

                    dfb_xmm.wait_front(1);
                    if constexpr (fp32_sfpu_normalizer) {
                        // SFPU normalisation does not select ex2pe in SrcB;
                        // eps or the previous tile's affine operand is still active.
                        reconfig_data_format(dfb_xmm_id, dfb_input_mask_id);
                    } else {
                        reconfig_data_format(dfb_xmm_id, dfb_xmm_id, dfb_ex2pe_id, dfb_input_mask_id);
                    }
                    mul_bcast_rows_init(dfb_xmm_id, dfb_input_mask_id);
                    tile_regs_acquire();
                    mul_tiles_bcast_rows(dfb_xmm_id, dfb_input_mask_id, 0, mask_index, dst0);
                    dfb_xmm.pop_front(1);

                    // // d. Accumulate into cb_x_id.
                    if (group_offset != 0) {
                        // Not the first group for this tile: add what is already in cb_x.
                        reconfig_data_format_srca(dfb_x_id);
                        add_reuse_dest_init<EltwiseBinaryReuseDestType::DEST_TO_SRCB>(dfb_x_id);
                        dfb_x.wait_front(1);
                        add_reuse_dest_tiles<EltwiseBinaryReuseDestType::DEST_TO_SRCB>(dfb_x_id, 0, dst0);
                        dfb_x.pop_front(1);
                    }
                    tile_regs_commit();

                    // Then we pack the result into cb_x_id
                    dfb_x.reserve_back(1);
                    tile_regs_wait();
                    pack_tile(dst0, dfb_x_id);
                    tile_regs_release();
                    dfb_x.push_back(1);

                    // The blocks after this loop assume srcb still carries cb_xmm's format.
                    reconfig_data_format_srcb(dfb_xmm_id);

                    const std::uint32_t cols_available = tile_width - group_offset;
                    const std::uint32_t cols_consumed = std::min(cols_available, channels_left);
                    channels_left -= cols_consumed;
                    group_offset += cols_consumed;

                    // There are still channels left to be processed for the current group
                    // This can only be done in the next tile. So we don't do any more groups
                    // for this tile.
                    if (channels_left > 0) {
                        // For the next tile, we need to use the next mask index
                        ++block_w_index;
                        break;
                    }

                    // Since we know that channels_left is 0, it also means that we have
                    // processed all the channels for the current group.
                    // We update the min_group so we never revisit this group again.
                    ++min_group;
                    channels_left = num_channels_per_group;
                    block_w_index = 0;

                    // All available columns have been used for this tile, so we don't do any
                    // more groups for this tile.
                    if (group_offset == tile_width) {
                        break;
                    }
                }
                ++tile_id;

                if constexpr (do_gamma) {
                    // fp32: reset SrcA to dfb_x (fp32).
                    if constexpr (enable_fp32_reconfig) {
                        reconfig_data_format_srca(dfb_x_id);
                    }
                    reconfig_data_format_srcb(dfb_xmm_id, dfb_gamma_id);
                    mul_bcast_rows_init(dfb_x_id, dfb_gamma_id);

                    dfb_x.wait_front(1);
                    tile_regs_acquire();
                    mul_tiles_bcast_rows(dfb_x_id, dfb_gamma_id, 0, nt, dst0);
                    tile_regs_commit();
                    dfb_x.pop_front(1);
                    if constexpr (do_beta) {
                        dfb_x.reserve_back(1);
                        tile_regs_wait();
                        pack_tile(dst0, dfb_x_id);
                        tile_regs_release();
                        dfb_x.push_back(1);
                    }
                }

                if constexpr (do_beta) {
                    // fp32: reset SrcA to dfb_x (fp32).
                    if constexpr (enable_fp32_reconfig) {
                        reconfig_data_format_srca(dfb_x_id);
                    }
                    reconfig_data_format_srcb(do_gamma ? dfb_gamma_id : dfb_xmm_id, dfb_beta_id);
                    add_bcast_rows_init(dfb_x_id, dfb_beta_id);

                    dfb_x.wait_front(1);
                    tile_regs_acquire();
                    add_tiles_bcast_rows(dfb_x_id, dfb_beta_id, 0, nt, dst0);
                    tile_regs_commit();
                    dfb_x.pop_front(1);
                }

                if constexpr (!do_gamma && !do_beta) {
                    if constexpr (enable_fp32_reconfig) {
                        reconfig_data_format_srca(dfb_x_id);
                    }
                    reconfig_data_format_srcb(dfb_xmm_id, dfb_x_id);
                    copy_init(dfb_x_id);

                    dfb_x.wait_front(1);
                    tile_regs_acquire();
                    copy_tile(dfb_x_id, 0, dst0);
                    tile_regs_commit();
                    dfb_x.pop_front(1);
                }

                // The final affine operation leaves its result in DST for this pack.
#ifdef UNTILIZE_OUT
                auto write_dfb_id = dfb_untilize_in_id;
#else
                auto write_dfb_id = dfb_out0_id;
#endif
                DataflowBuffer write_dfb(static_cast<uint16_t>(write_dfb_id));
                write_dfb.reserve_back(1);
                tile_regs_wait();
#ifndef UNTILIZE_OUT
                // Switch from the intermediate format to output for this pack,
                // then restore it. All-BF16 configurations need no reconfiguration.
                if constexpr (enable_fp32_reconfig) {
                    pack_reconfig_data_format(write_dfb_id);
                }
#endif
                pack_tile(dst0, static_cast<uint32_t>(write_dfb_id));
#ifndef UNTILIZE_OUT
                if constexpr (enable_fp32_reconfig) {
                    pack_reconfig_data_format(dfb_xmm_id);
                }
#endif
                tile_regs_release();
                write_dfb.push_back(1);
            }
        }

        dfb_ex_global.pop_front(2 * num_groups);
        dfb_ex2pe.pop_front(num_groups);
        if constexpr (fp32_sfpu_normalizer) {
            dfb_ex_global_fp32.pop_front(2 * num_groups);
            dfb_ex2pe_fp32.pop_front(num_groups);
        }
    }

    dfb_eps.pop_front(1);
    dfb_input_mask.pop_front(num_tiles_input_mask);

    // Pop all the cb_beta_id and cb_gamma_id if used
    if constexpr (do_beta) {
        dfb_beta.pop_front(per_core_N);
    }
    if constexpr (do_gamma) {
        dfb_gamma.pop_front(per_core_N);
    }

#ifdef TILIZE_IN
    // The tilized input is produced once by the tilize above and then read by tile offset for the
    // whole kernel, so it is waited once rather than per batch. Pop it here, after the last read,
    // to balance the buffer.
    dfb_in.pop_front(per_core_MN);
    if constexpr (welford_fp32_alias) {
        // The alias mirrors dfb_in's reserve and push, so it takes the matching pop.
        dfb_in_welford.pop_front(per_core_MN);
    }
#endif

#ifdef UNTILIZE_OUT
    // untilize - DEST capacity auto-detected
    compute_kernel_lib::untilize<
        per_core_N,
        dfb_untilize_in_id,
        dfb_untilize_out_id,
        compute_kernel_lib::untilize_config::InitUninitMode::InitAndUninit,
        compute_kernel_lib::untilize_config::WaitMode::WaitUpfront,
        compute_kernel_lib::untilize_config::ReconfigureRegisterDatatypeMode::NoReconfigure>(per_core_M);
#endif
}
