// SPDX-FileCopyrightText: © 2024 Tenstorrent USA, Inc.
//
// SPDX-License-Identifier: Apache-2.0

#define BCAST_LLKOP EltwiseBinaryType::ELWMUL
#define BCAST_DIM BroadcastType::COL

#include "api/compute/reduce.h"
#include "api/compute/bcast.h"
#include "api/compute/eltwise_binary.h"
#include "api/compute/layernorm.h"
#include "api/compute/tile_move_copy.h"
#include "api/dataflow/dataflow_buffer.h"
#include "experimental/kernel_args.h"
#include "ttnn/cpp/ttnn/kernel_lib/reduce_helpers_compute.hpp"

// SPLIT REDUCE across Cores
void kernel_main() {
    constexpr auto block_w = get_arg(args::block_w);
    constexpr auto block_h_const = get_arg(args::block_h);
    const volatile uint32_t block_h_volatile = get_arg(args::block_h);
    constexpr auto subblock_w_const = get_arg(args::subblock_w);
    const volatile uint32_t subblock_w_volatile = get_arg(args::subblock_w);
    constexpr auto num_subblocks_w = get_arg(args::num_subblocks_w);
    constexpr auto num_tiles_per_block = get_arg(args::num_tiles_per_block);
    constexpr bool FLOAT32_DTYPE = get_arg(args::float32_dtype) == 1;
    // gamma and beta each gate a buffer that only exists when their tensor was supplied, so the flag
    // has to reach the preprocessor as well as `if constexpr`.
#ifdef FUSE_GAMMA
    constexpr bool do_gamma = true;
#else
    constexpr bool do_gamma = false;
#endif
#ifdef FUSE_BETA
    constexpr bool do_beta = true;
#else
    constexpr bool do_beta = false;
#endif
    const uint32_t num_reduce_tiles_per_block_h = get_arg(
        args::num_reduce_tiles_per_block_h);  // This value is the same for all cores, except ones that have
                                              // padding tiles in it. In that case, skip reduce for padding tiles.
    // Only the cores that gather reduce the gathered statistics. They alone read that reduction's
    // runtime arguments and touch its three buffers, so the distinction is a compile-time one and
    // everything the reduction needs lives inside it.
#ifdef IS_ALLGATHER_WORKER
    const uint32_t num_tiles_per_allgather_worker = get_arg(args::num_rows_per_all_to_all_worker);
    const bool use_two_stage_reduce = get_arg(args::use_two_stage_reduce) == 1;
    const bool is_second_stage_reader = get_arg(args::is_second_stage_reader) == 1;
    const uint32_t num_distributed_blocks = get_arg(args::num_distributed_blocks);

    const bool enable_sqrt = not(use_two_stage_reduce and not is_second_stage_reader);
#endif

    constexpr uint32_t dst0 = 0;
    constexpr uint32_t dst1 = 1;
    constexpr uint32_t scaler0 = 0;

    constexpr uint32_t dfb_in0 = dfb::in0;
    constexpr uint32_t dfb_eps = dfb::eps;
    constexpr uint32_t dfb_scaler_global = dfb::scaler_global;
#ifdef FUSE_GAMMA
    constexpr uint32_t dfb_gamma = dfb::gamma;
#endif
#ifdef FUSE_BETA
    constexpr uint32_t dfb_beta = dfb::beta;
#endif

    constexpr uint32_t dfb_ex2 = dfb::ex2;              // E[x^2]
    constexpr uint32_t dfb_ex_global = dfb::ex_global;  // E[x] global reduce
    constexpr uint32_t dfb_fusion = dfb::xmm;           // stream gamma/beta
    constexpr uint32_t dfb_out = dfb::out;
    constexpr uint32_t dfb_ex_sqr = dfb::x;  // E[x]^2
    // The statistics reduction and its three buffers exist only on the cores that gather.
#ifdef IS_ALLGATHER_WORKER
    constexpr uint32_t dfb_stats = dfb::stats;                  // gathered [E[x], E[x^2]] from every device
    constexpr uint32_t dfb_stats_reduced = dfb::stats_reduced;  // reduced statistics
    constexpr uint32_t dfb_var = dfb::var;                      // Var[x]
#endif

    DataflowBuffer dfb_in0_obj(dfb_in0);
    DataflowBuffer dfb_eps_obj(dfb_eps);
    DataflowBuffer dfb_scaler_global_obj(dfb_scaler_global);
#ifdef FUSE_GAMMA
    DataflowBuffer dfb_gamma_obj(dfb_gamma);
#endif
#ifdef FUSE_BETA
    DataflowBuffer dfb_beta_obj(dfb_beta);
#endif
    DataflowBuffer dfb_ex2_obj(dfb_ex2);
    DataflowBuffer dfb_ex_global_obj(dfb_ex_global);
    DataflowBuffer dfb_out_obj(dfb_out);
    DataflowBuffer dfb_ex_sqr_obj(dfb_ex_sqr);
#ifdef IS_ALLGATHER_WORKER
    DataflowBuffer dfb_stats_obj(dfb_stats);
    DataflowBuffer dfb_stats_reduced_obj(dfb_stats_reduced);
    DataflowBuffer dfb_var_obj(dfb_var);
#endif

#ifdef RMSNORM
    constexpr uint32_t stats_tiles = 1;
    constexpr uint32_t dfb_xmm = dfb_in0;  // x
#ifdef IS_ALLGATHER_WORKER
    constexpr uint32_t init_in_dfb = dfb_stats;
    constexpr uint32_t init_out_dfb = dfb_var;
#else
    constexpr uint32_t init_in_dfb = dfb_in0;
    constexpr uint32_t init_out_dfb = dfb_out;
#endif
#else
    constexpr uint32_t stats_tiles = 2;
    constexpr uint32_t dfb_xmm = dfb::xmm;  // x minus mean
#ifdef IS_ALLGATHER_WORKER
    constexpr uint32_t init_in_dfb = dfb_stats;
    constexpr uint32_t init_out_dfb = dfb_stats_reduced;
#else
    constexpr uint32_t init_in_dfb = dfb_in0;
    constexpr uint32_t init_out_dfb = dfb_out;
#endif
#endif
    compute_kernel_hw_startup(init_in_dfb, dfb_scaler_global, init_out_dfb);
    DataflowBuffer dfb_xmm_obj(dfb_xmm);

    // set block_h to volatile to disable automatically unroll of the loops, avoid code overflow
    const uint32_t block_h = (block_w == 1) ? block_h_volatile : block_h_const;
    const uint32_t subblock_w = (block_w <= 2) ? subblock_w_volatile : subblock_w_const;

    uint32_t index_subblock_w_offset = 0;
    uint32_t index_h_offset = 0;
    uint32_t index = 0;

    constexpr uint32_t dfb_im = (do_gamma || do_beta) ? dfb_ex_sqr : dfb_out;
    DataflowBuffer dfb_im_obj(dfb_im);
    constexpr uint32_t dfb_outgamma = do_beta ? dfb_fusion : dfb_out;
    DataflowBuffer dfb_outgamma_obj(dfb_outgamma);
    // Beta reads gamma's fusion output when gamma ran. Without gamma, fusion is
    // never packed (and on layer_norm it aliases xmm), so beta reads dfb_im.
    constexpr uint32_t dfb_beta_src = do_gamma ? dfb_fusion : dfb_im;
    DataflowBuffer dfb_beta_src_obj(dfb_beta_src);

    // global reduce over the gathered statistics
#ifdef IS_ALLGATHER_WORKER
    if (enable_sqrt) {
#ifdef RMSNORM
        dfb_var_obj.reserve_back(1);
#else
        dfb_stats_reduced_obj.reserve_back(1);
        dfb_ex2_obj.reserve_back(1);
#endif

        dfb_scaler_global_obj.wait_front(1);
        reconfig_data_format(dfb_scaler_global, dfb_stats);
        reduce_init<PoolType::AVG, ReduceDim::REDUCE_ROW>(dfb_stats, dfb_scaler_global, dfb_var);
        tile_regs_acquire();
        // striding over the statistics, consisting [E(X), E(X^2)] from all the distributed devices in interleaved
        // order. stats borrows the resident gathered-statistics shard: nothing pushes it, so index it directly and
        // never pop it (a pop with no matching post faults Quasar's hardware tile counters).
        for (uint32_t w = 0; w < stats_tiles * num_distributed_blocks; w++) {
            reduce_tile<PoolType::AVG, ReduceDim::REDUCE_ROW>(
                dfb_stats,
                dfb_scaler_global,
                w,
                scaler0,
                w % stats_tiles);  // reducing E(x) and E(x^2) separately to different dst
        }
        tile_regs_commit();
        tile_regs_wait();

#ifdef RMSNORM
        pack_tile(dst0, dfb_var);
#else
        pack_tile(dst0, dfb_stats_reduced);
        // Quasar: pack_reconfig_data_format only reprograms the packer format gasket; the packer's L1
        // destination (BFD) is set by pack_init. Retarget it before every pack-target switch, else pack_tile
        // keeps writing into the previously programmed buffer and the new one is never written (all-zero output).
#ifdef ARCH_QUASAR
        pack_init(dfb_ex2);
#endif
        pack_tile(dst1, dfb_ex2);
#endif
        tile_regs_release();
        reduce_uninit();
#ifdef RMSNORM
        dfb_var_obj.push_back(stats_tiles);
#else
        dfb_stats_reduced_obj.push_back(1);
        dfb_ex2_obj.push_back(1);
#endif

#ifndef RMSNORM
        // calculate var = E(x^2) - E(x)^2
        // E(x)^2
        reconfig_data_format(dfb_stats_reduced, dfb_stats_reduced);
#ifdef ARCH_QUASAR
        pack_init(dfb_ex_sqr);
#endif
        dfb_ex_sqr_obj.reserve_back(1);
        dfb_stats_reduced_obj.wait_front(1);
        tile_regs_acquire();
        mul_init(dfb_stats_reduced, dfb_stats_reduced);
        mul_tiles(dfb_stats_reduced, dfb_stats_reduced, 0, 0, dst0);  // first tile in stats is always E(x)
        tile_regs_commit();
        tile_regs_wait();
        pack_tile(dst0, dfb_ex_sqr);
        dfb_ex_sqr_obj.push_back(1);
        tile_regs_release();

        // E(x^2) - E(x)^2
        reconfig_data_format_srca(dfb_stats_reduced, dfb_ex2);
        reconfig_data_format_srcb(dfb_stats_reduced, dfb_ex_sqr);
        pack_reconfig_data_format(dfb_var);
#ifdef ARCH_QUASAR
        pack_init(dfb_var);
#endif
        dfb_ex2_obj.wait_front(1);
        dfb_ex_sqr_obj.wait_front(1);
        dfb_var_obj.reserve_back(1);
        tile_regs_acquire();
        sub_init(dfb_ex2, dfb_ex_sqr);
        sub_tiles(dfb_ex2, dfb_ex_sqr, 0, 0, dst0);
        tile_regs_commit();
        tile_regs_wait();
        pack_tile(dst0, dfb_var);
        dfb_var_obj.push_back(1);
        tile_regs_release();
        dfb_ex2_obj.pop_front(1);
        dfb_ex_sqr_obj.pop_front(1);
#endif

        // 1/[sqrt(Var + eps)],
        reconfig_data_format(dfb_var, dfb_eps);  // the Var[x] buffer holds the gathered stats for RMS norm
        pack_reconfig_data_format(dfb_stats_reduced);
#ifdef ARCH_QUASAR
        pack_init(dfb_stats_reduced);
#endif
        dfb_var_obj.wait_front(1);
        dfb_eps_obj.wait_front(1);
        dfb_stats_reduced_obj.reserve_back(1);

        add_init(dfb_var, dfb_eps);
        tile_regs_acquire();
        add_tiles(dfb_var, dfb_eps, 0, 0, dst0);
        tile_regs_wait();
        rsqrt_tile_init();
        rsqrt_tile(dst0);
        tile_regs_commit();
        tile_regs_wait();
        pack_tile(dst0, dfb_stats_reduced);
        tile_regs_release();
        dfb_var_obj.pop_front(1);
        dfb_eps_obj.pop_front(1);
        dfb_stats_reduced_obj.push_back(1);
    }
#endif

#ifndef RMSNORM
    // x - E[x]
    reconfig_data_format(dfb_in0, dfb_ex_global);
    pack_reconfig_data_format(dfb_xmm);
#ifdef ARCH_QUASAR
    pack_init(dfb_xmm);
#endif
    index_h_offset = 0;
    sub_bcast_cols_init(dfb_in0, dfb_ex_global);
    // in0 is the resident input shard (it borrows the input tensor): nothing pushes it, so read it by
    // absolute tile index and never pop it -- a pop with no matching post is tolerated by WH/BH but
    // faults Quasar's hardware tile counters (posted=0 acked=N).
    dfb_xmm_obj.reserve_back(num_tiles_per_block);
    for (uint32_t i = 0; i < block_h; i++) {
        index_subblock_w_offset = 0;
        dfb_ex_global_obj.wait_front(1);
        for (uint32_t j = 0; j < num_subblocks_w; j++) {
            tile_regs_acquire();
            for (uint32_t w = 0; w < subblock_w; w++) {
                index = w + index_subblock_w_offset + index_h_offset;
                sub_tiles_bcast_cols(dfb_in0, dfb_ex_global, index, 0, w);
            }
            tile_regs_commit();
            tile_regs_wait();
            for (uint32_t dst_i = 0; dst_i < subblock_w; dst_i++) {
                pack_tile(dst_i, dfb_xmm);
            }
            tile_regs_release();
            index_subblock_w_offset += subblock_w;
        }
        dfb_ex_global_obj.pop_front(1);
        index_h_offset += block_w;
    }
    dfb_xmm_obj.push_back(num_tiles_per_block);
#endif

    if constexpr (!do_gamma && !do_beta) {
        pack_reconfig_data_format(dfb_out);
    } else {
        pack_reconfig_data_format(dfb_im);
    }

    // (x - Ex) * 1/[sqrt(Var + eps)]
    reconfig_data_format(dfb_xmm, dfb_ex_global);
    mul_bcast_cols_init(dfb_xmm, dfb_ex_global);
    index_h_offset = 0;
#ifdef ARCH_QUASAR
    pack_init(dfb_im);
#endif
    dfb_im_obj.reserve_back(num_tiles_per_block);
#ifndef RMSNORM
    dfb_xmm_obj.wait_front(num_tiles_per_block);
#endif
    for (uint32_t i = 0; i < block_h; i++) {
        index_subblock_w_offset = 0;
        dfb_ex_global_obj.wait_front(1);
        for (uint32_t j = 0; j < num_subblocks_w; j++) {
            tile_regs_acquire();
            for (uint32_t w = 0; w < subblock_w; w++) {
                index = w + index_subblock_w_offset + index_h_offset;
                mul_tiles_bcast_cols(dfb_xmm, dfb_ex_global, index, 0, w);
            }
            tile_regs_commit();

            tile_regs_wait();
            for (uint32_t dst_i = 0; dst_i < subblock_w; dst_i++) {
                pack_tile(dst_i, dfb_im);
            }
            tile_regs_release();

            index_subblock_w_offset += subblock_w;
        }
        index_h_offset += block_w;
        dfb_ex_global_obj.pop_front(1);
    }
    dfb_im_obj.push_back(num_tiles_per_block);

#ifndef RMSNORM
    // RMSNorm reads x straight from the resident input shard (xmm aliases in0), which is never pushed and
    // so must not be popped.
    dfb_xmm_obj.pop_front(num_tiles_per_block);
#endif

#ifdef FUSE_GAMMA
    {
        // The intermediate tiles were packed and pushed above. Wait for them before the loop
        // below reads them back by tile index. The gamma stage is their only reader and pops them.
        dfb_im_obj.wait_front(num_tiles_per_block);
        reconfig_data_format(dfb_im, dfb_gamma);
        if constexpr (!do_beta) {
            pack_reconfig_data_format(dfb_out);
        }
        mul_bcast_rows_init(dfb_im, dfb_gamma);
        dfb_gamma_obj.wait_front(block_w);
        index_h_offset = 0;
#ifdef ARCH_QUASAR
        pack_init(dfb_outgamma);
#endif
        dfb_outgamma_obj.reserve_back(num_tiles_per_block);
        for (uint32_t i = 0; i < block_h; i++) {
            index_subblock_w_offset = 0;
            for (uint32_t j = 0; j < num_subblocks_w; j++) {
                tile_regs_acquire();
                for (uint32_t w = 0; w < subblock_w; w++) {
                    index = w + index_subblock_w_offset;
                    mul_tiles_bcast_rows(dfb_im, dfb_gamma, index + index_h_offset, index, w);
                }
                tile_regs_commit();
                tile_regs_wait();
                for (uint32_t dst_i = 0; dst_i < subblock_w; dst_i++) {
                    pack_tile(dst_i, dfb_outgamma);
                }
                tile_regs_release();
                index_subblock_w_offset += subblock_w;
                dfb_outgamma_obj.push_back(subblock_w);
            }
            index_h_offset += block_w;
        }
        dfb_im_obj.pop_front(num_tiles_per_block);
    }
#endif

#ifdef FUSE_BETA
    {
        dfb_beta_src_obj.wait_front(num_tiles_per_block);
        reconfig_data_format(dfb_beta_src, dfb_beta);
        pack_reconfig_data_format(dfb_out);
        add_bcast_rows_init(dfb_beta_src, dfb_beta);
        dfb_beta_obj.wait_front(block_w);
        index_h_offset = 0;
#ifdef ARCH_QUASAR
        pack_init(dfb_out);
#endif
        dfb_out_obj.reserve_back(num_tiles_per_block);
        for (uint32_t i = 0; i < block_h; i++) {
            index_subblock_w_offset = 0;
            for (uint32_t j = 0; j < num_subblocks_w; j++) {
                tile_regs_acquire();
                for (uint32_t w = 0; w < subblock_w; w++) {
                    index = w + index_subblock_w_offset;
                    add_tiles_bcast_rows(dfb_beta_src, dfb_beta, index + index_h_offset, index, w);
                }
                tile_regs_commit();
                tile_regs_wait();
                for (uint32_t i = 0; i < subblock_w; i++) {
                    pack_tile(i, dfb_out);
                }
                tile_regs_release();
                index_subblock_w_offset += subblock_w;
            }
            index_h_offset += block_w;
        }
        dfb_out_obj.push_back(num_tiles_per_block);
        dfb_beta_src_obj.pop_front(num_tiles_per_block);
    }
#endif

#ifdef IS_ALLGATHER_WORKER
    if (enable_sqrt) {
        // The global-reduce scaler tile is pushed once and read by tile index across the reductions
        // above without being popped. Pop it under the same guard that gated the wait, so the buffer
        // is left balanced on every core.
        dfb_scaler_global_obj.pop_front(1);
    }
#endif
#ifdef FUSE_GAMMA
    // Gamma is read by tile index across every row of the block, so it is waited once rather
    // than per row. Pop it here to balance the buffer.
    dfb_gamma_obj.pop_front(block_w);
#endif
#ifdef FUSE_BETA
    // Beta is read by tile index across every row of the block, so it is waited once rather
    // than per row. Pop it here to balance the buffer.
    dfb_beta_obj.pop_front(block_w);
#endif
}
