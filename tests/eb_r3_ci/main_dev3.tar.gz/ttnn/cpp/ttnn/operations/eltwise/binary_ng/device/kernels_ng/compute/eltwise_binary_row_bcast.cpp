// SPDX-FileCopyrightText: © 2025 Tenstorrent USA, Inc.
//
// SPDX-License-Identifier: Apache-2.0

#include <cstdint>

#include "api/compute/eltwise_unary/sfpu_split_includes.h"
#include "api/compute/eltwise_binary.h"
#include "api/compute/bcast.h"

#include "ttnn/operations/eltwise/binary_ng/device/kernels/compute/eltwise_utils_common.hpp"
#include "ttnn/operations/eltwise/binary_ng/device/kernels/compute/eltwise_utils.hpp"
#include "api/dataflow/circular_buffer.h"

void kernel_main() {
    uint32_t num_tiles = get_arg_val<uint32_t>(0);

    constexpr uint32_t num_tiles_per_cycle = get_compile_time_arg_val(0);
    constexpr auto cb_out = tt::CBIndex::c_2;
    CircularBuffer exp_cb_out(cb_out);

#if SRC_BCAST
    constexpr auto cb_bcast = tt::CBIndex::c_0;
    constexpr auto cb_llk_post = tt::CBIndex::c_5;
    constexpr auto cb_pre_lhs = cb_llk_post;
    constexpr auto cb_pre_rhs = tt::CBIndex::c_1;
    constexpr auto cb_post_lhs = HAS_ACTIVATIONS(LHS) ? tt::CBIndex::c_3 : cb_llk_post;
    constexpr auto cb_post_rhs = HAS_ACTIVATIONS(RHS) ? tt::CBIndex::c_4 : tt::CBIndex::c_1;
#endif
#if SRC_BCAST_B
    constexpr auto cb_bcast = tt::CBIndex::c_1;
    constexpr auto cb_llk_post = tt::CBIndex::c_6;
    constexpr auto cb_pre_lhs = tt::CBIndex::c_0;
    constexpr auto cb_pre_rhs = cb_llk_post;
    constexpr auto cb_post_lhs = HAS_ACTIVATIONS(LHS) ? tt::CBIndex::c_3 : tt::CBIndex::c_0;
    constexpr auto cb_post_rhs = HAS_ACTIVATIONS(RHS) ? tt::CBIndex::c_4 : cb_llk_post;
#endif

    CircularBuffer exp_cb_bcast(cb_bcast);
    CircularBuffer exp_cb_llk_post(cb_llk_post);
    CircularBuffer exp_cb_post_lhs(cb_post_lhs);
    CircularBuffer exp_cb_post_rhs(cb_post_rhs);

    compute_kernel_hw_startup(cb_post_lhs, cb_post_rhs, cb_out);
#ifdef PACK_RELU
    pack_relu_config(ReluConfig::zero());
#endif

    for (uint32_t tile_id = 0; tile_id < num_tiles; ++tile_id) {
        exp_cb_bcast.wait_front(num_tiles_per_cycle);
        exp_cb_llk_post.reserve_back(num_tiles_per_cycle);
        pack_reconfig_data_format(cb_out, cb_llk_post);
        reconfig_data_format(cb_bcast, cb_bcast);
        unary_bcast_init<BroadcastType::ROW>(cb_bcast);

        tile_regs_acquire();
        unary_bcast<BroadcastType::ROW>(cb_bcast, 0, 0);
        tile_regs_commit();

        tile_regs_wait();
        pack_tile(0, cb_llk_post);
        exp_cb_llk_post.push_back(num_tiles_per_cycle);
        tile_regs_release();
        exp_cb_bcast.pop_front(num_tiles_per_cycle);
        // unary_bcast_uninit<BroadcastType::ROW>(cb_bcast);
        pack_reconfig_data_format(cb_llk_post, cb_out);

        PREPROCESS(LHS, CircularBuffer(cb_pre_lhs), exp_cb_post_lhs, exp_cb_out, num_tiles_per_cycle);
        exp_cb_post_lhs.wait_front(num_tiles_per_cycle);

        PREPROCESS(RHS, CircularBuffer(cb_pre_rhs), exp_cb_post_rhs, exp_cb_out, num_tiles_per_cycle);
        exp_cb_post_rhs.wait_front(num_tiles_per_cycle);

        binary_tiles_init<true, BINARY_OP_TYPE>(cb_post_lhs, cb_post_rhs);
        exp_cb_out.reserve_back(num_tiles_per_cycle);

        tile_regs_acquire();
        BINARY_OP(cb_post_lhs, cb_post_rhs, 0, 0, 0);
        PROCESS_POST_ACTIVATIONS(0);
        tile_regs_commit();

        tile_regs_wait();
        pack_tile(0, cb_out);
        tile_regs_release();

        exp_cb_out.push_back(num_tiles_per_cycle);
        exp_cb_post_lhs.pop_front(num_tiles_per_cycle);
        exp_cb_post_rhs.pop_front(num_tiles_per_cycle);
    }
}
