// SPDX-FileCopyrightText: © 2025 Tenstorrent USA, Inc.
//
// SPDX-License-Identifier: Apache-2.0

#include <cstdint>
#include "api/compute/eltwise_unary/sfpu_split_includes.h"
#include "api/compute/eltwise_binary.h"
#include "api/compute/eltwise_unary/trigonometry.h"
#include "api/compute/bcast.h"

#include "ttnn/operations/eltwise/binary_ng/device/kernels/compute/eltwise_utils_common.hpp"
#include "ttnn/operations/eltwise/binary_ng/device/kernels/compute/eltwise_utils.hpp"
#include "api/dataflow/circular_buffer.h"

ALWI void process_tile(
    tt::CBIndex cb_pre_lhs,
    tt::CBIndex cb_post_lhs,
    tt::CBIndex cb_pre_rhs,
    tt::CBIndex cb_post_rhs,
    tt::CBIndex cb_out,
    uint32_t freq,
    uint32_t tile_start,
    uint32_t num_tiles_per_cycle) {
    using namespace ckernel;
    CircularBuffer exp_cb_out(cb_out);

#if BCAST_INPUT  // ROW_A_COL_B
#define CB_PRE_BCAST cb_pre_rhs
#define CB_POST_BCAST cb_post_rhs
#define CB_POST_OTHER cb_post_lhs
    constexpr auto cb_raw_other = tt::CBIndex::c_0;
    constexpr auto cb_llk_post = tt::CBIndex::c_5;
    auto cb_left = cb_post_lhs;
    auto cb_right = cb_post_rhs;
#else  // ROW_B_COL_A
#define CB_PRE_BCAST cb_pre_lhs
#define CB_POST_BCAST cb_post_lhs
#define CB_POST_OTHER cb_post_rhs
    constexpr auto cb_raw_other = tt::CBIndex::c_1;
    constexpr auto cb_llk_post = tt::CBIndex::c_6;
    auto cb_left = cb_post_lhs;
    auto cb_right = cb_post_rhs;
#endif

    CircularBuffer exp_cb_raw_other(cb_raw_other);
    CircularBuffer exp_cb_llk_post(cb_llk_post);
    CircularBuffer exp_cb_post_bcast(CB_POST_BCAST);
    CircularBuffer exp_cb_post_other(CB_POST_OTHER);

    PREPROCESS(BCAST_OP, CircularBuffer(CB_PRE_BCAST), exp_cb_post_bcast, exp_cb_out, num_tiles_per_cycle);
    exp_cb_post_bcast.wait_front(num_tiles_per_cycle);

    for (uint32_t j = tile_start; j < freq; ++j) {
        exp_cb_raw_other.wait_front(num_tiles_per_cycle);
        exp_cb_llk_post.reserve_back(num_tiles_per_cycle);
        pack_reconfig_data_format(cb_out, cb_llk_post);
        reconfig_data_format(cb_raw_other, cb_raw_other);
        unary_bcast_init<BroadcastType::ROW>(cb_raw_other);

        tile_regs_acquire();
        unary_bcast<BroadcastType::ROW>(cb_raw_other, 0, 0);
        tile_regs_commit();

        tile_regs_wait();
        pack_tile(0, cb_llk_post);
        exp_cb_llk_post.push_back(num_tiles_per_cycle);
        tile_regs_release();
        exp_cb_raw_other.pop_front(num_tiles_per_cycle);
        // unary_bcast_uninit<BroadcastType::ROW>(cb_raw_other);
        pack_reconfig_data_format(cb_llk_post, cb_out);

        PREPROCESS(OTHER_OP, CircularBuffer(cb_llk_post), exp_cb_post_other, exp_cb_out, num_tiles_per_cycle);
        exp_cb_post_other.wait_front(num_tiles_per_cycle);

        binary_tiles_init<true, BINARY_OP_TYPE>(cb_left, cb_right);
        exp_cb_out.reserve_back(num_tiles_per_cycle);

        tile_regs_acquire();
        BINARY_OP(cb_left, cb_right, 0, 0, 0);
        PROCESS_POST_ACTIVATIONS(0);
        tile_regs_commit();

        tile_regs_wait();
        pack_tile(0, cb_out);
        tile_regs_release();

        exp_cb_out.push_back(num_tiles_per_cycle);
        exp_cb_post_other.pop_front(num_tiles_per_cycle);
    }
    exp_cb_post_bcast.pop_front(num_tiles_per_cycle);
}

void kernel_main() {
    uint32_t num_tiles = get_arg_val<uint32_t>(0);
    uint32_t tile_freq = get_arg_val<uint32_t>(1);
    uint32_t tile_start = get_arg_val<uint32_t>(2);

    constexpr uint32_t num_tiles_per_cycle = get_compile_time_arg_val(0);

    if (num_tiles == 0) {
        return;
    }

    constexpr auto cb_out = tt::CBIndex::c_2;

#if BCAST_INPUT  // ROW_A_COL_B: A=row bcast, B=col bcast
    constexpr auto cb_llk_post = tt::CBIndex::c_5;
    constexpr auto cb_pre_lhs = cb_llk_post;
    constexpr auto cb_post_lhs = HAS_ACTIVATIONS(LHS) ? tt::CBIndex::c_3 : cb_llk_post;
    constexpr auto cb_pre_rhs = tt::CBIndex::c_1;
    constexpr auto cb_post_rhs = HAS_ACTIVATIONS(RHS) ? tt::CBIndex::c_4 : tt::CBIndex::c_1;
#else  // ROW_B_COL_A: B=row bcast, A=col bcast
    constexpr auto cb_llk_post = tt::CBIndex::c_6;
    constexpr auto cb_pre_lhs = tt::CBIndex::c_0;
    constexpr auto cb_post_lhs = HAS_ACTIVATIONS(LHS) ? tt::CBIndex::c_3 : tt::CBIndex::c_0;
    constexpr auto cb_pre_rhs = cb_llk_post;
    constexpr auto cb_post_rhs = HAS_ACTIVATIONS(RHS) ? tt::CBIndex::c_4 : cb_llk_post;
#endif

    compute_kernel_hw_startup(cb_post_lhs, cb_post_rhs, cb_out);
#ifdef PACK_RELU
    pack_relu_config(ReluConfig::zero());
#endif

    uint32_t complete_iterations = (num_tiles + tile_start) / tile_freq;
    uint32_t remaining_iterations = (num_tiles + tile_start) % tile_freq;

    for (uint32_t i = 0; i < complete_iterations; ++i, tile_start = 0) {
        process_tile(
            cb_pre_lhs, cb_post_lhs, cb_pre_rhs, cb_post_rhs, cb_out, tile_freq, tile_start, num_tiles_per_cycle);
    }

    if (remaining_iterations > 0) {
        process_tile(
            cb_pre_lhs,
            cb_post_lhs,
            cb_pre_rhs,
            cb_post_rhs,
            cb_out,
            remaining_iterations,
            tile_start,
            num_tiles_per_cycle);
    }
}
