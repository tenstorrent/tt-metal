// SPDX-FileCopyrightText: © 2026 Tenstorrent USA, Inc.
//
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include "experimental/llk_math_fast_untilize.h"
#include "sanitizer/api.h"

/*************************************************************************
 * LLK MATH FAST UNTILIZE (BH)
 *************************************************************************/

inline void llk_math_fast_untilize_init() {
    SAN_HOOK(unsupported());
    ckernel::_llk_math_fast_untilize_init_();
}

inline void llk_math_fast_untilize_init_skip_remap() {
    SAN_HOOK(unsupported());
    ckernel::_llk_math_fast_untilize_init_<false>();
}

template <bool is_fp32_dest_acc_en>
inline void llk_math_fast_untilize_block(const std::uint32_t dst_index, const std::uint32_t block_ct_dim) {
    SAN_HOOK(unsupported());
    ckernel::_llk_math_fast_untilize_block_<is_fp32_dest_acc_en>(dst_index, block_ct_dim);
}

inline void llk_math_fast_untilize_uninit() {
    SAN_HOOK(unsupported());
    ckernel::_llk_math_fast_untilize_uninit_();
}
