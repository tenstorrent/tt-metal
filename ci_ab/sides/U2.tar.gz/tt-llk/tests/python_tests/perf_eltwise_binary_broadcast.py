# SPDX-FileCopyrightText: © 2026 Tenstorrent AI ULC
# SPDX-License-Identifier: Apache-2.0

import pytest
from helpers.llk_params import DestAccumulation, DestSync, Transpose
from helpers.param_config import parametrize
from helpers.perf.core import ALL_PERF_RUN_TYPES
from test_eltwise_binary import (
    BFP4_PERF_MATH_OPS,
    _get_valid_math_fidelity,
    _run_eltwise_binary_test,
    get_base_perf_formats,
    get_bfp4_formats,
    get_eltwise_binary_math_ops,
    get_eltwise_binary_perf_acc_to_dest,
    get_eltwise_binary_perf_input_dimensions,
    get_eltwise_binary_perf_tile_dimensions,
    get_eltwise_binary_transpose,
)
from test_eltwise_binary_broadcast import ELTWISE_BINARY_BROADCAST_TYPES

PERF_LOOP_FACTOR = 32


@pytest.mark.perf
@parametrize(
    dest_acc=[DestAccumulation.No, DestAccumulation.Yes],
    dest_sync=[DestSync.Half],
    unpack_to_dest=[False],
    formats=get_base_perf_formats,
    broadcast_type=ELTWISE_BINARY_BROADCAST_TYPES,
    math_op=lambda formats: get_eltwise_binary_math_ops(formats, is_perf=True),
    math_fidelity=lambda formats, math_op: _get_valid_math_fidelity(formats, math_op),
    transpose_srca=get_eltwise_binary_transpose,
    tile_dimensions=get_eltwise_binary_perf_tile_dimensions,
    input_dimensions=get_eltwise_binary_perf_input_dimensions,
    acc_to_dest=get_eltwise_binary_perf_acc_to_dest,
    run_types=[ALL_PERF_RUN_TYPES],
    loop_factor=[PERF_LOOP_FACTOR],
    is_perf=[True],
)
def test_perf_eltwise_binary_broadcast(
    perf_report,
    dest_acc,
    dest_sync,
    unpack_to_dest,
    formats,
    broadcast_type,
    math_op,
    math_fidelity,
    transpose_srca,
    tile_dimensions,
    input_dimensions,
    acc_to_dest,
    run_types,
    loop_factor,
    is_perf,
):
    _run_eltwise_binary_test(
        dest_acc,
        dest_sync,
        unpack_to_dest,
        formats,
        broadcast_type,
        math_op,
        math_fidelity,
        transpose_srca,
        input_dimensions,
        tile_dimensions,
        acc_to_dest,
        run_types=run_types,
        loop_factor=loop_factor,
        is_perf=is_perf,
        perf_report=perf_report,
    )


@pytest.mark.perf
@parametrize(
    dest_acc=[DestAccumulation.No, DestAccumulation.Yes],
    dest_sync=[DestSync.Half],
    unpack_to_dest=[False],
    formats=lambda: get_bfp4_formats(),
    broadcast_type=ELTWISE_BINARY_BROADCAST_TYPES,
    math_op=BFP4_PERF_MATH_OPS,
    math_fidelity=lambda formats, math_op: _get_valid_math_fidelity(formats, math_op),
    transpose_srca=[Transpose.No],
    tile_dimensions=get_eltwise_binary_perf_tile_dimensions,
    input_dimensions=get_eltwise_binary_perf_input_dimensions,
    acc_to_dest=get_eltwise_binary_perf_acc_to_dest,
    run_types=[ALL_PERF_RUN_TYPES],
    loop_factor=[PERF_LOOP_FACTOR],
    is_perf=[True],
)
def test_perf_eltwise_binary_bfp4_b_broadcast(
    perf_report,
    dest_acc,
    dest_sync,
    unpack_to_dest,
    formats,
    broadcast_type,
    math_op,
    math_fidelity,
    transpose_srca,
    tile_dimensions,
    input_dimensions,
    acc_to_dest,
    run_types,
    loop_factor,
    is_perf,
):
    _run_eltwise_binary_test(
        dest_acc,
        dest_sync,
        unpack_to_dest,
        formats,
        broadcast_type,
        math_op,
        math_fidelity,
        transpose_srca,
        input_dimensions,
        tile_dimensions,
        acc_to_dest,
        run_types=run_types,
        loop_factor=loop_factor,
        is_perf=is_perf,
        perf_report=perf_report,
    )
