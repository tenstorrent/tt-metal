# SPDX-FileCopyrightText: © 2026 Tenstorrent AI ULC
#
# SPDX-License-Identifier: Apache-2.0

import pytest
from conftest import skip_for_blackhole, skip_for_quasar, skip_for_wormhole
from fuser.config_parser import FUSER_CONFIG_DIR, FuserConfigSchema
from fuser.sweep import collect_fuser_cases
from helpers.llk_params import PERF_RUN_TYPES_QUASAR

yaml_files = sorted(FUSER_CONFIG_DIR.glob("*.yaml"))
case_configs = collect_fuser_cases(yaml_files)


# https://github.com/tenstorrent/tt-llk/issues/1584
@skip_for_blackhole
@skip_for_wormhole
@skip_for_quasar
@pytest.mark.perf
@pytest.mark.parametrize(
    "run_type", PERF_RUN_TYPES_QUASAR[0], ids=lambda mode: mode.name
)
@pytest.mark.parametrize("case_name", case_configs)
def test_fuser(
    case_name,
    run_type,
    regenerate_cpp,
    testrun_uid,
):
    config = FuserConfigSchema.load(case_name, case_configs[case_name])
    config.global_config.regenerate_cpp = regenerate_cpp
    config.run_perf_test(run_type, session_id=testrun_uid)
