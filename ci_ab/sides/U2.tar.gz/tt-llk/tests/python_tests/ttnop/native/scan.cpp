// SPDX-FileCopyrightText: (c) 2026 Tenstorrent AI ULC
//
// SPDX-License-Identifier: Apache-2.0

// One pass over a kernel ELF's .text. Emits, as JSON on stdout:
//   - the kernel body range (where detour sites may live)
//   - the cave range (scratch space the injector may overwrite)
//   - which unpacker(s) the kernel actually loads with
//   - every candidate detour site
//
//   scan [--mode sync|all] <elf>

#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>

#include "elf32.h"
#include "tensix_isa.h"

namespace
{

struct Site
{
    std::uint32_t addr = 0;
    std::uint32_t word = 0;
    std::string op;
    bool sfpu = false;
};

struct Range
{
    std::uint32_t start = 0;
    std::uint32_t end   = 0;

    bool valid() const
    {
        return end > start;
    }
};

// The body is the run_kernel function: optimisation folds the LLK helpers into it.
// The symbol is C++-mangled, so match by substring. Use the largest match.
Range find_body(const ElfImage& elf)
{
    const Symbol* run_kernel = nullptr;
    for (const auto& [name, symbol] : elf.symbols)
    {
        if (symbol.type == STT_FUNC && symbol.size > 0 && name.find("run_kernel") != std::string::npos)
        {
            if (run_kernel == nullptr || symbol.size > run_kernel->size)
            {
                run_kernel = &symbol;
            }
        }
    }
    if (run_kernel == nullptr)
    {
        // Every LLK test kernel has one. Falling back to all of .text would sweep the
        // runtime as well, so say so instead of guessing at a body.
        die("no run_kernel symbol. This is not an LLK test kernel");
    }
    return {run_kernel->value, run_kernel->value + run_kernel->size};
}

// LLK links its kernel into a fixed 16K L1 region whose tail is unused, and .loader_init
// is the next section after that region, so its start doubles as the region bound.
Range find_cave(const ElfImage& elf)
{
    const auto etext       = elf.symbols.find("_etext");
    const auto loader_init = elf.symbols.find("__loader_init_start");
    if (etext != elf.symbols.end() && loader_init != elf.symbols.end())
    {
        const std::uint32_t start = (etext->second.value + 15u) & ~15u;
        if (loader_init->second.value > start)
        {
            return {start, loader_init->second.value};
        }
    }
    return {};
}

std::string tensix_op_name(std::uint32_t opcode)
{
    if (const char* name = sync_op_name(opcode))
    {
        return name;
    }
    if (opcode == TT_OP_SFPNOP)
    {
        return "SFPNOP";
    }
    if (opcode == TT_OP_SETADCXX)
    {
        return "SETADCXX";
    }
    char buffer[16];
    std::snprintf(buffer, sizeof(buffer), is_sfpu_opcode(opcode) ? "SFPU_0x%02x" : "TTI_0x%02x", opcode);
    return buffer;
}

struct ScanResult
{
    std::vector<Site> sites;
    std::uint32_t unpacker_mask = 0;
};

ScanResult scan_text(const ElfImage& elf, const Range& body, bool all_instructions)
{
    ScanResult result;
    const Elf32_Shdr& text         = elf.text().header;
    const std::uint32_t text_start = text.sh_addr;
    const std::uint32_t text_end   = text_start + text.sh_size;
    // Sites only come from the body. Its word count is a safe reserve size.
    result.sites.reserve((body.end - body.start) / 4u);

    // Start from the top of .text rather than the body so the replay-payload counter is
    // already correct by the time the body begins.
    std::uint32_t replay_payload = 0;
    int since_sfpu               = 1 << 20; // Tensix instructions since the last SFPU opcode
    for (std::uint32_t vaddr = text_start; vaddr + 4u <= text_end; vaddr += 4u)
    {
        const std::uint32_t word = elf.word_at(vaddr);
        const bool tensix        = is_tensix_word(word);

        // A replay buffer being loaded holds Tensix words that are recorded, not executed.
        // The compiler can interleave RISC-V in there, so only Tensix words count down.
        if (replay_payload > 0)
        {
            replay_payload -= tensix ? 1u : 0u;
            continue;
        }

        const bool in_body = vaddr >= body.start && vaddr < body.end;

        if (!tensix)
        {
            if (all_instructions && in_body && is_relocatable_riscv(word))
            {
                char buffer[16];
                std::snprintf(buffer, sizeof(buffer), "RV32_0x%02x", word & RISCV_OPCODE_MASK);
                result.sites.push_back({vaddr, word, buffer, false});
            }
            continue;
        }

        const std::uint32_t op     = rotate_right_2(word);
        const std::uint32_t opcode = (op >> TT_OP_OPCODE_SHIFT) & TT_OP_OPCODE_MASK;
        const std::uint32_t params = op & TT_OP_PARAMS_MASK;

        if (opcode == TT_OP_REPLAY && (params & TT_REPLAY_LOAD_MODE))
        {
            replay_payload = (params >> TT_REPLAY_LEN_SHIFT) & TT_REPLAY_LEN_MASK;
            continue;
        }
        // The census covers all of .text: the SETADCXX that programs a datum count may be
        // hoisted out of the body by the optimiser.
        if (opcode == TT_OP_SETADCXX)
        {
            result.unpacker_mask |= (params >> TT_SETADCXX_CNTSETMASK_SHIFT) & TT_SETADCXX_UNP_MASK;
        }

        since_sfpu = is_sfpu_opcode(opcode) ? 0 : since_sfpu + 1;

        if (!in_body || !is_detourable_tensix(opcode))
        {
            continue;
        }

        // Quasar: do not tag SFPU sites. auto would pack sfpnop (WH encoding /
        // STALLWAIT detect still not trusted here). tti_nop + risc_nop only.
#if defined(ARCH_QUASAR)
        const bool sfpu = false;
#else
        // Shared stalls like dest_section_flip() wait on SFPU with no SFPU code nearby,
        const bool sfpu = is_sfpu_opcode(opcode) || (opcode == TT_OP_STALLWAIT && stallwait_touches_sfpu(params) && since_sfpu <= 4);
#endif
        if (all_instructions || sync_op_name(opcode) != nullptr)
        {
            result.sites.push_back({vaddr, word, tensix_op_name(opcode), sfpu});
        }
    }
    return result;
}

void emit_json(const std::string& path, const ElfImage& elf, const Range& body, const Range& cave, const ScanResult& scanned, const char* mode)
{
    const Elf32_Shdr& text = elf.text().header;
    std::printf("{\n");
    std::printf("  \"elf\": \"%s\",\n", path.c_str());
    std::printf("  \"mode\": \"%s\",\n", mode);
    std::printf("  \"text\": {\"start\": %u, \"end\": %u},\n", text.sh_addr, text.sh_addr + text.sh_size);
    std::printf("  \"body\": {\"start\": %u, \"end\": %u},\n", body.start, body.end);
    if (cave.valid())
    {
        std::printf("  \"cave\": {\"start\": %u, \"limit\": %u},\n", cave.start, cave.end);
    }
    else
    {
        std::printf("  \"cave\": null,\n");
    }
    std::printf("  \"unpacker_mask\": %u,\n", scanned.unpacker_mask);
    // Published so the host never has to keep its own copy of these encodings.
    std::printf(
        "  \"fillers\": {\"tti_nop\": %u, \"sfpnop\": %u, \"unpacr0\": %u, \"unpacr1\": %u, "
        "\"risc_nop\": %u, \"pacr\": %u, \"pacr_cfg_set\": %u, \"pacr_cfg_clr\": %u},\n",
        FILLER_TTI_NOP,
        FILLER_SFPNOP,
        FILLER_UNPACR0,
        FILLER_UNPACR1,
        FILLER_RISC_NOP,
        FILLER_PACR,
        FILLER_PACR_CFG_SET,
        FILLER_PACR_CFG_CLR);
    std::printf("  \"sites\": [");
    for (std::size_t i = 0; i < scanned.sites.size(); ++i)
    {
        const Site& site = scanned.sites[i];
        std::printf(
            "%s\n    {\"index\": %zu, \"addr\": %u, \"word\": %u, \"op\": \"%s\", \"sfpu\": %s}",
            i ? "," : "",
            i,
            site.addr,
            site.word,
            site.op.c_str(),
            site.sfpu ? "true" : "false");
    }
    std::printf("%s]\n}\n", scanned.sites.empty() ? "" : "\n  ");
}

} // namespace

int main(int argc, char** argv)
{
    const char* mode = "sync";
    const char* path = nullptr;
    for (int i = 1; i < argc; ++i)
    {
        if (std::strcmp(argv[i], "--mode") == 0 && i + 1 < argc)
        {
            mode = argv[++i];
        }
        else
        {
            path = argv[i];
        }
    }
    if (path == nullptr || (std::strcmp(mode, "sync") != 0 && std::strcmp(mode, "all") != 0))
    {
        std::fprintf(stderr, "usage: scan [--mode sync|all] <elf>\n");
        return 2;
    }

    ElfImage elf;
    load_elf(path, elf);

    const Range cave      = find_cave(elf);
    const Range body      = find_body(elf);
    const ScanResult scan = scan_text(elf, body, std::strcmp(mode, "all") == 0);

    if (cave.valid() && cave.start >= body.start && cave.start < body.end)
    {
        die("cave overlaps the kernel body. A detour would corrupt live code");
    }
    emit_json(path, elf, body, cave, scan, mode);
    return 0;
}
