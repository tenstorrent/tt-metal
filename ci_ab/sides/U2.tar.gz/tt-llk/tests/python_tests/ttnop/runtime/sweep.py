# SPDX-FileCopyrightText: (c) 2026 Tenstorrent AI ULC
# SPDX-License-Identifier: Apache-2.0

"""Build and run the timing perturbation plan."""

import math
import os
from dataclasses import dataclass, field
from pathlib import Path

from cave import DEFAULT_MAX_DELAY, filler_choices

TTNOP_DIR = Path(__file__).resolve().parents[1]
# Every count up to the cave's capacity. A race often only opens inside a narrow
# band of delays, so sampling powers of two walks straight past it.
DEFAULT_DELAYS = f"1-{DEFAULT_MAX_DELAY}"
FILLER_NAMES = ("tti_nop", "sfpnop", "risc_nop", "pacr")
UNPACR_FILLERS = ("unpacr0", "unpacr1")


@dataclass(frozen=True)
class Variant:
    thread: str
    site: object
    filler: str
    filler_word: int
    delay: int
    # Position in the full plan, kept so a record can be put back in sweep order
    # after several workers have appended to one log.
    seq: int = 0

    def label(self) -> str:
        return f"{self.thread} {self.site.label()} n={self.delay} {self.filler}"


def parse_delays(spec: str) -> tuple:
    """Parse comma-separated delay counts and ranges.

    "1-100" is the sweep, "1,5,10,20,40,60,80,100" a coarse probe, and the two mix
    freely ("1-8,16,32").
    """
    delays = []
    for part in spec.split(","):
        part = part.strip()
        if not part:
            continue
        low, dash, high = part.partition("-")
        wanted = range(int(low, 0), int(high, 0) + 1) if dash else [int(low, 0)]
        delays.extend(delay for delay in wanted if delay not in delays)
    return tuple(delays)


def shard_from_env() -> tuple:
    """Which slice of the plan this process owns, as (shard, shards).

    Only a depth run splits a plan: it hands the same case to every xdist worker
    (pytest's parallel processes) and sets TTNOP_SHARD_VARIANTS, so worker N
    takes every Nth variant and the cores share one sweep.
    """
    if os.environ.get("TTNOP_SHARD_VARIANTS", "") in ("", "0"):
        return 0, 1
    worker = os.environ.get("PYTEST_XDIST_WORKER", "")
    # Index of this xdist worker (pytest's parallel process).
    if not worker.startswith("gw"):
        return 0, 1
    shard = int(worker[2:])
    shards = int(os.environ.get("PYTEST_XDIST_WORKER_COUNT", "1") or 1)
    # A shard outside the count would silently drop the variants ahead of it.
    return (shard, shards) if shard < shards else (0, 1)


@dataclass
class Config:
    site_mode: str = "sync"
    threads: tuple = ("unpack", "math")
    delays: tuple = field(default_factory=lambda: parse_delays(DEFAULT_DELAYS))
    max_delay: int = DEFAULT_MAX_DELAY
    filler: str = "auto"
    enable_unpacr_nop: bool = False
    selector: str = ""
    repeats: int = 1
    # Which slice of the plan this process runs, when the runner has put the same
    # case on every xdist worker. (0, 1) is the whole thing.
    shard: int = 0
    shards: int = 1
    # Freeze the stimuli and compare each variant's output against the baseline's.
    # Off restores the rolling RNG stream, which samples different data per variant
    # but leaves nothing to compare against.
    drift: bool = True
    arch: str = "wormhole"
    report_dir: Path = field(default_factory=lambda: TTNOP_DIR / "reports")

    @classmethod
    def from_env(cls):
        shard, shards = shard_from_env()
        config = cls(
            site_mode=os.environ.get("TTNOP_SITE_MODE", "sync").strip().lower(),
            threads=tuple(
                part.strip()
                for part in os.environ.get("TTNOP_THREADS", "unpack,math").split(",")
                if part.strip()
            ),
            delays=parse_delays(
                os.environ.get("TTNOP_DELAYS", "").strip() or DEFAULT_DELAYS
            ),
            max_delay=int(os.environ.get("TTNOP_MAX_DELAY", DEFAULT_MAX_DELAY)),
            filler=os.environ.get("TTNOP_FILLER", "auto").strip().lower(),
            enable_unpacr_nop=os.environ.get("TTNOP_ENABLE_UNPACR_NOP", "").strip()
            not in ("", "0"),
            selector=os.environ.get("TTNOP_SITES", "").strip(),
            repeats=int(os.environ.get("TTNOP_REPEATS", "1")),
            shard=shard,
            shards=shards,
            drift=os.environ.get("TTNOP_DRIFT", "1").strip() not in ("", "0"),
            arch=os.environ.get("CHIP_ARCH", "wormhole").strip().lower(),
            report_dir=Path(
                os.environ.get("TTNOP_REPORT_DIR", str(TTNOP_DIR / "reports"))
            ).resolve(),
        )
        if config.site_mode not in ("sync", "all"):
            raise ValueError(
                f"TTNOP_SITE_MODE must be sync or all, got {config.site_mode!r}"
            )
        unknown_threads = set(config.threads) - {"unpack", "math", "pack"}
        if not config.threads or unknown_threads:
            raise ValueError("TTNOP_THREADS must contain only unpack, math, or pack")
        if config.filler in UNPACR_FILLERS:
            raise ValueError(
                "TTNOP_FILLER cannot select UNPACR NOPs directly; "
                "use TTNOP_ENABLE_UNPACR_NOP=1"
            )
        if config.filler != "auto" and config.filler not in FILLER_NAMES:
            try:
                int(config.filler, 0)
            except ValueError:
                raise ValueError(
                    f"TTNOP_FILLER must be auto, a raw word, or one of {FILLER_NAMES}"
                ) from None
        if not config.delays:
            raise ValueError("TTNOP_DELAYS selected no counts")
        if config.repeats < 1:
            raise ValueError("TTNOP_REPEATS must be at least 1")
        out_of_range = [d for d in config.delays if not 0 <= d <= config.max_delay]
        if out_of_range:
            raise ValueError(
                f"delay(s) {out_of_range} outside 0..TTNOP_MAX_DELAY={config.max_delay}. "
                "raise TTNOP_MAX_DELAY to grow the cave"
            )
        return config

    @property
    def forced_filler(self):
        return None if self.filler == "auto" else self.filler


def plan(config: Config, scans: dict) -> list:
    """Expand the config into the ordered list of variants this process will try."""
    selected = {}
    for part in config.selector.split(",") if config.selector else ():
        thread, colon, index = part.strip().partition(":")
        if not thread or not colon or not index:
            raise ValueError("TTNOP_SITES entries must be thread:index")
        selected.setdefault(thread, set()).add(int(index, 0))
    missing = {thread: set(indices) for thread, indices in selected.items()}

    variants = []
    for thread in config.threads:
        scan = scans.get(thread)
        if scan is None or not scan.cave_start:
            continue
        wanted = selected.get(thread)
        if selected and wanted is None:
            continue
        for site in scan.sites:
            if wanted is not None and site.index not in wanted:
                continue
            if wanted is not None:
                missing[thread].discard(site.index)
            for name, word in filler_choices(
                thread,
                site,
                scan,
                config.forced_filler,
                config.enable_unpacr_nop,
            ):
                # A depth run needs its own control: delay 0 still detours through the
                # cave, so it separates "the jump broke it" from "the fillers broke it".
                delays = (0,) + config.delays if config.repeats > 1 else config.delays
                for delay in delays:
                    variants.append(
                        Variant(thread, site, name, word, delay, len(variants))
                    )
    # Worker N takes every Nth variant (not a consecutive chunk). Slow
    # high-delay counts then spread across workers instead of one worker
    # getting a whole site.
    unmatched = [
        f"{thread}:{index}"
        for thread, indices in missing.items()
        for index in sorted(indices)
    ]
    if unmatched:
        raise ValueError(
            f"TTNOP_SITES did not match {', '.join(unmatched)}. "
            "Indices depend on TTNOP_SITE_MODE."
        )
    return variants[config.shard :: config.shards]


class DeviceWedged(RuntimeError):
    """A variant hung the core and needs supervisor recovery."""


def run(config: Config, variants: list, runtime, record_sink) -> list:
    """Run every variant `repeats` times. Returns (label, tags) per recorded variant."""
    failing = []
    for variant in variants:
        attempts, fails, tags, first_error = 0, 0, set(), ""
        # A hang ends the case, so save its finding before the exception leaves.
        try:
            for _ in range(config.repeats):
                attempts += 1
                tag, error = runtime.run(variant)
                if tag is None:
                    continue
                fails += 1
                tags.add(tag)
                first_error = first_error or error
                if tag == "hang":
                    raise DeviceWedged(variant.label())
        finally:
            if fails:
                failing.append((f"{variant.label()} {','.join(sorted(tags))}", tags))
                record_sink(variant, attempts, fails, tags, first_error)
    return failing


def same_elements(before, after):
    """Elementwise equality, with NaN counted as equal to itself.

    Two runs of the same kernel on the same stimuli put the same NaN in the same
    place. Plain `==` calls that a difference, which would report drift against
    every test whose golden contains one.
    """
    if before.is_floating_point():
        return (before == after) | (before.isnan() & after.isnan())
    return before == after


def describe_drift(before: list, after: list):
    """How `after` differs from `before`.

    Returns (message, pcc). Message is "" when the two runs agree exactly
    """
    if len(before) != len(after):
        return f"{len(after)} device run(s) against the baseline's {len(before)}", None
    for base, now in zip(before, after):
        if base is None and now is None:
            continue
        if base is None or now is None or base.shape != now.shape:
            return "result buffer changed shape or vanished", None
        same = same_elements(base, now)
        if bool(same.all()):
            continue
        moved = f"{int((~same).sum())} of {base.numel()} element(s)"
        try:
            from helpers.utils import calculate_pcc

            pcc = float(calculate_pcc(now, base))
            gap = (base.double() - now.double()).abs().max().item()
            if not math.isfinite(pcc):
                # Constant tensors have no correlation to report
                raise ValueError("pcc is not finite")
        except Exception:
            # PCC is optional. A scoring error should not hide the drift.
            return f"output changed vs baseline: {moved}", None
        return (
            f"output changed vs baseline: pcc={pcc:.6f} (Δ {1.0 - pcc:.2g}), "
            f"{moved}, max |delta|={gap:g}",
            pcc,
        )
    return "", None
