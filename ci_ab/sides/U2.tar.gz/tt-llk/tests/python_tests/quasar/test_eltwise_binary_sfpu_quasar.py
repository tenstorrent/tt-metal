# SPDX-FileCopyrightText: © 2026 Tenstorrent AI ULC
# SPDX-License-Identifier: Apache-2.0

import struct
from typing import List

import pytest
import torch
from helpers.format_config import DataFormat
from helpers.golden_generators import (
    BinarySFPUGolden,
    BroadcastGolden,
    get_golden_generator,
)
from helpers.llk_params import (
    ApproximationMode,
    BroadcastType,
    DataCopyType,
    DestAccumulation,
    DstRoundingMode,
    MathOperation,
    PerfRunType,
    UnpackerEngine,
    format_dict,
)
from helpers.param_config import (
    InputOutputFormat,
    generate_quasar_sfpu_format_variants,
    input_output_formats,
    parametrize,
    resolve_quasar_sfpu_variant,
    runtime,
)
from helpers.perf.core import create_test_or_perf_config
from helpers.stimuli_config import StimuliConfig
from helpers.stimuli_generator import (
    StimuliSpec,
    apply_log_uniform_magnitudes,
    compute_safe_input_magnitude_range,
    format_elem_max,
    generate_stimuli,
)
from helpers.test_variant_parameters import (
    APPROX_MODE,
    BROADCAST_TYPE,
    DATA_COPY_TYPE,
    DEST_INDEX,
    DEST_SYNC,
    LOOP_FACTOR,
    NUM_FACES,
    SFPU_BINARY_OP,
    SFPU_DST_ROUNDING_MODE,
    SFPU_TILE_INDICES,
    SIGN_MAGNITUDE_FORMAT,
    TEST_FACE_DIMS,
    TILE_COUNT,
    TYPECAST_FORMATS,
    UNPACKER_ENGINE_SEL,
    ZERO_POINT,
)
from helpers.tile_constants import MAX_NUM_FACES, MAX_TILE_ELEMENTS
from helpers.utils import passed_test


@pytest.fixture(autouse=True)
def _seed_rng():
    """Seed the RNG once per test so stimuli are deterministic across runs."""
    torch.manual_seed(42)


_CPP_SOURCE = "sources/quasar/eltwise_binary_sfpu_quasar_test.cpp"

# Shared (src0_idx, src1_idx, dst_idx) tile-index variants exercised by every
# binary SFPU family
_TILE_INDEX_VARIANTS = [(0, 1, 0), (2, 3, 0)]
DEFAULT_SFPU_BINARY_TILE_INDICES = _TILE_INDEX_VARIANTS[0]


def _stage_binary_operands(op0_flat, op1_flat, tile_indices, dtype):
    """Lay two binary operands into a TILE_CNT-tile buffer_A so buffer_A[i] maps
    to Dest[i]: op0 at tile src0_idx, op1 at tile src1_idx, gaps zero-filled.
    The kernel writes the result to Dest[dst_idx], which may alias an operand
    tile (e.g. (0, 1, 0)) or be disjoint (e.g. (2, 3, 0)). Shared by the max/min
    (float/int) and quant (raw-int32) families."""
    src0_idx, src1_idx, dst_idx = tile_indices
    tile_cnt = max(src0_idx, src1_idx, dst_idx) + 1

    def _pad_to_tile(flat):
        if len(flat) < MAX_TILE_ELEMENTS:
            return torch.cat(
                [flat, torch.zeros(MAX_TILE_ELEMENTS - len(flat), dtype=dtype)]
            )
        return flat

    tiles = [torch.zeros(MAX_TILE_ELEMENTS, dtype=dtype) for _ in range(tile_cnt)]
    tiles[src0_idx] = _pad_to_tile(op0_flat.flatten())
    tiles[src1_idx] = _pad_to_tile(op1_flat.flatten())
    return torch.cat(tiles), tile_cnt


def _run_sfpu_binary_llk_golden(
    formats,
    dest_acc,
    tile_indices,
    mathop,
    binary_op,
    prepare_stimuli,
    post_check=None,
    *,
    approx_mode=ApproximationMode.No,
    run_types=(PerfRunType.L1_TO_L1,),
    loop_factor=1,
    is_perf=False,
    perf_report=None,
    dst_rounding_mode=DstRoundingMode.Default,
    format_variant=None,
    max_ulp=None,
    broadcast_type=BroadcastType.None_,
):
    """Shared driver for the LLK-golden binary SFPU ops.

    ``prepare_stimuli(formats, input_dimensions, src0_idx, src1_idx, mathop)``
    returns ``(src_A, tile_cnt_A, src_B)``; both operands live in ``src_A`` at
    tiles ``src0_idx`` / ``src1_idx``. ``post_check(res_tensor)`` is an optional
    extra assertion (e.g. div's x/x special-case lanes). ``broadcast_type``
    broadcasts the ``src1_idx`` tile in the golden.
    """
    src0_idx, src1_idx, dst_idx = tile_indices
    input_dimensions = [(max(src0_idx, src1_idx, dst_idx) + 1) * 32, 32]
    num_faces = MAX_NUM_FACES

    src_A, tile_cnt_A, src_B = prepare_stimuli(
        formats, input_dimensions, src0_idx, src1_idx, mathop
    )

    golden_input = src_A
    if broadcast_type != BroadcastType.None_:
        golden_input = src_A.flatten().clone()
        src1_start = src1_idx * MAX_TILE_ELEMENTS
        src1_tile = golden_input[src1_start : src1_start + MAX_TILE_ELEMENTS]
        generate_broadcast = get_golden_generator(BroadcastGolden)
        golden_input[src1_start : src1_start + MAX_TILE_ELEMENTS] = generate_broadcast(
            broadcast_type, src1_tile, formats.input_format
        ).to(golden_input.dtype)

    generate_golden = get_golden_generator(BinarySFPUGolden)
    golden_full = generate_golden(
        mathop,
        golden_input,
        src0_idx,
        src1_idx,
        dst_idx,
        32,
        input_dimensions,
        formats.input_format,
    ).flatten()
    dst_start = dst_idx * MAX_TILE_ELEMENTS
    torch_format_out = format_dict[formats.output_format]
    golden_tensor = golden_full[dst_start : dst_start + MAX_TILE_ELEMENTS].to(
        torch_format_out
    )

    if is_perf and perf_report is None:
        raise ValueError("perf_report must be provided when is_perf=True")

    unpack_to_dest = (
        format_variant.unpack_to_dest if format_variant is not None else True
    )
    test_config_kwargs = {
        "test_name": _CPP_SOURCE,
        "formats": formats,
        "templates": [
            SFPU_BINARY_OP(binary_op),
            APPROX_MODE(approx_mode),
            DATA_COPY_TYPE(DataCopyType.A2D),
            UNPACKER_ENGINE_SEL(
                UnpackerEngine.UnpDest if unpack_to_dest else UnpackerEngine.UnpA
            ),
            DEST_SYNC(),
            # 2's-complement datapath (default); only the quant family reads this.
            SIGN_MAGNITUDE_FORMAT(False),
            SFPU_DST_ROUNDING_MODE(dst_rounding_mode),
            # The shared unary-SFPU dispatch in sfpu_operations_quasar.h has a typecast
            # branch that references the non-dependent globals TYPECAST_IN_FORMAT /
            # TYPECAST_OUT_FORMAT, so every build that includes it must define them.
            TYPECAST_FORMATS(),
            BROADCAST_TYPE(broadcast_type),
        ],
        "runtimes": [
            TILE_COUNT(tile_cnt_A),
            NUM_FACES(num_faces),
            TEST_FACE_DIMS(),
            DEST_INDEX(0),
            SFPU_TILE_INDICES(src0_idx, src1_idx, dst_idx),
            LOOP_FACTOR(loop_factor),
            ZERO_POINT(0),
        ],
        "variant_stimuli": StimuliConfig(
            src_A,
            formats.input_format,
            src_B,
            formats.input_format,
            formats.output_format,
            tile_count_A=tile_cnt_A,
            tile_count_B=tile_cnt_A,
            tile_count_res=1,
            num_faces=num_faces,
            twos_complement=formats.input_format.is_integer(),
        ),
        "unpack_to_dest": unpack_to_dest,
        "dest_acc": dest_acc,
    }

    configuration = create_test_or_perf_config(
        is_perf=is_perf,
        run_types=run_types,
        test_config_kwargs=test_config_kwargs,
    )
    if format_variant is not None:
        format_variant.apply_formats(configuration.formats_config)
    if is_perf:
        configuration.run(perf_report)
        return

    res_from_L1 = configuration.run().result
    assert len(res_from_L1) == len(golden_tensor)
    res_tensor = torch.tensor(res_from_L1, dtype=torch_format_out)
    assert passed_test(
        golden_tensor, res_tensor, formats.output_format, max_ulp=max_ulp
    )

    if broadcast_type != BroadcastType.None_ and mathop != MathOperation.SfpuElwmul:
        # isclose ignores the sign of zero. MUL is skipped: SFPMUL adds +0.0, so
        # x * -0.0 is +0.0 on hardware (as for the plain binary MUL).
        zero = golden_tensor == 0
        assert torch.equal(
            torch.signbit(res_tensor[zero]), torch.signbit(golden_tensor[zero])
        ), "binary_bcast lost the sign of a zero result"

    if post_check is not None:
        post_check(res_tensor)


# ===========================================================================
# Family 1 — integer ops (add, mul, gt, lt, le, ge, copy_dest, gcd, lcm), Int32 only.
# Ported from test_sfpu_binary_quasar.py.
# ===========================================================================
# lcm contract: |a|, |b| <= 2^15 - 1.
_LCM_MAX_OPERAND = 32767


def _prepare_lcm_stimuli(input_dimensions):
    """Uniform in-contract lcm operands; sfpu_int32_lcm_pairs_*.yaml cover the edge pairs."""
    spec = StimuliSpec.uniform(
        low=float(-_LCM_MAX_OPERAND), high=float(_LCM_MAX_OPERAND)
    )
    src_A, tile_cnt_A, src_B, _ = generate_stimuli(
        stimuli_format_A=DataFormat.Int32,
        input_dimensions_A=input_dimensions,
        stimuli_format_B=DataFormat.Int32,
        input_dimensions_B=input_dimensions,
        spec_A=spec,
        spec_B=spec,
    )
    return src_A, tile_cnt_A, src_B


def _prepare_int_stimuli(
    formats, input_dimensions, src0_idx, src1_idx, mathop, clamp_inputs
):
    """Integer stimuli: uniform over the dtype range, optionally clamped (int MUL
    clamps to keep the product representable). Both operands live in src_A."""
    if mathop == MathOperation.SfpuLcm:
        return _prepare_lcm_stimuli(input_dimensions)
    data_format = formats.input_format
    iinfo = torch.iinfo(format_dict[data_format])
    spec = StimuliSpec.uniform(low=float(iinfo.min), high=float(iinfo.max - 1))
    src_A, tile_cnt_A, src_B, _ = generate_stimuli(
        stimuli_format_A=data_format,
        input_dimensions_A=input_dimensions,
        stimuli_format_B=data_format,
        input_dimensions_B=input_dimensions,
        spec_A=spec,
        spec_B=spec,
    )
    if clamp_inputs is not None:
        src_A = torch.clamp(src_A, -clamp_inputs, clamp_inputs)
        src_B = torch.clamp(src_B, -clamp_inputs, clamp_inputs)
    return src_A, tile_cnt_A, src_B


_INT31_MAX = 2**31 - 1

_INT_CLAMP = {
    MathOperation.SfpuElwmulInt: 1000,
    MathOperation.SfpuGcd: _INT31_MAX,
}

# Shared with perf_eltwise_binary_sfpu_quasar.py. tile_indices stays functional-only.
INT_SWEEP = dict(
    formats=input_output_formats([DataFormat.Int32], same=True),
    dest_acc=[DestAccumulation.Yes],
    mathop=[
        MathOperation.SfpuElwadd,
        MathOperation.SfpuElwmulInt,
        MathOperation.SfpuElwGt,
        MathOperation.SfpuElwLt,
        MathOperation.SfpuElwLe,
        MathOperation.SfpuElwGe,
        MathOperation.SfpuCopyDest,
        MathOperation.SfpuGcd,
        MathOperation.SfpuLcm,
    ],
)


@pytest.mark.quasar
@parametrize(
    **INT_SWEEP,
    tile_indices=runtime(_TILE_INDEX_VARIANTS),
)
def test_eltwise_binary_sfpu_int_quasar(
    formats,
    dest_acc,
    mathop,
    tile_indices,
    *,
    approx_mode=ApproximationMode.No,
    run_types=(PerfRunType.L1_TO_L1,),
    loop_factor=1,
    is_perf=False,
    perf_report=None,
):
    """Binary SFPU integer ops (add, mul, gt, lt, le, ge, copy_dest, gcd, lcm), Int32."""
    binary_op = mathop.cpp_enum_value
    # GCD excludes INT_MIN: SFPABS saturates it.
    clamp_inputs = _INT_CLAMP.get(mathop)
    _run_sfpu_binary_llk_golden(
        formats,
        dest_acc,
        tile_indices,
        mathop,
        binary_op,
        prepare_stimuli=lambda f, dims, s0, s1, op: _prepare_int_stimuli(
            f, dims, s0, s1, op, clamp_inputs
        ),
        approx_mode=approx_mode,
        run_types=run_types,
        loop_factor=loop_factor,
        is_perf=is_perf,
        perf_report=perf_report,
    )


# ===========================================================================
# Family 2 — float ops (add, sub, mul, div, atan2, copy_dest). Ported from test_sfpu_binary_float_quasar.py.
# add/sub route the SFPU calculate_sfpu_binary ADD/SUB path (tenstorrent/tt-metal#49883).
# Operand/result tile-index variants exercise result-over-operand aliasing.
# ===========================================================================
# Crafted lanes in face 0 exercising the div special-case branches.
_DIV_SPECIAL_CASE_LANES = [
    (0, 0.0, 0.0, "nan"),
    (1, 1.5, 0.0, "pos_inf"),
    (2, -1.5, 0.0, "neg_inf"),
    (3, 2.7, 2.7, "one"),
    (4, -3.3, -3.3, "one"),
]


def _get_valid_float_formats_dest_acc():
    """Resolve all executable float binary format and path variants."""
    formats = input_output_formats(
        [DataFormat.Float16, DataFormat.Float16_b, DataFormat.Float32]
    )
    return generate_quasar_sfpu_format_variants(MathOperation.SfpuElwadd, formats)


def _prepare_float_inputs(src_A, data_format, src0_idx, src1_idx, mathop):
    """Map [0,1) uniform stimuli into op-appropriate ranges (div: ±[0.25,4] + special
    lanes; atan2: ±5; add/sub/mul: ±250)."""
    torch_format = format_dict[data_format]
    if mathop == MathOperation.SfpuAtan2:
        # atan2(y, x): y = tile src0_idx, x = tile src1_idx. Signed ±5 gives mixed
        # signs on both operands, so all four quadrants and the |y| >= |x| / x < 0
        # branches are exercised; the minimax approximation is matched under PCC.
        scaled = ((src_A.to(torch.float32) - 0.5) * 10.0).to(torch_format)
        return scaled.flatten().reshape(scaled.shape)
    if mathop == MathOperation.SfpuElwdiv:
        scaled = (src_A.to(torch.float32) - 0.5) * 8.0
        sign = torch.where(scaled >= 0, torch.tensor(1.0), torch.tensor(-1.0))
        abs_scaled = torch.maximum(scaled.abs(), torch.tensor(0.25))
        scaled = (sign * abs_scaled).to(torch_format)
        flat = scaled.flatten()
        for lane, dividend, divisor, _ in _DIV_SPECIAL_CASE_LANES:
            flat[src0_idx * MAX_TILE_ELEMENTS + lane] = dividend
            flat[src1_idx * MAX_TILE_ELEMENTS + lane] = divisor
        return flat.reshape(scaled.shape)
    # SfpuElwadd / SfpuElwsub / SfpuElwmul / SfpuCopyDest — symmetric ±250 range.
    scaled = ((src_A.to(torch.float32) - 0.5) * 500.0).to(torch_format)
    return scaled.flatten().reshape(scaled.shape)


def _prepare_float_stimuli(formats, input_dimensions, src0_idx, src1_idx, mathop):
    """Float stimuli: uniform [0,1) mapped to op-appropriate ranges by
    _prepare_float_inputs (div: ±[0.25,4] + special lanes; atan2: ±5;
    add/sub/mul: ±250)."""
    spec = StimuliSpec.uniform(low=0.0, high=1.0)
    src_A, tile_cnt_A, src_B, _ = generate_stimuli(
        stimuli_format_A=formats.input_format,
        input_dimensions_A=input_dimensions,
        stimuli_format_B=formats.input_format,
        input_dimensions_B=input_dimensions,
        spec_A=spec,
        spec_B=spec,
    )
    src_A = _prepare_float_inputs(
        src_A, formats.input_format, src0_idx, src1_idx, mathop
    )
    return src_A, tile_cnt_A, src_B


def _check_div_special_cases(res_tensor):
    """The kernel's x/x branch forces an exact 1.0 regardless of reciprocal
    rounding — verify the 'one' special-case lanes."""
    for lane, _, _, kind in _DIV_SPECIAL_CASE_LANES:
        if kind != "one":
            continue
        actual = res_tensor[lane].item()
        assert (
            actual == 1.0
        ), f"x/x special case at lane {lane}: expected 1.0, got {actual}"


_DIV_FP32_MAX_ULP = 4

_FLOAT_VARIANTS = _get_valid_float_formats_dest_acc()
_FLOAT_MATHOPS = [
    MathOperation.SfpuElwadd,
    MathOperation.SfpuElwsub,
    MathOperation.SfpuElwmul,
    MathOperation.SfpuElwdiv,
    MathOperation.SfpuAtan2,
    MathOperation.SfpuCopyDest,
]


def _dest_acc_for_float_formats(formats):
    dest_accs = []
    seen = set()
    for variant in _FLOAT_VARIANTS:
        same_io = (
            variant.formats.input_format == formats.input_format
            and variant.formats.output_format == formats.output_format
        )
        if same_io and variant.dest_acc not in seen:
            seen.add(variant.dest_acc)
            dest_accs.append(variant.dest_acc)
    return dest_accs


def _approx_modes_for_mathop(mathop):
    if mathop in (MathOperation.SfpuAtan2, MathOperation.SfpuElwdiv):
        return [ApproximationMode.No, ApproximationMode.Yes]
    return [ApproximationMode.No]


FLOAT_SWEEP = dict(
    formats=[variant.formats for variant in _FLOAT_VARIANTS],
    dest_acc=_dest_acc_for_float_formats,
    mathop=_FLOAT_MATHOPS,
    approx_mode=_approx_modes_for_mathop,
)


@pytest.mark.quasar
@parametrize(
    **FLOAT_SWEEP,
    tile_indices=runtime(_TILE_INDEX_VARIANTS),
)
def test_eltwise_binary_sfpu_float_quasar(
    formats,
    dest_acc,
    mathop,
    approx_mode,
    tile_indices,
    *,
    run_types=(PerfRunType.L1_TO_L1,),
    loop_factor=1,
    is_perf=False,
    perf_report=None,
):
    """Binary SFPU float ops (add, sub, mul, div, atan2, copy_dest)."""
    format_variant = resolve_quasar_sfpu_variant(
        MathOperation.SfpuElwadd, formats, dest_acc
    )
    assert (
        format_variant is not None
    ), f"no Quasar SFPU route for {formats} dest_acc={dest_acc}"
    binary_op = mathop.cpp_enum_value
    post_check = (
        _check_div_special_cases if mathop == MathOperation.SfpuElwdiv else None
    )
    # A 32-bit Dest DIV runs two Newton-Raphson steps in every approximation mode; the
    # default 5% tolerance would also pass the bare LUT seed, so gate it by ULP instead.
    max_ulp = (
        _DIV_FP32_MAX_ULP
        if mathop == MathOperation.SfpuElwdiv
        and formats.output_format == DataFormat.Float32
        else None
    )
    _run_sfpu_binary_llk_golden(
        formats,
        dest_acc,
        tile_indices,
        mathop,
        binary_op,
        prepare_stimuli=_prepare_float_stimuli,
        post_check=post_check,
        approx_mode=approx_mode,
        run_types=run_types,
        loop_factor=loop_factor,
        is_perf=is_perf,
        perf_report=perf_report,
        format_variant=format_variant,
        max_ulp=max_ulp,
    )


# ===========================================================================
# Broadcast float ops (add, sub, mul) with src1 col 0 (COL) or row 0 (ROW).
# ===========================================================================
BCAST_SWEEP = dict(
    formats=[variant.formats for variant in _FLOAT_VARIANTS],
    dest_acc=_dest_acc_for_float_formats,
    mathop=[
        MathOperation.SfpuElwadd,
        MathOperation.SfpuElwsub,
        MathOperation.SfpuElwmul,
    ],
    broadcast_type=[BroadcastType.Column, BroadcastType.Row],
)
# (0, 1, 1): the result overwrites the bcast tile, so bcast loads must precede the
# band's store. Two layouts keep the matrix under 100 cases.
_BCAST_TILE_INDEX_VARIANTS = [(2, 3, 0), (0, 1, 1)]
_BCAST_SPECIALS = [float("inf"), float("-inf"), float("nan")]
_BCAST_NEG_ZERO_STRIDE = 4


def _inject_bcast_specials(src_A, src0_idx, src1_idx, broadcast_type):
    """Fill the cells the broadcast ignores with Inf/NaN (must not leak) and put
    -0.0 at bcast x data crossings, where ADD must return -0.0."""
    flat = src_A.flatten().clone()
    base = src1_idx * MAX_TILE_ELEMENTS
    data_base = src0_idx * MAX_TILE_ELEMENTS
    face_elems = 16 * 16
    for face in range(MAX_NUM_FACES):
        for r in range(16):
            for c in range(16):
                tile_r = (face // 2) * 16 + r
                tile_c = (face % 2) * 16 + c
                is_col = broadcast_type == BroadcastType.Column
                ignored = tile_c != 0 if is_col else tile_r != 0
                offset = face * face_elems + r * 16 + c
                if (tile_c if is_col else tile_r) % _BCAST_NEG_ZERO_STRIDE == 1:
                    flat[data_base + offset] = -0.0
                idx = base + offset
                if ignored:
                    flat[idx] = _BCAST_SPECIALS[
                        (tile_r + tile_c) % len(_BCAST_SPECIALS)
                    ]
                elif (tile_r + tile_c) % _BCAST_NEG_ZERO_STRIDE == 1:
                    flat[idx] = -0.0
    return flat.reshape(src_A.shape)


@pytest.mark.quasar
@parametrize(
    **BCAST_SWEEP,
    tile_indices=runtime(_BCAST_TILE_INDEX_VARIANTS),
)
def test_eltwise_binary_sfpu_bcast_quasar(
    formats,
    dest_acc,
    mathop,
    broadcast_type,
    tile_indices,
    *,
    run_types=(PerfRunType.L1_TO_L1,),
    loop_factor=1,
    is_perf=False,
    perf_report=None,
):
    """Binary SFPU float ADD / SUB / MUL with src1 column or row broadcast."""
    format_variant = resolve_quasar_sfpu_variant(
        MathOperation.SfpuElwadd, formats, dest_acc
    )
    assert (
        format_variant is not None
    ), f"no Quasar SFPU route for {formats} dest_acc={dest_acc}"
    binary_op = mathop.cpp_enum_value

    def prepare_stimuli(formats, input_dimensions, src0_idx, src1_idx, mathop):
        src_A, tile_cnt_A, src_B = _prepare_float_stimuli(
            formats, input_dimensions, src0_idx, src1_idx, mathop
        )
        src_A = _inject_bcast_specials(src_A, src0_idx, src1_idx, broadcast_type)
        return src_A, tile_cnt_A, src_B

    _run_sfpu_binary_llk_golden(
        format_variant.formats,
        format_variant.dest_acc,
        tile_indices,
        mathop,
        binary_op,
        prepare_stimuli=prepare_stimuli,
        run_types=run_types,
        loop_factor=loop_factor,
        is_perf=is_perf,
        perf_report=perf_report,
        format_variant=format_variant,
        broadcast_type=broadcast_type,
    )


_BF16_ADD_SUB_OPS = [
    ("ADD", MathOperation.SfpuElwadd),
    ("SUB", MathOperation.SfpuElwsub),
]

BF16_RNE_SWEEP = dict(
    binary_op_mathop=_BF16_ADD_SUB_OPS,
)


@pytest.mark.quasar
@parametrize(
    **BF16_RNE_SWEEP,
    tile_indices=runtime(_TILE_INDEX_VARIANTS),
)
def test_eltwise_binary_sfpu_bf16_rne_quasar(
    binary_op_mathop,
    tile_indices,
    *,
    run_types=(PerfRunType.L1_TO_L1,),
    loop_factor=1,
    is_perf=False,
    perf_report=None,
):
    """Binary SFPU ADD/SUB with NearestEven rounding on bfloat16 inputs.

    RNE narrowing only applies when DEST holds bf16 (fp32 dest accumulation
    disabled), so this test is scoped to Float16_b with DestAccumulation.No.
    """
    binary_op, mathop = binary_op_mathop
    formats = InputOutputFormat(
        input_format=DataFormat.Float16_b, output_format=DataFormat.Float16_b
    )
    _run_sfpu_binary_llk_golden(
        formats,
        DestAccumulation.No,
        tile_indices,
        mathop,
        binary_op,
        prepare_stimuli=_prepare_float_stimuli,
        dst_rounding_mode=DstRoundingMode.NearestEven,
        run_types=run_types,
        loop_factor=loop_factor,
        is_perf=is_perf,
        perf_report=perf_report,
    )


# ===========================================================================
# add_top_row — adds the top four rows of faces 0 and 1 (the tile's top four rows) of two
# tiles; the rest of the result tile keeps what Dest held. Float32 and Int32, both with a
# 32-bit Dest. The golden models the same Dest rows as on Blackhole.
# ===========================================================================
_ADD_TOP_ROW_FORMATS = [DataFormat.Float32, DataFormat.Int32]


@pytest.mark.quasar
@parametrize(
    data_format=_ADD_TOP_ROW_FORMATS,
    tile_indices=runtime(_TILE_INDEX_VARIANTS),
)
def test_eltwise_binary_sfpu_add_top_row_quasar(
    data_format,
    tile_indices,
    *,
    run_types=(PerfRunType.L1_TO_L1,),
    loop_factor=1,
    is_perf=False,
    perf_report=None,
):
    """Binary SFPU add_top_row, Float32 and Int32."""
    formats = InputOutputFormat(input_format=data_format, output_format=data_format)
    if data_format == DataFormat.Int32:
        prepare_stimuli = lambda f, dims, s0, s1, op: _prepare_int_stimuli(
            f, dims, s0, s1, op, None
        )
    else:
        prepare_stimuli = _prepare_float_stimuli
    _run_sfpu_binary_llk_golden(
        formats,
        DestAccumulation.Yes,
        tile_indices,
        MathOperation.SfpuAddTopRow,
        "ADD_TOP_ROW",
        prepare_stimuli=prepare_stimuli,
        run_types=run_types,
        loop_factor=loop_factor,
        is_perf=is_perf,
        perf_report=perf_report,
    )


# ===========================================================================
# Family 3 — max / min (float + Int32). Ported from test_binary_max_min_quasar.py.
# Layout in0=Dest[0], in1=Dest[1], out=Dest[2]; dual unpack path; torch golden.
# ===========================================================================
SFPU_BINARY_MAX_MIN_FLOAT_FORMATS = input_output_formats(
    [
        DataFormat.Float16_b,
        DataFormat.Float16,
        DataFormat.Float32,
    ],
)
SFPU_BINARY_MAX_MIN_INT32_FORMATS = input_output_formats([DataFormat.Int32], same=True)


def prepare_binary_max_min_inputs(src_A, src_B, input_format, output_format):
    """Two safe-range inputs for max/min (result == one operand verbatim)."""
    torch_fmt = format_dict[input_format]

    if not torch_fmt.is_floating_point:
        iinfo = torch.iinfo(torch_fmt)
        in0 = torch.clamp(src_A, iinfo.min, iinfo.max).to(torch_fmt).to(torch.float32)
        in1 = torch.clamp(src_B, iinfo.min, iinfo.max).to(torch_fmt).to(torch.float32)
        return in0, in1

    cap = min(format_elem_max(input_format), format_elem_max(output_format))
    min_mag, max_mag = compute_safe_input_magnitude_range(
        input_format, output_format, input_magnitude_cap=cap, output_magnitude_cap=cap
    )
    in0 = apply_log_uniform_magnitudes(
        src_A,
        min_magnitude=min_mag,
        max_magnitude=max_mag,
        cast_to_format=input_format,
        sign_source=src_A,
    )
    in1 = apply_log_uniform_magnitudes(
        src_B,
        min_magnitude=min_mag,
        max_magnitude=max_mag,
        cast_to_format=input_format,
        sign_source=src_B,
    )
    return in0, in1


def _generate_max_min_combinations(
    formats_list: List[InputOutputFormat],
    input_dimensions_list=([32, 32],),
):
    """Generate max/min resolved routes and the operation-specific axes."""
    combinations = []
    for format_variant in generate_quasar_sfpu_format_variants(
        MathOperation.SfpuBinaryMax, formats_list
    ):
        for is_max_op in [True, False]:
            for input_dimensions in input_dimensions_list:
                combinations.append(
                    (
                        format_variant,
                        is_max_op,
                        input_dimensions,
                    )
                )
    return combinations


MAX_MIN_FLOAT_SWEEP = dict(
    formats_dest_acc_is_max_input_dims=_generate_max_min_combinations(
        SFPU_BINARY_MAX_MIN_FLOAT_FORMATS,
    ),
)
MAX_MIN_INT32_SWEEP = dict(
    formats_dest_acc_is_max_input_dims=_generate_max_min_combinations(
        SFPU_BINARY_MAX_MIN_INT32_FORMATS,
    ),
)


def _run_max_min(
    format_variant,
    is_max_op,
    input_dimensions,
    spec,
    tile_indices,
    is_int,
    *,
    run_types=(PerfRunType.L1_TO_L1,),
    loop_factor=1,
    is_perf=False,
    perf_report=None,
):
    formats = format_variant.formats
    dest_acc = format_variant.dest_acc
    binary_op = "MAX" if is_max_op else "MIN"
    src0_idx, src1_idx, dst_idx = tile_indices
    num_faces = MAX_NUM_FACES

    src_A, tile_cnt_A, src_B, _ = generate_stimuli(
        stimuli_format_A=formats.input_format,
        input_dimensions_A=input_dimensions,
        stimuli_format_B=formats.input_format,
        input_dimensions_B=input_dimensions,
        spec_A=spec,
        spec_B=spec,
    )

    in0, in1 = prepare_binary_max_min_inputs(
        src_A, src_B, formats.input_format, formats.output_format
    )
    output_torch_fmt = format_dict[formats.output_format]

    if is_int:
        in0_int = in0.to(torch.int32)
        in1_int = in1.to(torch.int32)
        golden_int = (
            torch.maximum(in0_int, in1_int)
            if is_max_op
            else torch.minimum(in0_int, in1_int)
        )
        golden_tensor = golden_int.to(torch.float32)
        buffer_A_combined, tile_cnt = _stage_binary_operands(
            in0_int, in1_int, tile_indices, torch.int32
        )
        buffer_B_dummy = in1_int
    else:
        torch_fmt = format_dict[formats.input_format]
        in0 = in0.to(torch_fmt)
        in1 = in1.to(torch_fmt)
        in0_f32 = in0.to(torch.float32)
        in1_f32 = in1.to(torch.float32)
        golden_f32 = (
            torch.maximum(in0_f32, in1_f32)
            if is_max_op
            else torch.minimum(in0_f32, in1_f32)
        )
        golden_tensor = golden_f32.to(output_torch_fmt)
        buffer_A_combined, tile_cnt = _stage_binary_operands(
            in0, in1, tile_indices, in0.dtype
        )
        buffer_B_dummy = in1

    unpack_to_dest = format_variant.unpack_to_dest

    if is_perf and perf_report is None:
        raise ValueError("perf_report must be provided when is_perf=True")

    test_config_kwargs = {
        "test_name": _CPP_SOURCE,
        "formats": formats,
        "templates": [
            SFPU_BINARY_OP(binary_op),
            APPROX_MODE(),
            DATA_COPY_TYPE(DataCopyType.A2D),
            UNPACKER_ENGINE_SEL(
                UnpackerEngine.UnpDest if unpack_to_dest else UnpackerEngine.UnpA
            ),
            DEST_SYNC(),
            # 2's-complement datapath (default); only the quant family reads this.
            SIGN_MAGNITUDE_FORMAT(False),
            SFPU_DST_ROUNDING_MODE(),
            # The shared unary-SFPU dispatch in sfpu_operations_quasar.h has a typecast
            # branch that references the non-dependent globals TYPECAST_IN_FORMAT /
            # TYPECAST_OUT_FORMAT, so every build that includes it must define them.
            TYPECAST_FORMATS(),
            BROADCAST_TYPE(BroadcastType.None_),
        ],
        "runtimes": [
            TILE_COUNT(tile_cnt),
            NUM_FACES(num_faces),
            TEST_FACE_DIMS(),
            DEST_INDEX(0),
            SFPU_TILE_INDICES(src0_idx, src1_idx, dst_idx),
            LOOP_FACTOR(loop_factor),
            ZERO_POINT(0),
        ],
        "variant_stimuli": StimuliConfig(
            buffer_A_combined,
            formats.input_format,
            buffer_B_dummy,  # dummy buffer_B (unused by kernel)
            formats.input_format,
            formats.output_format,
            tile_count_A=tile_cnt,
            tile_count_B=1,
            tile_count_res=1,
            num_faces=num_faces,
            sfpu=True,
        ),
        "unpack_to_dest": unpack_to_dest,
        "dest_acc": dest_acc,
    }

    configuration = create_test_or_perf_config(
        is_perf=is_perf,
        run_types=run_types,
        test_config_kwargs=test_config_kwargs,
    )
    format_variant.apply_formats(configuration.formats_config)
    if is_perf:
        configuration.run(perf_report)
        return

    res_from_L1 = configuration.run().result
    assert len(res_from_L1) == len(golden_tensor)
    res_tensor = torch.tensor(res_from_L1, dtype=output_torch_fmt)
    assert passed_test(golden_tensor, res_tensor, formats.output_format), (
        f"max/min failed for is_max_op={is_max_op}, "
        f"format={formats.input_format}->{formats.output_format}, dest_acc={dest_acc}"
    )


@pytest.mark.quasar
@parametrize(
    **MAX_MIN_FLOAT_SWEEP,
    tile_indices=runtime(_TILE_INDEX_VARIANTS),
)
def test_eltwise_binary_sfpu_max_min_float_quasar(
    formats_dest_acc_is_max_input_dims,
    tile_indices,
    *,
    run_types=(PerfRunType.L1_TO_L1,),
    loop_factor=1,
    is_perf=False,
    perf_report=None,
):
    """Binary SFPU max/min for the non-redundant floating-point formats."""
    format_variant, is_max_op, input_dimensions = formats_dest_acc_is_max_input_dims
    spec = StimuliSpec.uniform(low=-0.9, high=1.1)
    _run_max_min(
        format_variant,
        is_max_op,
        input_dimensions,
        spec,
        tile_indices,
        is_int=False,
        run_types=run_types,
        loop_factor=loop_factor,
        is_perf=is_perf,
        perf_report=perf_report,
    )


@pytest.mark.quasar
@parametrize(
    **MAX_MIN_INT32_SWEEP,
    tile_indices=runtime(_TILE_INDEX_VARIANTS),
)
def test_eltwise_binary_sfpu_max_min_int32_quasar(
    formats_dest_acc_is_max_input_dims,
    tile_indices,
    *,
    run_types=(PerfRunType.L1_TO_L1,),
    loop_factor=1,
    is_perf=False,
    perf_report=None,
):
    """Binary SFPU max/min (Int32)."""
    format_variant, is_max_op, input_dimensions = formats_dest_acc_is_max_input_dims
    formats = format_variant.formats
    iinfo = torch.iinfo(format_dict[formats.input_format])
    spec = StimuliSpec.uniform(low=float(iinfo.min), high=float(iinfo.max - 1))
    _run_max_min(
        format_variant,
        is_max_op,
        input_dimensions,
        spec,
        tile_indices,
        is_int=True,
        run_types=run_types,
        loop_factor=loop_factor,
        is_perf=is_perf,
        perf_report=perf_report,
    )


# ===========================================================================
# Family 4 — quant / requant / dequant. Mixed int/float operands with a runtime
# fp32 zero-point. Ported from Blackhole ckernel_sfpu_quant.h.
#
#   quant:   out_int32 = clamp(round(A_fp32 * scale_fp32 + zp), -127, 127)
#   requant: out_int32 = clamp(round(int32_to_fp32(A) * scale_fp32 + zp), -127, 127)
#   dequant: out_fp32  = (int32_to_fp32(A) - zp) * scale_fp32
#
# Operand A and the fp32 scale B are both staged into buffer_A as raw 32-bit words
# (Int32 tag, twos_complement=True => identity bit copy). The unpack-to-dest path
# moves the raw 32 bits into Dest unchanged; the kernel re-interprets each operand
# via its explicit per-operand SFPLOAD sfpmem mode (FP32 vs INT32). The packer
# format is set per op (Int32 for quant/requant, Float32 for dequant) by patching
# the inferred FormatConfig, since input and output formats differ.
# ===========================================================================
# The binary SFPU params wrapper calls the kernel once per face (4 faces); each
# call runs ITERATIONS=8 unrolled rows, covering the whole 1024-element dst tile.
_PROCESSED_ELEMS = MAX_TILE_ELEMENTS

# SMAG8 saturation: the STOCH_RND fp32->sint8 path clamps magnitude to 127, so the
# representable output range is [-127, +127] (-128 is NOT representable).
_QUANT_INT8_MIN = -127
_QUANT_INT8_MAX = 127


def _fp32_bits_as_int32(t: torch.Tensor) -> torch.Tensor:
    """Reinterpret a float32 tensor's bits as int32 (no numeric conversion)."""
    return t.to(torch.float32).contiguous().view(torch.int32)


def _int32_to_smag32(t: torch.Tensor) -> torch.Tensor:
    """Encode a 2's-complement int32 tensor as sign-magnitude 32-bit (SMAG32):
    bit31 = sign, bits[30:0] = magnitude. Used to stage operands for and model
    the SIGN_MAGNITUDE_FORMAT kernel path, which skips the 2's-comp<->SM casts."""
    v = t.to(torch.int64)
    return (v.abs() | ((v < 0).to(torch.int64) << 31)).to(torch.int32)


_QUANT_OPS = ["QUANT", "REQUANT", "DEQUANT"]

QUANT_SWEEP = dict(
    binary_op=_QUANT_OPS,
    sign_magnitude=[False, True],
)


def _run_quant(
    binary_op,
    tile_indices,
    sign_magnitude=False,
    *,
    run_types=(PerfRunType.L1_TO_L1,),
    loop_factor=1,
    is_perf=False,
    perf_report=None,
):
    src0_idx, src1_idx, dst_idx = tile_indices
    dest_acc = DestAccumulation.Yes  # all quant endpoints are 32-bit
    num_faces = MAX_NUM_FACES

    is_dequant = binary_op == "DEQUANT"
    a_is_int = binary_op in ("REQUANT", "DEQUANT")
    output_format = DataFormat.Float32 if is_dequant else DataFormat.Int32

    # ---- stimuli (one tile's worth of active datums) ----
    n = MAX_TILE_ELEMENTS

    # Scale: small positive fp32 so the quantized magnitudes stay inside [-127,127].
    scale = torch.rand(n, dtype=torch.float32) * 0.04 + 0.01  # [0.01, 0.05)
    # Zero-point: a small fp32 offset.
    zero_point = 3.0

    if a_is_int:
        # int32 operand A in a modest range so int*scale stays well within int8.
        a_vals = torch.randint(-2000, 2000, (n,), dtype=torch.int32)
        a_float = a_vals.to(torch.float32)
        # The SIGN_MAGNITUDE_FORMAT path skips the 2's-comp->SM input cast, so operand
        # A must already be SMAG32; the default path expects raw 2's-complement.
        a_staged = _int32_to_smag32(a_vals) if sign_magnitude else a_vals
    else:
        # fp32 operand A.
        a_float = (torch.rand(n, dtype=torch.float32) - 0.5) * 4000.0  # +/-2000
        a_vals = a_float
        a_staged = _fp32_bits_as_int32(a_float)

    b_staged = _fp32_bits_as_int32(scale)

    buffer_A, tile_cnt = _stage_binary_operands(
        a_staged, b_staged, tile_indices, torch.int32
    )

    # ---- golden ----
    if is_dequant:
        golden_active = (a_float - zero_point) * scale  # fp32
        golden_active = golden_active.to(torch.float32)
        out_dtype = torch.float32
    else:
        prod = a_float * scale + zero_point
        rounded = torch.round(prod)  # round-half-to-even matches SFP STOCH_RND NearEven
        clamped = torch.clamp(rounded, _QUANT_INT8_MIN, _QUANT_INT8_MAX).to(torch.int32)
        # STOCH_RND emits a sign-magnitude int8 result. A negative value whose
        # magnitude rounds to 0 becomes sign-magnitude negative-zero (0x80000000).
        neg_zero = (clamped == 0) & (prod < 0)
        if sign_magnitude:
            # SM path stores the STOCH_RND SMAG32 result as-is (no SM32_TO_2SC cast):
            # negatives keep bit31|magnitude and negative-zero stays 0x80000000.
            golden_active = _int32_to_smag32(clamped)
            golden_active[neg_zero] = torch.tensor(-(2**31), dtype=torch.int32)
        else:
            # 2's-comp path: SM32_TO_2SC maps STOCH_RND negative-zero to -1 (not +0).
            golden_active = clamped
            golden_active[neg_zero] = -1
        out_dtype = torch.int32

    golden_tensor = torch.zeros(MAX_TILE_ELEMENTS, dtype=out_dtype)
    golden_tensor[:_PROCESSED_ELEMS] = golden_active[:_PROCESSED_ELEMS]

    # zero_point bits passed to the kernel init (DEQUANT negates the contract).
    zp_for_kernel = -zero_point if is_dequant else zero_point
    zp_bits = struct.unpack("<I", struct.pack("<f", zp_for_kernel))[0]

    # buffer_A is raw int32; operand B's fp32 bits ride along as int32 words.
    formats = InputOutputFormat(
        input_format=DataFormat.Int32, output_format=output_format
    )

    test_config_kwargs = {
        "test_name": _CPP_SOURCE,
        "formats": formats,
        "templates": [
            SFPU_BINARY_OP(binary_op),
            APPROX_MODE(),
            DATA_COPY_TYPE(DataCopyType.A2D),
            UNPACKER_ENGINE_SEL(UnpackerEngine.UnpDest),
            DEST_SYNC(),
            SIGN_MAGNITUDE_FORMAT(sign_magnitude),
            SFPU_DST_ROUNDING_MODE(),
            TYPECAST_FORMATS(),
            BROADCAST_TYPE(BroadcastType.None_),
        ],
        "runtimes": [
            TILE_COUNT(tile_cnt),
            NUM_FACES(num_faces),
            TEST_FACE_DIMS(),
            DEST_INDEX(0),
            SFPU_TILE_INDICES(src0_idx, src1_idx, dst_idx),
            LOOP_FACTOR(loop_factor),
            ZERO_POINT(zp_bits),
        ],
        "variant_stimuli": StimuliConfig(
            buffer_A,
            DataFormat.Int32,
            buffer_A[:MAX_TILE_ELEMENTS],  # dummy buffer_B (unused by kernel)
            DataFormat.Int32,
            output_format,
            tile_count_A=tile_cnt,
            tile_count_B=1,
            tile_count_res=1,
            num_faces=num_faces,
            twos_complement=True,  # raw 32-bit identity staging
        ),
        "unpack_to_dest": True,
        "dest_acc": dest_acc,
    }
    configuration = create_test_or_perf_config(
        is_perf=is_perf,
        run_types=run_types,
        test_config_kwargs=test_config_kwargs,
    )

    # Packer reads the SFPU result tile from Dest. For dequant the result is fp32;
    # for quant/requant it is int32. Format inference ties pack_src to the
    # (Int32) input format, so override it to match the actual output datum width.
    fc = configuration.formats_config[0]
    fc.pack_src = output_format
    fc.pack_dst = output_format
    fc.pack_S_src = output_format
    fc.pack_S_dst = output_format

    if is_perf:
        configuration.run(perf_report)
        return

    res_from_L1 = configuration.run().result
    assert len(res_from_L1) == len(golden_tensor)
    res_tensor = torch.tensor(res_from_L1, dtype=out_dtype)
    # Compare only the rows the kernel processes (8 iterations * faces).
    assert passed_test(
        golden_tensor[:_PROCESSED_ELEMS],
        res_tensor[:_PROCESSED_ELEMS],
        output_format,
    ), f"{binary_op} (sign_magnitude={sign_magnitude}) mismatch (tile_indices={tile_indices})"


@pytest.mark.quasar
@parametrize(
    **QUANT_SWEEP,
    tile_indices=runtime(_TILE_INDEX_VARIANTS),
)
def test_eltwise_binary_sfpu_quant_quasar(
    binary_op,
    sign_magnitude,
    tile_indices,
    *,
    run_types=(PerfRunType.L1_TO_L1,),
    loop_factor=1,
    is_perf=False,
    perf_report=None,
):
    """Binary SFPU quant family (quant / requant / dequant), Int32-staged operands
    with a runtime fp32 zero-point; output Int32 (quant/requant) or Float32
    (dequant). Exercised on both the 2's-complement and SIGN_MAGNITUDE_FORMAT
    (SMAG32) datapaths."""
    _run_quant(
        binary_op,
        tile_indices,
        sign_magnitude,
        run_types=run_types,
        loop_factor=loop_factor,
        is_perf=is_perf,
        perf_report=perf_report,
    )
