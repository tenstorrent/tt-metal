# SPDX-FileCopyrightText: © 2025 Tenstorrent AI ULC
# SPDX-License-Identifier: Apache-2.0

import pytest
import torch
from helpers.constraints import get_valid_math_fidelities
from helpers.format_config import DataFormat, InputOutputFormat
from helpers.golden_generators import (
    EltwiseBinaryGolden,
    get_golden_generator,
)
from helpers.llk_params import (
    DestAccumulation,
    DestSync,
    MathFidelity,
    MathOperation,
    PerfRunType,
    format_dict,
)
from helpers.param_config import (
    generate_reduced_input_dimensions,
    get_num_blocks_and_num_tiles_in_block,
    input_output_formats,
    parametrize,
    quasar_mx_smoke,
    runtime,
    select_perf_tile_sizes,
)
from helpers.perf.core import create_test_or_perf_config
from helpers.stimuli_config import StimuliConfig
from helpers.stimuli_generator import StimuliSpec, generate_stimuli
from helpers.test_config import BootMode
from helpers.test_variant_parameters import (
    ACC_TO_DEST,
    DEST_SYNC,
    ENABLE_DIRECT_INDEXING,
    INPUT_TILE_CNT,
    LOOP_FACTOR,
    MATH_FIDELITY,
    MATH_OP,
    NUM_BLOCKS,
    NUM_FACES,
    NUM_FACES_C_DIM,
    NUM_FACES_R_DIM,
    NUM_TILES_IN_BLOCK,
    OUTPUT_TILE_CNT,
    TEST_FACE_DIMS,
    TILE_COUNT,
    generate_input_dim,
)
from helpers.tile_constants import is_mx_unsupported_tile_dims
from helpers.tile_shape import construct_tile_shape
from helpers.utils import passed_test


def _eltwise_dest_acc_sync(dest_acc_modes, *, is_perf=False):
    dest_sync_modes = (DestSync.Half,) if is_perf else (DestSync.Half, DestSync.Full)
    return [
        (dest_sync, dest_acc)
        for dest_sync in dest_sync_modes
        for dest_acc in dest_acc_modes
    ]


def eltwise_binary_dest_sync_dest_acc(formats, *, is_perf=False):
    dest_acc_modes = (
        (DestAccumulation.Yes,)
        if formats.input_format == DataFormat.Int8
        else (DestAccumulation.No,)
    )
    return _eltwise_dest_acc_sync(dest_acc_modes, is_perf=is_perf)


# For acc_to_dest setting, accumulate two result tiles into dest. Can be extended.
def get_num_tiles_per_accumulation(acc_to_dest: bool) -> int:
    return 2 if acc_to_dest else 1


def runs_tile_shape_paths(
    formats,
    mathop,
    math_fidelity,
    dest_sync_dest_acc,
    enable_direct_indexing,
    *,
    is_perf=False,
):
    """Whether a variant also runs on partial tiles and with direct indexing.

    Full 32x32 tiles without direct indexing keep the complete matrix. The tile-shape and
    direct-indexing paths depend on dest width, LoFi vs HiFi phases and accumulation, so a
    representative slice of the matrix covers them.
    """
    if is_perf:
        return (
            formats.input_format == DataFormat.Float16_b
            and mathop == MathOperation.Elwadd
            and math_fidelity == MathFidelity.LoFi
        )
    if dest_sync_dest_acc[0] != DestSync.Half:
        return False
    if math_fidelity == MathFidelity.HiFi4:
        # Float16 is the only input format that keeps HiFi fidelities on Quasar.
        return (
            mathop == MathOperation.Elwmul
            and formats.input_format == DataFormat.Float16
        )
    lofi_formats = (
        (DataFormat.Float16_b,)
        if enable_direct_indexing
        else (DataFormat.Float16_b, DataFormat.Int8)
    )
    return math_fidelity == MathFidelity.LoFi and formats.input_format in lofi_formats


def eltwise_binary_direct_indexing(
    formats,
    mathop,
    math_fidelity,
    dest_sync_dest_acc,
    *,
    is_perf=False,
):
    if runs_tile_shape_paths(
        formats,
        mathop,
        math_fidelity,
        dest_sync_dest_acc,
        True,
        is_perf=is_perf,
    ):
        return [False, True]
    return [False]


def eltwise_binary_tile_dimensions(
    formats,
    mathop,
    math_fidelity,
    dest_sync_dest_acc,
    enable_direct_indexing,
    *,
    is_perf=False,
):
    if not runs_tile_shape_paths(
        formats,
        mathop,
        math_fidelity,
        dest_sync_dest_acc,
        enable_direct_indexing,
        is_perf=is_perf,
    ):
        return [(32, 32)]
    # Cover full, single-face, narrow, and sparse two-face tiles.
    tile_sizes = [(32, 32), (16, 16), (32, 16), (1, 32)]
    if is_perf:
        tile_sizes = select_perf_tile_sizes(tile_sizes)
    return [
        dims
        for dims in tile_sizes
        if not is_mx_unsupported_tile_dims(
            formats.input_format, formats.output_format, dims
        )
    ]


def valid_acc_to_dest(input_dimensions, tile_dimensions) -> list:
    """Pick the acc_to_dest modes worth running for a given input size.

    acc_to_dest=True accumulates `get_num_tiles_per_accumulation(True)` result tiles into
    dest, so it only makes sense when the tile count is a non-zero multiple of that.
    """
    total_tiles = (input_dimensions[0] * input_dimensions[1]) // construct_tile_shape(
        tile_dimensions
    ).total_tile_size()

    per_acc = get_num_tiles_per_accumulation(True)
    if total_tiles >= per_acc and total_tiles % per_acc == 0:
        return [False, True]
    return [False]


ELTWISE_FORMATS = (
    input_output_formats(
        [
            DataFormat.Float16_b,
            DataFormat.Float16,
        ],
    )
    + [InputOutputFormat(DataFormat.Int8, DataFormat.Int32)]
    + quasar_mx_smoke(DataFormat.MxFp4, DataFormat.Float16_b)
)


@pytest.mark.quasar
@parametrize(
    formats=ELTWISE_FORMATS,
    mathop=[
        MathOperation.Elwadd,
        MathOperation.Elwsub,
        MathOperation.Elwmul,
    ],
    math_fidelity=lambda formats, mathop: get_valid_math_fidelities(formats, mathop),
    dest_sync_dest_acc=lambda formats: eltwise_binary_dest_sync_dest_acc(
        formats, is_perf=False
    ),
    enable_direct_indexing=lambda formats, mathop, math_fidelity, dest_sync_dest_acc: eltwise_binary_direct_indexing(
        formats,
        mathop,
        math_fidelity,
        dest_sync_dest_acc,
        is_perf=False,
    ),
    tile_dimensions=runtime(
        lambda formats, mathop, math_fidelity, dest_sync_dest_acc, enable_direct_indexing: eltwise_binary_tile_dimensions(
            formats,
            mathop,
            math_fidelity,
            dest_sync_dest_acc,
            enable_direct_indexing,
            is_perf=False,
        )
    ),
    input_dimensions=runtime(
        lambda dest_sync_dest_acc, tile_dimensions: generate_reduced_input_dimensions(
            dest_sync_dest_acc[1],
            dest_sync_dest_acc[0],
            construct_tile_shape(tile_dimensions),
        )
    ),
    acc_to_dest=valid_acc_to_dest,
    run_types=[[PerfRunType.L1_TO_L1]],
    loop_factor=[1],
)
def test_eltwise_binary(
    formats,
    mathop,
    math_fidelity,
    dest_sync_dest_acc,
    input_dimensions,
    acc_to_dest,
    tile_dimensions,
    enable_direct_indexing,
    run_types,
    loop_factor,
    boot_mode=BootMode.DEFAULT,
    *,
    is_perf=False,
    perf_report=None,
):
    dest_sync_mode, dest_acc = dest_sync_dest_acc
    tile_shape = construct_tile_shape(tile_dimensions)
    num_faces = tile_shape.total_num_faces()

    num_tiles_per_accumulation = get_num_tiles_per_accumulation(acc_to_dest)

    num_blocks, input_tiles_in_block = get_num_blocks_and_num_tiles_in_block(
        dest_sync_mode,
        dest_acc,
        formats,
        input_dimensions,
        tile_dimensions=tile_dimensions,
    )
    output_tiles_in_block = input_tiles_in_block // num_tiles_per_accumulation

    if formats.input_format == DataFormat.Int8:
        stimuli_spec = StimuliSpec.uniform(low=-127.0, high=127.0)
    else:
        stimuli_spec = StimuliSpec.uniform(low=0.0, high=1.0)
    src_A, tile_cnt_A, src_B, _ = generate_stimuli(
        stimuli_format_A=formats.input_format,
        input_dimensions_A=input_dimensions,
        stimuli_format_B=formats.input_format,
        input_dimensions_B=input_dimensions,
        spec_A=stimuli_spec,
        spec_B=stimuli_spec,
        output_format=formats.output_format,
        tile_dimensions=tile_dimensions,
    )

    tile_cnt_res = src_A.numel() // (
        tile_shape.total_tile_size() * num_tiles_per_accumulation
    )

    generate_golden = get_golden_generator(EltwiseBinaryGolden)
    golden_tensor = generate_golden(
        mathop,
        src_A,
        src_B,
        formats.output_format,
        math_fidelity,
        input_format=formats.input_format,
        acc_to_dest=acc_to_dest,
        tile_shape=tile_shape,
        num_tiles_per_accumulation=num_tiles_per_accumulation,
    )

    if is_perf and perf_report is None:
        raise ValueError("perf_report must be provided when is_perf=True")

    test_config_kwargs = {
        "test_name": "sources/quasar/eltwise_binary_test.cpp",
        "formats": formats,
        "templates": [
            MATH_FIDELITY(math_fidelity),
            MATH_OP(mathop=mathop),
            DEST_SYNC(dest_sync_mode),
            ACC_TO_DEST(acc_to_dest),
            ENABLE_DIRECT_INDEXING(enable_direct_indexing),
        ],
        "runtimes": [
            generate_input_dim(
                input_dimensions, input_dimensions, tile_dimensions=tile_dimensions
            ),
            TILE_COUNT(tile_cnt_A),
            INPUT_TILE_CNT(tile_cnt_A),
            OUTPUT_TILE_CNT(tile_cnt_res),
            NUM_FACES(num_faces, num_faces, num_faces),
            TEST_FACE_DIMS(tile_shape.face_r_dim),
            NUM_FACES_R_DIM(tile_shape.num_faces_r_dim, tile_shape.num_faces_r_dim),
            NUM_FACES_C_DIM(tile_shape.num_faces_c_dim, tile_shape.num_faces_c_dim),
            NUM_BLOCKS(num_blocks),
            NUM_TILES_IN_BLOCK(
                input_tiles_in_block,
                output_num_tiles_in_block=output_tiles_in_block,
            ),
            LOOP_FACTOR(loop_factor),
        ],
        "variant_stimuli": StimuliConfig(
            src_A,
            formats.input_format,
            src_B,
            formats.input_format,
            formats.output_format,
            tile_count_A=tile_cnt_A,
            tile_count_B=tile_cnt_A,
            tile_count_res=tile_cnt_res,
            num_faces=num_faces,
            face_r_dim=tile_shape.face_r_dim,
            tile_dimensions=tile_dimensions,
            use_dense_tile_dimensions=True,
        ),
        "unpack_to_dest": (
            formats.input_format.is_32_bit() and dest_acc == DestAccumulation.Yes
        ),
        "dest_acc": dest_acc,
    }

    configuration = create_test_or_perf_config(
        is_perf=is_perf,
        run_types=run_types,
        test_config_kwargs=test_config_kwargs,
        boot_mode=boot_mode,
    )
    if is_perf:
        configuration.run(perf_report)
        return

    res_from_L1 = configuration.run().result

    # Verify results match golden
    assert len(res_from_L1) == len(
        golden_tensor
    ), "Result tensor and golden tensor are not of the same length"

    torch_format = format_dict[formats.output_format]
    res_tensor = torch.tensor(res_from_L1, dtype=torch_format)

    assert passed_test(
        golden_tensor,
        res_tensor,
        formats.output_format,
    ), "Assert against golden failed"
