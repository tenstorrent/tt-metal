# SPDX-FileCopyrightText: © 2025 Tenstorrent AI ULC
# SPDX-License-Identifier: Apache-2.0

from typing import List

import pytest
import torch
from helpers.format_config import DataFormat, FormatConfig
from helpers.golden_generators import (
    DataCopyGolden,
    get_golden_generator,
)
from helpers.llk_params import (
    BlocksCalculationAlgorithm,
    DataCopyType,
    DestAccumulation,
    DestSync,
    PerfRunType,
    UnpackerEngine,
    format_dict,
)
from helpers.param_config import (
    calculate_edgecase_dest_indices,
    generate_perf_input_dimensions,
    generate_reduced_input_dimensions,
    get_num_blocks_and_num_tiles_in_block,
    input_output_formats,
    parametrize,
    quasar_mx_smoke,
    runtime,
    select_perf_tile_sizes,
)
from helpers.perf.core import create_test_or_perf_config
from helpers.stimuli_config import StimuliConfig
from helpers.stimuli_generator import generate_stimuli
from helpers.test_variant_parameters import (
    DATA_COPY_TYPE,
    DEST_INDEX,
    DEST_SYNC,
    LOOP_FACTOR,
    NUM_BLOCKS,
    NUM_FACES,
    NUM_FACES_C_DIM,
    NUM_FACES_R_DIM,
    NUM_TILES_IN_BLOCK,
    TEST_FACE_DIMS,
    TILE_COUNT,
    UNPACKER_ENGINE_SEL,
    generate_input_dim,
)
from helpers.tile_constants import SUPPORTED_TILE_SIZES, is_mx_unsupported_tile_dims
from helpers.tile_shape import construct_tile_shape
from helpers.utils import passed_test


def generate_eltwise_unary_datacopy_combinations(
    formats_list: List[FormatConfig],
    *,
    is_perf=False,
):
    """
    Generate eltwise_unary_datacopy combinations.

    Args: List of input-output format pairs

    Returns: List of (format, dest_acc, data_copy_type, input_dimensions, dest_sync, edgecase_dest_index, tile_dimensions) tuples
    """
    combinations = []

    for fmt in formats_list:
        in_fmt = fmt.input_format

        dest_acc_modes = (DestAccumulation.No, DestAccumulation.Yes)
        dest_sync_modes = (
            (DestSync.Half,) if is_perf else (DestSync.Half, DestSync.Full)
        )
        data_copy_types = (DataCopyType.A2D, DataCopyType.B2D)
        tile_sizes = (
            select_perf_tile_sizes(SUPPORTED_TILE_SIZES)
            if is_perf
            else SUPPORTED_TILE_SIZES
        )

        for dest_acc in dest_acc_modes:
            if (
                in_fmt != DataFormat.Float32
                and fmt.output_format == DataFormat.Float32
                and dest_acc == DestAccumulation.No
            ):
                continue

            for dest_sync in dest_sync_modes:
                for data_copy_type in data_copy_types:
                    for tile_dims in tile_sizes:
                        if is_mx_unsupported_tile_dims(
                            in_fmt, fmt.output_format, tile_dims
                        ):
                            continue
                        tile_shape = construct_tile_shape(tile_dims)
                        dimensions_list = (
                            generate_perf_input_dimensions(
                                dest_acc, dest_sync, tile_shape
                            )
                            if is_perf
                            else generate_reduced_input_dimensions(
                                dest_acc, dest_sync=dest_sync, tile_shape=tile_shape
                            )
                        )
                        for dimensions in dimensions_list:
                            # calculate_edgecase_dest_indices returns dest_index = 0 when the
                            # matrix is larger than full dest
                            dest_indices = (
                                [0]
                                if is_perf
                                else [
                                    edgecase_dest_index
                                    for _, edgecase_dest_index in calculate_edgecase_dest_indices(
                                        (
                                            True
                                            if dest_acc == DestAccumulation.Yes
                                            else False
                                        ),
                                        dimensions[0]
                                        // tile_dims[0]
                                        * dimensions[1]
                                        // tile_dims[1],
                                        [dest_sync],
                                    )
                                ]
                            )
                            for dest_index in dest_indices:
                                combinations.append(
                                    (
                                        fmt,
                                        dest_acc,
                                        data_copy_type,
                                        runtime(dimensions),
                                        dest_sync,
                                        runtime(dest_index),
                                        runtime(tile_dims),
                                    )
                                )

    return combinations


DATACOPY_FORMATS = input_output_formats(
    [
        DataFormat.Float16_b,
        DataFormat.Float16,
    ]
) + quasar_mx_smoke(DataFormat.MxFp4, DataFormat.Float16_b)
ALL_DATACOPY_COMBINATIONS = generate_eltwise_unary_datacopy_combinations(
    DATACOPY_FORMATS
)
PERF_DATACOPY_COMBINATIONS = generate_eltwise_unary_datacopy_combinations(
    DATACOPY_FORMATS,
    is_perf=True,
)


@pytest.mark.quasar
@parametrize(
    formats_dest_acc_data_copy_type_dims_dest_sync_dest_indices=ALL_DATACOPY_COMBINATIONS,
    run_types=[[PerfRunType.L1_TO_L1]],
    loop_factor=[1],
)
def test_eltwise_unary_datacopy_quasar(
    formats_dest_acc_data_copy_type_dims_dest_sync_dest_indices,
    run_types,
    loop_factor,
    *,
    is_perf=False,
    perf_report=None,
):
    (
        formats,
        dest_acc,
        data_copy_type,
        input_dimensions,
        dest_sync_mode,
        dest_index,
        tile_dimensions,
    ) = formats_dest_acc_data_copy_type_dims_dest_sync_dest_indices

    tile_shape = construct_tile_shape(tile_dimensions)

    src_A, tile_cnt_A, src_B, _ = generate_stimuli(
        stimuli_format_A=formats.input_format,
        input_dimensions_A=input_dimensions,
        stimuli_format_B=formats.input_format,
        input_dimensions_B=input_dimensions,
        tile_dimensions=tile_dimensions,
    )

    num_faces = tile_shape.total_num_faces()

    num_blocks, tiles_in_block = get_num_blocks_and_num_tiles_in_block(
        dest_sync_mode,
        dest_acc,
        formats,
        input_dimensions,
        tile_dimensions,
        BlocksCalculationAlgorithm.Standard,
    )

    golden_src = src_B if data_copy_type == DataCopyType.B2D else src_A
    generate_golden = get_golden_generator(DataCopyGolden)
    golden_tensor = generate_golden(
        golden_src,
        formats.output_format,
        num_faces=num_faces,
        face_r_dim=tile_shape.face_r_dim,
        input_dimensions=input_dimensions,
        input_format=formats.input_format,
        tile_shape=tile_shape,
    )

    if is_perf and perf_report is None:
        raise ValueError("perf_report must be provided when is_perf=True")

    test_config_kwargs = {
        "test_name": "sources/quasar/eltwise_unary_datacopy_quasar_test.cpp",
        "formats": formats,
        "templates": [
            DATA_COPY_TYPE(data_copy_type),
            UNPACKER_ENGINE_SEL(
                UnpackerEngine.UnpB
                if data_copy_type == DataCopyType.B2D
                else UnpackerEngine.UnpA
            ),
            DEST_SYNC(dest_sync_mode),
        ],
        "runtimes": [
            TILE_COUNT(tile_cnt_A),
            NUM_FACES(num_faces),
            TEST_FACE_DIMS(tile_shape.face_r_dim),
            NUM_FACES_R_DIM(tile_shape.num_faces_r_dim),
            NUM_FACES_C_DIM(tile_shape.num_faces_c_dim),
            DEST_INDEX(dest_index),
            NUM_BLOCKS(num_blocks),
            NUM_TILES_IN_BLOCK(tiles_in_block),
            LOOP_FACTOR(loop_factor),
            generate_input_dim(
                input_dimensions, input_dimensions, tile_dimensions=tile_dimensions
            ),
        ],
        "variant_stimuli": StimuliConfig(
            src_A,
            formats.input_format,
            src_B,
            formats.input_format,
            formats.output_format,
            tile_count_A=tile_cnt_A,
            tile_count_B=tile_cnt_A,
            tile_count_res=tile_cnt_A,
            num_faces=num_faces,
            face_r_dim=tile_shape.face_r_dim,
            tile_dimensions=tile_dimensions,
            use_dense_tile_dimensions=True,
        ),
        "unpack_to_dest": False,
        "dest_acc": dest_acc,
    }

    configuration = create_test_or_perf_config(
        is_perf=is_perf,
        run_types=run_types,
        test_config_kwargs=test_config_kwargs,
    )
    if is_perf:
        configuration.run(perf_report)
        return

    res_from_L1 = configuration.run().result

    assert len(res_from_L1) == len(
        golden_tensor
    ), "Result tensor and golden tensor are not of the same length"

    torch_format = format_dict[formats.output_format]
    res_tensor = torch.tensor(res_from_L1, dtype=torch_format)

    assert passed_test(
        golden_tensor,
        res_tensor,
        formats.output_format,
    ), "Assert against golden failed"
