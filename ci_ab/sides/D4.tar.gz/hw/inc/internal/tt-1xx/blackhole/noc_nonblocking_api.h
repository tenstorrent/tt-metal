// SPDX-FileCopyrightText: © 2023 Tenstorrent USA, Inc.
//
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include <stdint.h>
#include "internal/risc_attribs.h"
#include "internal/tt-1xx/cache.h"
#include "noc_parameters.h"
#include "hostdev/dev_msgs.h"
#include "noc_overlay_parameters.h"
#include "api/debug/assert.h"

#if defined(COMPILE_FOR_AERISC)
#include "eth_fw_api.h"
#endif

#if defined(COMPILE_FOR_BRISC)
constexpr std::underlying_type_t<TensixProcessorTypes> proc_type =
    static_cast<std::underlying_type_t<TensixProcessorTypes>>(TensixProcessorTypes::DM0);
#elif defined(COMPILE_FOR_NCRISC)
constexpr std::underlying_type_t<TensixProcessorTypes> proc_type =
    static_cast<std::underlying_type_t<TensixProcessorTypes>>(TensixProcessorTypes::DM1);
#elif defined(COMPILE_FOR_AERISC)
constexpr std::underlying_type_t<EthProcessorTypes> proc_type =
    static_cast<std::underlying_type_t<EthProcessorTypes>>(PHYSICAL_AERISC_ID);
#elif defined(COMPILE_FOR_IDLE_ERISC)
constexpr std::underlying_type_t<EthProcessorTypes> proc_type =
    static_cast<std::underlying_type_t<EthProcessorTypes>>(PROCESSOR_INDEX);
#elif defined(COMPILE_FOR_DRISC)
constexpr std::underlying_type_t<DramProcessorTypes> proc_type =
    static_cast<std::underlying_type_t<DramProcessorTypes>>(DramProcessorTypes::DM0);
#elif defined(COMPILE_FOR_TRISC)
// TRISC is not a data movement processor. This is just so it compiles
constexpr std::underlying_type_t<TensixProcessorTypes> proc_type =
    static_cast<std::underlying_type_t<TensixProcessorTypes>>(TensixProcessorTypes::DM1);
#else
// Lite Fabric compile
constexpr std::underlying_type_t<EthProcessorTypes> proc_type =
    static_cast<std::underlying_type_t<EthProcessorTypes>>(EthProcessorTypes::DM1);
#endif

// Helper functions to convert NoC coordinates to NoC-0 coordinates, used in metal as "physical" coordinates.
#define NOC_0_X(noc_index, noc_size_x, x) x
#define NOC_0_Y(noc_index, noc_size_y, y) y
#define NOC_0_X_PHYS_COORD(noc_index, noc_size_x, x) (noc_index == 0 ? (x) : (noc_size_x - 1 - (x)))
#define NOC_0_Y_PHYS_COORD(noc_index, noc_size_y, y) (noc_index == 0 ? (y) : (noc_size_y - 1 - (y)))
#define MY_NOC_ENCODING(noc_index) NOC_CMD_BUF_READ_REG(noc_index, 0, NOC_CFG(NOC_ID_LOGICAL))

////
/*TODO: RT review this file, currently using wormhole b0 copy, check if any changes needed for BH*/
constexpr uint32_t DYNAMIC_NOC_NCRISC_WR_CMD_BUF = 2;  // all writes share cmd buf
constexpr uint32_t DYNAMIC_NOC_NCRISC_WR_REG_CMD_BUF = 2;
constexpr uint32_t DYNAMIC_NOC_NCRISC_AT_CMD_BUF = 3;
constexpr uint32_t DYNAMIC_NOC_NCRISC_RD_CMD_BUF = 3;

constexpr uint32_t DYNAMIC_NOC_BRISC_WR_CMD_BUF = 0;  // all writes share cmd buf
constexpr uint32_t DYNAMIC_NOC_BRISC_WR_REG_CMD_BUF = 0;
constexpr uint32_t DYNAMIC_NOC_BRISC_AT_CMD_BUF = 1;
constexpr uint32_t DYNAMIC_NOC_BRISC_RD_CMD_BUF = 1;

constexpr uint32_t NCRISC_WR_CMD_BUF = 0;      // for large writes
constexpr uint32_t NCRISC_RD_CMD_BUF = 1;      // for all reads
constexpr uint32_t NCRISC_WR_REG_CMD_BUF = 2;  // for small writes (e.g., registers, semaphores)
constexpr uint32_t NCRISC_AT_CMD_BUF = 3;      // for atomics

constexpr uint32_t BRISC_WR_CMD_BUF = 0;      // for large writes
constexpr uint32_t BRISC_RD_CMD_BUF = 1;      // for all reads
constexpr uint32_t BRISC_WR_REG_CMD_BUF = 2;  // for small writes (e.g., registers, semaphores)
constexpr uint32_t BRISC_AT_CMD_BUF = 3;      // for atomics
constexpr uint32_t NUM_NOC_CMD_BUFS = 4;

// BH has 64 bit address space but pipegen was not updated to support this so WH scheme of encoding addresses is used
// (36 bits of address followed by coordinates) This means that lo and mid registers need to have the address portion
// while the coordinates go into hi register Metal does not need to use more than 32 bits for addresses but the 60th bit
// needs to be set to enable NoC transactions through PCIe (see get_pcie_base_addr_from_device)
constexpr uint32_t NOC_ADDR_COORD_SHIFT = 36;
const uint32_t NOC_TARG_ADDR_COORDINATE = NOC_TARG_ADDR_HI;
const uint32_t NOC_RET_ADDR_COORDINATE = NOC_RET_ADDR_HI;
const uint32_t NOC_COORDINATE_MASK = 0xFFFFFF;

// Mask for the 60th bit of the address in NOC_TARG/RET_ADDR_MID, which is set to enable PCIe transactions
constexpr uint32_t NOC_PCIE_MASK = 0x1000000F;

extern uint32_t noc_reads_num_issued[NUM_NOCS];
extern uint32_t noc_nonposted_writes_num_issued[NUM_NOCS];
extern uint32_t noc_nonposted_writes_acked[NUM_NOCS];
extern uint32_t noc_nonposted_atomics_acked[NUM_NOCS];
extern uint32_t noc_posted_writes_num_issued[NUM_NOCS];

enum class NocBarrierType : uint8_t {
    READS_NUM_ISSUED,
    NONPOSTED_WRITES_NUM_ISSUED,
    NONPOSTED_WRITES_ACKED,
    NONPOSTED_ATOMICS_ACKED,
    POSTED_WRITES_NUM_ISSUED,
    COUNT
};

static constexpr uint8_t NUM_BARRIER_TYPES = static_cast<uint32_t>(NocBarrierType::COUNT);

struct BarrierCounter {
    uint32_t barrier[NUM_BARRIER_TYPES];
};

struct RiscBarrierCounter {
    BarrierCounter risc[MaxDMProcessorsPerCoreType];
};

struct NocBarrierCounter {
    RiscBarrierCounter noc[NUM_NOCS];
};

// Must update the allocated size for the counters in dev_mem_map.h AND base FW if this changes
static_assert(sizeof(NocBarrierCounter) == 80, "NocBarrierCounter size is not 80 bytes");

template <uint8_t proc_t, NocBarrierType barrier_type>
inline __attribute__((always_inline)) uint32_t get_noc_counter_address(uint32_t noc) {
    static_assert(proc_t < MaxDMProcessorsPerCoreType);
    static_assert(static_cast<std::underlying_type_t<NocBarrierType>>(barrier_type) < NUM_BARRIER_TYPES);
#if defined(COMPILE_FOR_AERISC)
    constexpr uint32_t base = MEM_AERISC_NOC_COUNTER_BASE;
#else
    constexpr uint32_t base = MEM_NOC_COUNTER_BASE;
#endif

    // Calculate most of the offset at compile time. Only the noc is variable at runtime.
    constexpr uint32_t compile_time_offset =
        offsetof(NocBarrierCounter, noc) + proc_t * sizeof(decltype(std::declval<NocBarrierCounter>().noc[0].risc[0])) +
        static_cast<std::underlying_type_t<NocBarrierType>>(barrier_type) *
            sizeof(decltype(std::declval<NocBarrierCounter>().noc[0].risc[0].barrier[0]));

    constexpr uint32_t noc_stride = sizeof(decltype(std::declval<NocBarrierCounter>().noc[0]));

    return base + noc * noc_stride + compile_time_offset;
}

// noc_nonposted_writes_acked
template <uint8_t proc_t, NocBarrierType barrier_type>
inline __attribute__((always_inline)) uint32_t get_noc_counter_val(uint32_t noc) {
    uint32_t counter_addr = get_noc_counter_address<proc_t, barrier_type>(noc);
    return *reinterpret_cast<volatile tt_l1_ptr uint32_t*>(counter_addr);
}

template <uint8_t proc_t, NocBarrierType barrier_type>
inline __attribute__((always_inline)) void inc_noc_counter_val(uint32_t noc, uint32_t inc = 1) {
    uint32_t counter_addr = get_noc_counter_address<proc_t, barrier_type>(noc);
    *reinterpret_cast<volatile tt_l1_ptr uint32_t*>(counter_addr) += inc;
}

template <uint8_t proc_t, NocBarrierType barrier_type>
inline __attribute__((always_inline)) void set_noc_counter_val(uint32_t noc, uint32_t val) {
    uint32_t counter_addr = get_noc_counter_address<proc_t, barrier_type>(noc);
    *reinterpret_cast<volatile tt_l1_ptr uint32_t*>(counter_addr) = val;
}

inline __attribute__((always_inline)) void NOC_CMD_BUF_WRITE_REG(
    uint32_t noc, uint32_t buf, uint32_t addr, uint32_t val) {
#if defined(WATCHER_ENABLE_NOC_SANITIZE_LINKED_TRANSACTION)
    if (addr == NOC_CTRL) {
        auto* watcher_msg = GET_MAILBOX_ADDRESS_DEV(watcher);
        watcher_msg->noc_linked_status[noc] = (val & NOC_CMD_VC_LINKED) != 0;
    }
#endif
    uint32_t offset = (buf << NOC_CMD_BUF_OFFSET_BIT) + (noc << NOC_INSTANCE_OFFSET_BIT) + addr;
    volatile uint32_t* ptr = (volatile uint32_t*)offset;
    *ptr = val;
}

inline __attribute__((always_inline)) uint32_t NOC_CMD_BUF_READ_REG(uint32_t noc, uint32_t buf, uint32_t addr) {
    uint32_t offset = (buf << NOC_CMD_BUF_OFFSET_BIT) + (noc << NOC_INSTANCE_OFFSET_BIT) + addr;
    volatile uint32_t* ptr = (volatile uint32_t*)offset;
    return *ptr;
}

inline __attribute__((always_inline)) uint32_t NOC_STATUS_READ_REG(uint32_t noc, uint32_t reg_id) {
    uint32_t offset = (noc << NOC_INSTANCE_OFFSET_BIT) + NOC_STATUS(reg_id);
    volatile uint32_t* ptr = (volatile uint32_t*)offset;
    return *ptr;
}

inline __attribute__((always_inline)) uint32_t NOC_CFG_READ_REG(uint32_t noc, uint32_t reg_id) {
    uint32_t offset = (noc << NOC_INSTANCE_OFFSET_BIT) + NOC_CFG(reg_id);
    volatile uint32_t* ptr = (volatile uint32_t*)offset;
    return *ptr;
}

inline __attribute__((always_inline)) void NOC_CFG_WRITE_REG(uint32_t noc, uint32_t reg_id, uint32_t val) {
    uint32_t offset = (noc << NOC_INSTANCE_OFFSET_BIT) + NOC_CFG(reg_id);
    *(volatile uint32_t*)offset = val;
}

inline __attribute__((always_inline)) bool noc_cmd_buf_ready(uint32_t noc, uint32_t cmd_buf) {
    return (NOC_CMD_BUF_READ_REG(noc, cmd_buf, NOC_CMD_CTRL) == NOC_CTRL_STATUS_READY);
}

inline __attribute__((always_inline)) void noc_clear_outstanding_req_cnt(uint32_t noc, uint32_t id_mask) {
    uint32_t offset = (noc << NOC_INSTANCE_OFFSET_BIT) + NOC_CLEAR_OUTSTANDING_REQ_CNT;
    volatile uint32_t* ptr = (volatile uint32_t*)offset;
    *ptr = id_mask;
}

// Save/restore entire command buffer state (e.g. for profiler).
// Same struct on all arches; ret_addr_mid only used on Blackhole and Quasar (WH keeps it for layout uniformity).
struct NocCmdBufState {
    uint32_t ctrl;
    uint32_t ret_addr_coord;
    uint32_t targ_addr_lo;
    uint32_t ret_addr_lo;
    uint32_t at_len_be;
    uint32_t targ_addr_coord;
    uint32_t targ_addr_mid;
    uint32_t packet_tag;
    uint32_t at_data;
    uint32_t ret_addr_mid;
};

// Saves all cmd_buf registers into state; clears reserved NOC_CTRL bits in the saved state.
inline __attribute__((always_inline)) void noc_cmd_buf_save_state(
    uint32_t noc, uint32_t cmd_buf, NocCmdBufState* state) {
    state->ctrl = NOC_CMD_BUF_READ_REG(noc, cmd_buf, NOC_CTRL);
    // Clear reserved bits in NOC_CTRL so they are not restored.
    constexpr uint32_t noc_ctrl_reserved_bit_mask = ((1u << 27) - (1u << 18)) | (1u << 31);
    state->ctrl &= ~noc_ctrl_reserved_bit_mask;
    state->ret_addr_coord = NOC_CMD_BUF_READ_REG(noc, cmd_buf, NOC_RET_ADDR_COORDINATE);
    state->targ_addr_lo = NOC_CMD_BUF_READ_REG(noc, cmd_buf, NOC_TARG_ADDR_LO);
    state->ret_addr_lo = NOC_CMD_BUF_READ_REG(noc, cmd_buf, NOC_RET_ADDR_LO);
    state->at_len_be = NOC_CMD_BUF_READ_REG(noc, cmd_buf, NOC_AT_LEN_BE);
    state->targ_addr_coord = NOC_CMD_BUF_READ_REG(noc, cmd_buf, NOC_TARG_ADDR_COORDINATE);
    state->targ_addr_mid = NOC_CMD_BUF_READ_REG(noc, cmd_buf, NOC_TARG_ADDR_MID);
    state->packet_tag = NOC_CMD_BUF_READ_REG(noc, cmd_buf, NOC_PACKET_TAG);
    state->at_data = NOC_CMD_BUF_READ_REG(noc, cmd_buf, NOC_AT_DATA);
    state->ret_addr_mid = NOC_CMD_BUF_READ_REG(noc, cmd_buf, NOC_RET_ADDR_MID);
}

// Clears NOC_PACKET_TAG register for the specified cmd_buf.
inline __attribute__((always_inline)) void noc_clear_packet_tag(uint32_t noc, uint32_t cmd_buf) {
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_PACKET_TAG, 0);
}

inline __attribute__((always_inline)) void noc_clear_packet_tags(uint32_t noc) {
    for (uint32_t cmd_buf = 0; cmd_buf < NUM_NOC_CMD_BUFS; cmd_buf++) {
        noc_clear_packet_tag(noc, cmd_buf);
    }
}

inline __attribute__((always_inline)) void noc_clear_all_packet_tags() {
    for (uint32_t noc = 0; noc < NUM_NOCS; noc++) {
        noc_clear_packet_tags(noc);
    }
}

// Kernels that do not explicitly set transaction IDs should naturally use transaction ID 0 for multicast writes after
// kernel handoff. Only write/atomic-capable command buffers matter for this assert.
inline __attribute__((always_inline)) bool ncrisc_noc_packet_tags_cleared(uint32_t noc) {
    return NOC_CMD_BUF_READ_REG(noc, NCRISC_WR_CMD_BUF, NOC_PACKET_TAG) == 0 &&
           NOC_CMD_BUF_READ_REG(noc, NCRISC_WR_REG_CMD_BUF, NOC_PACKET_TAG) == 0 &&
           NOC_CMD_BUF_READ_REG(noc, NCRISC_AT_CMD_BUF, NOC_PACKET_TAG) == 0;
}

// Restores cmd_buf from state; waits for cmd_buf ready before writing.
inline __attribute__((always_inline)) void noc_cmd_buf_restore_state(
    uint32_t noc, uint32_t cmd_buf, const NocCmdBufState* state) {
    while (!noc_cmd_buf_ready(noc, cmd_buf));
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_CTRL, state->ctrl);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_RET_ADDR_COORDINATE, state->ret_addr_coord);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_TARG_ADDR_LO, state->targ_addr_lo);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_RET_ADDR_LO, state->ret_addr_lo);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_AT_LEN_BE, state->at_len_be);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_TARG_ADDR_COORDINATE, state->targ_addr_coord);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_TARG_ADDR_MID, state->targ_addr_mid);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_PACKET_TAG, state->packet_tag);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_AT_DATA, state->at_data);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_RET_ADDR_MID, state->ret_addr_mid);
}

/**
 * Returns the number of read transactions issued on this NOC.
 *
 * Return value: Number of read transactions issued
 *
 * | Argument | Description                | Data type | Valid range | Required |
 * |----------|----------------------------|-----------|-------------|----------|
 * | noc      | NOC index                  | uint32_t  | 0 or 1      | True     |
 */
inline __attribute__((always_inline)) uint32_t noc_get_reads_issued(uint32_t noc) { return noc_reads_num_issued[noc]; }

/**
 * Returns the number of nonposted write transactions issued on this NOC.
 *
 * Return value: Number of nonposted write transactions issued
 *
 * | Argument | Description                | Data type | Valid range | Required |
 * |----------|----------------------------|-----------|-------------|----------|
 * | noc      | NOC index                  | uint32_t  | 0 or 1      | True     |
 */
inline __attribute__((always_inline)) uint32_t noc_get_nonposted_writes_issued(uint32_t noc) {
    return noc_nonposted_writes_num_issued[noc];
}

/**
 * Returns the number of nonposted write acknowledgments received on this NOC.
 *
 * Return value: Number of nonposted write acks received
 *
 * | Argument | Description                | Data type | Valid range | Required |
 * |----------|----------------------------|-----------|-------------|----------|
 * | noc      | NOC index                  | uint32_t  | 0 or 1      | True     |
 */
inline __attribute__((always_inline)) uint32_t noc_get_nonposted_writes_acked(uint32_t noc) {
    return noc_nonposted_writes_acked[noc];
}

/**
 * Returns the number of nonposted atomic acknowledgments received on this NOC.
 *
 * Return value: Number of nonposted atomic acks received
 *
 * | Argument | Description                | Data type | Valid range | Required |
 * |----------|----------------------------|-----------|-------------|----------|
 * | noc      | NOC index                  | uint32_t  | 0 or 1      | True     |
 */
inline __attribute__((always_inline)) uint32_t noc_get_nonposted_atomics_acked(uint32_t noc) {
    return noc_nonposted_atomics_acked[noc];
}

/**
 * Returns the number of posted write transactions issued on this NOC.
 *
 * Return value: Number of posted write transactions issued
 *
 * | Argument | Description                | Data type | Valid range | Required |
 * |----------|----------------------------|-----------|-------------|----------|
 * | noc      | NOC index                  | uint32_t  | 0 or 1      | True     |
 */
inline __attribute__((always_inline)) uint32_t noc_get_posted_writes_issued(uint32_t noc) {
    return noc_posted_writes_num_issued[noc];
}

/**
 * Increments the nonposted write acknowledgments counter by the specified delta.
 * Useful for multicast write accounting where multiple destinations receive the same write.
 *
 * Return value: None
 *
 * | Argument | Description                                    | Data type | Valid range | Required |
 * |----------|------------------------------------------------|-----------|-------------|----------|
 * | noc      | NOC index                                      | uint32_t  | 0 or 1      | True     |
 * | delta    | Amount to increment the counter by             | uint32_t  | 0..2^32-1   | True     |
 */
inline __attribute__((always_inline)) void noc_increment_nonposted_writes_acked(uint32_t noc, uint32_t delta) {
    noc_nonposted_writes_acked[noc] += delta;
}

/**
 * Increments the nonposted write issued counter by the specified delta.
 * Useful for multicast write accounting where a single transaction targets multiple destinations.
 *
 * Return value: None
 *
 * | Argument | Description                                    | Data type | Valid range | Required |
 * |----------|------------------------------------------------|-----------|-------------|----------|
 * | noc      | NOC index                                      | uint32_t  | 0 or 1      | True     |
 * | delta    | Amount to increment the counter by             | uint32_t  | 0..2^32-1   | True     |
 */
inline __attribute__((always_inline)) void noc_increment_nonposted_writes_issued(uint32_t noc, uint32_t delta) {
    noc_nonposted_writes_num_issued[noc] += delta;
}

// True if hardware nonposted-writes-sent count has reached expected_count (wrap-around safe).
inline __attribute__((always_inline)) bool noc_nonposted_writes_sent_at_count(uint32_t noc, uint32_t expected_count) {
    uint32_t sent = NOC_STATUS_READ_REG(noc, NIU_MST_NONPOSTED_WR_REQ_SENT);
    return (int32_t)(sent - expected_count) >= 0;
}

/**
 * Sets the target address coordinates for a NOC command buffer.
 * Writes only the NOC_TARG_ADDR_COORDINATE register (NOC x,y coordinates).
 *
 * Return value: None
 *
 * | Argument | Description                                        | Data type | Valid range | Required |
 * |----------|----------------------------------------------------|-----------|-------------|----------|
 * | noc      | NOC index                                          | uint32_t  | 0 or 1      | True     |
 * | cmd_buf  | Command buffer index                               | uint32_t  | 0 - 3       | True     |
 * | coord    | Packed NOC coordinates from NOC_XY_COORD(x, y)     | uint32_t  | 0..2^32-1   | True     |
 */
inline __attribute__((always_inline)) void noc_cmd_buf_set_targ_addr_coordinate(
    uint32_t noc, uint32_t cmd_buf, uint32_t coord) {
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_TARG_ADDR_COORDINATE, coord);
}

/**
 * Sets the full target address for a NOC command buffer.
 * Writes NOC_TARG_ADDR_LO, NOC_TARG_ADDR_MID, and NOC_TARG_ADDR_COORDINATE registers.
 *
 * Return value: None
 *
 * | Argument  | Description                                        | Data type | Valid range | Required |
 * |-----------|----------------------------------------------------|-----------|-------------|----------|
 * | noc       | NOC index                                          | uint32_t  | 0 or 1      | True     |
 * | cmd_buf   | Command buffer index                               | uint32_t  | 0 - 3       | True     |
 * | targ_addr | Full NOC address from NOC_XY_ADDR(x, y, addr)      | uint64_t  | 0..2^64-1   | True     |
 */
inline __attribute__((always_inline)) void noc_cmd_buf_set_targ_addr(
    uint32_t noc, uint32_t cmd_buf, uint64_t targ_addr) {
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_TARG_ADDR_LO, (uint32_t)(targ_addr & 0xFFFFFFFF));
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_TARG_ADDR_MID, (uint32_t)(targ_addr >> 32) & NOC_PCIE_MASK);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_TARG_ADDR_COORDINATE, (uint32_t)(targ_addr >> NOC_ADDR_COORD_SHIFT));
}

/**
 * Sets the return address coordinates for a NOC command buffer.
 * Writes only the NOC_RET_ADDR_COORDINATE register (NOC x,y coordinates).
 *
 * Return value: None
 *
 * | Argument | Description                                        | Data type | Valid range | Required |
 * |----------|----------------------------------------------------|-----------|-------------|----------|
 * | noc      | NOC index                                          | uint32_t  | 0 or 1      | True     |
 * | cmd_buf  | Command buffer index                               | uint32_t  | 0 - 3       | True     |
 * | coord    | Packed NOC coordinates from NOC_XY_COORD(x, y)     | uint32_t  | 0..2^32-1   | True     |
 */
inline __attribute__((always_inline)) void noc_cmd_buf_set_ret_addr_coordinate(
    uint32_t noc, uint32_t cmd_buf, uint32_t coord) {
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_RET_ADDR_COORDINATE, coord);
}

/**
 * Sets the full return address for a NOC command buffer.
 * Writes NOC_RET_ADDR_LO, NOC_RET_ADDR_MID, and NOC_RET_ADDR_COORDINATE registers.
 * Typically used for atomic operations where a return value is expected.
 *
 * Return value: None
 *
 * | Argument | Description                                        | Data type | Valid range | Required |
 * |----------|----------------------------------------------------|-----------|-------------|----------|
 * | noc      | NOC index                                          | uint32_t  | 0 or 1      | True     |
 * | cmd_buf  | Command buffer index                               | uint32_t  | 0 - 3       | True     |
 * | ret_addr | Full NOC address from NOC_XY_ADDR(x, y, addr)      | uint64_t  | 0..2^64-1   | True     |
 */
inline __attribute__((always_inline)) void noc_cmd_buf_set_ret_addr(uint32_t noc, uint32_t cmd_buf, uint64_t ret_addr) {
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_RET_ADDR_LO, (uint32_t)(ret_addr & 0xFFFFFFFF));
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_RET_ADDR_MID, (uint32_t)(ret_addr >> 32) & NOC_PCIE_MASK);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_RET_ADDR_COORDINATE, (uint32_t)(ret_addr >> NOC_ADDR_COORD_SHIFT));
}

/**
 * Sets NOC_TARG_ADDR_MID to route reads through the PCIe core. This register is sticky per command buffer,
 * so every use must be paired with noc_cmd_buf_clear_targ_addr_mid once cmd_buf is ready after the last read. A stale
 * value misroutes the next unrelated read on cmd_buf to host memory.
 *
 * Return value: None
 *
 * | Argument | Description                                        | Data type | Valid range | Required |
 * |----------|----------------------------------------------------|-----------|-------------|----------|
 * | noc      | NOC index                                          | uint32_t  | 0 or 1      | True     |
 * | cmd_buf  | Command buffer index                               | uint32_t  | 0 - 3       | True     |
 * | addr     | Full NOC address from NOC_XY_PCIE_ENCODING(...)    | uint64_t  | 0..2^64-1   | True     |
 */
inline __attribute__((always_inline)) void noc_cmd_buf_set_targ_addr_mid_pcie(
    uint32_t noc, uint32_t cmd_buf, uint64_t addr) {
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_TARG_ADDR_MID, (uint32_t)(addr >> 32) & NOC_PCIE_MASK);
}

// Clears NOC_TARG_ADDR_MID back to 0, so that later ordinary reads on cmd_buf are not misrouted. Call this
// after every use of noc_cmd_buf_set_targ_addr_mid_pcie.
inline __attribute__((always_inline)) void noc_cmd_buf_clear_targ_addr_mid(uint32_t noc, uint32_t cmd_buf) {
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_TARG_ADDR_MID, 0);
}

// Same as noc_cmd_buf_set_targ_addr_mid_pcie, but for NOC_RET_ADDR_MID, which holds a write's destination.
inline __attribute__((always_inline)) void noc_cmd_buf_set_ret_addr_mid_pcie(
    uint32_t noc, uint32_t cmd_buf, uint64_t addr) {
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_RET_ADDR_MID, (uint32_t)(addr >> 32) & NOC_PCIE_MASK);
}

// Clears NOC_RET_ADDR_MID back to 0, so that later ordinary writes on cmd_buf are not misrouted. Call this
// after every use of noc_cmd_buf_set_ret_addr_mid_pcie.
inline __attribute__((always_inline)) void noc_cmd_buf_clear_ret_addr_mid(uint32_t noc, uint32_t cmd_buf) {
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_RET_ADDR_MID, 0);
}

// Debug only: the routing register must agree with the address being issued. The plain issue paths do not write
// MID, so a stale value left behind by a PCIe batch would silently misroute an on-chip transaction, and a missing
// one would send a PCIe transaction to an on-chip core. Both read as a correct address in every other register.
// ASSERT leaves its operand unevaluated in a release build, so the register read costs nothing there.
// Both sides are masked because callers using the separate-coordinate issuers program MID with the full high
// word of a 64-bit address, while an addr packed WH-style only carries routing in the masked bits. Comparing
// unmasked would fail on an address above 2^36 that was programmed correctly.
inline __attribute__((always_inline)) void noc_assert_targ_addr_mid_matches(
    uint32_t noc, uint32_t cmd_buf, uint64_t addr) {
    ASSERT(
        (NOC_CMD_BUF_READ_REG(noc, cmd_buf, NOC_TARG_ADDR_MID) & NOC_PCIE_MASK) ==
        ((uint32_t)(addr >> 32) & NOC_PCIE_MASK));
}

inline __attribute__((always_inline)) void noc_assert_ret_addr_mid_matches(
    uint32_t noc, uint32_t cmd_buf, uint64_t addr) {
    ASSERT(
        (NOC_CMD_BUF_READ_REG(noc, cmd_buf, NOC_RET_ADDR_MID) & NOC_PCIE_MASK) ==
        ((uint32_t)(addr >> 32) & NOC_PCIE_MASK));
}

// Debug only: asserts that no PCIe batch is open on cmd_buf. Used by the paths that overwrite
// NOC_TARG_ADDR_MID with an on-chip address, which would silently misroute the rest of such a batch.
inline __attribute__((always_inline)) void noc_assert_targ_addr_mid_clear(uint32_t noc, uint32_t cmd_buf) {
    ASSERT(NOC_CMD_BUF_READ_REG(noc, cmd_buf, NOC_TARG_ADDR_MID) == 0);
}

// True when cmd_buf holds no PCIe routing, i.e. both MID registers are back to their on-chip value of zero.
// The plain issue paths no longer rewrite MID, so anything left here is inherited by the next transaction on
// this buffer. Callers use it to assert the buffer was handed back clean.
inline __attribute__((always_inline)) bool noc_cmd_buf_mid_clear(uint32_t noc, uint32_t cmd_buf) {
    return NOC_CMD_BUF_READ_REG(noc, cmd_buf, NOC_TARG_ADDR_MID) == 0 &&
           NOC_CMD_BUF_READ_REG(noc, cmd_buf, NOC_RET_ADDR_MID) == 0;
}

// Debug only: returns NOC_AT_LEN_BE for cmd_buf (transaction length). Requires NOC_LOGGING_ENABLED.
inline __attribute__((always_inline)) uint32_t noc_debug_read_at_len_be(uint32_t noc, uint32_t cmd_buf) {
    return NOC_CMD_BUF_READ_REG(noc, cmd_buf, NOC_AT_LEN_BE);
}

inline __attribute__((always_inline)) uint32_t noc_get_interim_inline_value_addr(uint32_t noc, uint64_t dst_noc_addr) {
    // On Blackhole issuing inline writes and atomics requires all 4 memory ports to accept the transaction at the same
    // time. If one port on the recipient has no back-pressure then the transaction will hang because there is no
    // mechanism to allow one memory port to move ahead of another. To workaround this hang, we emulate inline writes on
    // Blackhole by writing the value to be written to local L1 first and then issue a noc async write.

    // If dst_noc_addr is not L1 aligned then we need to offset the src address by 4B since inline write dst address
    // needs to respect 4B alignment.
    ASSERT((dst_noc_addr & 0x3) == 0);
    uint32_t offset = dst_noc_addr & 0xF;

#if defined(COMPILE_FOR_IDLE_ERISC)
    uint32_t src_addr = MEM_IERISC_L1_INLINE_BASE + (2 * MEM_L1_INLINE_SIZE_PER_NOC) * proc_type;
#elif defined(COMPILE_FOR_ERISC)
    uint32_t src_addr = MEM_AERISC_L1_INLINE_BASE + (2 * MEM_L1_INLINE_SIZE_PER_NOC) * proc_type;
#else
    uint32_t src_addr = MEM_L1_INLINE_BASE + (2 * MEM_L1_INLINE_SIZE_PER_NOC) * proc_type;
#endif

#ifdef COMPILE_FOR_TRISC
    ASSERT(0);  // we do not have L1 space for inline values for TRISCs.
#endif
    src_addr += noc * MEM_L1_INLINE_SIZE_PER_NOC + offset;
    return src_addr;
}

template <uint8_t noc_mode = DM_DEDICATED_NOC>
inline __attribute__((always_inline)) void ncrisc_noc_fast_read(
    uint32_t noc,
    uint32_t cmd_buf,
    uint64_t src_addr,
    uint32_t dest_addr,
    uint32_t len_bytes,
    uint32_t read_req_vc = 1) {
    if constexpr (noc_mode == DM_DYNAMIC_NOC) {
        inc_noc_counter_val<proc_type, NocBarrierType::READS_NUM_ISSUED>(noc, 1);
    }
    if constexpr (noc_mode == DM_DYNAMIC_NOC) {
        uint32_t noc_rd_cmd_field =
            NOC_CMD_CPY | NOC_CMD_RD | NOC_CMD_RESP_MARKED | NOC_CMD_VC_STATIC | NOC_CMD_STATIC_VC(read_req_vc);
        NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_CTRL, noc_rd_cmd_field);
    }
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_RET_ADDR_LO, dest_addr);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_TARG_ADDR_LO, (uint32_t)src_addr);
    // NOC_TARG_ADDR_MID is not written here, since it is 0 for every on-chip src_addr. Callers targeting
    // the PCIe core must set it with noc_cmd_buf_set_targ_addr_mid_pcie beforehand, and clear it after.
    noc_assert_targ_addr_mid_matches(noc, cmd_buf, src_addr);
    NOC_CMD_BUF_WRITE_REG(
        noc, cmd_buf, NOC_TARG_ADDR_COORDINATE, (uint32_t)(src_addr >> NOC_ADDR_COORD_SHIFT) & NOC_COORDINATE_MASK);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_AT_LEN_BE, len_bytes);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_CMD_CTRL, NOC_CTRL_SEND_REQ);
    if constexpr (noc_mode == DM_DEDICATED_NOC) {
        noc_reads_num_issued[noc] += 1;
    }
}

inline __attribute__((always_inline)) bool ncrisc_dynamic_noc_reads_flushed(uint32_t noc) {
    uint32_t status_reg_val = NOC_STATUS_READ_REG(noc, NIU_MST_RD_RESP_RECEIVED);
    uint32_t self_risc_acked = get_noc_counter_val<proc_type, NocBarrierType::READS_NUM_ISSUED>(noc);
    uint32_t other_risc_acked = get_noc_counter_val<1 - proc_type, NocBarrierType::READS_NUM_ISSUED>(noc);
    return (status_reg_val == (self_risc_acked + other_risc_acked));
}

inline __attribute__((always_inline)) bool ncrisc_noc_reads_flushed(uint32_t noc) {
    return (NOC_STATUS_READ_REG(noc, NIU_MST_RD_RESP_RECEIVED) == noc_reads_num_issued[noc]);
}

inline __attribute__((always_inline)) bool ncrisc_noc_read_with_transaction_id_flushed(
    uint32_t noc, uint32_t transcation_id) {
    return (NOC_STATUS_READ_REG(noc, NIU_MST_REQS_OUTSTANDING_ID(transcation_id)) == 0);
}

inline __attribute__((always_inline)) uint32_t noc_available_transactions(uint32_t noc, uint32_t trid) {
    return NOC_MAX_TRANSACTION_ID_COUNT - NOC_STATUS_READ_REG(noc, NIU_MST_REQS_OUTSTANDING_ID(trid));
}

template <uint8_t noc_mode = DM_DEDICATED_NOC, bool use_trid = false, bool update_counter = true>
inline __attribute__((always_inline)) void ncrisc_noc_fast_write(
    uint32_t noc,
    uint32_t cmd_buf,
    uint32_t src_addr,
    uint64_t dest_addr,
    uint32_t len_bytes,
    uint32_t vc,
    bool mcast,
    bool linked,
    uint32_t num_dests,
    bool multicast_path_reserve,
    bool posted = false,
    uint32_t trid = 0) {
    if constexpr (update_counter && noc_mode == DM_DYNAMIC_NOC) {
        if (posted) {
            inc_noc_counter_val<proc_type, NocBarrierType::POSTED_WRITES_NUM_ISSUED>(noc, 1);
        } else {
            inc_noc_counter_val<proc_type, NocBarrierType::NONPOSTED_WRITES_NUM_ISSUED>(noc, 1);
            inc_noc_counter_val<proc_type, NocBarrierType::NONPOSTED_WRITES_ACKED>(noc, num_dests);
        }
    }
    uint32_t noc_cmd_field =
        NOC_CMD_CPY | NOC_CMD_WR | NOC_CMD_VC_STATIC | NOC_CMD_STATIC_VC(vc) | (linked ? NOC_CMD_VC_LINKED : 0x0) |
        (mcast ? ((multicast_path_reserve ? NOC_CMD_PATH_RESERVE : 0) | NOC_CMD_BRCST_PACKET) : 0x0) |
        (posted ? 0 : NOC_CMD_RESP_MARKED);

    if constexpr (use_trid) {
        NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_PACKET_TAG, NOC_PACKET_TAG_TRANSACTION_ID(trid));
    }

    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_CTRL, noc_cmd_field);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_TARG_ADDR_LO, src_addr);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_RET_ADDR_LO, (uint32_t)dest_addr);
    // NOC_RET_ADDR_MID is not written here, since it is 0 for every on-chip dest_addr. Callers targeting
    // the PCIe core must set it with noc_cmd_buf_set_ret_addr_mid_pcie beforehand, and clear it after.
    noc_assert_ret_addr_mid_matches(noc, cmd_buf, dest_addr);
    NOC_CMD_BUF_WRITE_REG(
        noc, cmd_buf, NOC_RET_ADDR_COORDINATE, (uint32_t)(dest_addr >> NOC_ADDR_COORD_SHIFT) & NOC_COORDINATE_MASK);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_AT_LEN_BE, len_bytes);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_CMD_CTRL, NOC_CTRL_SEND_REQ);

    if constexpr (update_counter && noc_mode == DM_DEDICATED_NOC) {
        if (posted) {
            noc_posted_writes_num_issued[noc] += 1;
        } else {
            noc_nonposted_writes_num_issued[noc] += 1;
            noc_nonposted_writes_acked[noc] += num_dests;
        }
    }
}

template <uint8_t noc_mode = DM_DEDICATED_NOC>
inline __attribute__((always_inline)) void ncrisc_noc_fast_write_loopback_src(
    uint32_t noc,
    uint32_t cmd_buf,
    uint32_t src_addr,
    uint64_t dest_addr,
    uint32_t len_bytes,
    uint32_t vc,
    bool mcast,
    bool linked,
    uint32_t num_dests,
    bool multicast_path_reserve) {
    if constexpr (noc_mode == DM_DYNAMIC_NOC) {
        inc_noc_counter_val<proc_type, NocBarrierType::NONPOSTED_WRITES_NUM_ISSUED>(noc, 1);
        inc_noc_counter_val<proc_type, NocBarrierType::NONPOSTED_WRITES_ACKED>(noc, num_dests);
    }
    uint32_t noc_cmd_field =
        NOC_CMD_CPY | NOC_CMD_WR | NOC_CMD_VC_STATIC | NOC_CMD_STATIC_VC(vc) | (linked ? NOC_CMD_VC_LINKED : 0x0) |
        (mcast ? ((multicast_path_reserve ? NOC_CMD_PATH_RESERVE : 0) | NOC_CMD_BRCST_PACKET) : 0x0) |
        NOC_CMD_BRCST_SRC_INCLUDE | NOC_CMD_RESP_MARKED;

    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_CTRL, noc_cmd_field);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_TARG_ADDR_LO, src_addr);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_RET_ADDR_LO, (uint32_t)dest_addr);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_RET_ADDR_MID, (uint32_t)(dest_addr >> 32) & NOC_PCIE_MASK);
    NOC_CMD_BUF_WRITE_REG(
        noc, cmd_buf, NOC_RET_ADDR_COORDINATE, (uint32_t)(dest_addr >> NOC_ADDR_COORD_SHIFT) & NOC_COORDINATE_MASK);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_AT_LEN_BE, len_bytes);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_CMD_CTRL, NOC_CTRL_SEND_REQ);
    if constexpr (noc_mode == DM_DEDICATED_NOC) {
        noc_nonposted_writes_num_issued[noc] += 1;
        noc_nonposted_writes_acked[noc] += num_dests;
    }
}

template <uint8_t noc_mode = DM_DEDICATED_NOC>
[[deprecated("unused function, use async write instead")]]
inline __attribute__((always_inline)) void ncrisc_noc_blitz_write_setup(
    uint32_t noc, uint32_t cmd_buf, uint64_t dest_addr, uint32_t len_bytes, uint32_t vc, uint32_t num_times_to_write) {
    if constexpr (noc_mode == DM_DYNAMIC_NOC) {
        inc_noc_counter_val<proc_type, NocBarrierType::NONPOSTED_WRITES_NUM_ISSUED>(noc, num_times_to_write);
        inc_noc_counter_val<proc_type, NocBarrierType::NONPOSTED_WRITES_ACKED>(noc, num_times_to_write);
    }
    uint32_t noc_cmd_field = NOC_CMD_CPY | NOC_CMD_WR | NOC_CMD_VC_STATIC | NOC_CMD_STATIC_VC(vc) | NOC_CMD_RESP_MARKED;

    while (!noc_cmd_buf_ready(noc, cmd_buf));
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_CTRL, noc_cmd_field);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_AT_LEN_BE, len_bytes);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_RET_ADDR_MID, (uint32_t)(dest_addr >> 32) & NOC_PCIE_MASK);
    NOC_CMD_BUF_WRITE_REG(
        noc, cmd_buf, NOC_RET_ADDR_COORDINATE, (uint32_t)(dest_addr >> NOC_ADDR_COORD_SHIFT) & NOC_COORDINATE_MASK);
    if constexpr (noc_mode == DM_DEDICATED_NOC) {
        noc_nonposted_writes_num_issued[noc] += num_times_to_write;
        noc_nonposted_writes_acked[noc] += num_times_to_write;
    }
}

inline __attribute__((always_inline)) bool ncrisc_dynamic_noc_nonposted_writes_sent(uint32_t noc) {
    uint32_t status_reg_val = NOC_STATUS_READ_REG(noc, NIU_MST_NONPOSTED_WR_REQ_SENT);
    uint32_t self_risc_acked = get_noc_counter_val<proc_type, NocBarrierType::NONPOSTED_WRITES_NUM_ISSUED>(noc);
    uint32_t other_risc_acked = get_noc_counter_val<1 - proc_type, NocBarrierType::NONPOSTED_WRITES_NUM_ISSUED>(noc);
    return (status_reg_val == (self_risc_acked + other_risc_acked));
}

inline __attribute__((always_inline)) bool ncrisc_noc_nonposted_writes_sent(uint32_t noc) {
    return (NOC_STATUS_READ_REG(noc, NIU_MST_NONPOSTED_WR_REQ_SENT) == noc_nonposted_writes_num_issued[noc]);
}

inline __attribute__((always_inline)) bool ncrisc_dynamic_noc_posted_writes_sent(uint32_t noc) {
    uint32_t status_reg_val = NOC_STATUS_READ_REG(noc, NIU_MST_POSTED_WR_REQ_SENT);
    uint32_t self_risc_acked = get_noc_counter_val<proc_type, NocBarrierType::POSTED_WRITES_NUM_ISSUED>(noc);
    uint32_t other_risc_acked = get_noc_counter_val<1 - proc_type, NocBarrierType::POSTED_WRITES_NUM_ISSUED>(noc);
    return (status_reg_val == (self_risc_acked + other_risc_acked));
}

inline __attribute__((always_inline)) bool ncrisc_noc_posted_writes_sent(uint32_t noc) {
    return (NOC_STATUS_READ_REG(noc, NIU_MST_POSTED_WR_REQ_SENT) == noc_posted_writes_num_issued[noc]);
}

inline __attribute__((always_inline)) bool ncrisc_dynamic_noc_nonposted_writes_flushed(uint32_t noc) {
    uint32_t status_reg_val = NOC_STATUS_READ_REG(noc, NIU_MST_WR_ACK_RECEIVED);
    uint32_t self_risc_acked = get_noc_counter_val<proc_type, NocBarrierType::NONPOSTED_WRITES_ACKED>(noc);
    uint32_t other_risc_acked = get_noc_counter_val<1 - proc_type, NocBarrierType::NONPOSTED_WRITES_ACKED>(noc);
    return (status_reg_val == (self_risc_acked + other_risc_acked));
}

inline __attribute__((always_inline)) bool ncrisc_noc_nonposted_writes_flushed(uint32_t noc) {
    return (NOC_STATUS_READ_REG(noc, NIU_MST_WR_ACK_RECEIVED) == noc_nonposted_writes_acked[noc]);
}

inline __attribute__((always_inline)) bool ncrisc_noc_nonposted_write_with_transaction_id_sent(
    uint32_t noc, uint32_t transcation_id) {
    return (NOC_STATUS_READ_REG(noc, NIU_MST_WRITE_REQS_OUTGOING_ID(transcation_id)) == 0);
}

inline __attribute__((always_inline)) bool ncrisc_noc_nonposted_write_with_transaction_id_flushed(
    uint32_t noc, uint32_t transcation_id) {
    return (NOC_STATUS_READ_REG(noc, NIU_MST_REQS_OUTSTANDING_ID(transcation_id)) == 0);
}

inline __attribute__((always_inline)) bool ncrisc_dynamic_noc_nonposted_atomics_flushed(uint32_t noc) {
    uint32_t status_reg_val = NOC_STATUS_READ_REG(noc, NIU_MST_ATOMIC_RESP_RECEIVED);
    uint32_t self_risc_acked = get_noc_counter_val<proc_type, NocBarrierType::NONPOSTED_ATOMICS_ACKED>(noc);
    uint32_t other_risc_acked = get_noc_counter_val<1 - proc_type, NocBarrierType::NONPOSTED_ATOMICS_ACKED>(noc);
    return (status_reg_val == (self_risc_acked + other_risc_acked));
}

inline __attribute__((always_inline)) bool ncrisc_noc_nonposted_atomics_flushed(uint32_t noc) {
    return (NOC_STATUS_READ_REG(noc, NIU_MST_ATOMIC_RESP_RECEIVED) == noc_nonposted_atomics_acked[noc]);
}

inline __attribute__((always_inline)) void noc_init_one(uint32_t noc, uint32_t atomic_ret_val) {
    uint32_t noc_id_reg = NOC_CMD_BUF_READ_REG(noc, 0, NOC_CFG(NOC_ID_LOGICAL));
    uint32_t my_x = noc_id_reg & NOC_NODE_ID_MASK;
    uint32_t my_y = (noc_id_reg >> NOC_ADDR_NODE_ID_BITS) & NOC_NODE_ID_MASK;
    uint64_t xy_local_addr = NOC_XY_ADDR(my_x, my_y, 0);

    NOC_CMD_BUF_WRITE_REG(noc, NCRISC_WR_CMD_BUF, NOC_TARG_ADDR_MID, 0x0);
    NOC_CMD_BUF_WRITE_REG(noc, NCRISC_WR_CMD_BUF, NOC_RET_ADDR_MID, 0x0);
    NOC_CMD_BUF_WRITE_REG(
        noc,
        NCRISC_WR_CMD_BUF,
        NOC_TARG_ADDR_COORDINATE,
        (uint32_t)(xy_local_addr >> NOC_ADDR_COORD_SHIFT) & NOC_COORDINATE_MASK);
    NOC_CMD_BUF_WRITE_REG(noc, NCRISC_WR_REG_CMD_BUF, NOC_TARG_ADDR_MID, 0x0);
    NOC_CMD_BUF_WRITE_REG(
        noc,
        NCRISC_WR_REG_CMD_BUF,
        NOC_TARG_ADDR_COORDINATE,
        (uint32_t)(xy_local_addr >> NOC_ADDR_COORD_SHIFT) & NOC_COORDINATE_MASK);

    uint64_t atomic_ret_addr = NOC_XY_ADDR(my_x, my_y, atomic_ret_val);
    NOC_CMD_BUF_WRITE_REG(noc, NCRISC_AT_CMD_BUF, NOC_RET_ADDR_LO, (uint32_t)(atomic_ret_addr & 0xFFFFFFFF));
    NOC_CMD_BUF_WRITE_REG(noc, NCRISC_AT_CMD_BUF, NOC_RET_ADDR_MID, 0x0);
    NOC_CMD_BUF_WRITE_REG(
        noc,
        NCRISC_AT_CMD_BUF,
        NOC_RET_ADDR_COORDINATE,
        (uint32_t)(atomic_ret_addr >> NOC_ADDR_COORD_SHIFT) & NOC_COORDINATE_MASK);

    uint32_t noc_rd_cmd_field =
        NOC_CMD_CPY | NOC_CMD_RD | NOC_CMD_RESP_MARKED | NOC_CMD_VC_STATIC | NOC_CMD_STATIC_VC(1);
    NOC_CMD_BUF_WRITE_REG(noc, NCRISC_RD_CMD_BUF, NOC_CTRL, noc_rd_cmd_field);
    NOC_CMD_BUF_WRITE_REG(noc, NCRISC_RD_CMD_BUF, NOC_RET_ADDR_MID, 0x0);  // get rid of this?
    NOC_CMD_BUF_WRITE_REG(noc, NCRISC_RD_CMD_BUF, NOC_TARG_ADDR_MID, 0x0);
    NOC_CMD_BUF_WRITE_REG(
        noc,
        NCRISC_RD_CMD_BUF,
        NOC_RET_ADDR_COORDINATE,
        (uint32_t)(xy_local_addr >> NOC_ADDR_COORD_SHIFT) & NOC_COORDINATE_MASK);
}

template <uint8_t MAX_NOCS_TO_INIT = NUM_NOCS>
inline __attribute__((always_inline)) void noc_init(uint32_t atomic_ret_val) {
#pragma GCC unroll 0
    for (uint8_t noc = 0; noc < MAX_NOCS_TO_INIT; noc++) {
        noc_init_one(noc, atomic_ret_val);
    }
}

inline __attribute__((always_inline)) void dynamic_noc_init() {
#pragma GCC unroll 0
    for (int noc = 0; noc < NUM_NOCS; noc++) {
        uint32_t noc_id_reg = NOC_CMD_BUF_READ_REG(noc, 0, NOC_CFG(NOC_ID_LOGICAL));
        uint32_t my_x = noc_id_reg & NOC_NODE_ID_MASK;
        uint32_t my_y = (noc_id_reg >> NOC_ADDR_NODE_ID_BITS) & NOC_NODE_ID_MASK;
        uint64_t xy_local_addr = NOC_XY_ADDR(my_x, my_y, 0);

        // Plain transactions do not program either MID register, so both halves of every command buffer
        // start at 0 here. Firmware only runs this when the NOC mode changes, so it scrubs a PCIe value left
        // by a kernel in the other mode but not one left by a kernel in this mode. Buffers alias in this mode,
        // so clearing both registers on all four covers reads, writes, register writes and atomics.
#pragma GCC unroll 0
        for (uint32_t cmd_buf = 0; cmd_buf < NUM_NOC_CMD_BUFS; cmd_buf++) {
            NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_TARG_ADDR_MID, 0x0);
            NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_RET_ADDR_MID, 0x0);
        }

        // program brisc cmd_buf 0
        NOC_CMD_BUF_WRITE_REG(
            noc,
            DYNAMIC_NOC_BRISC_RD_CMD_BUF,
            NOC_RET_ADDR_COORDINATE,
            (uint32_t)(xy_local_addr >> NOC_ADDR_COORD_SHIFT));

        // program brisc cmd_buf 1
        NOC_CMD_BUF_WRITE_REG(
            noc,
            DYNAMIC_NOC_BRISC_WR_CMD_BUF,
            NOC_TARG_ADDR_COORDINATE,
            (uint32_t)(xy_local_addr >> NOC_ADDR_COORD_SHIFT));

        // program ncrisc cmd_buf 2
        NOC_CMD_BUF_WRITE_REG(
            noc,
            DYNAMIC_NOC_NCRISC_RD_CMD_BUF,
            NOC_RET_ADDR_COORDINATE,
            (uint32_t)(xy_local_addr >> NOC_ADDR_COORD_SHIFT));

        // program ncrisc cmd_buf 3
        NOC_CMD_BUF_WRITE_REG(
            noc,
            DYNAMIC_NOC_NCRISC_WR_CMD_BUF,
            NOC_TARG_ADDR_COORDINATE,
            (uint32_t)(xy_local_addr >> NOC_ADDR_COORD_SHIFT));
    }
}

// set noc local memory state for a single kernel from the global state
inline __attribute__((always_inline)) void noc_local_state_init(int noc) {
    // Hide latency of NOC reg reads by reading first, writing second
    uint32_t reads_num_issued = NOC_STATUS_READ_REG(noc, NIU_MST_RD_RESP_RECEIVED);
    uint32_t nonposted_writes_num_issued = NOC_STATUS_READ_REG(noc, NIU_MST_NONPOSTED_WR_REQ_SENT);
    uint32_t nonposted_writes_acked = NOC_STATUS_READ_REG(noc, NIU_MST_WR_ACK_RECEIVED);
    uint32_t nonposted_atomics_acked = NOC_STATUS_READ_REG(noc, NIU_MST_ATOMIC_RESP_RECEIVED);
    uint32_t posted_writes_num_issued = NOC_STATUS_READ_REG(noc, NIU_MST_POSTED_WR_REQ_SENT);

    noc_reads_num_issued[noc] = reads_num_issued;
    noc_nonposted_writes_num_issued[noc] = nonposted_writes_num_issued;
    noc_nonposted_writes_acked[noc] = nonposted_writes_acked;
    noc_nonposted_atomics_acked[noc] = nonposted_atomics_acked;
    noc_posted_writes_num_issued[noc] = posted_writes_num_issued;
}

template <NocBarrierType barrier_type, uint32_t status_register>
inline __attribute__((always_inline)) void dynamic_noc_local_barrier_init(
    uint32_t noc0_status_reg, uint32_t noc1_status_reg) {
#if defined(COMPILE_FOR_AERISC)
    // For ERISC, use EthProcessorTypes
    using underlying_processor_types_t = std::underlying_type_t<EthProcessorTypes>;
    constexpr underlying_processor_types_t dm0 = static_cast<underlying_processor_types_t>(EthProcessorTypes::DM0);
    constexpr underlying_processor_types_t dm1 = static_cast<underlying_processor_types_t>(EthProcessorTypes::DM1);
#else
    // For Tensix, use TensixProcessorTypes
    using underlying_processor_types_t = std::underlying_type_t<TensixProcessorTypes>;
    constexpr underlying_processor_types_t dm0 = static_cast<underlying_processor_types_t>(TensixProcessorTypes::DM0);
    constexpr underlying_processor_types_t dm1 = static_cast<underlying_processor_types_t>(TensixProcessorTypes::DM1);
#endif

    set_noc_counter_val<dm0, barrier_type>(NOC_0, noc0_status_reg);
    set_noc_counter_val<dm0, barrier_type>(NOC_1, 0);
    set_noc_counter_val<dm1, barrier_type>(NOC_0, 0);
    set_noc_counter_val<dm1, barrier_type>(NOC_1, noc1_status_reg);
}

inline __attribute__((always_inline)) void dynamic_noc_local_state_init() {
    // Pipeline all register reads first to hide latency
    uint32_t noc0_reads_num_issued = NOC_STATUS_READ_REG(NOC_0, NIU_MST_RD_RESP_RECEIVED);
    uint32_t noc1_reads_num_issued = NOC_STATUS_READ_REG(NOC_1, NIU_MST_RD_RESP_RECEIVED);
    uint32_t noc0_nonposted_writes_num_issued = NOC_STATUS_READ_REG(NOC_0, NIU_MST_NONPOSTED_WR_REQ_SENT);
    uint32_t noc1_nonposted_writes_num_issued = NOC_STATUS_READ_REG(NOC_1, NIU_MST_NONPOSTED_WR_REQ_SENT);
    uint32_t noc0_nonposted_writes_acked = NOC_STATUS_READ_REG(NOC_0, NIU_MST_WR_ACK_RECEIVED);
    uint32_t noc1_nonposted_writes_acked = NOC_STATUS_READ_REG(NOC_1, NIU_MST_WR_ACK_RECEIVED);
    uint32_t noc0_nonposted_atomics_acked = NOC_STATUS_READ_REG(NOC_0, NIU_MST_ATOMIC_RESP_RECEIVED);
    uint32_t noc1_nonposted_atomics_acked = NOC_STATUS_READ_REG(NOC_1, NIU_MST_ATOMIC_RESP_RECEIVED);
    uint32_t noc0_posted_writes_num_issued = NOC_STATUS_READ_REG(NOC_0, NIU_MST_POSTED_WR_REQ_SENT);
    uint32_t noc1_posted_writes_num_issued = NOC_STATUS_READ_REG(NOC_1, NIU_MST_POSTED_WR_REQ_SENT);
    dynamic_noc_local_barrier_init<NocBarrierType::READS_NUM_ISSUED, NIU_MST_RD_RESP_RECEIVED>(
        noc0_reads_num_issued, noc1_reads_num_issued);
    dynamic_noc_local_barrier_init<NocBarrierType::NONPOSTED_WRITES_NUM_ISSUED, NIU_MST_NONPOSTED_WR_REQ_SENT>(
        noc0_nonposted_writes_num_issued, noc1_nonposted_writes_num_issued);
    dynamic_noc_local_barrier_init<NocBarrierType::NONPOSTED_WRITES_ACKED, NIU_MST_WR_ACK_RECEIVED>(
        noc0_nonposted_writes_acked, noc1_nonposted_writes_acked);
    dynamic_noc_local_barrier_init<NocBarrierType::NONPOSTED_ATOMICS_ACKED, NIU_MST_ATOMIC_RESP_RECEIVED>(
        noc0_nonposted_atomics_acked, noc1_nonposted_atomics_acked);
    dynamic_noc_local_barrier_init<NocBarrierType::POSTED_WRITES_NUM_ISSUED, NIU_MST_POSTED_WR_REQ_SENT>(
        noc0_posted_writes_num_issued, noc1_posted_writes_num_issued);
}

template <uint8_t MAX_NOCS_TO_INIT = NUM_NOCS>
inline __attribute__((always_inline)) void ncrisc_noc_counters_init() {
    for (int noc = 0; noc < MAX_NOCS_TO_INIT; noc++) {
        // Hide latency of NOC reg reads by reading first, writing second
        uint32_t reads_num_issued = NOC_STATUS_READ_REG(noc, NIU_MST_RD_RESP_RECEIVED);
        uint32_t nonposted_writes_num_issued = NOC_STATUS_READ_REG(noc, NIU_MST_NONPOSTED_WR_REQ_SENT);
        uint32_t nonposted_writes_acked = NOC_STATUS_READ_REG(noc, NIU_MST_WR_ACK_RECEIVED);
        uint32_t nonposted_atomics_acked = NOC_STATUS_READ_REG(noc, NIU_MST_ATOMIC_RESP_RECEIVED);
        uint32_t posted_writes_num_issued = NOC_STATUS_READ_REG(noc, NIU_MST_POSTED_WR_REQ_SENT);

        noc_reads_num_issued[noc] = reads_num_issued;
        noc_nonposted_writes_num_issued[noc] = nonposted_writes_num_issued;
        noc_nonposted_writes_acked[noc] = nonposted_writes_acked;
        noc_nonposted_atomics_acked[noc] = nonposted_atomics_acked;
        noc_posted_writes_num_issued[noc] = posted_writes_num_issued;
    }
}

inline __attribute__((always_inline)) void ncrisc_noc_sync(uint32_t noc) {
    while (!ncrisc_noc_reads_flushed(noc));
    while (!ncrisc_noc_nonposted_writes_sent(noc));
    while (!ncrisc_noc_nonposted_writes_flushed(noc));
    while (!ncrisc_noc_nonposted_atomics_flushed(noc));
    while (!ncrisc_noc_posted_writes_sent(noc));
}

template <uint8_t MAX_NOCS_TO_INIT = NUM_NOCS>
inline __attribute__((always_inline)) void ncrisc_noc_full_sync() {
    for (uint32_t n = 0; n < MAX_NOCS_TO_INIT; n++) {
        ncrisc_noc_sync(n);
    }
}

template <uint8_t noc_mode = DM_DEDICATED_NOC>
inline __attribute__((always_inline)) void ncrisc_noc_fast_read_any_len(
    uint32_t noc,
    uint32_t cmd_buf,
    uint64_t src_addr,
    uint32_t dest_addr,
    uint32_t len_bytes,
    uint32_t read_req_vc = 1) {
    while (len_bytes > NOC_MAX_BURST_SIZE) {
        while (!noc_cmd_buf_ready(noc, cmd_buf));
        ncrisc_noc_fast_read<noc_mode>(noc, cmd_buf, src_addr, dest_addr, NOC_MAX_BURST_SIZE, read_req_vc);
        src_addr += NOC_MAX_BURST_SIZE;
        dest_addr += NOC_MAX_BURST_SIZE;
        len_bytes -= NOC_MAX_BURST_SIZE;
    }
    while (!noc_cmd_buf_ready(noc, cmd_buf));
    ncrisc_noc_fast_read<noc_mode>(noc, cmd_buf, src_addr, dest_addr, len_bytes, read_req_vc);
}

template <uint8_t noc_mode = DM_DEDICATED_NOC, bool use_trid = false, bool one_packet = false>
inline __attribute__((always_inline)) void ncrisc_noc_fast_write_any_len(
    uint32_t noc,
    uint32_t cmd_buf,
    uint32_t src_addr,
    uint64_t dest_addr,
    uint32_t len_bytes,
    uint32_t vc,
    bool mcast,
    bool linked,
    uint32_t num_dests,
    bool multicast_path_reserve,
    bool posted = false,
    uint32_t trid = 0) {
    if constexpr (!one_packet) {
        while (len_bytes > NOC_MAX_BURST_SIZE) {
            while (!noc_cmd_buf_ready(noc, cmd_buf));
            ncrisc_noc_fast_write<noc_mode, use_trid>(
                noc,
                cmd_buf,
                src_addr,
                dest_addr,
                NOC_MAX_BURST_SIZE,
                vc,
                mcast,
                linked,
                num_dests,
                multicast_path_reserve,
                posted,
                trid);
            src_addr += NOC_MAX_BURST_SIZE;
            dest_addr += NOC_MAX_BURST_SIZE;
            len_bytes -= NOC_MAX_BURST_SIZE;
        }
    }
    while (!noc_cmd_buf_ready(noc, cmd_buf));
    ncrisc_noc_fast_write<noc_mode, use_trid>(
        noc,
        cmd_buf,
        src_addr,
        dest_addr,
        len_bytes,
        vc,
        mcast,
        linked,
        num_dests,
        multicast_path_reserve,
        posted,
        trid);
}

template <uint8_t noc_mode = DM_DEDICATED_NOC>
inline __attribute__((always_inline)) void ncrisc_noc_fast_write_any_len_loopback_src(
    uint32_t noc,
    uint32_t cmd_buf,
    uint32_t src_addr,
    uint64_t dest_addr,
    uint32_t len_bytes,
    uint32_t vc,
    bool mcast,
    bool linked,
    uint32_t num_dests,
    bool multicast_path_reserve) {
    while (len_bytes > NOC_MAX_BURST_SIZE) {
        while (!noc_cmd_buf_ready(noc, cmd_buf));
        ncrisc_noc_fast_write_loopback_src<noc_mode>(
            noc,
            cmd_buf,
            src_addr,
            dest_addr,
            NOC_MAX_BURST_SIZE,
            vc,
            mcast,
            linked,
            num_dests,
            multicast_path_reserve);
        src_addr += NOC_MAX_BURST_SIZE;
        dest_addr += NOC_MAX_BURST_SIZE;
        len_bytes -= NOC_MAX_BURST_SIZE;
    }
    while (!noc_cmd_buf_ready(noc, cmd_buf));
    ncrisc_noc_fast_write_loopback_src<noc_mode>(
        noc, cmd_buf, src_addr, dest_addr, len_bytes, vc, mcast, linked, num_dests, multicast_path_reserve);
}

template <uint8_t noc_mode = DM_DEDICATED_NOC, bool flush = true>
inline __attribute__((always_inline)) void noc_fast_spoof_write_dw_inline(
    uint32_t noc,
    uint32_t cmd_buf,
    uint32_t val,
    uint64_t dest_addr,
    uint32_t be,
    uint32_t static_vc,
    bool mcast,
    bool posted = false,
    uint32_t customized_src_addr = 0) {
    // On Blackhole issuing inline writes and atomics requires all 4 memory ports to accept the transaction at the same
    // time. If one port on the recipient has back-pressure then the transaction will hang because there is no
    // mechanism to allow one memory port to move ahead of another. To workaround this hang, we emulate inline writes on
    // Blackhole by writing the value to be written to local L1 first and then issue a noc async write.
    ASSERT((dest_addr & 0x3) == 0);
    uint32_t src_addr;
    if constexpr (!flush) {
        src_addr = customized_src_addr;
    } else {
        src_addr = noc_get_interim_inline_value_addr(noc, dest_addr);
    }
    // Flush to make sure write left L1 before updating it. Both posted and non-posted counters
    // need to be checked because we don't know, in the moment, the history of spoofed writes and
    // if they were posted or non-posted.
    //
    // An alternative to this is to force the spoofed write to be posted. However this breaks some
    // niche user code cases. For example, when a user wants to send some data via an inline write
    // (say if they need to send data where src/dest are not aligned), and they need to signal to
    // a consumer when the write has completed (when the data and consumer are on different cores -
    // a completion ack is needed to avoid race). Forcing posted removes this as a supported use
    // case; it was not chosen as an approach.
    if constexpr (flush) {
        if constexpr (noc_mode == DM_DYNAMIC_NOC) {
            while (!ncrisc_dynamic_noc_nonposted_writes_sent(noc));
            while (!ncrisc_dynamic_noc_posted_writes_sent(noc));
        } else {
            while (!ncrisc_noc_nonposted_writes_sent(noc));
            while (!ncrisc_noc_posted_writes_sent(noc));
        }
    }

    volatile tt_l1_ptr uint32_t* interim_addr_ptr = reinterpret_cast<volatile tt_l1_ptr uint32_t*>(src_addr);
    *interim_addr_ptr = val;

// Copied from dataflow_cmd_bufs.h
#if defined(COMPILE_FOR_BRISC)
    constexpr uint32_t write_cmd_buf = noc_mode == DM_DEDICATED_NOC ? BRISC_WR_CMD_BUF : DYNAMIC_NOC_BRISC_WR_CMD_BUF;
#elif defined(COMPILE_FOR_NCRISC)
    constexpr uint32_t write_cmd_buf = noc_mode == DM_DEDICATED_NOC ? NCRISC_WR_CMD_BUF : DYNAMIC_NOC_NCRISC_WR_CMD_BUF;
#else
    constexpr uint32_t write_cmd_buf = NCRISC_WR_CMD_BUF;
#endif

    while (!noc_cmd_buf_ready(noc, write_cmd_buf));
    ncrisc_noc_fast_write<noc_mode>(
        noc,
        write_cmd_buf,
        src_addr,
        dest_addr,
        4,
        static_vc,
        mcast,  // mcast
        false,  // linked
        1,      // num_dests
        true,   // multicast_path_reserve
        posted  // posted
    );
}

template <uint8_t noc_mode = DM_DEDICATED_NOC>
inline __attribute__((always_inline)) void noc_fast_default_write_dw_inline(
    uint32_t noc,
    uint32_t cmd_buf,
    uint32_t val,
    uint64_t dest_addr,
    uint32_t be,
    uint32_t static_vc,
    bool mcast,
    bool posted = false,
    uint32_t num_dests = 1) {
    ASSERT(be == 0xF);
    if constexpr (noc_mode == DM_DYNAMIC_NOC) {
        if (posted) {
            inc_noc_counter_val<proc_type, NocBarrierType::POSTED_WRITES_NUM_ISSUED>(noc, 1);
        } else {
            inc_noc_counter_val<proc_type, NocBarrierType::NONPOSTED_WRITES_NUM_ISSUED>(noc, 1);
            inc_noc_counter_val<proc_type, NocBarrierType::NONPOSTED_WRITES_ACKED>(noc, num_dests);
        }
    }
    bool static_vc_alloc = true;
    uint32_t noc_cmd_field = (static_vc_alloc ? NOC_CMD_VC_STATIC : 0x0) | NOC_CMD_STATIC_VC(static_vc) | NOC_CMD_CPY |
                             NOC_CMD_WR | NOC_CMD_WR_INLINE |
                             (mcast ? (NOC_CMD_PATH_RESERVE | NOC_CMD_BRCST_PACKET) : 0x0) |
                             (posted ? 0x0 : NOC_CMD_RESP_MARKED);

    uint32_t be32 = be;
    // If we're given a misaligned address, don't write to the bytes in the word below the address
    uint32_t be_shift = (dest_addr & (NOC_WORD_BYTES - 1));
    be32 = (be32 << be_shift);

    while (!noc_cmd_buf_ready(noc, cmd_buf));
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_AT_DATA, val);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_CTRL, noc_cmd_field);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_TARG_ADDR_LO, (uint32_t)(dest_addr));
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_TARG_ADDR_MID, (uint32_t)(dest_addr >> 32) & NOC_PCIE_MASK);
    NOC_CMD_BUF_WRITE_REG(
        noc, cmd_buf, NOC_TARG_ADDR_COORDINATE, (uint32_t)(dest_addr >> NOC_ADDR_COORD_SHIFT) & NOC_COORDINATE_MASK);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_AT_LEN_BE, be32);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_CMD_CTRL, NOC_CTRL_SEND_REQ);
    if constexpr (noc_mode == DM_DEDICATED_NOC) {
        if (posted) {
            noc_posted_writes_num_issued[noc] += 1;
        } else {
            noc_nonposted_writes_num_issued[noc] += 1;
            noc_nonposted_writes_acked[noc] += num_dests;
        }
    }
}

template <uint8_t noc_mode = DM_DEDICATED_NOC, InlineWriteDst dst_type = InlineWriteDst::DEFAULT, bool flush = true>
inline __attribute__((always_inline)) void noc_fast_write_dw_inline_impl(
    uint32_t noc,
    uint32_t cmd_buf,
    uint32_t val,
    uint64_t dest_addr,
    uint32_t be,
    uint32_t static_vc,
    bool mcast,
    bool posted,
    uint32_t customized_src_addr,
    uint32_t num_dests) {
    if constexpr (dst_type == InlineWriteDst::DEFAULT) {
        if ((dest_addr & 0xFFFFFFFF) >= NOC_REG_SPACE_START_ADDR) {
            noc_fast_default_write_dw_inline<noc_mode>(
                noc, cmd_buf, val, dest_addr, be, static_vc, mcast, posted, num_dests);
        } else {
            noc_fast_spoof_write_dw_inline<noc_mode, flush>(
                noc, cmd_buf, val, dest_addr, be, static_vc, mcast, posted, customized_src_addr);
        }
    } else if constexpr (dst_type == InlineWriteDst::L1) {
        noc_fast_spoof_write_dw_inline<noc_mode, flush>(
            noc, cmd_buf, val, dest_addr, be, static_vc, mcast, posted, customized_src_addr);
    } else {
        ASSERT((dest_addr & 0xFFFFFFFF) >= NOC_REG_SPACE_START_ADDR);
        noc_fast_default_write_dw_inline<noc_mode>(
            noc, cmd_buf, val, dest_addr, be, static_vc, mcast, posted, num_dests);
    }
}

template <uint8_t noc_mode = DM_DEDICATED_NOC, InlineWriteDst dst_type = InlineWriteDst::DEFAULT, bool flush = true>
inline __attribute__((always_inline)) void noc_fast_write_dw_inline(
    uint32_t noc,
    uint32_t cmd_buf,
    uint32_t val,
    uint64_t dest_addr,
    uint32_t be,
    uint32_t static_vc,
    bool mcast,
    bool posted = false,
    uint32_t customized_src_addr = 0) {
    noc_fast_write_dw_inline_impl<noc_mode, dst_type, flush>(
        noc, cmd_buf, val, dest_addr, be, static_vc, mcast, posted, customized_src_addr, 1);
}

template <uint8_t noc_mode = DM_DEDICATED_NOC, InlineWriteDst dst_type = InlineWriteDst::DEFAULT, bool flush = true>
inline __attribute__((always_inline)) void noc_fast_write_dw_inline_multicast(
    uint32_t noc,
    uint32_t cmd_buf,
    uint32_t val,
    uint64_t dest_addr,
    uint32_t be,
    uint32_t static_vc,
    bool mcast,
    bool posted = false,
    uint32_t customized_src_addr = 0,
    uint32_t num_dests = 1) {
    noc_fast_write_dw_inline_impl<noc_mode, dst_type, flush>(
        noc, cmd_buf, val, dest_addr, be, static_vc, mcast, posted, customized_src_addr, num_dests);
}

template <uint8_t noc_mode = DM_DEDICATED_NOC, bool program_ret_addr = false>
inline __attribute__((always_inline)) void noc_fast_atomic_increment(
    uint32_t noc,
    uint32_t cmd_buf,
    uint64_t addr,
    uint32_t vc,
    uint32_t incr,
    uint32_t wrap,
    bool linked,
    bool posted = false,
    uint32_t atomic_ret_val = 0) {
    // On Blackhole issuing inline writes and atomics requires all 4 memory ports to accept the transaction at the same
    // time. If one port on the recipient has no back-pressure then the transaction will hang because there is no
    // mechanism to allow one memory port to move ahead of another. To workaround this hang, we emulate force atomics to
    // be non-posted.
    posted = false;
    if constexpr (noc_mode == DM_DYNAMIC_NOC) {
        if (!posted) {
            inc_noc_counter_val<proc_type, NocBarrierType::NONPOSTED_ATOMICS_ACKED>(noc, 1);
        }
    }
    while (!noc_cmd_buf_ready(noc, cmd_buf));
    // Atomics always target an on-chip semaphore, so this overwrites NOC_TARG_ADDR_MID with 0. Under
    // DM_DYNAMIC_NOC the atomic command buffer is the read command buffer, so a non-zero value here means
    // an open PCIe read batch is about to be misrouted on-chip. Clear MID before the atomic, or batch on a
    // different command buffer.
    noc_assert_targ_addr_mid_clear(noc, cmd_buf);
    if constexpr (noc_mode == DM_DYNAMIC_NOC || program_ret_addr == true) {
        uint32_t noc_id_reg = NOC_CMD_BUF_READ_REG(noc, 0, NOC_NODE_ID);
        uint32_t my_x = noc_id_reg & NOC_NODE_ID_MASK;
        uint32_t my_y = (noc_id_reg >> NOC_ADDR_NODE_ID_BITS) & NOC_NODE_ID_MASK;
        uint64_t atomic_ret_addr = NOC_XY_ADDR(my_x, my_y, atomic_ret_val);
        NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_RET_ADDR_LO, (uint32_t)(atomic_ret_addr & 0xFFFFFFFF));
    }
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_TARG_ADDR_LO, (uint32_t)(addr & 0xFFFFFFFF));
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_TARG_ADDR_MID, (uint32_t)(addr >> 32) & NOC_PCIE_MASK);
    NOC_CMD_BUF_WRITE_REG(
        noc, cmd_buf, NOC_TARG_ADDR_COORDINATE, (uint32_t)(addr >> NOC_ADDR_COORD_SHIFT) & NOC_COORDINATE_MASK);
    NOC_CMD_BUF_WRITE_REG(
        noc,
        cmd_buf,
        NOC_CTRL,
        NOC_CMD_VC_STATIC | NOC_CMD_STATIC_VC(vc) | (linked ? NOC_CMD_VC_LINKED : 0x0) |
            (posted ? 0 : NOC_CMD_RESP_MARKED) | NOC_CMD_AT);
    NOC_CMD_BUF_WRITE_REG(
        noc,
        cmd_buf,
        NOC_AT_LEN_BE,
        NOC_AT_INS(NOC_AT_INS_INCR_GET) | NOC_AT_WRAP(wrap) | NOC_AT_IND_32((addr >> 2) & 0x3) | NOC_AT_IND_32_SRC(0));
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_AT_DATA, incr);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_CMD_CTRL, 0x1);
    if constexpr (noc_mode == DM_DEDICATED_NOC) {
        if (!posted) {
            noc_nonposted_atomics_acked[noc] += 1;
        }
    }
}

template <uint8_t noc_mode = DM_DEDICATED_NOC>
inline __attribute__((always_inline)) void noc_fast_multicast_atomic_increment(
    uint32_t noc,
    uint32_t cmd_buf,
    uint64_t addr,
    uint32_t vc,
    uint32_t incr,
    uint32_t wrap,
    bool linked,
    uint32_t num_dests,
    bool multicast_path_reserve,
    bool posted = false,
    uint32_t atomic_ret_val = 0) {
    // On Blackhole issuing inline writes and atomics requires all 4 memory ports to accept the transaction at the same
    // time. If one port on the recipient has no back-pressure then the transaction will hang because there is no
    // mechanism to allow one memory port to move ahead of another. Also, due to HW bug, using posted with
    // multicast can introduce hangs. To workaround this, we emulate force atomics to be non-posted.
    posted = false;
    if constexpr (noc_mode == DM_DYNAMIC_NOC) {
        if (!posted) {
            inc_noc_counter_val<proc_type, NocBarrierType::NONPOSTED_ATOMICS_ACKED>(noc, num_dests);
        }
    }
    while (!noc_cmd_buf_ready(noc, cmd_buf));
    if constexpr (noc_mode == DM_DYNAMIC_NOC) {
        uint32_t noc_id_reg = NOC_CMD_BUF_READ_REG(noc, 0, NOC_NODE_ID);
        uint32_t my_x = noc_id_reg & NOC_NODE_ID_MASK;
        uint32_t my_y = (noc_id_reg >> NOC_ADDR_NODE_ID_BITS) & NOC_NODE_ID_MASK;
        uint64_t atomic_ret_addr = NOC_XY_ADDR(my_x, my_y, atomic_ret_val);
        NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_RET_ADDR_LO, (uint32_t)(atomic_ret_addr & 0xFFFFFFFF));
    }
    // Same hazard as the unicast atomic: this overwrites NOC_TARG_ADDR_MID, and under DM_DYNAMIC_NOC the
    // atomic command buffer is the read command buffer.
    noc_assert_targ_addr_mid_clear(noc, cmd_buf);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_TARG_ADDR_LO, (uint32_t)(addr & 0xFFFFFFFF));
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_TARG_ADDR_MID, (uint32_t)(addr >> 32) & NOC_PCIE_MASK);
    NOC_CMD_BUF_WRITE_REG(
        noc, cmd_buf, NOC_TARG_ADDR_COORDINATE, (uint32_t)(addr >> NOC_ADDR_COORD_SHIFT) & NOC_COORDINATE_MASK);
    NOC_CMD_BUF_WRITE_REG(
        noc,
        cmd_buf,
        NOC_CTRL,
        NOC_CMD_VC_STATIC | NOC_CMD_STATIC_VC(vc) | (linked ? NOC_CMD_VC_LINKED : 0x0) |
            (multicast_path_reserve ? NOC_CMD_PATH_RESERVE : 0) | NOC_CMD_BRCST_PACKET |
            (posted ? 0 : NOC_CMD_RESP_MARKED) | NOC_CMD_AT);
    NOC_CMD_BUF_WRITE_REG(
        noc,
        cmd_buf,
        NOC_AT_LEN_BE,
        NOC_AT_INS(NOC_AT_INS_INCR_GET) | NOC_AT_WRAP(wrap) | NOC_AT_IND_32((addr >> 2) & 0x3) | NOC_AT_IND_32_SRC(0));
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_AT_DATA, incr);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_CMD_CTRL, 0x1);
    if constexpr (noc_mode == DM_DEDICATED_NOC) {
        if (!posted) {
            noc_nonposted_atomics_acked[noc] += num_dests;
        }
    }
}

// issue noc reads while wait for outstanding transactions done
template <uint8_t noc_mode = DM_DEDICATED_NOC, bool skip_ptr_update = false, bool skip_cmdbuf_chk = false>
inline __attribute__((always_inline)) void ncrisc_noc_fast_read_with_transaction_id(
    uint32_t noc, uint32_t cmd_buf, uint32_t src_base_addr, uint32_t src_addr, uint32_t dest_addr, uint32_t trid) {
    if constexpr (noc_mode == DM_DYNAMIC_NOC && !skip_ptr_update) {
        inc_noc_counter_val<proc_type, NocBarrierType::READS_NUM_ISSUED>(noc, 1);
    }
    uint32_t src_addr_;
    src_addr_ = src_base_addr + src_addr;

    if constexpr (!skip_cmdbuf_chk) {
        while (!noc_cmd_buf_ready(noc, cmd_buf));
    } else {
        ASSERT(noc_cmd_buf_ready(noc, cmd_buf));
    }
    while (NOC_STATUS_READ_REG(noc, NIU_MST_REQS_OUTSTANDING_ID(trid)) > ((NOC_MAX_TRANSACTION_ID_COUNT + 1) / 2));

    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_RET_ADDR_LO, dest_addr);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_TARG_ADDR_LO, src_addr_);  // (uint32_t)src_addr
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_CMD_CTRL, NOC_CTRL_SEND_REQ);
    if constexpr (noc_mode == DM_DEDICATED_NOC && !skip_ptr_update) {
        noc_reads_num_issued[noc] += 1;
    }
}

// clang-format off
/**
 * Sets the transaction id for a noc transaction.
 *
 * Return value: None
 *
 * | Argument | Description                                        | Data type | Valid range | Required |
 * |----------|----------------------------------------------------|-----------|-------------|----------|
 * | noc      | Which NOC to use for the transaction               | uint32_t  | 0 or 1      | True     |
 * | cmd_buf  | Which command buffer to use for the transaction    | uint32_t  | 0 - 3       | True     |
 * | trid     | Transaction id for the transaction                 | uint32_t  | 0x0 - 0xF   | True     |
 */
// clang-format on
inline __attribute__((always_inline)) void ncrisc_noc_set_transaction_id(
    uint32_t noc, uint32_t cmd_buf, uint32_t trid) {
    while (!noc_cmd_buf_ready(noc, cmd_buf));
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_PACKET_TAG, NOC_PACKET_TAG_TRANSACTION_ID(trid));
}

// clang-format off
/**
 * Sets the stateful registers for an asynchronous read from a specified source node located at NOC
 * coordinates (x,y) at a local address (encoded as a uint64_t using \a
 * get_noc_addr function). This function is used to set up the state for
 * \a ncrisc_noc_read_with_state, which will issue the actual read request.
 *
 * The source node can be either a DRAM bank, a Tensix core or a PCIe controller.
 *
 * Return value: None
 *
 * | Argument                        | Description                                        | Data type | Valid range                                              | required |
 * |---------------------------------|----------------------------------------------------|-----------|----------------------------------------------------------|----------|
 * | noc                             | Which NOC to use for the transaction               | uint32_t  | 0 or 1                                                   | True     |
 * | cmd_buf                         | Which command buffer to use for the transaction    | uint32_t  | 0 - 3                                                    | True     |
 * | src_noc_addr                    | Encoding of the source NOC location (x,y)+address  | uint64_t  | Results of \a get_noc_addr calls                         | True     |
 * | len_bytes                       | Size of the transaction in bytes.                  | uint32_t  | 0..1 MB                                                  | False    |
 * | vc                              | Which VC to use for the transaction                | uint32_t  | 0 - 3                                                    | False    |
 * | noc_mode (template parameter)   | NOC mode for the transaction                       | uint8_t   | DM_DEDICATED_NOC, DM_DYNAMIC_NOC or DM_INVALID_NOC (0-2) | False    |
 * | one_packet (template parameter) | Whether transaction size is <= NOC_MAX_BURST_SIZE  | bool      | true or false                                            | False    |
 * | use_vc (template parameter)     | Use custom VC, enables vc parameter                | bool      | true or false                                            | False    |
 */
// clang-format on
template <uint8_t noc_mode = DM_DEDICATED_NOC, bool one_packet = false, bool use_vc = false>
inline __attribute__((always_inline)) void ncrisc_noc_read_set_state(
    uint32_t noc, uint32_t cmd_buf, uint64_t src_noc_addr, uint32_t len_bytes = 0, const uint32_t vc = 0) {
    while (!noc_cmd_buf_ready(noc, cmd_buf));

    if constexpr (noc_mode == DM_DYNAMIC_NOC) {
        uint32_t noc_rd_cmd_field =
            NOC_CMD_CPY | NOC_CMD_RD | NOC_CMD_RESP_MARKED | NOC_CMD_VC_STATIC | NOC_CMD_STATIC_VC(1);
        NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_CTRL, noc_rd_cmd_field);
    }
    if constexpr (use_vc) {
        uint32_t noc_rd_cmd_field =
            NOC_CMD_CPY | NOC_CMD_RD | NOC_CMD_RESP_MARKED | NOC_CMD_VC_STATIC | NOC_CMD_STATIC_VC(vc);
        NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_CTRL, noc_rd_cmd_field);
    }
    // Handles reading from PCIe
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_TARG_ADDR_MID, (uint32_t)(src_noc_addr >> 32) & NOC_PCIE_MASK);
    NOC_CMD_BUF_WRITE_REG(
        noc, cmd_buf, NOC_TARG_ADDR_COORDINATE, (uint32_t)(src_noc_addr >> NOC_ADDR_COORD_SHIFT) & NOC_COORDINATE_MASK);

    // If one packet, set data size
    if constexpr (one_packet) {
        NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_AT_LEN_BE, len_bytes);
    }
}

// clang-format off
/**
 * Initiates an asynchronous read from a specified source node located at NOC
 * coordinates (x,y) at a local address (encoded as a uint64_t using \a
 * get_noc_addr function) for a single packet with size <= NOC_MAX_BURST_SIZE (i.e. maximum packet size).
 * This function must be preceded by a call to \a ncrisc_noc_read_set_state.
 * This function is used to issue the actual read request after the state has been set up.
 *
 * Return value: None
 *
 * | Argument                            | Description                                        | Data type | Valid range                                              | required |
 * |-------------------------------------|----------------------------------------------------|-----------|----------------------------------------------------------|----------|
 * | noc                                 | Which NOC to use for the transaction               | uint32_t  | 0 or 1                                                   | True     |
 * | cmd_buf                             | Which command buffer to use for the transaction    | uint32_t  | 0 - 3                                                    | True     |
 * | src_local_addr                      | Address in local L1 memory on source core          | uint32_t  | 0..1 MB                                                  | True     |
 * | dst_local_addr                      | Address in local L1 memory on destination core     | uint32_t  | 0..1 MB                                                  | True     |
 * | len_bytes                           | Size of transaction in bytes                       | uint32_t  | 0..1 MB                                                  | False    |
 * | noc_mode (template parameter)       | NOC mode for the transaction                       | uint8_t   | DM_DEDICATED_NOC, DM_DYNAMIC_NOC or DM_INVALID_NOC (0-2) | False    |
 * | inc_num_issued (template parameter) | Increment enable for transaction issued counters   | bool      | true or false                                            | False    |
 * | one_packet (template parameter)     | Whether transaction size is <= NOC_MAX_BURST_SIZE  | bool      | true or false                                            | False    |
 * | skip_cmdbuf_chk (template param)    | Skip the cmd buf ready poll (see note)             | bool      | true or false                                            | False    |
 *
 * Only set skip_cmdbuf_chk on the first issue after ncrisc_noc_read_set_state. That function waits for the
 * command buffer and then writes registers that do not make it busy again, so the poll here is guaranteed
 * to pass. Every later issue must poll, because the one before it wrote NOC_CMD_CTRL. Setting this anywhere
 * else corrupts the transaction already in flight.
 */
// clang-format on
template <
    uint8_t noc_mode = DM_DEDICATED_NOC,
    bool inc_num_issued = true,
    bool one_packet = false,
    bool skip_cmdbuf_chk = false>
inline __attribute__((always_inline)) void ncrisc_noc_read_with_state(
    uint32_t noc, uint32_t cmd_buf, uint32_t src_local_addr, uint32_t dst_local_addr, uint32_t len_bytes = 0) {
    if constexpr (inc_num_issued && noc_mode == DM_DYNAMIC_NOC) {
        inc_noc_counter_val<proc_type, NocBarrierType::READS_NUM_ISSUED>(noc, 1);
    }

    if constexpr (!skip_cmdbuf_chk) {
        while (!noc_cmd_buf_ready(noc, cmd_buf));
    }

    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_RET_ADDR_LO, dst_local_addr);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_TARG_ADDR_LO, src_local_addr);
    if constexpr (!one_packet) {
        NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_AT_LEN_BE, len_bytes);
    }
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_CMD_CTRL, NOC_CTRL_SEND_REQ);

    if constexpr (inc_num_issued && noc_mode == DM_DEDICATED_NOC) {
        noc_reads_num_issued[noc] += 1;
    }
}

// clang-format off
/**
 * Initiates an asynchronous read for all transaction sizes.
 * Refer to \a ncrisc_noc_read_with_state for more details.
 *
 * Return value: None
 *
 * | Argument                            | Description                                        | Data type | Valid range                                              | required |
 * |-------------------------------------|----------------------------------------------------|-----------|----------------------------------------------------------|----------|
 * | noc                                 | Which NOC to use for the transaction               | uint32_t  | 0 or 1                                                   | True     |
 * | cmd_buf                             | Which command buffer to use for the transaction    | uint32_t  | 0 - 3                                                    | True     |
 * | src_local_addr                      | Address in local L1 memory on source core          | uint32_t  | 0..1 MB                                                  | True     |
 * | dst_local_addr                      | Address in local L1 memory on destination core     | uint32_t  | 0..1 MB                                                  | True     |
 * | len_bytes                           | Size of transaction in bytes                       | uint32_t  | 0..1 MB                                                  | True     |
 * | noc_mode (template parameter)       | NOC mode for the transaction                       | uint8_t   | DM_DEDICATED_NOC, DM_DYNAMIC_NOC or DM_INVALID_NOC (0-2) | False    |
 * | inc_num_issued (template parameter) | Increment enable for transaction issued counters   | bool      | true or false                                            | False    |
 * | skip_cmdbuf_chk (template param)    | Skip the cmd buf ready poll on the FIRST burst only| bool      | true or false                                            | False    |
 *
 * skip_cmdbuf_chk applies to the first burst issued here and to no other. Every burst after it must poll,
 * since the one before wrote NOC_CMD_CTRL. Only set it when this call directly follows
 * ncrisc_noc_read_set_state.
 */
// clang-format on
template <uint8_t noc_mode = DM_DEDICATED_NOC, bool inc_num_issued = true, bool skip_cmdbuf_chk = false>
inline __attribute__((always_inline)) void ncrisc_noc_read_any_len_with_state(
    uint32_t noc, uint32_t cmd_buf, uint32_t src_local_addr, uint32_t dst_local_addr, uint32_t len_bytes) {
    if (len_bytes > NOC_MAX_BURST_SIZE) {
        // Set data size for while loop
        NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_AT_LEN_BE, NOC_MAX_BURST_SIZE);

        if constexpr (skip_cmdbuf_chk) {
            // The first burst is issued here rather than in the loop below so that the skip applies to it
            // alone. This branch only compiles when the caller asks for the skip, so callers that do not
            // ask keep the original code shape.
            ncrisc_noc_read_with_state<noc_mode, inc_num_issued, true /* one_packet */, true /* skip */>(
                noc, cmd_buf, src_local_addr, dst_local_addr);
            len_bytes -= NOC_MAX_BURST_SIZE;
            src_local_addr += NOC_MAX_BURST_SIZE;
            dst_local_addr += NOC_MAX_BURST_SIZE;
        }

        while (len_bytes > NOC_MAX_BURST_SIZE) {
            ncrisc_noc_read_with_state<noc_mode, inc_num_issued, true /* one_packet */>(
                noc, cmd_buf, src_local_addr, dst_local_addr);

            len_bytes -= NOC_MAX_BURST_SIZE;
            src_local_addr += NOC_MAX_BURST_SIZE;
            dst_local_addr += NOC_MAX_BURST_SIZE;
        }

        // left-over packet. The first burst above already used the skip.
        ncrisc_noc_read_with_state<noc_mode, inc_num_issued>(noc, cmd_buf, src_local_addr, dst_local_addr, len_bytes);
        return;
    }

    // Only one burst to issue, so the skip belongs to it.
    ncrisc_noc_read_with_state<noc_mode, inc_num_issued, false /* one_packet */, skip_cmdbuf_chk>(
        noc, cmd_buf, src_local_addr, dst_local_addr, len_bytes);
}

// clang-format off
/**
 * Sets the stateful registers for an asynchronous write to a specified destination node located at
 * NOC coordinates (x,y) at a local address (encoded as a uint64_t using \a
 * get_noc_addr function). This function is used to set up the state for
 * \a ncrisc_noc_write_with_state, which will issue the actual
 * write request.
 *
 * The destination node can be either a DRAM bank, a Tensix core or a PCIe controller.
 *
 * Return value: None
 *
 * | Argument                        | Description                                              | Data type | Valid range                      | required |
 * |---------------------------------|----------------------------------------------------------|-----------|----------------------------------|----------|
 * | noc                             | NOC to use for the transaction                           | uint32_t  | 0 or 1                           | True     |
 * | cmd_buf                         | Command buffer to use for the transaction                | uint32_t  | 0 - 3                            | True     |
 * | dst_noc_addr                    | Encoding of the destination NOC location (x,y)+address   | uint64_t  | Results of \a get_noc_addr calls | True     |
 * | len_bytes                       | Size of the transaction in bytes.                        | uint32_t  | 0..1 MB                          | False    |
 * | vc                              | Which VC to use for the transaction                      | uint32_t  | 0 - 3                            | False    |
 * | posted (template parameter)     | Whether the transaction is posted (i.e. no ack required) | bool      | true or false                    | False    |
 * | one_packet (template parameter) | Whether transaction size is <= NOC_MAX_BURST_SIZE        | bool      | true or false                    | False    |
 */
// clang-format on
template <bool posted = false, bool one_packet = false>
inline __attribute__((always_inline)) void ncrisc_noc_write_set_state(
    uint32_t noc, uint32_t cmd_buf, uint64_t dst_noc_addr, uint32_t len_bytes = 0, const uint32_t vc = 0) {
    while (!noc_cmd_buf_ready(noc, cmd_buf));

    uint32_t noc_cmd_field = NOC_CMD_CPY | NOC_CMD_WR | NOC_CMD_VC_STATIC | NOC_CMD_STATIC_VC(vc) |
                             0x0 |  // (linked ? NOC_CMD_VC_LINKED : 0x0)
                             0x0 |  // (mcast ? (NOC_CMD_PATH_RESERVE | NOC_CMD_BRCST_PACKET) : 0x0)
                             (!posted ? NOC_CMD_RESP_MARKED : 0x0);

    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_CTRL, noc_cmd_field);
    // Handles writing to PCIe
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_RET_ADDR_MID, (uint32_t)(dst_noc_addr >> 32) & NOC_PCIE_MASK);
    NOC_CMD_BUF_WRITE_REG(
        noc, cmd_buf, NOC_RET_ADDR_COORDINATE, (uint32_t)(dst_noc_addr >> NOC_ADDR_COORD_SHIFT) & NOC_COORDINATE_MASK);

    // If one packet, set data size
    if constexpr (one_packet) {
        NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_AT_LEN_BE, len_bytes);
    }
}

// clang-format off
/**
 * Initiates an asynchronous write to a specified destination node located at
 * NOC coordinates (x,y) at a local address (encoded as a uint64_t using \a
 * get_noc_addr function). This function must be preceded by a call to
 * \a ncrisc_noc_write_set_state. This function is used to issue the actual
 * write request after the state has been set up.
 *
 * Return value: None
 *
 * | Argument                            | Description                                              | Data type | Valid range                                              | required |
 * |-------------------------------------|----------------------------------------------------------|-----------|----------------------------------------------------------|----------|
 * | noc                                 | NOC to use for the transaction                           | uint32_t  | 0 or 1                                                   | True     |
 * | cmd_buf                             | Command buffer to use for the transaction                | uint32_t  | 0 - 3                                                    | True     |
 * | src_local_addr                      | Address in local L1 memory on source core                | uint32_t  | 0..1 MB                                                  | True     |
 * | dst_local_addr                      | Address in local L1 memory on destination core           | uint32_t  | 0..1 MB                                                  | True     |
 * | len_bytes                           | Size of transaction in bytes                             | uint32_t  | 0..1 MB                                                  | False    |
 * | noc_mode (template parameter)       | NOC mode for the transaction                             | uint8_t   | DM_DEDICATED_NOC, DM_DYNAMIC_NOC or DM_INVALID_NOC (0-2) | False    |
 * | posted (template parameter)         | Whether the transaction is posted (i.e. no ack required) | bool      | true or false                                            | False    |
 * | update_counter (template parameter) | Whether to increment write counters                      | bool      | true or false                                            | False    |
 * | one_packet (template parameter)     | Whether transaction size is <= NOC_MAX_BURST_SIZE        | bool      | true or false                                            | False    |
 * | skip_cmdbuf_chk (template param)    | Skip the cmd buf ready poll (see note)                   | bool      | true or false                                            | False    |
 *
 * Only set skip_cmdbuf_chk on the first issue after ncrisc_noc_write_set_state. That function waits for the
 * command buffer and then writes registers that do not make it busy again, so the poll here is guaranteed
 * to pass. Every later issue must poll, because the one before it wrote NOC_CMD_CTRL. Setting this anywhere
 * else corrupts the transaction already in flight.
 */
// clang-format on
template <
    uint8_t noc_mode = DM_DEDICATED_NOC,
    bool posted = false,
    bool update_counter = true,
    bool one_packet = false,
    bool skip_cmdbuf_chk = false>
inline __attribute__((always_inline)) void ncrisc_noc_write_with_state(
    uint32_t noc, uint32_t cmd_buf, uint32_t src_local_addr, uint32_t dst_local_addr, uint32_t len_bytes = 0) {
    if constexpr (update_counter && noc_mode == DM_DYNAMIC_NOC) {
        if constexpr (posted) {
            inc_noc_counter_val<proc_type, NocBarrierType::POSTED_WRITES_NUM_ISSUED>(noc, 1);
        } else {
            inc_noc_counter_val<proc_type, NocBarrierType::NONPOSTED_WRITES_NUM_ISSUED>(noc, 1);
            inc_noc_counter_val<proc_type, NocBarrierType::NONPOSTED_WRITES_ACKED>(noc, 1);
        }
    }

    if constexpr (!skip_cmdbuf_chk) {
        while (!noc_cmd_buf_ready(noc, cmd_buf));
    }

    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_TARG_ADDR_LO, src_local_addr);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_RET_ADDR_LO, dst_local_addr);
    if constexpr (!one_packet) {
        NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_AT_LEN_BE, len_bytes);
    }
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_CMD_CTRL, NOC_CTRL_SEND_REQ);

    if constexpr (update_counter && noc_mode == DM_DEDICATED_NOC) {
        if constexpr (posted) {
            noc_posted_writes_num_issued[noc] += 1;
        } else {
            noc_nonposted_writes_num_issued[noc] += 1;
            noc_nonposted_writes_acked[noc] += 1;
        }
    }
}

// clang-format off
/**
 * Initiates an asynchronous write for all transaction sizes.
 * Refer to \a ncrisc_noc_write_with_state for more details.
 *
 * Return value: None
 *
 * | Argument                            | Description                                              | Data type | Valid range                                              | required |
 * |-------------------------------------|----------------------------------------------------------|-----------|----------------------------------------------------------|----------|
 * | noc                                 | NOC to use for the transaction                           | uint32_t  | 0 or 1                                                   | True     |
 * | cmd_buf                             | Command buffer to use for the transaction                | uint32_t  | 0 - 3                                                    | True     |
 * | src_local_addr                      | Address in local L1 memory on source core                | uint32_t  | 0..1 MB                                                  | True     |
 * | dst_local_addr                      | Address in local L1 memory on destination core           | uint32_t  | 0..1 MB                                                  | True     |
 * | len_bytes                           | Size of transaction in bytes                             | uint32_t  | 0..1 MB                                                  | True     |
 * | noc_mode (template parameter)       | NOC mode for the transaction                             | uint8_t   | DM_DEDICATED_NOC, DM_DYNAMIC_NOC or DM_INVALID_NOC (0-2) | False    |
 * | posted (template parameter)         | Whether the transaction is posted (i.e. no ack required) | bool      | true or false                                            | False    |
 * | update_counter (template parameter) | Whether to increment write counters                      | bool      | true or false                                            | False    |
 * | skip_cmdbuf_chk (template param)    | Skip the cmd buf ready poll on the FIRST burst only      | bool      | true or false                                            | False    |
 *
 * skip_cmdbuf_chk applies to the first burst issued here and to no other. Every burst after it must poll,
 * since the one before wrote NOC_CMD_CTRL. Only set it when this call directly follows
 * ncrisc_noc_write_set_state.
 */
// clang-format on
template <
    uint8_t noc_mode = DM_DEDICATED_NOC,
    bool posted = false,
    bool update_counter = true,
    bool skip_cmdbuf_chk = false>
inline __attribute__((always_inline)) void ncrisc_noc_write_any_len_with_state(
    uint32_t noc, uint32_t cmd_buf, uint32_t src_local_addr, uint32_t dst_local_addr, uint32_t len_bytes) {
    if (len_bytes > NOC_MAX_BURST_SIZE) {
        // Set data size for while loop
        NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_AT_LEN_BE, NOC_MAX_BURST_SIZE);

        if constexpr (skip_cmdbuf_chk) {
            // The first burst is issued here rather than in the loop below so that the skip applies to it
            // alone. This branch only compiles when the caller asks for the skip, so callers that do not
            // ask keep the original code shape.
            ncrisc_noc_write_with_state<noc_mode, posted, update_counter, true /* one_packet */, true /* skip */>(
                noc, cmd_buf, src_local_addr, dst_local_addr);
            len_bytes -= NOC_MAX_BURST_SIZE;
            src_local_addr += NOC_MAX_BURST_SIZE;
            dst_local_addr += NOC_MAX_BURST_SIZE;
        }

        while (len_bytes > NOC_MAX_BURST_SIZE) {
            ncrisc_noc_write_with_state<noc_mode, posted, update_counter, true /* one_packet */>(
                noc, cmd_buf, src_local_addr, dst_local_addr);

            len_bytes -= NOC_MAX_BURST_SIZE;
            src_local_addr += NOC_MAX_BURST_SIZE;
            dst_local_addr += NOC_MAX_BURST_SIZE;
        }

        // left-over packet. The first burst above already used the skip.
        ncrisc_noc_write_with_state<noc_mode, posted, update_counter>(
            noc, cmd_buf, src_local_addr, dst_local_addr, len_bytes);
        return;
    }

    // Only one burst to issue, so the skip belongs to it.
    ncrisc_noc_write_with_state<noc_mode, posted, update_counter, false /* one_packet */, skip_cmdbuf_chk>(
        noc, cmd_buf, src_local_addr, dst_local_addr, len_bytes);
}

// clang-format off
/**
 * Sets the stateful registers for an inline write of a 32-bit value to a NOC destination.
 * This function is used to set up the state for \a noc_fast_write_dw_inline_with_state, which will issue the actual
 * write request. The 32-bit value and part of the destination address can be set later in \a noc_fast_write_dw_inline_with_state.
 *
 * The destination node can be either a Tensix core+L1 memory
 * address or a PCIe controller; This API does not support DRAM addresses.
 *
 * Note: On Blackhole, this API can only write to stream registers, writing to L1 will cause hangs!
 *
 * Return value: None
 *
 * | Argument                     | Description                                            | Type     | Valid Range                      | Required |
 * |------------------------------|--------------------------------------------------------|----------|----------------------------------|----------|
 * | noc                          | NOC to use for the transaction                         | uint32_t | 0 or 1                           | True     |
 * | cmd_buf                      | Command buffer to use for the transaction              | uint32_t | 0 - 3                            | True     |
 * | dest_addr                    | Encoding of the destination NOC location (x,y)+address | uint64_t | Results of \a get_noc_addr calls | True     |
 * | be                           | Byte-enable                                            | uint32_t | 0x1-0xF                          | True     |
 * | static_vc                    | VC to use for the transaction                          | uint32_t | 0 - 3 (Unicast VCs)              | True     |
 * | val                          | The value to be written                                | uint32_t | Any uint32_t value               | False    |
 * | posted (template parameter)  | Whether the call is posted (i.e. ack requirement)      | bool     | true or false                    | False    |
 * | set_val (template parameter) | Whether to set the value for the write here            | bool     | true or false                    | False    |
 */
// clang-format on
template <bool posted = false, bool set_val = false>
inline __attribute__((always_inline)) void noc_fast_write_dw_inline_set_state(
    uint32_t noc, uint32_t cmd_buf, uint64_t dest_addr, uint32_t be, uint32_t static_vc, uint32_t val = 0) {
    while (!noc_cmd_buf_ready(noc, cmd_buf));

    if constexpr (set_val) {
        NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_AT_DATA, val);
    }

    uint32_t noc_cmd_field = NOC_CMD_VC_STATIC | NOC_CMD_STATIC_VC(static_vc) | NOC_CMD_CPY | NOC_CMD_WR |
                             NOC_CMD_WR_INLINE | 0x0 | (posted ? 0x0 : NOC_CMD_RESP_MARKED);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_CTRL, noc_cmd_field);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_TARG_ADDR_LO, (uint32_t)dest_addr);
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_TARG_ADDR_MID, (uint32_t)(dest_addr >> 32) & NOC_PCIE_MASK);
    NOC_CMD_BUF_WRITE_REG(
        noc, cmd_buf, NOC_TARG_ADDR_COORDINATE, (uint32_t)(dest_addr >> NOC_ADDR_COORD_SHIFT) & NOC_COORDINATE_MASK);

    // If we're given a misaligned address, don't write to the bytes in the word below the address
    uint32_t be32 = be << (dest_addr & (NOC_WORD_BYTES - 1));
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_AT_LEN_BE, be32);
}

// clang-format off
/**
 * Initiates an inline write of a 32-bit value to a NOC destination.
 * This function must be preceded by a call to \a noc_fast_write_dw_inline_set_state.
 * This function is used to issue the actual write request after the state has been set up.
 * The 32-bit value and part of the destination address can also be set in this API
 * (Either hi or lo address should be getting updated).
 *
 * The destination node can be either a Tensix core+L1 memory
 * address or a PCIe controller; This API does not support DRAM addresses.
 *
 * Note: On Blackhole, this API can only write to stream registers, writing to L1 will cause hangs!
 *
 * Return value: None
 *
 * | Argument                            | Description                                            | Type     | Valid Range                      | Required |
 * |-------------------------------------|--------------------------------------------------------|----------|----------------------------------|----------|
 * | noc                                 | NOC to use for the transaction                         | uint32_t | 0 or 1                           | True     |
 * | cmd_buf                             | Command buffer to use for the transaction              | uint32_t | 0 - 3                            | True     |
 * | val                                 | The value to be written                                | uint32_t | Any uint32_t value               | False    |
 * | dest_addr                           | Encoding of the destination NOC location (x,y)+address | uint64_t | Results of \a get_noc_addr calls | False    |
 * | update_addr_lo (template parameter) | Whether to update the lower 32 bits of the address     | bool     | true or false                    | False    |
 * | update_addr_hi (template parameter) | Whether to update the upper 32 bits of the address     | bool     | true or false                    | False    |
 * | update_val (template parameter)     | Whether to set the value to be written                 | bool     | true or false                    | False    |
 * | posted (template parameter)         | Whether the call is posted (i.e. ack requirement)      | bool     | true or false                    | False    |
 * | update_counter (template parameter) | Whether to update the write counters                   | bool     | true or false                    | False    |
 * | dst_type (template parameter)       | Whether the write is targeting L1 or a Stream Register | InlineWriteDst     | DEFAULT, L1, REG       | False    |
 */
// clang-format on
template <
    uint8_t noc_mode = DM_DEDICATED_NOC,
    bool update_addr_lo = false,
    bool update_addr_hi = false,
    bool update_val = false,
    bool posted = false,
    bool update_counter = true,
    InlineWriteDst dst_type = InlineWriteDst::DEFAULT>
inline __attribute__((always_inline)) void noc_fast_write_dw_inline_with_state(
    uint32_t noc, uint32_t cmd_buf, uint32_t val = 0, uint64_t dest_addr = 0) {
    static_assert("Error: Only High or Low address update is supported" && (update_addr_lo && update_addr_hi) == 0);
    if constexpr (update_counter && noc_mode == DM_DYNAMIC_NOC) {
        if constexpr (posted) {
            inc_noc_counter_val<proc_type, NocBarrierType::POSTED_WRITES_NUM_ISSUED>(noc, 1);
        } else {
            inc_noc_counter_val<proc_type, NocBarrierType::NONPOSTED_WRITES_NUM_ISSUED>(noc, 1);
            inc_noc_counter_val<proc_type, NocBarrierType::NONPOSTED_WRITES_ACKED>(noc, 1);
        }
    }

    while (!noc_cmd_buf_ready(noc, cmd_buf));

    if constexpr (update_addr_lo) {
        NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_TARG_ADDR_LO, dest_addr);
        if constexpr (dst_type != InlineWriteDst::REG) {
            uint32_t be32 = 0xF << (dest_addr & (NOC_WORD_BYTES - 1));
            NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_AT_LEN_BE, be32);
        }
    } else if constexpr (update_addr_hi) {
        NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_TARG_ADDR_COORDINATE, dest_addr);
    }
    if constexpr (update_val) {
        NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_AT_DATA, val);
    }
    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_CMD_CTRL, NOC_CTRL_SEND_REQ);

    if constexpr (update_counter && noc_mode == DM_DEDICATED_NOC) {
        if constexpr (posted) {
            noc_posted_writes_num_issued[noc] += 1;
        } else {
            noc_nonposted_writes_num_issued[noc] += 1;
            noc_nonposted_writes_acked[noc] += 1;
        }
    }
}

// clang-format off
/**
 * The stateful NOC commands provide granular control over NOC register programming by writing
 * only a subset of registers for each transaction. This approach leverages the fact that many
 * transactions reuse certain values (e.g. length, coordinates) while varying others.
 *
 * This design provides significant advantages over previous stateful APIs:
 * - Fine-grained control: Users can specify exactly which registers to update per transaction
 * - Better optimization: Avoid unnecessary register writes for unchanged values
 * - Flexible transaction patterns: Support complex sequences with selective updates
 * - Performance benefits: Reduce NOC register write overhead for repetitive operations
 *
 * The flags parameter uses a bitmask approach to specify which registers to program.
 * Making template functions with a long list of booleans makes understanding what registers
 * are being set tedious. This is an attempt to pack that data in a way that's ~easy to visually parse.
 *
 * S/s: write, do not write to src address register (NOC_TARG_ADDR_LO)
 * N/n: write, do not write to noc coordinates register (NOC_RET_ADDR_COORDINATE)
 * D/d: write, do not write to dst address register (NOC_RET_ADDR_LO)
 * L/l: write, do not write to length register (NOC_AT_LEN_BE)
 *
 * M/m: write, do not write to multicast register (NOC_CMD_BRCST_PACKET)
 * K/k: write, do not write to linked register (NOC_CMD_VC_LINKED)
 * P/p: write, do not write to posted register (NOC_CMD_RESP_MARKED)
 *
 * V/v: write, do not write to value register (NOC_AT_DATA)
 * B/b: write, do not write to byte-enable register (NOC_AT_LEN_BE)
 *
 * WAIT/wait: wait, do not wait for command buffer readiness (NOC_CMD_CTRL)
 * SEND/send: send, do not send the transaction immediately (NOC_CTRL_SEND_REQ)
 */
// clang-format on
constexpr uint32_t CQ_NOC_FLAG_SRC = 0x01;
constexpr uint32_t CQ_NOC_FLAG_NOC = 0x02;
constexpr uint32_t CQ_NOC_FLAG_DST = 0x04;
constexpr uint32_t CQ_NOC_FLAG_LEN = 0x08;

constexpr uint32_t CQ_NOC_INLINE_FLAG_VAL = 0x10;
constexpr uint32_t CQ_NOC_INLINE_FLAG_BE = 0x20;

constexpr uint32_t CQ_NOC_CMD_FLAG_MCAST = 0x01;
constexpr uint32_t CQ_NOC_CMD_FLAG_LINKED = 0x02;
constexpr uint32_t CQ_NOC_CMD_FLAG_POSTED = 0x04;

enum CQNocFlags {
    CQ_NOC_sndl = 0,
    CQ_NOC_sndL = CQ_NOC_FLAG_LEN,
    CQ_NOC_snDl = CQ_NOC_FLAG_DST,
    CQ_NOC_snDL = CQ_NOC_FLAG_DST | CQ_NOC_FLAG_LEN,
    CQ_NOC_sNdl = CQ_NOC_FLAG_NOC,
    CQ_NOC_sNdL = CQ_NOC_FLAG_NOC | CQ_NOC_FLAG_LEN,
    CQ_NOC_sNDl = CQ_NOC_FLAG_NOC | CQ_NOC_FLAG_DST,
    CQ_NOC_sNDL = CQ_NOC_FLAG_NOC | CQ_NOC_FLAG_DST | CQ_NOC_FLAG_LEN,
    CQ_NOC_Sndl = CQ_NOC_FLAG_SRC,
    CQ_NOC_SndL = CQ_NOC_FLAG_SRC | CQ_NOC_FLAG_LEN,
    CQ_NOC_SnDl = CQ_NOC_FLAG_SRC | CQ_NOC_FLAG_DST,
    CQ_NOC_SnDL = CQ_NOC_FLAG_SRC | CQ_NOC_FLAG_DST | CQ_NOC_FLAG_LEN,
    CQ_NOC_SNdl = CQ_NOC_FLAG_SRC | CQ_NOC_FLAG_NOC,
    CQ_NOC_SNdL = CQ_NOC_FLAG_SRC | CQ_NOC_FLAG_NOC | CQ_NOC_FLAG_LEN,
    CQ_NOC_SNDl = CQ_NOC_FLAG_SRC | CQ_NOC_FLAG_NOC | CQ_NOC_FLAG_DST,
    CQ_NOC_SNDL = CQ_NOC_FLAG_SRC | CQ_NOC_FLAG_NOC | CQ_NOC_FLAG_DST | CQ_NOC_FLAG_LEN,
};

enum CQNocCmdFlags {
    CQ_NOC_mkp = 0,
    CQ_NOC_mkP = CQ_NOC_CMD_FLAG_POSTED,
    CQ_NOC_mKp = CQ_NOC_CMD_FLAG_LINKED,
    CQ_NOC_mKP = CQ_NOC_CMD_FLAG_LINKED | CQ_NOC_CMD_FLAG_POSTED,
    CQ_NOC_Mkp = CQ_NOC_CMD_FLAG_MCAST,
    CQ_NOC_MkP = CQ_NOC_CMD_FLAG_MCAST | CQ_NOC_CMD_FLAG_POSTED,
    CQ_NOC_MKp = CQ_NOC_CMD_FLAG_MCAST | CQ_NOC_CMD_FLAG_LINKED,
    CQ_NOC_MKP = CQ_NOC_CMD_FLAG_MCAST | CQ_NOC_CMD_FLAG_LINKED | CQ_NOC_CMD_FLAG_POSTED,
};

enum CQNocInlineFlags {
    CQ_NOC_INLINE_ndvb = 0,
    CQ_NOC_INLINE_ndvB = CQ_NOC_INLINE_FLAG_BE,
    CQ_NOC_INLINE_ndVb = CQ_NOC_INLINE_FLAG_VAL,
    CQ_NOC_INLINE_ndVB = CQ_NOC_INLINE_FLAG_VAL | CQ_NOC_INLINE_FLAG_BE,
    CQ_NOC_INLINE_nDvb = CQ_NOC_FLAG_DST,
    CQ_NOC_INLINE_nDvB = CQ_NOC_FLAG_DST | CQ_NOC_INLINE_FLAG_BE,
    CQ_NOC_INLINE_nDVb = CQ_NOC_FLAG_DST | CQ_NOC_INLINE_FLAG_VAL,
    CQ_NOC_INLINE_nDVB = CQ_NOC_FLAG_DST | CQ_NOC_INLINE_FLAG_VAL | CQ_NOC_INLINE_FLAG_BE,
    CQ_NOC_INLINE_Ndvb = CQ_NOC_FLAG_NOC,
    CQ_NOC_INLINE_NdvB = CQ_NOC_FLAG_NOC | CQ_NOC_INLINE_FLAG_BE,
    CQ_NOC_INLINE_NdVb = CQ_NOC_FLAG_NOC | CQ_NOC_INLINE_FLAG_VAL,
    CQ_NOC_INLINE_NdVB = CQ_NOC_FLAG_NOC | CQ_NOC_INLINE_FLAG_VAL | CQ_NOC_INLINE_FLAG_BE,
    CQ_NOC_INLINE_NDvb = CQ_NOC_FLAG_NOC | CQ_NOC_FLAG_DST,
    CQ_NOC_INLINE_NDvB = CQ_NOC_FLAG_NOC | CQ_NOC_FLAG_DST | CQ_NOC_INLINE_FLAG_BE,
    CQ_NOC_INLINE_NDVb = CQ_NOC_FLAG_NOC | CQ_NOC_FLAG_DST | CQ_NOC_INLINE_FLAG_VAL,
    CQ_NOC_INLINE_NDVB = CQ_NOC_FLAG_NOC | CQ_NOC_FLAG_DST | CQ_NOC_INLINE_FLAG_VAL | CQ_NOC_INLINE_FLAG_BE,
};

enum CQNocWait {
    CQ_NOC_wait = 0,
    CQ_NOC_WAIT = 1,
};
enum CQNocSend {
    CQ_NOC_send = 0,
    CQ_NOC_SEND = 1,
};

// clang-format off
/**
 * Initializes the stateful registers for NOC read operations using a specific command buffer.
 * This function sets up the basic NOC read command configuration that will be reused across
 * multiple read transactions using the same command buffer.
 *
 * Return value: None
 *
 * | Argument                     | Description                                     | Data type | Valid range | Required |
 * |------------------------------|-------------------------------------------------|-----------|-------------|----------|
 * | noc                          | Which NOC to use for the transaction            | uint32_t  | 0 or 1      | True     |
 * | cmd_buf (template parameter) | Which command buffer to initialize              | uint32_t  | 0 - 3       | True     |
 */
// clang-format on
template <uint32_t cmd_buf>
inline __attribute__((always_inline)) void noc_read_init_state(uint32_t noc) {
    uint32_t noc_rd_cmd_field =
        NOC_CMD_CPY | NOC_CMD_RD | NOC_CMD_RESP_MARKED | NOC_CMD_VC_STATIC | NOC_CMD_STATIC_VC(1);

    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_CTRL, noc_rd_cmd_field);
}

// clang-format off
/**
 * Initiates an asynchronous read transaction using previously initialized stateful registers.
 * This function must be preceded by a call to \a noc_read_init_state for the same command buffer.
 * The function leverages stateful NOC registers to minimize register writes for repeated transactions
 * with similar characteristics.
 *
 * This function provides more granular control compared to previous stateful NOC APIs by allowing
 * selective register updates via the flags parameter. Users can specify exactly which NOC registers
 * (source address, destination address, coordinates, length) should be programmed on each call,
 * enabling fine-tuned optimization for specific transaction patterns.
 *
 * Return value: None
 *
 * | Argument                      | Description                                              | Data type        | Valid range                                              | Required |
 * |-------------------------------|----------------------------------------------------------|------------------|----------------------------------------------------------|----------|
 * | noc                           | Which NOC to use for the transaction                     | uint32_t         | 0 or 1                                                   | True     |
 * | src_addr                      | Source NOC address (x,y)+local address                   | uint64_t         | Results of \a get_noc_addr calls                         | True     |
 * | dst_addr                      | Destination address in local L1 memory                   | uint32_t         | 0..1 MB                                                  | True     |
 * | size                          | Size of transaction in bytes                             | uint32_t         | 0..NOC_MAX_BURST_SIZE for single packet                  | True     |
 * | noc_mode (template parameter) | NOC mode for the transaction                             | uint8_t          | DM_DEDICATED_NOC, DM_DYNAMIC_NOC or DM_INVALID_NOC (0-2) | False    |
 * | cmd_buf (template parameter)  | Which command buffer to use for the transaction          | uint32_t         | 0 - 3                                                    | True     |
 * | flags (template parameter)    | Which NOC registers to update in this call               | enum CQNocFlags  | Combination of CQ_NOC_FLAG_* flags                       | True     |
 * | send (template parameter)     | Whether to send the transaction immediately              | enum CQNocSend   | CQ_NOC_SEND or CQ_NOC_send                               | False    |
 * | wait (template parameter)     | Whether to wait for command buffer readiness             | enum CQNocWait   | CQ_NOC_WAIT or CQ_NOC_wait                               | False    |
 */
// clang-format on
template <uint8_t noc_mode, uint32_t cmd_buf, enum CQNocFlags flags, enum CQNocSend send, enum CQNocWait wait>
inline __attribute__((always_inline)) void noc_common_read_with_state(uint32_t noc, uint32_t dst_addr, uint32_t size) {
    if constexpr (send) {
        if constexpr (noc_mode == DM_DYNAMIC_NOC) {
            inc_noc_counter_val<proc_type, NocBarrierType::READS_NUM_ISSUED>(noc, 1);
        } else if constexpr (noc_mode == DM_DEDICATED_NOC) {
            noc_reads_num_issued[noc] += 1;
        }
    }
    if constexpr (wait) {
        while (!noc_cmd_buf_ready(noc, cmd_buf));
    }
    if constexpr (flags & CQ_NOC_FLAG_DST) {
        NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_RET_ADDR_LO, dst_addr);
    }
    if constexpr (flags & CQ_NOC_FLAG_LEN) {
        // TODO: Runtime assert for size < MAX_BURST_SIZE
        NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_AT_LEN_BE, size);
    }
}
template <
    uint8_t noc_mode = DM_DEDICATED_NOC,
    uint32_t cmd_buf,
    enum CQNocFlags flags,
    enum CQNocSend send = CQ_NOC_SEND,
    enum CQNocWait wait = CQ_NOC_WAIT>
inline __attribute__((always_inline)) void noc_read_with_state(
    uint32_t noc, uint64_t src_addr, uint32_t dst_addr, uint32_t size) {
    noc_common_read_with_state<noc_mode, cmd_buf, flags, send, wait>(noc, dst_addr, size);
    if constexpr (flags & CQ_NOC_FLAG_SRC) {
        NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_TARG_ADDR_LO, (uint32_t)src_addr);
    }
    if constexpr (flags & CQ_NOC_FLAG_NOC) {
        // This path only carries on-chip addresses, so MID stays at zero. 64 bit sources use the separate
        // coordinate overload, and noc_async_read_set_pcie_state sets and clears PCIe routing around a transfer.
        ASSERT(((src_addr >> 32) & NOC_PCIE_MASK) == 0);
        NOC_CMD_BUF_WRITE_REG(
            noc, cmd_buf, NOC_TARG_ADDR_COORDINATE, (uint32_t)(src_addr >> NOC_ADDR_COORD_SHIFT) & NOC_COORDINATE_MASK);
    }
    if constexpr (send) {
        NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_CMD_CTRL, NOC_CTRL_SEND_REQ);
    }
}

// Same as above, but with src_noc_addr giving the source NOC address separately. This allows 64 bit addresses within
// the NOC transactions.
// clang-format on
template <
    uint8_t noc_mode = DM_DEDICATED_NOC,
    uint32_t cmd_buf,
    enum CQNocFlags flags,
    enum CQNocSend send = CQ_NOC_SEND,
    enum CQNocWait wait = CQ_NOC_WAIT>
inline __attribute__((always_inline)) void noc_read_with_state(
    uint32_t noc, uint32_t src_noc_addr, uint64_t src_addr, uint32_t dst_addr, uint32_t size) {
    noc_common_read_with_state<noc_mode, cmd_buf, flags, send, wait>(noc, dst_addr, size);
    if constexpr (flags & CQ_NOC_FLAG_SRC) {
        NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_TARG_ADDR_LO, (uint32_t)src_addr);
        NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_TARG_ADDR_MID, (uint32_t)(src_addr >> 32));
    }
    if constexpr (flags & CQ_NOC_FLAG_NOC) {
        NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_TARG_ADDR_COORDINATE, src_noc_addr);
    }
    if constexpr (send) {
        NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_CMD_CTRL, NOC_CTRL_SEND_REQ);
    }
}

// clang-format off
/**
 * Initializes the stateful registers for NOC write operations using a specific command buffer.
 * This function sets up the basic NOC write command configuration including VC, multicast,
 * linked, and posted flags that will be reused across multiple write transactions using
 * the same command buffer.
 *
 * Return value: None
 *
 * | Argument                       | Description                                        | Data type           | Valid range         | Required |
 * |--------------------------------|----------------------------------------------------|---------------------|---------------------|----------|
 * | noc                            | Which NOC to use for the transaction               | uint32_t            | 0 or 1              | True     |
 * | vc                             | Virtual channel to use for the transactions        | uint32_t            | 0 - 3               | True     |
 * | cmd_buf (template parameter)   | Which command buffer to initialize                 | uint32_t            | 0 - 3               | True     |
 * | cmd_flags (template parameter) | Command flags for multicast/linked/posted options  | enum CQNocCmdFlags  | CQ_NOC_mkp variants | False    |
 */
// clang-format on
template <uint32_t cmd_buf, enum CQNocCmdFlags cmd_flags = CQ_NOC_mkp>
inline __attribute__((always_inline)) void noc_write_init_state(uint32_t noc, uint32_t vc) {
    constexpr bool multicast_path_reserve = true;
    uint32_t noc_cmd_field = NOC_CMD_CPY | NOC_CMD_WR | NOC_CMD_VC_STATIC | NOC_CMD_STATIC_VC(vc) |
                             ((cmd_flags & CQ_NOC_CMD_FLAG_LINKED) ? NOC_CMD_VC_LINKED : 0x0) |
                             ((cmd_flags & CQ_NOC_CMD_FLAG_MCAST)
                                  ? ((multicast_path_reserve ? NOC_CMD_PATH_RESERVE : 0) | NOC_CMD_BRCST_PACKET)
                                  : 0x0) |
                             ((cmd_flags & CQ_NOC_CMD_FLAG_POSTED) ? 0 : NOC_CMD_RESP_MARKED);

    NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_CTRL, noc_cmd_field);
}

// clang-format off
/**
 * Initiates an asynchronous write transaction using previously initialized stateful registers.
 * This function must be preceded by a call to \a noc_write_init_state for the same command buffer.
 * The function leverages stateful NOC registers to minimize register writes for repeated transactions
 * with similar characteristics.
 *
 * This function provides more granular control compared to previous stateful NOC APIs by allowing
 * selective register updates via the flags parameter. Users can specify exactly which NOC registers
 * (source address, destination address, coordinates, length) should be programmed on each call,
 * enabling fine-tuned optimization for specific transaction patterns.
 *
 * Return value: None
 *
 * | Argument                            | Description                                              | Data type       | Valid range                                              | Required |
 * |-------------------------------------|----------------------------------------------------------|-----------------|----------------------------------------------------------|----------|
 * | noc                                 | Which NOC to use for the transaction                     | uint32_t        | 0 or 1                                                   | True     |
 * | src_addr                            | Source address in local L1 memory                        | uint32_t        | 0..1 MB                                                  | True     |
 * | dst_addr                            | Destination NOC address (x,y)+local address              | uint64_t        | Results of \a get_noc_addr calls                         | True     |
 * | size                                | Size of transaction in bytes                             | uint32_t        | 0..NOC_MAX_BURST_SIZE for single packet                  | False    |
 * | ndests                              | Number of destinations for multicast operations          | uint32_t        | 1 or more                                                | False    |
 * | noc_mode (template parameter)       | NOC mode for the transaction                             | uint8_t         | DM_DEDICATED_NOC, DM_DYNAMIC_NOC or DM_INVALID_NOC (0-2) | False    |
 * | cmd_buf (template parameter)        | Which command buffer to use for the transaction          | uint32_t        | 0 - 3                                                    | True     |
 * | flags (template parameter)          | Which NOC registers to update in this call               | enum CQNocFlags | Combination of CQ_NOC_FLAG_* flags                       | True     |
 * | send (template parameter)           | Whether to send the transaction immediately              | enum CQNocSend  | CQ_NOC_SEND or CQ_NOC_send                               | False    |
 * | wait (template parameter)           | Whether to wait for command buffer readiness             | enum CQNocWait  | CQ_NOC_WAIT or CQ_NOC_wait                               | False    |
 * | update_counter (template parameter) | Whether to increment write counters                      | bool            | true or false                                            | False    |
 * | posted (template parameter)         | Whether the transaction is posted (no ack required)      | bool            | true or false                                            | False    |
 */
// clang-format on
template <
    uint8_t noc_mode,
    uint32_t cmd_buf,
    enum CQNocFlags flags,
    enum CQNocWait wait,
    bool update_counter,
    bool posted>
inline __attribute__((always_inline)) void noc_common_write_with_state(
    uint32_t noc, uint32_t src_addr, uint32_t size, uint32_t ndests) {
    if constexpr (update_counter && noc_mode == DM_DYNAMIC_NOC) {
        if constexpr (posted) {
            inc_noc_counter_val<proc_type, NocBarrierType::POSTED_WRITES_NUM_ISSUED>(noc, 1);
        } else {
            inc_noc_counter_val<proc_type, NocBarrierType::NONPOSTED_WRITES_NUM_ISSUED>(noc, 1);
            inc_noc_counter_val<proc_type, NocBarrierType::NONPOSTED_WRITES_ACKED>(noc, ndests);
        }
    }
    if constexpr (update_counter && noc_mode == DM_DEDICATED_NOC) {
        if constexpr (posted) {
            noc_posted_writes_num_issued[noc] += 1;
        } else {
            noc_nonposted_writes_num_issued[noc] += 1;
            noc_nonposted_writes_acked[noc] += ndests;
        }
    }
    if constexpr (wait) {
        while (!noc_cmd_buf_ready(noc, cmd_buf));
    }
    if constexpr (flags & CQ_NOC_FLAG_SRC) {
        NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_TARG_ADDR_LO, src_addr);
    }
    if constexpr (flags & CQ_NOC_FLAG_LEN) {
        // TODO: Runtime assert for size < MAX_BURST_SIZE
        NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_AT_LEN_BE, size);
    }
}
template <
    uint8_t noc_mode = DM_DEDICATED_NOC,
    uint32_t cmd_buf,
    enum CQNocFlags flags,
    enum CQNocSend send = CQ_NOC_SEND,
    enum CQNocWait wait = CQ_NOC_WAIT,
    bool update_counter = true,
    bool posted = false>
inline __attribute__((always_inline)) void noc_write_with_state(
    uint32_t noc, uint32_t src_addr, uint64_t dst_addr, uint32_t size = 0, uint32_t ndests = 1) {
    noc_common_write_with_state<noc_mode, cmd_buf, flags, wait, update_counter, posted>(noc, src_addr, size, ndests);
    if constexpr (flags & CQ_NOC_FLAG_DST) {
        NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_RET_ADDR_LO, (uint32_t)dst_addr);
    }
    if constexpr (flags & CQ_NOC_FLAG_NOC) {
        // This path only carries on-chip addresses, so MID stays at zero. 64 bit destinations use the separate
        // coordinate overload, and noc_async_write_set_pcie_state sets and clears PCIe routing around a transfer.
        ASSERT(((dst_addr >> 32) & NOC_PCIE_MASK) == 0);
        NOC_CMD_BUF_WRITE_REG(
            noc, cmd_buf, NOC_RET_ADDR_COORDINATE, (uint32_t)(dst_addr >> NOC_ADDR_COORD_SHIFT) & NOC_COORDINATE_MASK);
    }
    if constexpr (send) {
        NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_CMD_CTRL, NOC_CTRL_SEND_REQ);
    }
}
// clang-format off
/**
 * Similar to above except takes additional argument, \a  dst_noc_addr, to free up \a dst_addr to be 64 bits
 *
 */
template <
    uint8_t noc_mode = DM_DEDICATED_NOC,
    uint32_t cmd_buf,
    enum CQNocFlags flags,
    enum CQNocSend send = CQ_NOC_SEND,
    enum CQNocWait wait = CQ_NOC_WAIT,
    bool update_counter = true,
    bool posted = false>
inline __attribute__((always_inline)) void noc_wwrite_with_state(
    uint32_t noc, uint32_t src_addr, uint32_t dst_noc_addr, uint64_t dst_addr, uint32_t size = 0, uint32_t ndests = 1) {
    noc_common_write_with_state<noc_mode, cmd_buf, flags, wait, update_counter, posted>(noc, src_addr, size, ndests);
    if constexpr (flags & CQ_NOC_FLAG_DST) {
        NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_RET_ADDR_LO, (uint32_t)dst_addr);
        NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_RET_ADDR_MID, (uint32_t)(dst_addr >> 32));
    }
    if constexpr (flags & CQ_NOC_FLAG_NOC) {
        // Handles writing to PCIe
        NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_RET_ADDR_COORDINATE, dst_noc_addr);
    }
    if constexpr (send) {
        NOC_CMD_BUF_WRITE_REG(noc, cmd_buf, NOC_CMD_CTRL, NOC_CTRL_SEND_REQ);
    }
}

template <uint8_t MAX_NOCS_TO_INIT = NUM_NOCS>
inline __attribute__((always_inline)) void ncrisc_dynamic_noc_full_sync() {
    for (uint32_t noc = 0; noc < MAX_NOCS_TO_INIT; noc++) {
        while (!ncrisc_dynamic_noc_reads_flushed(noc)) {
            invalidate_l1_cache();
        }
        while (!ncrisc_dynamic_noc_nonposted_writes_sent(noc)) {
            invalidate_l1_cache();
        }
        while (!ncrisc_dynamic_noc_nonposted_writes_flushed(noc)) {
            invalidate_l1_cache();
        }
        while (!ncrisc_dynamic_noc_nonposted_atomics_flushed(noc)) {
            invalidate_l1_cache();
        }
        while (!ncrisc_dynamic_noc_posted_writes_sent(noc)) {
            invalidate_l1_cache();
        }
    }
}

template <bool write, bool posted>
inline __attribute__((always_inline)) uint32_t get_noc_counter_for_debug(uint32_t noc) {
    if constexpr (write) {
        if constexpr (posted) {
            return NOC_STATUS_READ_REG(noc, NIU_MST_POSTED_WR_REQ_SENT);
        } else {
            return NOC_STATUS_READ_REG(noc, NIU_MST_NONPOSTED_WR_REQ_SENT);
        }
    } else {
        // Read
        static_assert(posted == false, "There is no such thing as posted reads");
        return NOC_STATUS_READ_REG(noc, NIU_MST_RD_RESP_RECEIVED);
    }
}
