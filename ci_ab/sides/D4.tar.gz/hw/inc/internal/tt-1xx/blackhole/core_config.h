// SPDX-FileCopyrightText: © 2024 Tenstorrent USA, Inc.
//
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include <stdint.h>
#include "hostdev/debug_ring_buffer_common.h"

enum ProgrammableCoreType {
    TENSIX = 0,
    ACTIVE_ETH = 1,
    IDLE_ETH = 2,
    DRAM = 3,
    COUNT = 4,
};

enum class TensixProcessorTypes : uint8_t { DM0 = 0, DM1 = 1, MATH0 = 2, MATH1 = 3, MATH2 = 4, COUNT = 5 };

enum class EthProcessorTypes : uint8_t { DM0 = 0, DM1 = 1, COUNT = 2 };

enum class DramProcessorTypes : uint8_t { DM0 = 0, COUNT = 1 };

union subordinate_map_t {
    volatile uint32_t all;
    struct {
        volatile uint8_t dm1;  // ncrisc must come first, see ncrisc-halt.S
        volatile uint8_t trisc0;
        volatile uint8_t trisc1;
        volatile uint8_t trisc2;
    };
};

constexpr uint8_t MaxProcessorsPerCoreType = 5;
constexpr uint8_t MaxProcessorsForThreadingVariables = 0;  // No multi-threading on Blackhole. Set to 0 to save space.
constexpr uint8_t MaxDMProcessorsPerCoreType = 2;
constexpr uint8_t MaxNumKernels = MaxDMProcessorsPerCoreType+1; // +1 for the compute kernel.
constexpr uint8_t noc_size_x = 17;
constexpr uint8_t noc_size_y = 12;
constexpr uint8_t tensix_harvest_axis = 0x2;
constexpr uint8_t subordinate_map_size = sizeof(subordinate_map_t);
#define LOG_BASE_2_OF_DRAM_ALIGNMENT 6
#define LOG_BASE_2_OF_L1_ALIGNMENT 4

constexpr uint32_t debug_ring_buf_size = sizeof(debug_mpsc_ring_buf_msg_blackhole_t);
