// SPDX-FileCopyrightText: © 2026 Tenstorrent USA, Inc.
//
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include "llk_math_common_api.h"
#include "experimental/llk_math_generalized_moe_gate_transpose_dest_single_face.h"
#include "sanitizer/api.h"

namespace ckernel {

template <bool is_32bit = false>
inline void llk_math_generalized_moe_gate_transpose_dest_single_face_common_init() {
    SAN_HOOK(unsupported());
    _llk_math_generalized_moe_gate_transpose_dest_single_face_common_init_<is_32bit>();
}

template <bool is_32bit = false>
inline void llk_math_generalized_moe_gate_transpose_dest_single_face_step0_init() {
    SAN_HOOK(unsupported());
    _llk_math_generalized_moe_gate_transpose_dest_single_face_step0_init_<is_32bit>();
}

template <bool is_fp32_dest_acc_en, bool is_32bit = false>
inline void llk_math_generalized_moe_gate_transpose_dest_single_face_step0() {
    SAN_HOOK(unsupported());
    _llk_math_generalized_moe_gate_transpose_dest_single_face_step0_<is_fp32_dest_acc_en, is_32bit>();
}

template <bool is_32bit = false>
inline void llk_math_generalized_moe_gate_transpose_dest_single_face_step1_init() {
    SAN_HOOK(unsupported());
    _llk_math_generalized_moe_gate_transpose_dest_single_face_step1_init_<is_32bit>();
}

template <bool is_fp32_dest_acc_en, bool is_32bit = false>
inline void llk_math_generalized_moe_gate_transpose_dest_single_face_step1() {
    SAN_HOOK(unsupported());
    _llk_math_generalized_moe_gate_transpose_dest_single_face_step1_<is_fp32_dest_acc_en, is_32bit>();
}

template <std::uint32_t src = 0, std::uint32_t dst = 0, bool is_32bit = false, std::uint32_t srcb = 16>
inline void llk_math_generalized_moe_gate_copy4rows_init() {
    SAN_HOOK(unsupported());
    _llk_math_generalized_moe_gate_copy4rows_init_<src, dst, is_32bit, srcb>();
}

template <bool is_fp32_dest_acc_en, bool is_32bit = false>
inline void llk_math_generalized_moe_gate_copy4rows() {
    SAN_HOOK(unsupported());
    _llk_math_generalized_moe_gate_copy4rows_<is_fp32_dest_acc_en, is_32bit>();
}

template <std::uint32_t d2b_dst = 0, std::uint32_t b2d_base = 24, bool is_32bit = false>
inline void llk_math_generalized_moe_gate_transpose_dest_single_face_step1_hi_init() {
    SAN_HOOK(unsupported());
    _llk_math_generalized_moe_gate_transpose_dest_single_face_step1_hi_init_<d2b_dst, b2d_base, is_32bit>();
}

template <bool is_fp32_dest_acc_en, bool is_32bit = false>
inline void llk_math_generalized_moe_gate_transpose_dest_single_face_step1_hi() {
    SAN_HOOK(unsupported());
    _llk_math_generalized_moe_gate_transpose_dest_single_face_step1_hi_<is_fp32_dest_acc_en, is_32bit>();
}

template <bool is_32bit = false, std::uint32_t num_tiles = 3>
inline void llk_math_generalized_moe_gate_transpose_dest_single_face_step2_init() {
    SAN_HOOK(unsupported());
    _llk_math_generalized_moe_gate_transpose_dest_single_face_step2_init_<is_32bit, num_tiles>();
}

template <bool is_fp32_dest_acc_en, bool is_32bit = false>
inline void llk_math_generalized_moe_gate_transpose_dest_single_face_step2() {
    SAN_HOOK(unsupported());
    _llk_math_generalized_moe_gate_transpose_dest_single_face_step2_<is_fp32_dest_acc_en, is_32bit>();
}

}  // namespace ckernel
