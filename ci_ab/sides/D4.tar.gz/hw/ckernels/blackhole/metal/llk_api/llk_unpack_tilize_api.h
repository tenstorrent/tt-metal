// SPDX-FileCopyrightText: © 2024 Tenstorrent USA, Inc.
//
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include "sanitizer/api.h"
#include <cstdint>
#include "llk_unpack_common_api.h"
#include "llk_unpack_tilize.h"

/*************************************************************************
 * LLK UNPACK TILIZE
 *************************************************************************/

// Unified cores, shared by the CB-id API below and the LLKOperand API (experimental/). They take
// already-resolved scalar format/geometry (+ the runtime base address for the op); the per-source
// prologue (resolving these from a CB id, or from an MemDescriptor) lives in the callers.
inline void llk_unpack_tilize_init_impl(
    const std::uint32_t src_format,
    const std::uint32_t dst_format,
    const std::uint32_t ct_dim,
    const std::uint32_t face_r_dim,
    const bool narrow_tile,
    const std::uint32_t num_faces) {
    SAN_HOOK(init<OperationUnpackTilize>(
        StateVal<OperationUnpackTilize::BlockCtDim>(ct_dim),
        StateVal<OperationUnpackTilize::NarrowTile>(narrow_tile),
        StateVal<Operand<Exu::Unpack>::InputFormatA>(src_format),
        StateVal<Operand<Exu::Unpack>::OutputFormatA>(dst_format),
        StateVal<Operand<Exu::Unpack>::FaceHeightA>(face_r_dim),
        StateVal<Operand<Exu::Unpack>::NumFacesA>(num_faces)));

    _llk_unpack_tilize_init_(src_format, dst_format, ct_dim, face_r_dim, narrow_tile, num_faces);
}

inline void llk_unpack_tilize_impl(
    const std::uint32_t base_address,
    const std::uint32_t tile_index,
    const std::uint32_t src_format,
    const std::uint32_t dst_format,
    const std::uint32_t face_r_dim,
    const std::uint32_t num_faces,
    const bool narrow_tile) {
    WAYPOINT("UPTW");
    SAN_HOOK(execute<OperationUnpackTilize>(
        StateVal<OperationUnpackTilize::NarrowTile>(narrow_tile),
        StateVal<Operand<Exu::Unpack>::InputFormatA>(src_format),
        StateVal<Operand<Exu::Unpack>::OutputFormatA>(dst_format),
        StateVal<Operand<Exu::Unpack>::FaceHeightA>(face_r_dim),
        StateVal<Operand<Exu::Unpack>::NumFacesA>(num_faces),
        StateDiscard<std::uint32_t>(tile_index)));

    _llk_unpack_tilize_(base_address, tile_index, src_format, dst_format, face_r_dim, num_faces, narrow_tile);
    WAYPOINT("UPTD");
}

/**
 * Initialize the unpacker for a single-operand tilize operation.
 *
 * Face row dimension, narrow-tile flag and face count are derived from the operand's CB metadata.
 *
 * @param operand Input circular buffer / operand index.
 * @param ct_dim  Number of tiles along the column (tilize block width).
 */
inline void llk_unpack_tilize_init(const std::uint32_t operand, const std::uint32_t ct_dim) {
    const std::uint32_t operand_id = get_operand_id(operand);
    llk_unpack_tilize_init_impl(
        unpack_src_format[operand_id],
        unpack_dst_format[operand_id],
        ct_dim,
        get_operand_face_r_dim(operand_id),
        get_operand_narrow_tile(operand_id),
        get_operand_num_faces(operand_id));
}

/**
 * Tear down the tilize unpacker configuration so a subsequent operation can reprogram the unpacker.
 *
 * Tile geometry comes from the operand's CB metadata, so the restore matches the operand rather
 * than a hardcoded 16x16, 4-face tile.
 *
 * @param operand Input circular buffer / operand index.
 */
inline void llk_unpack_tilize_uninit_impl(const std::uint32_t dst_format, const ckernel::TensorShape tensor_shape) {
    SAN_HOOK(uninit<OperationUnpackTilize>(
        StateVal<Operand<Exu::Unpack>::OutputFormatA>(dst_format),
        StateVal<Operand<Exu::Unpack>::FaceHeightA>(tensor_shape.face_r_dim),
        StateVal<Operand<Exu::Unpack>::NumFacesA>(tensor_shape.total_num_faces())));

    _llk_unpack_tilize_uninit_(dst_format, tensor_shape);
}

inline void llk_unpack_tilize_uninit(const std::uint32_t operand) {
    std::uint32_t operand_id = get_operand_id(operand);
    const std::uint32_t num_faces = get_operand_num_faces(operand_id);
    const std::uint32_t face_r_dim = get_operand_face_r_dim(operand_id);
    llk_unpack_tilize_uninit_impl(
        (std::uint32_t)unpack_dst_format[operand_id], ckernel::tensor_shape_from_num_faces(face_r_dim, num_faces));
}

/**
 * Unpack and tilize a single tile from the operand's circular buffer into srcA.
 *
 * Face geometry and narrow-tile flag are derived from the operand's CB metadata; the source base
 * address is read from the CB fifo state.
 *
 * @param operand    Input circular buffer / operand index.
 * @param tile_index Tile index within the input to tilize.
 */
inline void llk_unpack_tilize(std::uint32_t operand, std::uint32_t tile_index) {
    std::uint32_t operand_id = get_operand_id(operand);
    std::uint32_t base_address =
        get_local_cb_interface(operand_id).fifo_rd_ptr - 1;  // Remove header size added by descriptor

    llk_unpack_tilize_impl(
        base_address,
        tile_index,
        unpack_src_format[operand_id],
        unpack_dst_format[operand_id],
        get_operand_face_r_dim(operand_id),
        get_operand_num_faces(operand_id),
        get_operand_narrow_tile(operand_id));
}

/**
 * Unpack and tilize a contiguous block of tiles by repeatedly calling llk_unpack_tilize.
 *
 * @param operand          Input circular buffer / operand index.
 * @param block_c_tiles    Number of column tiles in the block.
 * @param input_tile_index Starting tile index within the input (defaults to 0).
 */
inline void llk_unpack_tilize_block(std::uint32_t operand, std::uint32_t block_c_tiles, std::uint32_t input_tile_index = 0) {
    // Not sure if input_tile_index can be arbitrary but it works for moving across rows of files,
    // i.e. input_tile_index % block_c_tiles == 0
    const std::uint32_t tile_r_dim = get_operand_tile_r_dim(get_operand_id(operand));
    const auto block = input_tile_index / block_c_tiles;
    const auto offset = input_tile_index % block_c_tiles;
    input_tile_index = block * (block_c_tiles * tile_r_dim) + offset;
    for (std::uint32_t tile_index = 0; tile_index < block_c_tiles; tile_index++) {
        llk_unpack_tilize(operand, input_tile_index + tile_index);
    }
}

/*************************************************************************
 * LLK UNPACK TILIZE SRC A, UNPACK SRC B
 *************************************************************************/

/**
 * Program the unpacker MOP (macro-op) configuration for the combined tilize-A / unpack-B operation.
 *
 * @tparam neginf_srcA      Initialize srcA padding with negative infinity (for reduce-max).
 * @tparam reload_srcB      Whether srcB is reloaded each iteration.
 * @tparam zero_srcA        Zero out srcA.
 * @tparam zero_srcA_reduce Zero out srcA for the reduce path.
 * @param  num_faces        Number of faces per tile (defaults to 4).
 */
// TODO: add support for all the template parameters
template <bool neginf_srcA = false, std::uint32_t reload_srcB = false, bool zero_srcA = false, bool zero_srcA_reduce = false>
inline void llk_unpack_tilizeA_B_mop_config(const std::uint32_t num_faces = 4) {
    SAN_HOOK(unsupported());
    _llk_unpack_tilizeA_B_mop_config_<neginf_srcA, reload_srcB, zero_srcA, zero_srcA_reduce>(num_faces);
}

/**
 * Initialize the unpacker for the combined tilize-A / unpack-B operation.
 *
 * Operand A and B face geometry (face_r_dim, num_faces) is derived from circular-buffer unpack
 * metadata (see set_unpack_face_geometry). In debug builds, validates that both unpackers are
 * configured consistently before programming the init sequence.
 *
 * @tparam neginf_srcA      Initialize srcA padding with negative infinity (for reduce-max).
 * @tparam reload_srcB      Whether srcB is reloaded each iteration.
 * @tparam zero_srcA        Zero out srcA.
 * @tparam zero_srcA_reduce Zero out srcA for the reduce path.
 * @param  operandA         Input operand index for tilize source A.
 * @param  operandB         Input operand index for unpack source B.
 * @param  ct_dim           Number of tiles along the column (tilize block width).
 */
template <bool neginf_srcA = false, std::uint32_t reload_srcB = false, bool zero_srcA = false, bool zero_srcA_reduce = false>
inline void llk_unpack_tilizeA_B_init(
    const std::uint32_t operandA, const std::uint32_t operandB, const std::uint32_t ct_dim) {
    SAN_HOOK(unsupported());
    const std::uint32_t operandA_id = get_operand_id(operandA);
    const std::uint32_t operandB_id = get_operand_id(operandB);
    const std::uint32_t num_faces = get_operand_num_faces(operandA_id);
    const std::uint32_t unpA_face_r_dim = get_operand_face_r_dim(operandA_id);
    const std::uint32_t unpB_face_r_dim = get_operand_face_r_dim(operandB_id);

    LLK_ASSERT_BLOCK(are_unpackers_AB_configured_correctly<UnpackerProgramType::ProgramByFace>(
        unpack_src_format[operandA_id],
        unpack_dst_format[operandA_id],
        unpack_src_format[operandB_id],
        unpack_dst_format[operandB_id],
        unpA_face_r_dim,
        unpB_face_r_dim,
        num_faces,
        get_operand_num_faces(operandB_id)));

    _llk_unpack_tilizeA_B_init_<neginf_srcA, reload_srcB, zero_srcA, zero_srcA_reduce>(
        unpack_src_format[operandA_id],
        unpack_dst_format[operandA_id],
        ct_dim,
        num_faces,
        unpB_face_r_dim
    );
}

/**
 * Unpack and tilize one srcA tile while unpacking the corresponding srcB tile.
 *
 * Operand A face geometry and narrow-tile flag are derived from CB unpack metadata; source base
 * addresses are read from the CB fifo state.
 *
 * @tparam neginf_srcA      Initialize srcA padding with negative infinity (for reduce-max).
 * @tparam reload_srcB      Whether srcB is reloaded each iteration.
 * @tparam zero_srcA        Zero out srcA.
 * @tparam zero_srcA_reduce Zero out srcA for the reduce path.
 * @param  operandA     Input operand index for tilize source A.
 * @param  operandB     Input operand index for unpack source B.
 * @param  tile_index_a Tile index within operand A.
 * @param  tile_index_b Tile index within operand B.
 * @param  block_ct_dim Number of column tiles in the block.
 */
template <bool neginf_srcA = false, std::uint32_t reload_srcB = false, bool zero_srcA = false, bool zero_srcA_reduce = false>
inline void llk_unpack_tilizeA_B(
    std::uint32_t operandA,
    std::uint32_t operandB,
    std::uint32_t tile_index_a,
    std::uint32_t tile_index_b,
    std::uint32_t block_ct_dim) {
    SAN_HOOK(unsupported());
    std::uint32_t operandA_id = get_operand_id(operandA);
    std::uint32_t operandB_id = get_operand_id(operandB);

    const std::uint32_t face_r_dim = get_operand_face_r_dim(operandA_id);
    const std::uint32_t num_faces = get_operand_num_faces(operandA_id);

    const std::uint32_t base_address_a =
        get_local_cb_interface(operandA_id).fifo_rd_ptr - 1;  // Remove header size added by descriptor

    const std::uint32_t base_address_b =
        get_local_cb_interface(operandB_id).fifo_rd_ptr - 1;  // Remove header size added by descriptor
    const std::uint32_t offset_address_b = tile_index_b * get_local_cb_interface(operandB_id).fifo_page_size;
    const std::uint32_t address_b = base_address_b + offset_address_b;

    LLK_ASSERT_BLOCK(are_unpackers_AB_configured_correctly<UnpackerProgramType::ProgramByFace>(
        unpack_src_format[operandA_id],
        unpack_dst_format[operandA_id],
        unpack_src_format[operandB_id],
        unpack_dst_format[operandB_id],
        face_r_dim,
        get_operand_face_r_dim(operandB_id),
        num_faces,
        get_operand_num_faces(operandB_id)));

    WAYPOINT("UPTW");

    _llk_unpack_tilizeA_B_<neginf_srcA, reload_srcB, zero_srcA, zero_srcA_reduce>(
        unpack_src_format[operandA_id],
        face_r_dim,
        base_address_a,
        address_b,
        tile_index_a,
        block_ct_dim,
        num_faces
    );

    WAYPOINT("UPTD");
}

/**
 * Unpack and tilize a block of srcA column tiles against srcB by repeatedly calling
 * llk_unpack_tilizeA_B.
 *
 * @tparam neginf_srcA      Initialize srcA padding with negative infinity (for reduce-max).
 * @tparam reload_srcB      Whether srcB is reloaded each iteration.
 * @tparam zero_srcA        Zero out srcA.
 * @tparam zero_srcA_reduce Zero out srcA for the reduce path.
 * @param  operandA        Input operand index for tilize source A.
 * @param  operandB        Input operand index for unpack source B.
 * @param  block_c_tiles_a Number of column tiles in operand A's block.
 * @param  tile_idx_b      Tile index within operand B.
 */
template <bool neginf_srcA = false, std::uint32_t reload_srcB = false, bool zero_srcA = false, bool zero_srcA_reduce = false>
inline void llk_unpack_tilizeA_B_block(
    std::uint32_t operandA,
    std::uint32_t operandB,
    std::uint32_t block_c_tiles_a,
    std::uint32_t tile_idx_b) {
    SAN_HOOK(unsupported());
    for (std::uint32_t tile_idx_a = 0; tile_idx_a < block_c_tiles_a; tile_idx_a++) {
        llk_unpack_tilizeA_B<neginf_srcA, reload_srcB, zero_srcA, zero_srcA_reduce>(
            operandA, operandB, tile_idx_a, tile_idx_b, block_c_tiles_a);
    }
}

/**
 * Tear down the combined tilize-A / unpack-B configuration so a subsequent operation can reprogram
 * the unpacker.
 *
 * Reverts the SrcA Y stride its init wrote. Tile_x_dim_cntx0 is left alone, since its init never
 * programs it.
 *
 * @param operand Input circular buffer / operand index.
 */
inline void llk_unpack_tilizeA_B_uninit(const std::uint32_t operand) {
    SAN_HOOK(unsupported());
    std::uint32_t operand_id = get_operand_id(operand);
    _llk_unpack_tilizeA_B_uninit_((std::uint32_t)unpack_dst_format[operand_id]);
}
