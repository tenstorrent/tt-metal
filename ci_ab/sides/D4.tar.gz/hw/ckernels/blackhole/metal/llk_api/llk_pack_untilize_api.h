// SPDX-FileCopyrightText: © 2026 Tenstorrent USA, Inc.
//
// SPDX-License-Identifier: Apache-2.0

#pragma once
#include <cstdint>
#include "llk_pack_common_api.h"
#include "llk_pack_untilize.h"
#include "sanitizer/api.h"

/*************************************************************************
 * LLK PACK UNTILIZE
 *************************************************************************/

// Unified cores, shared by the CB-id API below and the LLKOperand API (experimental/2_0/). They take
// already-resolved scalar formats/geometry + a runtime write address / per-row stride; the per-source
// prologue (resolving these from a CB id, or from an LLKMemDescriptor) lives in the callers. The CB-id
// callers pass base_addr = fifo_wr_ptr - 1 and page_stride = full_ct_dim * fifo_page_size; the id-free
// callers pass base_addr = cb_write_address(...) and a compile-time page_stride derived from the output
// descriptor (fifo_page_size == a single tile size assumption -- see experimental/2_0/llk_pack_untilize.h).

// Never defined: a call that survives constant folding fails the kernel build.
[[gnu::error(
    "pack untilize: an Fp8_e4m3 output in one-tile blocks of a wider row writes 32 bytes of zeros after every row "
    "(tt-metal#59140); split the row into blocks of two or more tiles")]] void
llk_pack_untilize_fp8_one_tile_block_unsupported();

template <
    std::uint32_t block_ct_dim = 8,
    std::uint32_t full_ct_dim = block_ct_dim,
    bool narrow_row = false,
    std::uint32_t row_num_datums = TILE_C_DIM,
    bool dense = false,
    bool pace_32bit_rows = true>
inline void llk_pack_untilize_init_impl(
    const std::uint32_t pack_src_format,
    const std::uint32_t pack_dst_format,
    const std::uint32_t face_r_dim,
    const std::uint32_t num_faces) {
    LLK_ASSERT_BLOCK(are_packers_configured_correctly(pack_src_format, pack_dst_format));
    if constexpr (block_ct_dim == 1 && full_ct_dim > 1 && !narrow_row) {
        // A kernel with a compile-time output format is refused at build time; the LLK asserts otherwise.
        if (__builtin_constant_p(pack_dst_format) &&
            pack_dst_format == static_cast<std::uint32_t>(DataFormat::Fp8_e4m3)) {
            llk_pack_untilize_fp8_one_tile_block_unsupported();
        }
    }

    if constexpr (narrow_row || row_num_datums != TILE_C_DIM) {
        // Narrow-row packing is not modelled yet: https://github.com/tenstorrent/tt-metal/issues/56088
        SAN_HOOK(unsupported());
    }

    SAN_HOOK(init<OperationPackUntilize>(
        StateVal<OperationPackUntilize::BlockCtDim>(block_ct_dim),
        StateVal<OperationPackUntilize::FullCtDim>(full_ct_dim),
        StateVal<Operand<Exu::Pack>::InputFormat>(pack_src_format),
        StateVal<Operand<Exu::Pack>::OutputFormat>(pack_dst_format),
        StateVal<Operand<Exu::Pack>::FaceHeight>(face_r_dim),
        StateVal<Operand<Exu::Pack>::NumFaces>(num_faces),
        StateDiscard<bool>(narrow_row),
        StateDiscard<std::uint32_t>(row_num_datums),
        StateDiscard<bool>(false /* diagonal: WH-only */),
        StateDiscard<bool>(dense)));

    _llk_pack_untilize_init_<block_ct_dim, full_ct_dim, narrow_row, row_num_datums, dense, pace_32bit_rows>(
        pack_src_format, pack_dst_format, face_r_dim, num_faces);
}

template <
    std::uint32_t block_ct_dim = 8,
    std::uint32_t full_ct_dim = block_ct_dim,
    bool narrow_row = false,
    std::uint32_t row_num_datums = TILE_C_DIM,
    std::uint32_t tile_dst_ct_offset = 0,
    bool dense = false>
inline void llk_pack_untilize_impl(
    const std::uint32_t block_rt_dim,
    const std::uint32_t base_addr,
    const std::uint32_t pack_src_format,
    const std::uint32_t pack_dst_format,
    const std::uint32_t page_stride,
    const std::uint32_t face_r_dim,
    const std::uint32_t num_faces,
    const std::uint32_t block_c_index,
    const std::uint32_t tile_dst_rt_offset) {
    std::uint32_t pack_tile_addr =
        base_addr + SCALE_DATUM_SIZE(
                        pack_dst_format,
                        (block_c_index * ((num_faces > 2) ? num_faces / 2 : num_faces) * block_ct_dim * FACE_C_DIM)) /
                        16;

    LLK_ASSERT_BLOCK(are_packers_configured_correctly(pack_src_format, pack_dst_format));

    if constexpr (narrow_row || row_num_datums != TILE_C_DIM) {
        // Narrow-row packing is not modelled yet: https://github.com/tenstorrent/tt-metal/issues/56088
        SAN_HOOK(unsupported());
    }

    SAN_HOOK(execute<OperationPackUntilize>(
        StateVal<OperationPackUntilize::BlockCtDim>(block_ct_dim),
        StateVal<OperationPackUntilize::FullCtDim>(full_ct_dim),
        StateVal<Operand<Exu::Pack>::InputFormat>(pack_src_format),
        StateVal<Operand<Exu::Pack>::OutputFormat>(pack_dst_format),
        StateVal<Operand<Exu::Pack>::FaceHeight>(face_r_dim),
        StateVal<Operand<Exu::Pack>::NumFaces>(num_faces),
        StateDiscard<bool>(narrow_row),
        StateDiscard<std::uint32_t>(row_num_datums),
        StateDiscard<bool>(false /* diagonal: WH-only */),
        StateDiscard<bool>(dense),
        StateDiscard<std::uint32_t>(block_rt_dim),
        StateDiscard<std::uint32_t>(block_c_index),
        StateDiscard<std::uint32_t>(tile_dst_rt_offset)));

    for (std::uint32_t block_rt = 0; block_rt < block_rt_dim; block_rt++) {
        _llk_pack_untilize_<block_ct_dim, full_ct_dim, narrow_row, tile_dst_ct_offset, dense>(
            pack_tile_addr, num_faces, block_rt * block_ct_dim + tile_dst_rt_offset);

        pack_tile_addr += page_stride;
    }
}

inline void llk_pack_untilize_uninit_impl(const std::uint32_t pack_src_format) {
    SAN_HOOK(uninit<OperationPackUntilize>(StateVal<Operand<Exu::Pack>::InputFormat>(pack_src_format)));

    _llk_pack_untilize_uninit_(pack_src_format);
}

/**
 * Initialize the packer for an untilize operation on the given output operand.
 *
 * Face geometry (face_r_dim, num_faces) is derived from the output CB metadata. In
 * debug builds, validates that the packers are configured correctly for the resolved
 * face row dimension before programming the untilize init sequence.
 *
 * @tparam block_ct_dim   Width of a single block in tiles.
 * @tparam full_ct_dim    Width of the full input in tiles (defaults to block_ct_dim).
 * @tparam diagonal       Diagonal packing flag (unused on Blackhole; must be false).
 * @tparam narrow_row     Whether the input rows are narrow.
 * @tparam row_num_datums Number of datums per row.
 * @tparam dense          Pack two 2-face tiles into a single 4-face region.
 * @param  output         Output circular buffer / operand index.
 */
template <
    std::uint32_t block_ct_dim = 8,
    std::uint32_t full_ct_dim = block_ct_dim,
    bool diagonal = false /* unused */,
    bool narrow_row = false,
    std::uint32_t row_num_datums = TILE_C_DIM,
    bool dense = false,
    bool pace_32bit_rows = true>
inline void llk_pack_untilize_init(std::uint32_t output) {
    static_assert(diagonal == false, "Diagonal is only supported on WH");
    const std::uint32_t output_id = get_output_id(output);
    const std::uint32_t face_r_dim = get_output_face_r_dim(output_id);
    const std::uint32_t num_faces = get_output_num_faces(output_id);

    llk_pack_untilize_init_impl<block_ct_dim, full_ct_dim, narrow_row, row_num_datums, dense, pace_32bit_rows>(
        pack_src_format[output_id], pack_dst_format[output_id], face_r_dim, num_faces);
}

/**
 * Tear down the packer untilize configuration so a subsequent operation can
 * reprogram the packer. The source format is read from the output CB metadata.
 *
 * @param output Output circular buffer / operand index.
 */
inline void llk_pack_untilize_uninit(std::uint32_t output) {
    const std::uint32_t output_id = get_output_id(output);
    llk_pack_untilize_uninit_impl(pack_src_format[output_id]);
}

/**
 * Pack an untilized block of tiles from the destination register into the output CB.
 *
 * Iterates over block_rt_dim tile rows, computing the packer write address from the
 * output CB fifo state for each row. Face geometry (face_r_dim, num_faces) is derived
 * from the output CB metadata.
 *
 * @tparam block_ct_dim       Width of a single block in tiles.
 * @tparam full_ct_dim        Width of the full input in tiles (defaults to block_ct_dim).
 * @tparam diagonal           Diagonal packing flag (unused on Blackhole; must be false).
 * @tparam narrow_row         Whether the input rows are narrow.
 * @tparam row_num_datums     Number of datums per row (unused on Blackhole).
 * @tparam tile_dst_ct_offset Compile-time column offset of the tile in the destination register.
 * @tparam dense              Pack two 2-face tiles into a single 4-face region.
 * @param  block_rt_dim       Height of the block in tiles (number of rows to pack).
 * @param  output             Output circular buffer / operand index.
 * @param  block_c_index      Block column index (used when full_ct_dim > block_ct_dim).
 * @param  tile_dst_rt_offset Runtime row offset of the tile in the destination register.
 */
template <
    std::uint32_t block_ct_dim = 8,
    std::uint32_t full_ct_dim = block_ct_dim,
    bool diagonal = false /* unused */,
    bool narrow_row = false,
    std::uint32_t row_num_datums = TILE_C_DIM /* unused */,
    std::uint32_t tile_dst_ct_offset = 0,
    bool dense = false>
inline void llk_pack_untilize(
    std::uint32_t block_rt_dim,
    std::uint32_t output,
    const std::uint32_t block_c_index = 0,
    const std::uint32_t tile_dst_rt_offset = 0) {
    static_assert(diagonal == false, "Diagonal is only supported on WH");
    // The block index addresses even blocks; a block at any other tile column takes llk_pack_untilize_at_col.
    static_assert(full_ct_dim % block_ct_dim == 0, "full_ct_dim must be divisible by block_ct_dim");
    const std::uint32_t output_id = get_output_id(output);
    const std::uint32_t face_r_dim = get_output_face_r_dim(output_id);
    const std::uint32_t num_faces = get_output_num_faces(output_id);

    llk_pack_untilize_impl<block_ct_dim, full_ct_dim, narrow_row, row_num_datums, tile_dst_ct_offset, dense>(
        block_rt_dim,
        get_local_cb_interface(output_id).fifo_wr_ptr - 1,
        pack_src_format[output_id],
        pack_dst_format[output_id],
        full_ct_dim * get_local_cb_interface(output_id).fifo_page_size,
        face_r_dim,
        num_faces,
        block_c_index,
        tile_dst_rt_offset);
}

// A block that starts at tile column first_col of the output row, for a row split into blocks of different widths.
// The pack untilize init must be for the same block_ct_dim and full_ct_dim.
template <std::uint32_t block_ct_dim, std::uint32_t full_ct_dim>
inline void llk_pack_untilize_at_col(std::uint32_t output, const std::uint32_t first_col) {
    const std::uint32_t output_id = get_output_id(output);
    const std::uint32_t face_r_dim = get_output_face_r_dim(output_id);
    const std::uint32_t num_faces = get_output_num_faces(output_id);
    const std::uint32_t col_offset =
        SCALE_DATUM_SIZE(
            pack_dst_format[output_id], first_col * ((num_faces > 2) ? num_faces / 2 : num_faces) * FACE_C_DIM) /
        16;

    llk_pack_untilize_impl<block_ct_dim, full_ct_dim>(
        1 /* block_rt_dim */,
        get_local_cb_interface(output_id).fifo_wr_ptr - 1 + col_offset,
        pack_src_format[output_id],
        pack_dst_format[output_id],
        full_ct_dim * get_local_cb_interface(output_id).fifo_page_size,
        face_r_dim,
        num_faces,
        0 /* block_c_index */,
        0 /* tile_dst_rt_offset */);
}
