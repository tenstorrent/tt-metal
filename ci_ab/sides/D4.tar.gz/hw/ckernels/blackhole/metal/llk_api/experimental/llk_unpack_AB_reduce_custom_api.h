// SPDX-FileCopyrightText: © 2025 Tenstorrent USA, Inc.
//
// SPDX-License-Identifier: Apache-2.0

#pragma once
#include <cstdint>
#include "ckernel.h"
#include "ckernel_defs.h"
#include "ckernel_globals.h"
#include "ckernel_template.h"
#include "cunpack_common.h"
#include "llk_defs.h"
#include "llk_io.h"
#include "llk_operands.h"
#include "llk_param_structs.h"
#include "experimental/llk_unpack_AB_reduce_custom.h"
#include "llk_unpack_common.h"
#include "sanitizer/api.h"

using namespace ckernel;
using namespace ckernel::unpacker;

/*************************************************************************
 * LLK UNPACK AB REDUCE CUSTOM - Specialized reduce_max_row operations
 *************************************************************************/

/**
 * Initializes unpacker configuration for block-based reduce_max_row operations.
 * Sets up tile dimensions and saves unpacker state that will be modified during operation.
 *
 * This function works with the following assumptions:
 * - Scaler values are 1.0 and are contained inside F0 of the scaler tile
 * - The scaler doesn't change for the duration of the whole block operation
 * - Operand and scaler data format is bfloat16_b
 * - Operand tile is num_faces faces (4 for a 32x32 tile, 2 for a 16x32 tiny tile)
 * - Can work on both 16-bit or 32-bit DEST register modes based on is_fp32_dest_acc_en flag
 * - Does only MAX pool on ROW dimension
 *
 * respect_trigger parameter enables an optimization used in SDPA (Scaled Dot-Product Attention)
 * kernels to increase utilization. When enabled, it splits the unpack MOP (Macro Operation) into two halves
 * with hardware semaphore synchronization, allowing better pipelining and avoiding a more costly circular buffer
 * synchronization. The same value has to be passed to init, execute and uninit functions for this to take effect.
 *
 * num_faces selects the operand tile geometry (4 for a 32x32 tile, 2 for a 16x32 tiny tile).
 *
 * This function should NOT be used as a substitute for native llk_unpack_AB_reduce_init LLK.
 * Use the standard llk_unpack_AB_reduce_init<ReduceDim::REDUCE_ROW> for general-purpose reduction.
 */
template <std::uint32_t block_ct_dim, bool is_fp32_dest_acc_en, bool respect_trigger = false>
inline void llk_unpack_AB_reduce_block_max_row_init(const ckernel::TensorShape& tensor_shape) {
    SAN_HOOK(unsupported());
    _llk_unpack_AB_reduce_block_max_row_init_<block_ct_dim, is_fp32_dest_acc_en, respect_trigger>(tensor_shape);
}

/**
 * Performs unpacking for block-based reduce_max_row operation across multiple tiles.
 *
 * This function works with the following assumptions:
 * - Scaler values are 1.0 and are contained inside F0 of the scaler tile
 * - The scaler doesn't change for the duration of the whole block operation
 * - Operand and scaler data format is bfloat16_b
 * - Operand tile size is 32x32
 * - Can work on both 16-bit or 32-bit DEST register modes based on is_fp32_dest_acc_en flag
 * - Does only MAX pool on ROW dimension
 *
 * respect_trigger parameter enables an optimization used in SDPA (Scaled Dot-Product Attention)
 * kernels to increase utilization. When enabled, it splits the unpack MOP (Macro Operation) into two halves
 * with hardware semaphore synchronization, allowing better pipelining and avoiding a more costly circular buffer
 * synchronization. The same value has to be passed to init, execute and uninit functions for this to take effect.
 *
 * This function should NOT be used as a substitute for native llk_unpack_AB LLK.
 * Use the standard llk_unpack_AB<BroadcastType::NONE> in a loop for general-purpose operations.
 */
template <std::uint32_t block_ct_dim, bool respect_trigger = false>
inline void llk_unpack_AB_reduce_block_max_row(
    const std::uint32_t operandA, const std::uint32_t operandB, const std::uint32_t row_start_index) {
    SAN_HOOK(unsupported());
    std::uint32_t operandA_id = get_operand_id(operandA);
    std::uint32_t operandB_id = get_operand_id(operandB);
    std::uint32_t base_address_a = get_local_cb_interface(operandA_id).fifo_rd_ptr - 1;
    std::uint32_t offset_address_a = get_local_cb_interface(operandA_id).fifo_page_size * row_start_index;
    std::uint32_t address_a = base_address_a + offset_address_a;
    std::uint32_t base_address_b = get_local_cb_interface(operandB_id).fifo_rd_ptr - 1;

    LLK_ASSERT(
        cb_access_within_bounds(operandA_id, row_start_index, block_ct_dim), "Indexed tile read exceeds CB boundary");

    _llk_unpack_AB_reduce_block_max_row_<respect_trigger>(address_a, base_address_b);
}

/**
 * Uninitializes block-based reduce_max_row unpacker operation.
 * Restores the unpacker state that was saved during initialization.
 *
 * This function works with the following assumptions:
 * - Scaler values are 1.0 and are contained inside F0 of the scaler tile
 * - The scaler doesn't change for the duration of the whole block operation
 * - Operand and scaler data format is bfloat16_b
 * - Operand tile size is 32x32
 * - Can work on both 16-bit or 32-bit DEST register modes based on is_fp32_dest_acc_en flag
 * - Does only MAX pool on ROW dimension
 *
 * respect_trigger parameter enables an optimization used in SDPA (Scaled Dot-Product Attention)
 * kernels to increase utilization. When enabled, it splits the unpack MOP (Macro Operation) into two halves
 * with hardware semaphore synchronization, allowing better pipelining and avoiding a more costly circular buffer
 * synchronization. The same value has to be passed to init, execute and uninit functions for this to take effect.
 *
 * This function should NOT be used as a substitute for native llk_unpack_AB_reduce_init LLK.
 * Use standard LLK cleanup procedures for general-purpose operations.
 */
template <bool respect_trigger = false>
inline void llk_unpack_AB_reduce_block_max_row_uninit() {
    SAN_HOOK(unsupported());
    _llk_unpack_AB_reduce_block_max_row_uninit_<respect_trigger>();
}
