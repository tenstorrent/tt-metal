// SPDX-FileCopyrightText: © 2026 Tenstorrent USA, Inc.
//
// SPDX-License-Identifier: Apache-2.0

#pragma once
#include <cstdint>
#include "llk_math_common_api.h"
#include "experimental/llk_math_reduce_custom.h"
#include "experimental/llk_math_reduce_runtime_custom.h"
#include "sanitizer/api.h"

/*************************************************************************
 * LLK REDUCE CUSTOM - Specialized reduce_max_row operations
 *************************************************************************/

// Block-based reduce row max functions
/**
 * Initializes block-based reduce_max_row operation for processing multiple tiles.
 *
 * This function works with the following assumptions:
 * - Scaler values are 1.0 and are contained inside F0 of the scaler tile
 * - The scaler doesn't change for the duration of the whole block operation
 * - Operand and scaler data format is bfloat16_b
 * - Operand tile size is 32x32
 * - Can work on both 16-bit or 32-bit DEST register modes based on is_fp32_dest_acc_en flag
 * - Does only MAX pool on ROW dimension
 *
 * This function should NOT be used as a substitute for the native llk_math_reduce_init LLK.
 * Use the standard llk_math_reduce_init<PoolType::MAX, ReduceDim::REDUCE_ROW>() with multiple
 * llk_math_reduce() calls in a loop for general-purpose block reduction.
 */
template <bool is_fp32_dest_acc_en>
inline void llk_math_reduce_block_max_row_init_runtime(
    std::uint32_t block_ct_dim, const ckernel::TensorShape& tensor_shape) {
    SAN_HOOK(unsupported());
    _llk_math_reduce_block_max_row_init_runtime_<is_fp32_dest_acc_en>(block_ct_dim, tensor_shape);
}

template <bool is_fp32_dest_acc_en>
inline void llk_math_reduce_block_max_row_mop_config_runtime(
    std::uint32_t block_ct_dim, const ckernel::TensorShape& tensor_shape) {
    SAN_HOOK(unsupported());
    _llk_math_reduce_block_max_row_mop_config_runtime_<is_fp32_dest_acc_en>(block_ct_dim, tensor_shape);
}

/**
 * Performs block-based reduce_max_row operation across multiple tiles in the width dimension.
 *
 * This function works with the following assumptions:
 * - Scaler values are 1.0 and are contained inside F0 of the scaler tile
 * - The scaler doesn't change for the duration of the whole block operation
 * - Operand and scaler data format is bfloat16_b
 * - Operand tile size is 32x32
 * - Can work on both 16-bit or 32-bit DEST register modes based on is_fp32_dest_acc_en flag
 * - Does only MAX pool on ROW dimension
 *
 * This function should NOT be used as a substitute for the native llk_math_reduce LLK.
 * Use the standard llk_math_reduce<PoolType::MAX, ReduceDim::REDUCE_ROW>() in a loop
 * for general-purpose block reduction across multiple tiles.
 */
template <bool is_fp32_dest_acc_en>
inline void llk_math_reduce_block_max_row_runtime(
    const std::uint32_t dst_index, const ckernel::TensorShape tensor_shape) {
    SAN_HOOK(unsupported());
    LLK_ASSERT((dst_index < get_dest_max_tiles_rt<DST_SYNC_MODE, DstTileShape::Tile32x32>()), "");

    _llk_math_reduce_block_max_row_runtime_<is_fp32_dest_acc_en>(dst_index, tensor_shape);
}

/**
 * Reinitializes the block-based reduce_max_row operation after a matmul.
 *
 * This LLK API function is used only to re-initialize the address modifiers after a
 * matmul operation in an SDPA inner loop. Please don't use this function as a substitute for
 * the native llk_math_reduce_block_max_row_init LLK. This function is highly specialized
 * for a certain use case and the LLK team does not guarantee any degree of generality.
 */
inline void llk_math_reduce_block_max_row_reinit_runtime() {
    SAN_HOOK(unsupported());
    _llk_math_reduce_block_max_row_reinit_runtime_();
}

/**
 * Short reinitialization for block-based reduce_max_row operation after a matmul.
 * Reprograms address modifiers and MOP configuration with runtime block_ct_dim.
 *
 * This LLK API function is used only to re-initialize the address modifiers and MOP
 * after a matmul operation in an SDPA inner loop.
 */
template <bool is_fp32_dest_acc_en>
inline void llk_math_reduce_block_max_row_reinit_short_runtime(
    std::uint32_t block_ct_dim, const ckernel::TensorShape& tensor_shape) {
    SAN_HOOK(unsupported());
    _llk_math_reduce_block_max_row_reinit_short_runtime_<is_fp32_dest_acc_en>(block_ct_dim, tensor_shape);
}

/**
 * Minimal reinitialization for block-based reduce_max_row operation.
 * Only reconfigures ADDR_MOD_1, ADDR_MOD_2, and ADDR_MOD_6 (preserves ADDR_MOD_3).
 */
inline void llk_math_reduce_block_max_row_reinit_minimal_runtime() {
    SAN_HOOK(unsupported());
    _llk_math_reduce_block_max_row_reinit_minimal_runtime_();
}
