// SPDX-FileCopyrightText: © 2026 Tenstorrent USA, Inc.
// SPDX-FileCopyrightText: © 2025 Jason Davies <jason@jasondavies.com>
//
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include "ckernel.h"
#include "ckernel_defs.h"
#include "cmath_common.h"
#include "sfpi.h"

using namespace sfpi;

namespace ckernel {
namespace sfpu {

// See: Kokosiński, Z., Gepner, P., Moroz, L. et al.
// Fast and accurate approximation algorithms for computing floating point square root. Numerical Algorithms (2024).
// https://doi.org/10.1007/s11075-024-01932-7

// x's bits with the sign shifted out: `_bits_without_sign_(x) != 0` is a magnitude test that
// treats -0.0 and +0.0 alike, which a bare `as<vInt>(x) != 0` does not.
sfpi_inline sfpi::vInt _bits_without_sign_(const sfpi::vFloat x) { return sfpi::as<sfpi::vInt>(x) << 1; }

// Computes the square root or reciprocal square root of a positive floating point value x.
template <bool APPROXIMATE = false, bool RECIPROCAL = false, bool FAST_APPROX = false>
sfpi_inline sfpi::vFloat _calculate_sqrt_body_(const sfpi::vFloat x) {
    sfpi::vInt i = sfpi::as<sfpi::vInt>(sfpi::as<sfpi::vUInt>(x) >> 1);
    sfpi::vFloat y = sfpi::as<sfpi::vFloat>(sfpi::vConstIntPrgm0 - i);

    if constexpr (APPROXIMATE) {
        // Algorithm SQRT_10-bits, with modifications for reciprocal.
        sfpi::vFloat c = x * y;
        sfpi::vFloat negative_y = -y;
        sfpi::vFloat infinity = sfpi::sFloat16b(std::numeric_limits<float>::infinity());
        sfpi::vInt infinity_bits = sfpi::as<sfpi::vInt>(infinity);
        sfpi::vFloat t = sfpi::vConstFloatPrgm1 + negative_y * c;
        if constexpr (RECIPROCAL) {
            sfpi::vInt x_bits = sfpi::as<sfpi::vInt>(x);
            sfpi::vInt infinity_minus_x_bits = infinity_bits - x_bits;
            // If x != inf and x has a non-zero magnitude.
            v_if(infinity_minus_x_bits != 0 && _bits_without_sign_(x) != 0) {
                y = y * t;
                if constexpr (!FAST_APPROX) {
                    // This region already excludes +/-0 and +inf, so a bare sign test is enough.
                    v_if(x < 0.0f) {
                        y = std::numeric_limits<float>::quiet_NaN();  // nan for fp32, inf for bf16
                    }
                    v_endif;
                }
            }
            // Otherwise x = +/-0 gives +/-inf (the subtraction carries x's sign), x = inf gives 0.
            v_else { y = sfpi::as<sfpi::vFloat>(infinity_minus_x_bits); }
            v_endif;
        } else {
            y = c;
            // If x != inf.  Otherwise, y = inf, since c = inf.
            v_if(sfpi::as<sfpi::vInt>(x) != infinity_bits) { y = y * t; }
            v_endif;
        }
    } else {
        // Algorithm SQRT_23-bits, with modifications for reciprocal.
        sfpi::vFloat xy = x * y;
        sfpi::vFloat negative_y = -y;
        sfpi::vFloat c = negative_y * xy;
        sfpi::vFloat infinity = sfpi::sFloat16b(std::numeric_limits<float>::infinity());
        sfpi::vInt infinity_bits = sfpi::as<sfpi::vInt>(infinity);
        y = y * (sfpi::vConstFloatPrgm1 + c * (sfpi::vConstFloatPrgm2 + c));
        xy = x * y;
        negative_y = -y;
        sfpi::vFloat one_minus_xyy = 1.0f + (negative_y * xy);

        if constexpr (RECIPROCAL) {
            sfpi::vFloat half_y = sfpi::addexp(y, -1);
            sfpi::vInt x_bits = sfpi::as<sfpi::vInt>(x);
            sfpi::vInt infinity_minus_x_bits = infinity_bits - x_bits;
            // If x != inf and x has a non-zero magnitude.
            v_if(infinity_minus_x_bits != 0 && _bits_without_sign_(x) != 0) {
                y = one_minus_xyy * half_y + y;
                if constexpr (!FAST_APPROX) {
                    // This region already excludes +/-0 and +inf, so a bare sign test is enough.
                    v_if(x < 0.0f) {
                        y = std::numeric_limits<float>::quiet_NaN();  // nan for fp32, inf for bf16
                    }
                    v_endif;
                }
            }
            // Otherwise x = +/-0 gives +/-inf (the subtraction carries x's sign), x = inf gives 0.
            v_else { y = sfpi::as<sfpi::vFloat>(infinity_minus_x_bits); }
            v_endif;
        } else {
            sfpi::vFloat half_xy = 0.5f * xy;
            // If x == inf, we need to skip to avoid y = inf - inf = nan; y will already be inf.
            // Keep this as `<`, not `!=`: it skips positive NaN, which would otherwise run the
            // step and come back sign-flipped (a bf16 pack then makes that -inf). Negative NaN
            // does run the step -- the compare wraps -- but the clamp below rewrites it.
            v_if(sfpi::as<sfpi::vInt>(x) < infinity_bits) { y = one_minus_xyy * half_xy + xy; }
            v_endif;
        }
    }

    // All edge handling is gated on !FAST_APPROX, as the negative clamp alone was before: the
    // fast path trades every edge guard for speed, so there a negative is unclamped and
    // sqrt(-0) is +0. Everything below is a FAST_APPROX=false claim.
    if constexpr (!FAST_APPROX) {
        // `x < 0.0f` is a sign-bit test, so it claims -0.0 as well; zero magnitudes are kept
        // out of it and answered separately.
        if constexpr (!RECIPROCAL) {
            // rsqrt's clamp is inside the refinement guard above, where the predicate already
            // excludes +/-0 and +inf.
            // sqrt(+/-0) = +/-0: return x, because the refinement cannot produce a signed zero.
            v_if(_bits_without_sign_(x) == 0) { y = x; }
            v_elseif(x < 0.0f) {
                y = std::numeric_limits<float>::quiet_NaN();  // returns nan for fp32 and inf for bf16
            }
            v_endif;
        }
    }

    return y;
}

template <bool APPROXIMATION_MODE, int ITERATIONS, bool fp32_dest_acc_en, bool RECIPROCAL, bool FAST_APPROX>
inline void _calculate_sqrt_internal_() {
#pragma GCC unroll 8
    for (int d = 0; d < ITERATIONS; d++) {
        sfpi::vFloat tmp = _calculate_sqrt_body_<APPROXIMATION_MODE, RECIPROCAL, FAST_APPROX>(sfpi::dst_reg[0]);
        if constexpr (!fp32_dest_acc_en) {
            tmp = sfpi::convert<sfpi::vFloat16b>(tmp, sfpi::RoundMode::Nearest);
        }
        sfpi::dst_reg[0] = tmp;
        sfpi::dst_reg++;
    }
}

template <bool APPROXIMATION_MODE, int ITERATIONS = 8, bool fp32_dest_acc_en, bool FAST_APPROX>
inline void calculate_sqrt() {
    _calculate_sqrt_internal_<APPROXIMATION_MODE, ITERATIONS, fp32_dest_acc_en, false, FAST_APPROX>();
}

template <bool APPROXIMATION_MODE>
void sqrt_init() {
    math::reset_counters(p_setrwc::SET_ABD_F);
    if constexpr (APPROXIMATION_MODE) {
        sfpi::vConstIntPrgm0 = 0x5f0b3892;
        sfpi::vConstFloatPrgm1 = 1.89099014875f;
    } else {
        sfpi::vConstIntPrgm0 = 0x5f1110a0;
        sfpi::vConstFloatPrgm1 = 2.2825186f;
        sfpi::vConstFloatPrgm2 = 2.2533049f;
    }
}

}  // namespace sfpu
}  // namespace ckernel
