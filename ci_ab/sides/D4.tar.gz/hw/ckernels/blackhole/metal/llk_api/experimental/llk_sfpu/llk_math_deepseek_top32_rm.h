// SPDX-FileCopyrightText: © 2025 Tenstorrent AI ULC
//
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include "llk_math_eltwise_unary_sfpu_init.h"
#include "llk_math_eltwise_unary_sfpu_params.h"
#include "sfpu/experimental/ckernel_sfpu_deepseek_top32_rm.h"
#include "sanitizer/api.h"

namespace ckernel {

template <bool APPROXIMATE>
inline void llk_math_deepseek_top32_rm_init() {
    SAN_HOOK(unsupported());
    llk_math_eltwise_unary_sfpu_init<SfpuType::unused>(sfpu::_top32_rm_init_);
}

template <bool APPROXIMATE, bool is_fp32_dest_acc_en>
inline void llk_math_deepseek_top32_rm_local_sort(
    uint dst_index, int idir, VectorMode vector_mode = VectorMode::RC_custom) {
    SAN_HOOK(unsupported());
    _llk_math_eltwise_unary_sfpu_params_(
        ckernel::sfpu::_bitonic_top32_phases_steps_<APPROXIMATE, is_fp32_dest_acc_en>, dst_index, vector_mode, idir);
}

template <bool APPROXIMATE, bool is_fp32_dest_acc_en, bool idir = false>
inline void llk_math_deepseek_top32_rm_merge(
    uint dst_index, bool across_tiles, VectorMode vector_mode = VectorMode::RC_custom) {
    SAN_HOOK(unsupported());
    _llk_math_eltwise_unary_sfpu_params_(
        ckernel::sfpu::_bitonic_top32_merge_<APPROXIMATE, is_fp32_dest_acc_en, idir>,
        dst_index,
        vector_mode,
        across_tiles);
}

template <bool APPROXIMATE, bool is_fp32_dest_acc_en>
inline void llk_math_deepseek_top32_rm_rebuild(
    uint dst_index, bool idir, bool skip_second, VectorMode vector_mode = VectorMode::RC_custom) {
    SAN_HOOK(unsupported());
    _llk_math_eltwise_unary_sfpu_params_(
        ckernel::sfpu::_bitonic_top32_rebuild_<APPROXIMATE, is_fp32_dest_acc_en>,
        dst_index,
        vector_mode,
        idir,
        skip_second);
}

template <bool APPROXIMATE, bool is_fp32_dest_acc_en, bool top_min>
inline void llk_math_deepseek_top32_of_1024_rm_pre_sorted_prep(
    uint dst_index, VectorMode vector_mode = VectorMode::RC_custom) {
    SAN_HOOK(unsupported());
    _llk_math_eltwise_unary_sfpu_params_(
        ckernel::sfpu::_bitonic_top32_of_1024_rm_pre_sorted_prep_<APPROXIMATE, is_fp32_dest_acc_en, top_min>,
        dst_index,
        vector_mode,
        dst_index);
}

template <bool APPROXIMATE, bool is_fp32_dest_acc_en>
inline void llk_math_deepseek_top32_of_1024_rm_pre_sorted_combine(
    uint dst_index, VectorMode vector_mode = VectorMode::RC_custom) {
    SAN_HOOK(unsupported());
    _llk_math_eltwise_unary_sfpu_params_(
        ckernel::sfpu::_bitonic_top32_of_1024_rm_pre_sorted_combine_<APPROXIMATE, is_fp32_dest_acc_en>,
        dst_index,
        vector_mode,
        dst_index);
}

template <bool APPROXIMATE, bool is_fp32_dest_acc_en>
inline void llk_math_deepseek_top32_of_1024_rm_pre_sorted_final(
    uint dst_index, VectorMode vector_mode = VectorMode::RC_custom) {
    SAN_HOOK(unsupported());
    _llk_math_eltwise_unary_sfpu_params_(
        ckernel::sfpu::_bitonic_top32_of_1024_rm_pre_sorted_final_<APPROXIMATE, is_fp32_dest_acc_en>,
        dst_index,
        vector_mode,
        dst_index);
}

}  // namespace ckernel
