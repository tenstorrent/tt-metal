// SPDX-FileCopyrightText: © 2026 Tenstorrent USA, Inc.
//
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include <cstdint>

#include "ckernel.h"
#include "ckernel_defs.h"
#include "cmath_common.h"
#include "sfpi.h"

using namespace sfpi;

namespace ckernel {
namespace sfpu {

inline void sign_init() { math::reset_counters(p_setrwc::SET_ABD_F); }

template <bool APPROXIMATION_MODE, int ITERATIONS = 8>
inline void calculate_sign(const uint /*exponent_size_8*/) {
// All params are in FP16 format
#pragma GCC unroll 0
    for (int d = 0; d < ITERATIONS; d++) {
        sfpi::vFloat v = sfpi::dst_reg[0];
        // copysgn stamps v's sign bit onto 1.0, which is exactly the v < 0 arm. Only the
        // zero case is left for a branch, so the v_elseif and its predicate-complement
        // disappear.
        sfpi::vFloat res = sfpi::copysgn(sfpi::vFloat(1.0f), v);
        // SFPSETCC is unspecified for -0.0 (VectorUnit.md), so a bare compare can miss it.
        v_if(sfpi::abs(v) == 0.0F) { res = 0.0f; }
        v_endif;
        sfpi::dst_reg[0] = res;
        sfpi::dst_reg++;
    }
}

}  // namespace sfpu
}  // namespace ckernel
