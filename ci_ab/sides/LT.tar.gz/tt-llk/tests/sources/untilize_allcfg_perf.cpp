// SPDX-FileCopyrightText: © 2026 Tenstorrent AI ULC
// SPDX-License-Identifier: Apache-2.0
// Local sweep source (not committed): pack_untilize_perf.cpp with every pack untilize knob exposed. UT_* constants and
// dest_sync come from perf_untilize_allcfg.py; UT_HEAD_API selects #59149's wrapper and harness forms (block unpack,
// math DEST clear, release that selects the next half first), as that PR's pack_untilize_perf.cpp does.

#include <algorithm>
#include <cstdint>
#include <cstdio>

#include "ckernel.h"
#include "counters.h"
#include "llk_defs.h"
#include "params.h"
#include "perf.h"
#include "profiler.h"

std::uint32_t unp_cfg_context          = 0;
std::uint32_t pack_sync_tile_dst_ptr   = 0;
std::uint32_t math_sync_tile_dst_index = 0;

static_assert(PERF_RUN_TYPE != PerfRunType::MATH_ISOLATE, "Math isolation not supported for this benchmark");
static_assert(PERF_RUN_TYPE != PerfRunType::UNPACK_ISOLATE, "Unpack isolation not supported for this benchmark");

// DEST tiles one section holds (math tiles: 4-face slots)
static constexpr std::uint32_t UT_SECTION = BLOCK_CT_DIM * UT_BLOCK_RT;
static constexpr std::uint32_t UT_CAP     = (is_fp32_dest_acc_en ? 4 : 8) * (dest_sync == ckernel::DstSync::SyncFull ? 2 : 1);
static_assert(UT_SECTION + UT_CT_OFF + UT_RT_OFF <= UT_CAP, "section must fit in DEST");
static_assert(FULL_CT_DIM % BLOCK_CT_DIM == 0, "FULL_CT_DIM must be divisible by BLOCK_CT_DIM");
static constexpr std::uint32_t UT_PK_BLOCK = UT_DENSE ? 2 * BLOCK_CT_DIM : BLOCK_CT_DIM;
static constexpr std::uint32_t UT_PK_FULL  = UT_DENSE ? 2 * FULL_CT_DIM : FULL_CT_DIM;
static constexpr std::uint32_t UT_PK_FACES = UT_DENSE ? 2 : UT_NUM_FACES;
static constexpr std::uint32_t UT_IN_FACES = UT_DENSE ? 4 : UT_NUM_FACES;
static constexpr bool UT_NARROW            = UT_ROW_DATUMS < 32;
static constexpr bool UT_STD_TILE          = UT_IN_FACES == 4 && UT_FACE_R_DIM == 16;
// Arms (scratch): UT_BLK_ALL 1 puts tiny and dense tiles through the block unpack too; UT_BLK_MIN is the largest block width kept per tile.
#ifndef UT_BLK_ALL
#define UT_BLK_ALL 0
#endif
#ifndef UT_BLK_MIN
#define UT_BLK_MIN 2
#endif

#ifdef LLK_TRISC_UNPACK

#include "llk_unpack_A.h"
#include "llk_unpack_common.h"

void run_kernel(RUNTIME_PARAMETERS params)
{
#if defined(RUNTIME_FORMATS) && !defined(SPEED_OF_LIGHT)
    const FormatConfig& formats = params.formats;
#endif
#ifndef SPEED_OF_LIGHT
    const std::uint32_t LOOP_FACTOR = params.LOOP_FACTOR;
    const std::uint32_t TILE_CNT    = params.TILE_CNT;
#endif
    {
        START_PERF_MEASURE("INIT")
        _llk_unpack_A_init_<BroadcastType::NONE, false, EltwiseBinaryReuseDestType::NONE, unpack_to_dest>(
            0, 0, ckernel::make_tensor_shape_from_legacy(UT_FACE_R_DIM, UT_IN_FACES), formats.unpack_A_src, formats.unpack_A_dst);
        _llk_unpack_hw_configure_<is_fp32_dest_acc_en>(
            formats.unpack_A_src, formats.unpack_B_src, formats.unpack_A_dst, formats.unpack_B_dst, UT_FACE_R_DIM, UT_FACE_R_DIM, UT_IN_FACES, UT_IN_FACES);
        PROFILER_SYNC();
    }
    {
        START_PERF_MEASURE("TILE_LOOP")
        if (PERF_RUN_TYPE == PerfRunType::PACK_ISOLATE)
        {
            return;
        }
        for (std::uint32_t loop = 0; loop < LOOP_FACTOR; loop++)
        {
#if defined(ARCH_BLACKHOLE) && defined(UT_HEAD_API)
            if constexpr (BLOCK_CT_DIM >= 2 && unpack_to_dest && is_fp32_dest_acc_en && UT_STD_TILE)
            {
                const std::uint32_t stride_16B = PERF_ADDRESS(PERF_INPUT_A, 1) - PERF_ADDRESS(PERF_INPUT_A, 0);
                for (std::uint32_t i = 0; i < TILE_CNT; i += BLOCK_CT_DIM)
                {
                    _llk_unpack_A_block_<BroadcastType::NONE, false, EltwiseBinaryReuseDestType::NONE, true, is_fp32_dest_acc_en>(
                        PERF_ADDRESS(PERF_INPUT_A, i), BLOCK_CT_DIM, stride_16B, formats.unpack_A_src, formats.unpack_A_dst);
                }
                continue;
            }
#endif
#if defined(ARCH_BLACKHOLE) && defined(UT_HEAD_API)
            if constexpr (BLOCK_CT_DIM > UT_BLK_MIN && !unpack_to_dest && (UT_STD_TILE || UT_BLK_ALL))
            {
                const bool dense = !IS_BFP_FORMAT(formats.unpack_A_src);
                const std::uint32_t stride_16B =
                    dense ? UT_IN_FACES * UT_FACE_R_DIM * datum_size_in_bytes(formats.unpack_A_src) : PERF_ADDRESS(PERF_INPUT_A, 1) - PERF_ADDRESS(PERF_INPUT_A, 0);
                for (std::uint32_t i = 0; i < TILE_CNT; i += BLOCK_CT_DIM)
                {
                    if (dense)
                    {
                        _llk_unpack_A_block_<BroadcastType::NONE, false, EltwiseBinaryReuseDestType::NONE, false, is_fp32_dest_acc_en, true>(
                            PERF_ADDRESS(PERF_INPUT_A, i), BLOCK_CT_DIM, stride_16B, formats.unpack_A_src, formats.unpack_A_dst, UT_IN_FACES, UT_FACE_R_DIM);
                    }
                    else
                    {
                        _llk_unpack_A_block_<BroadcastType::NONE, false, EltwiseBinaryReuseDestType::NONE, false, is_fp32_dest_acc_en>(
                            PERF_ADDRESS(PERF_INPUT_A, i), BLOCK_CT_DIM, stride_16B, formats.unpack_A_src, formats.unpack_A_dst, UT_IN_FACES, UT_FACE_R_DIM);
                    }
                }
                continue;
            }
#endif
            for (std::uint32_t i = 0; i < TILE_CNT; ++i)
            {
                _llk_unpack_A_<BroadcastType::NONE, false, EltwiseBinaryReuseDestType::NONE, unpack_to_dest>(
                    PERF_ADDRESS(PERF_INPUT_A, i), formats.unpack_A_src, formats.unpack_A_dst);
            }
        }
        PROFILER_SYNC();
    }
}

#endif

#ifdef LLK_TRISC_MATH

#include "llk_lib_math_wrappers.h"

using namespace ckernel;

void run_kernel(RUNTIME_PARAMETERS params)
{
#if defined(RUNTIME_FORMATS) && !defined(SPEED_OF_LIGHT)
    const FormatConfig& formats = params.formats;
#endif
#ifndef SPEED_OF_LIGHT
    const std::uint32_t LOOP_FACTOR = params.LOOP_FACTOR;
    const std::uint32_t TILE_CNT    = params.TILE_CNT;
#endif
    constexpr bool is_int_fpu_en = false;
    {
        START_PERF_MEASURE("INIT")
        _llk_math_eltwise_unary_datacopy_init_wrapper_<DataCopyType::A2D, is_fp32_dest_acc_en, BroadcastType::NONE, is_int_fpu_en, PackMode::Default>(
            UT_IN_FACES, formats.math);
        _llk_math_pack_sync_init_<dest_sync, is_fp32_dest_acc_en>();
        _llk_math_hw_configure_<is_fp32_dest_acc_en>(formats.math, formats.math);
        _llk_math_reconfig_remap_wrapper_(true);
        PROFILER_SYNC();
    }
    {
        START_PERF_MEASURE("TILE_LOOP")
        if constexpr (PERF_RUN_TYPE == PerfRunType::PACK_ISOLATE)
        {
            return;
        }
        for (std::uint32_t loop = 0; loop < LOOP_FACTOR; loop++)
        {
            for (std::uint32_t s = 0; s < TILE_CNT / UT_SECTION; s++)
            {
                _llk_math_wait_for_dest_available_<dest_sync>();
#if defined(ARCH_BLACKHOLE) && defined(UT_HEAD_API)
                if constexpr (BLOCK_CT_DIM >= 2 && unpack_to_dest && is_fp32_dest_acc_en && UT_STD_TILE)
                {
                    for (std::uint32_t t = 0; t < UT_SECTION; t += BLOCK_CT_DIM)
                    {
                        _llk_math_eltwise_unary_datacopy_block_<DataCopyType::A2D, dest_sync, is_fp32_dest_acc_en, BroadcastType::NONE, unpack_to_dest>(
                            t, BLOCK_CT_DIM, formats.math, formats.math);
                    }
                }
                else
#endif
                {
                    for (std::uint32_t t = 0; t < UT_SECTION; t++)
                    {
                        _llk_math_eltwise_unary_datacopy_<DataCopyType::A2D, dest_sync, is_fp32_dest_acc_en, BroadcastType::NONE, unpack_to_dest>(
                            t, formats.math, formats.math);
                    }
                }
#if defined(ARCH_BLACKHOLE) && defined(UT_HEAD_API)
                if constexpr (!unpack_to_dest)
                {
                    _llk_math_clear_dest_section_<dest_sync, is_fp32_dest_acc_en>();
                }
#endif
                _llk_math_dest_section_done_<dest_sync, is_fp32_dest_acc_en>();
            }
        }
        PROFILER_SYNC();
    }
}

#endif

#ifdef LLK_TRISC_PACK

#include "llk_lib_pack_wrappers.h"
#include "llk_pack_common.h"

#ifdef UT_HEAD_API
#define UT_INIT_ARGS UT_PK_BLOCK, UT_PK_FULL, false, UT_NARROW, UT_ROW_DATUMS, UT_DENSE, unpack_to_dest
#define UT_CALL_ARGS UT_PK_BLOCK, UT_PK_FULL, false, UT_NARROW, UT_ROW_DATUMS, UT_CT_OFF, UT_DENSE
#else
#define UT_INIT_ARGS UT_PK_BLOCK, UT_PK_FULL, false, UT_NARROW, UT_ROW_DATUMS, UT_DENSE
#define UT_CALL_ARGS UT_PK_BLOCK, UT_PK_FULL, false, UT_NARROW, UT_ROW_DATUMS, UT_CT_OFF, UT_DENSE
#endif

// production pack_src of a compressed input with a 16-bit DEST is the output family (get_single_pack_src_format), not the compressed format
constexpr bool UT_BFP_IN = UNPACK_A_IN == ckernel::to_underlying(DataFormat::Bfp8_b) || UNPACK_A_IN == ckernel::to_underlying(DataFormat::Bfp4_b) ||
                           UNPACK_A_IN == ckernel::to_underlying(DataFormat::Bfp8);
constexpr std::uint32_t UT_PACK_SRC = (UT_BFP_IN && !is_fp32_dest_acc_en) ? ckernel::to_underlying(DataFormat::Float16_b) : formats.pack_src;

inline void ut_section_done()
{
#if defined(ARCH_BLACKHOLE) && defined(UT_HEAD_API)
    _llk_pack_dest_section_done_<dest_sync, is_fp32_dest_acc_en, unpack_to_dest, true>();
#else
    _llk_pack_dest_section_done_<dest_sync, is_fp32_dest_acc_en>();
#endif
}

void run_kernel(RUNTIME_PARAMETERS params)
{
#if defined(RUNTIME_FORMATS) && !defined(SPEED_OF_LIGHT)
    const FormatConfig& formats = params.formats;
#endif
#ifndef SPEED_OF_LIGHT
    const std::uint32_t LOOP_FACTOR = params.LOOP_FACTOR;
    const std::uint32_t TILE_CNT    = params.TILE_CNT;
#endif
    constexpr bool UNTILIZE = true;
    {
        START_PERF_MEASURE("INIT")
        _llk_pack_hw_configure_wrapper_<is_fp32_dest_acc_en, llk_test_pack_mode_v<UNTILIZE, false>>(
            UT_PACK_SRC, formats.pack_dst, 16 * 16 * 4 /* tile_size */);
        _llk_pack_dest_init_wrapper_<dest_sync, is_fp32_dest_acc_en, llk_test_pack_mode_v<UNTILIZE, false>>();
        _llk_pack_untilize_init_wrapper_<UT_INIT_ARGS>(UT_PACK_SRC, formats.pack_dst, UT_FACE_R_DIM, UT_PK_FACES);
        PROFILER_SYNC();
    }
    {
        START_PERF_MEASURE("TILE_LOOP")
        for (std::uint32_t loop = 0; loop < LOOP_FACTOR; loop++)
        {
            for (std::uint32_t i = 0; i < TILE_CNT; i += UT_SECTION)
            {
                if constexpr (PERF_RUN_TYPE != PerfRunType::PACK_ISOLATE)
                {
                    _llk_packer_wait_for_math_done_();
                }
                for (std::uint32_t r = 0; r < UT_BLOCK_RT; r++)
                {
                    _llk_pack_untilize_wrapper_<UT_CALL_ARGS>(
                        PERF_ADDRESS(PERF_OUTPUT, i + r * BLOCK_CT_DIM), formats.pack_dst, UT_FACE_R_DIM, UT_PK_FACES, UT_RT_OFF + r * BLOCK_CT_DIM);
                }
                if constexpr (PERF_RUN_TYPE != PerfRunType::PACK_ISOLATE)
                {
                    ut_section_done();
                }
            }
        }
        PROFILER_SYNC();
    }
    _llk_pack_untilize_uninit_wrapper_(UT_PACK_SRC, UT_FACE_R_DIM);
}

#endif
