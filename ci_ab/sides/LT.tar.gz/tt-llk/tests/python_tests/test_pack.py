# SPDX-FileCopyrightText: © 2026 Tenstorrent AI ULC
# SPDX-License-Identifier: Apache-2.0
"""Test pack operation with various configurations.

Tests the LLK pack kernel with:
- Different data formats (Float16_b, Float16, Float32, Int32, Bfp8_b)
- Destination accumulation modes
- Variable tile dimensions
- ReLU activation
- Destination sync modes (SyncHalf for double-buffering, SyncFull for single-buffering)
"""

import pytest
import torch
from conftest import skip_for_wormhole
from helpers.chip_architecture import ChipArchitecture, get_chip_architecture
from helpers.constraints import (
    get_valid_dest_accumulation_modes,
    get_valid_dest_indices,
)
from helpers.data_format_inference import infer_data_formats
from helpers.format_config import DataFormat
from helpers.golden_generators import (
    FACES_PER_TILE,
    TILE_DIMENSIONS,
    PackGolden,
    get_golden_generator,
)
from helpers.llk_params import (
    BlocksCalculationAlgorithm,
    DestAccumulation,
    DestSync,
    PackerReluType,
    PerfRunType,
    format_dict,
)
from helpers.param_config import (
    get_num_blocks_and_num_tiles_in_block,
    input_output_formats,
    parametrize,
)
from helpers.perf.core import create_test_or_perf_config
from helpers.stimuli_config import StimuliConfig
from helpers.stimuli_generator import generate_stimuli
from helpers.test_variant_parameters import (
    DEST_INDEX,
    DEST_SYNC,
    LOOP_FACTOR,
    NUM_BLOCKS,
    NUM_FACES,
    NUM_TILES_IN_BLOCK,
    PACK_BLOCK,
    RELU_CONFIG,
    TILE_COUNT,
    TILIZE,
    generate_input_dim,
)
from helpers.utils import passed_test

PACK_FORMATS = input_output_formats(
    [
        DataFormat.Float16_b,
        DataFormat.Float16,
        DataFormat.Float32,
        DataFormat.Int32,
        DataFormat.Bfp8_b,
    ]
)
PACK_RELU_TYPES = [
    PackerReluType.NoRelu,
    PackerReluType.ZeroRelu,
    PackerReluType.MinThresholdRelu,
    PackerReluType.MaxThresholdRelu,
]

# Shared with perf_pack.py so the two sweeps stay aligned.
# dest_index stays a lambda: get_valid_dest_indices also takes all_indices, which
# is not a sweep axis and would fail dependency resolution if passed directly.
PACK_SWEEP = dict(
    formats=PACK_FORMATS,
    dest_acc=get_valid_dest_accumulation_modes,
    input_dimensions=[[32, 32], [64, 64], [32, 64], [64, 32]],
    relu_type=PACK_RELU_TYPES,
    dest_sync=[DestSync.Half, DestSync.Full],
    dest_index=lambda dest_acc, dest_sync, formats, input_dimensions: get_valid_dest_indices(
        dest_sync, dest_acc, formats, input_dimensions
    ),
)


@parametrize(**PACK_SWEEP)
def test_pack(
    formats,
    dest_acc,
    input_dimensions,
    relu_type,
    dest_sync,
    dest_index,
    *,
    is_perf: bool = False,
    perf_report=None,
    run_types=None,
    loop_factor: int = 1,
    pack_block: bool = False,
):
    if (formats.input_format == DataFormat.Int32) ^ (
        formats.output_format == DataFormat.Int32
    ):
        pytest.skip(
            "Pack does not support mixing Int32 with other formats. Check format conversions in packer for more information."
        )

    src_A, tile_cnt_A, src_B, tile_cnt_B = generate_stimuli(
        stimuli_format_A=formats.input_format,
        input_dimensions_A=input_dimensions,
        stimuli_format_B=formats.input_format,
        input_dimensions_B=input_dimensions,
    )

    # Generate golden output
    generate_golden = get_golden_generator(PackGolden)
    golden_tensor = generate_golden(
        src_A,
        formats.output_format,
        input_dimensions=input_dimensions,
    )

    unpack_to_dest = (
        formats.input_format.is_32_bit() and dest_acc == DestAccumulation.Yes
    )
    # To come as close as possible to actual hardware behavior, we infer data formats here
    # and use the inferred pack_src format for ReLU operations.
    data_formats = infer_data_formats(
        input_format=formats.input_format,
        output_format=formats.output_format,
        is_fp32_dest_acc_en=dest_acc,
        unpacking_to_dest=unpack_to_dest,
    )

    # This is a bug in infer_pack_in function for blackhole. Force Float32 intermediate for DestAccumulation.Yes
    # TODO: fix infer_pack_in for blackhole.
    if (
        dest_acc == DestAccumulation.Yes
        and get_chip_architecture() == ChipArchitecture.BLACKHOLE
        and not formats.input_format.is_integer()
    ):
        data_formats.pack_src = DataFormat.Float32

    if data_formats.pack_src.is_integer() and relu_type in [
        PackerReluType.MinThresholdRelu,
        PackerReluType.MaxThresholdRelu,
    ]:
        pytest.skip(
            "Pack source format cannot be an integer format with ReLu Type: "
            + str(relu_type)
        )

    # Perf folds RELU_CONFIG into the ELF under --speed-of-light. Compile-producer
    # replaces PackGolden with zeros, so a threshold from torch.mean(golden) hashes a
    # different variant than compile-consumer (missing unpack.elf / riscv-tt-elf-size).
    tensor_average = (
        0.0
        if is_perf or formats.output_format.is_integer()
        else torch.mean(golden_tensor).item()
    )

    relu_config = PackGolden.generate_relu_config(
        relu_type,
        relu_threshold=tensor_average,  # We use the average value for this.
        intermediate_format=data_formats.pack_src,
    )

    # Perform relu.
    golden_tensor = PackGolden.apply_relu(
        golden_tensor,
        relu_config,
        data_formats.pack_src,
    )

    num_blocks, num_tiles_in_block = get_num_blocks_and_num_tiles_in_block(
        dest_sync,
        dest_acc,
        formats,
        input_dimensions,
        TILE_DIMENSIONS,
        BlocksCalculationAlgorithm.Standard,
    )

    if dest_index != 0:
        num_tiles_in_block = num_tiles_in_block - dest_index
        if num_tiles_in_block <= 0 or tile_cnt_A % num_tiles_in_block != 0:
            pytest.skip(
                f"Dest index {dest_index} is not valid for tile count {tile_cnt_A} and num_tiles_in_block {num_tiles_in_block}."
            )
        num_blocks = tile_cnt_A // num_tiles_in_block

    if is_perf and perf_report is None:
        raise ValueError("perf_report must be provided when is_perf=True")

    if run_types is None:
        run_types = [PerfRunType.L1_TO_L1]

    test_config_kwargs = {
        "test_name": "sources/pack_test.cpp",
        "formats": formats,
        "templates": [
            generate_input_dim(input_dimensions, input_dimensions),
            TILIZE(),
            DEST_SYNC(dest_sync),
            PACK_BLOCK(pack_block),
        ],
        "runtimes": [
            TILE_COUNT(tile_cnt_A),
            DEST_INDEX(dest_index),
            RELU_CONFIG(relu_config),
            NUM_FACES(num_faces=FACES_PER_TILE),
            NUM_BLOCKS(num_blocks),
            NUM_TILES_IN_BLOCK(num_tiles_in_block),
            LOOP_FACTOR(loop_factor),
        ],
        "variant_stimuli": StimuliConfig(
            src_A,
            formats.input_format,
            src_B,
            formats.input_format,
            formats.output_format,
            tile_count_A=tile_cnt_A,
            tile_count_B=tile_cnt_B,
            tile_count_res=tile_cnt_A,
        ),
        "dest_acc": dest_acc,
        "unpack_to_dest": unpack_to_dest,
    }

    configuration = create_test_or_perf_config(
        is_perf=is_perf,
        run_types=run_types,
        test_config_kwargs=test_config_kwargs,
    )
    if is_perf:
        configuration.run(perf_report)
        return

    res_from_L1 = configuration.run().result

    assert len(res_from_L1) == len(
        golden_tensor
    ), "Result tensor and golden tensor are not of the same length"

    torch_format = format_dict[formats.output_format]
    res_tensor = torch.tensor(res_from_L1, dtype=torch_format)

    test_passed = passed_test(
        golden_tensor, res_tensor, formats.output_format, print_errors=False
    )

    if (
        not test_passed
        and relu_type
        in [
            PackerReluType.MinThresholdRelu,
            PackerReluType.MaxThresholdRelu,
        ]
        and PackGolden.is_relu_threshold_tolerance_issue(
            golden_tensor,
            res_tensor,
            relu_config,
            data_formats.pack_src,
        )
    ):
        # When a datum is extremely close to the ReLU threshold, differences can arise due to
        # floating point precision limitations and rounding during format conversions.
        # We check if all mismatches are within a small tolerance of the threshold. If so, we consider the test as passed.
        test_passed = True

    assert test_passed


PACK_BLOCK_SWEEP = dict(
    formats=PACK_FORMATS,
    dest_acc=get_valid_dest_accumulation_modes,
    input_dimensions=[[32, 32], [64, 64], [128, 64], [128, 128]],
    relu_type=[PackerReluType.NoRelu],
    dest_sync=[DestSync.Half, DestSync.Full],
    dest_index=lambda dest_acc, dest_sync, formats, input_dimensions: get_valid_dest_indices(
        dest_sync, dest_acc, formats, input_dimensions
    ),
)


PACK_BLOCK_PERF_SWEEP = dict(
    formats=input_output_formats(
        [DataFormat.Float16_b, DataFormat.Float32, DataFormat.Int32, DataFormat.Bfp8_b]
    ),
    dest_acc=get_valid_dest_accumulation_modes,
    input_dimensions=[[64, 64], [128, 64], [128, 128]],
    relu_type=[PackerReluType.NoRelu],
    dest_sync=[DestSync.Half, DestSync.Full],
    dest_index=[0],
)


@skip_for_wormhole
@parametrize(**PACK_BLOCK_SWEEP)
def test_pack_block(
    formats,
    dest_acc,
    input_dimensions,
    relu_type,
    dest_sync,
    dest_index,
):
    test_pack(
        formats,
        dest_acc,
        input_dimensions,
        relu_type,
        dest_sync,
        dest_index,
        pack_block=True,
    )
