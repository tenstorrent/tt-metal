# SPDX-FileCopyrightText: © 2025 Tenstorrent AI ULC
# SPDX-License-Identifier: Apache-2.0

from itertools import chain, product

import pytest
import torch
from helpers.format_config import DataFormat
from helpers.golden_generators import (
    TILE_DIM,
    MatmulGolden,
    TransposeGolden,
    get_golden_generator,
)
from helpers.llk_params import (
    DestAccumulation,
    DestSync,
    MathFidelity,
    PerfRunType,
    StochasticRounding,
    Transpose,
    format_dict,
)
from helpers.logger import logger
from helpers.matmul_sweep import sweep_matmul, sweep_tiny_tiles_matmul
from helpers.param_config import DEST_SYNC_TILE_LIMITS, input_output_formats
from helpers.stimuli_config import StimuliConfig
from helpers.stimuli_generator import convert_to_l1_view, generate_face_matmul_data
from helpers.test_config import TestConfig
from helpers.test_variant_parameters import (
    CRK_TILE_DIMM,
    DEST_INDEX,
    DEST_SYNC,
    IN_TILE_DIMS,
    LOOP_FACTOR,
    MATH_FIDELITY,
    NUM_BLOCKS,
    NUM_FACES,
    NUM_TILES_IN_BLOCK,
    PARTIAL_FACE,
    PERF_RUN_TYPE,
    STOCHASTIC_ROUNDING,
    THROTTLE_LEVEL,
    TILE_COUNT,
    UNPACK_TRANS_FACES,
    UNPACK_TRANS_WITHIN_FACE,
)
from helpers.tilize_untilize import tilize_block
from helpers.utils import passed_test

MATMUL_FORMATS = input_output_formats(
    [
        DataFormat.Float16_b,
        DataFormat.Float16,
        DataFormat.Float32,
    ]
)
DEST_ACC_MODES = [DestAccumulation.No, DestAccumulation.Yes]
DEST_SYNC_MODES = [DestSync.Half, DestSync.Full]
STOCHASTIC_ROUNDING_MODES = [StochasticRounding.No]
MATH_FIDELITIES = [
    MathFidelity.LoFi,
    MathFidelity.HiFi2,
    MathFidelity.HiFi3,
    MathFidelity.HiFi4,
]
MATMUL_COMBINATIONS = sweep_matmul(
    MATMUL_FORMATS,
    DEST_ACC_MODES,
    STOCHASTIC_ROUNDING_MODES,
    DEST_SYNC_MODES,
    math_matmul=True,
)
TINY_TILES_MATMUL_COMBINATIONS = sweep_tiny_tiles_matmul(
    MATMUL_FORMATS,
    DEST_ACC_MODES,
    STOCHASTIC_ROUNDING_MODES,
    DEST_SYNC_MODES,
    math_matmul=True,
)


def representative_tiny_tile_combinations():
    """One tiny-tile config per distinct set of inputs the throttle dispatch can see.

    _llk_math_matmul_init_ picks between the throttled and the unthrottled MOP on tile geometry
    alone, and on the fallback it issues the same matmul_configure_mop call the level-0 branch
    issues, then takes the same execute path. Every rt_dim/ct_dim shape is therefore already
    covered by the throttle-0 sweep below; repeating all of them at a throttled level only
    re-tests the same dispatch decision. Keep one config per (geometry, formats, dest mode).
    """
    representatives = {}
    for config in TINY_TILES_MATMUL_COMBINATIONS:
        tile_dims = config.tile_dimensions
        dispatch_key = (
            tile_dims.in0_tile_r_dim,
            tile_dims.in0_tile_c_dim,
            tile_dims.in1_tile_r_dim,
            tile_dims.in1_tile_c_dim,
            config.formats.input_format,
            config.formats.output_format,
            config.dest_acc,
            config.dest_sync,
        )
        representatives.setdefault(dispatch_key, config)
    return list(representatives.values())


TINY_TILES_THROTTLE_COMBINATIONS = representative_tiny_tile_combinations()

# Throttle level standing in for 1-3, where _llk_math_matmul_init_ takes the unthrottled
# fallback regardless of fidelity.
TINY_TILE_LOW_THROTTLE = 1
# Throttle level standing in for 4-5, where the fallback is taken only at LoFi: above level 3
# the execute path runs the MOP once per fidelity phase, which the unthrottled MOP already
# does internally, so the LLK keeps high-fidelity matmuls on the throttled path. MM_THROTTLE_MAX
# in tt_metal/hw/inc/api/compute/matmul.h is 5, so cover 5 rather than 4.
TINY_TILE_HIGH_THROTTLE = 5


ALL_TEST_PARAMS = list(
    chain(
        # Regular matmul with all throttle levels
        (
            (fidelity, combinations, throttle)
            for fidelity, combinations, throttle in product(
                MATH_FIDELITIES, MATMUL_COMBINATIONS, [1, 2, 3, 4, 5]
            )
        ),
        # Tiny tiles at throttle 0: the full sweep, unchanged.
        (
            (fidelity, combinations, 0)
            for fidelity, combinations in product(
                MATH_FIDELITIES, TINY_TILES_MATMUL_COMBINATIONS
            )
        ),
        # Tiny tiles at a throttled level <= 3: the fallback to the unthrottled MOP is taken
        # at every fidelity.
        (
            (fidelity, combinations, TINY_TILE_LOW_THROTTLE)
            for fidelity, combinations in product(
                MATH_FIDELITIES, TINY_TILES_THROTTLE_COMBINATIONS
            )
        ),
        # Tiny tiles above level 3, LoFi only: the one case where the fallback depends on
        # fidelity as well as geometry. HiFi is deliberately absent -- there the LLK keeps the
        # throttled path, which the geometry cannot serve. Measured on Blackhole: HiFi4 at
        # throttle 5 on a tiny tile wedges the math thread, with asserts on (some geometries hit
        # the LLK assert, others time out first) and with asserts off. Adding it here would wedge
        # the board rather than fail the case.
        (
            (MathFidelity.LoFi, combinations, TINY_TILE_HIGH_THROTTLE)
            for combinations in TINY_TILES_THROTTLE_COMBINATIONS
        ),
    )
)


@pytest.mark.nightly
@pytest.mark.parametrize("math_fidelity,matmul_config,throttle", ALL_TEST_PARAMS)
def test_math_matmul(
    math_fidelity,
    matmul_config,
    throttle,
):
    formats = matmul_config.formats
    in0_dimensions = matmul_config.tile_dimensions.in0_dimensions
    in1_dimensions = matmul_config.tile_dimensions.in1_dimensions
    in0_tile_r_dim = matmul_config.tile_dimensions.in0_tile_r_dim
    in0_tile_c_dim = matmul_config.tile_dimensions.in0_tile_c_dim
    in1_tile_r_dim = matmul_config.tile_dimensions.in1_tile_r_dim
    in1_tile_c_dim = matmul_config.tile_dimensions.in1_tile_c_dim
    transpose = matmul_config.face_layout_config.unpack_transpose_faces
    tile_cnt_in1 = matmul_config.tile_dimensions.tile_cnt_in1
    num_faces_in0 = matmul_config.face_layout_config.num_faces_in0
    num_faces_in1 = matmul_config.face_layout_config.num_faces_in1
    num_faces = matmul_config.face_layout_config.num_faces

    torch_format = format_dict[formats.output_format]

    in0 = generate_face_matmul_data(
        num_faces=num_faces_in0,
        stimuli_format=formats.input_format,
        input_dimensions=in0_dimensions,  # This will generate the right number of tiles
        is_matrix_A=True,  # matrix A (In0/SrcB) uses f0,f1 for 2-face mode
        face_r_dim=(
            matmul_config.tile_dimensions.in0_tile_r_dim
            if matmul_config.tile_dimensions.in0_tile_r_dim < 16
            else 16
        ),
    )

    in1 = generate_face_matmul_data(
        num_faces=num_faces_in1,
        stimuli_format=formats.input_format,
        input_dimensions=in1_dimensions,  # This will generate the right number of tiles
        is_matrix_A=False,  # matrix B (In1/SrcA) uses f0,f2 for 2-face mode
    )

    in1_golden = in1
    if transpose == Transpose.Yes:
        t_matrix = get_golden_generator(TransposeGolden)

        in1_golden = t_matrix.transpose_faces_multi_tile(
            in1,
            formats.input_format,
            num_tiles=tile_cnt_in1,
            tilize=True,
            input_dimensions=in1_dimensions,
        )
        in1_golden = t_matrix.transpose_within_faces_multi_tile(
            in1_golden,
            formats.input_format,
            num_tiles=tile_cnt_in1,
            untilize=True,
            input_dimensions=in1_dimensions,
        )

    generate_golden = get_golden_generator(MatmulGolden)
    golden_tensor = generate_golden(
        in0,
        in1_golden,
        formats.output_format,
        math_fidelity,
        input_A_dimensions=in0_dimensions,
        input_B_dimensions=in1_dimensions,
        tilize=True,  # Golden cannot model FPU strided for tilized data computation, so we tilize output after computation
        input_A_format=formats.input_format,
        input_B_format=formats.input_format,
    )

    tilized_in0 = tilize_block(
        in0, dimensions=in0_dimensions, stimuli_format=formats.input_format
    )
    tilized_in1 = tilize_block(
        in1, dimensions=in1_dimensions, stimuli_format=formats.input_format
    )
    tilized_in0_l1_view = convert_to_l1_view(
        tilized_in0, in0_dimensions, tile_dimensions=[in0_tile_r_dim, in0_tile_c_dim]
    )
    tilized_in1_l1_view = convert_to_l1_view(
        tilized_in1, in1_dimensions, tile_dimensions=[in1_tile_r_dim, in1_tile_c_dim]
    )

    # Matmul sweep shapes deliberately fit one destination section. Repeat the
    # complete matmul block four times so the same test also validates section
    # hand-off without changing the operation's RT/CT/KT contract.
    #
    # SyncFull + 16-bit dest (dest_acc=No) holds 16 tiles. Pack CLR_ALL after a
    # tiny-tile section whose dest window straddles the half-sync boundary
    # leaves packer dest addressing stuck at that tile on the next section
    # (1x32 through 16x32). Skip the 4-block handoff for those windows;
    # restore num_blocks=4 after #53500. Windows that stay in one half,
    # SyncHalf, dest_acc=Yes, and full 32x32 tiles still cover the handoff.
    num_tiles_in_block = matmul_config.tile_dimensions.tile_cnt
    dst_index = matmul_config.dst_index
    half_dest_tiles = DEST_SYNC_TILE_LIMITS[DestSync.Half]
    dest_straddles_half = (
        matmul_config.dest_sync == DestSync.Full
        and matmul_config.dest_acc == DestAccumulation.No
        and matmul_config.tile_dimensions.in0_tile_r_dim < TILE_DIM
        and dst_index < half_dest_tiles < dst_index + num_tiles_in_block
    )
    if dest_straddles_half:
        logger.warning(
            "Skipping 4-block dest section handoff for tiny-tile matmul "
            "(dst_index={}, num_tiles_in_block={}); restore num_blocks=4 after #53500",
            dst_index,
            num_tiles_in_block,
        )
    num_blocks = 1 if dest_straddles_half else 4

    configuration = TestConfig(
        "sources/math_matmul_test.cpp",
        formats,
        templates=[
            STOCHASTIC_ROUNDING(matmul_config.stochastic_rnd),
            MATH_FIDELITY(math_fidelity),
            THROTTLE_LEVEL(throttle),
            DEST_SYNC(matmul_config.dest_sync),
            PERF_RUN_TYPE(PerfRunType.L1_TO_L1),
        ],
        runtimes=[
            TILE_COUNT(matmul_config.tile_dimensions.tile_cnt),
            NUM_BLOCKS(num_blocks),
            LOOP_FACTOR(1),
            NUM_TILES_IN_BLOCK(num_tiles_in_block),
            NUM_FACES(num_faces, num_faces_in0, num_faces_in1),
            UNPACK_TRANS_FACES(transpose),
            UNPACK_TRANS_WITHIN_FACE(transpose),
            PARTIAL_FACE(
                partial_a=matmul_config.face_layout_config.partial_face_in0,
                partial_face_pack=matmul_config.face_layout_config.partial_face_pack,
                partial_b=matmul_config.face_layout_config.partial_face_in1,
                partial_face_math=matmul_config.face_layout_config.partial_face_math,
            ),
            CRK_TILE_DIMM(
                matmul_config.tile_dimensions.ct_dim,
                matmul_config.tile_dimensions.rt_dim,
                matmul_config.tile_dimensions.kt_dim,
            ),
            IN_TILE_DIMS(
                matmul_config.tile_dimensions.in0_tile_r_dim,
                matmul_config.tile_dimensions.in0_tile_c_dim,
                matmul_config.tile_dimensions.in1_tile_r_dim,
                matmul_config.tile_dimensions.in1_tile_c_dim,
            ),
            DEST_INDEX(dst_index),
        ],
        variant_stimuli=StimuliConfig(
            tilized_in0_l1_view.flatten(),
            formats.input_format,
            tilized_in1_l1_view.flatten(),
            formats.input_format,
            formats.output_format,
            tile_count_A=matmul_config.tile_dimensions.tile_cnt_in0,
            tile_count_B=matmul_config.tile_dimensions.tile_cnt_in1,
            tile_count_res=matmul_config.tile_dimensions.tile_cnt * num_blocks,
        ),
        dest_acc=matmul_config.dest_acc,
    )
    res_from_L1 = configuration.run().result

    res_tensor = torch.tensor(res_from_L1, dtype=torch_format)

    # Convert golden tensor to L1 memory view for comparison
    golden_tensor = convert_to_l1_view(
        golden_tensor,
        (in0_dimensions[0], in1_dimensions[1]),
        tile_dimensions=[in0_tile_r_dim, in1_tile_c_dim],
    )
    golden_tensor = golden_tensor.repeat(num_blocks)

    assert len(res_from_L1) == len(
        golden_tensor
    ), "Result tensor and golden tensor are not of the same length"

    if num_faces < 4:
        num_elements_per_tile = in0_tile_r_dim * in1_tile_c_dim
        tile_cnt = matmul_config.tile_dimensions.output_tile_cnt * num_blocks

        # Compare each tile separately
        TILE_R_DIM, TILE_C_DIM = 32, 32
        for i in range(tile_cnt):
            start = i * (TILE_R_DIM * TILE_C_DIM)
            assert passed_test(
                golden_tensor[
                    start : start + num_elements_per_tile
                ],  # Only compare active faces in this tile
                res_tensor[
                    start : start + num_elements_per_tile
                ],  # Only compare active faces in this tile
                formats.output_format,
            ), f"Assert on tile {i}/{tile_cnt} against golden failed"
    else:
        assert passed_test(
            golden_tensor, res_tensor, formats.output_format
        ), "Assert against golden failed"
