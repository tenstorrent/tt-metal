# SPDX-FileCopyrightText: © 2026 Tenstorrent AI ULC
#
# SPDX-License-Identifier: Apache-2.0

import pytest
from conftest import skip_for_coverage, skip_for_quasar
from fuser.config_parser import FUSER_CONFIG_DIR, FuserConfigSchema
from fuser.sweep import collect_fuser_cases

yaml_files = sorted(FUSER_CONFIG_DIR.glob("*.yaml"))
case_configs = collect_fuser_cases(yaml_files)


@skip_for_quasar
@skip_for_coverage
@pytest.mark.parametrize("case_name", case_configs)
def test_fuser(
    case_name,
    regenerate_cpp,
):
    config = FuserConfigSchema.load(case_name, case_configs[case_name])
    config.global_config.regenerate_cpp = regenerate_cpp
    config.run_regular_test()
