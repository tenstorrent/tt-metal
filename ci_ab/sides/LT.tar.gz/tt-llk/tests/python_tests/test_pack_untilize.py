# SPDX-FileCopyrightText: © 2026 Tenstorrent AI ULC
# SPDX-License-Identifier: Apache-2.0

import pytest
import torch
from conftest import skip_for_wormhole
from helpers.chip_architecture import ChipArchitecture, get_chip_architecture
from helpers.constraints import get_valid_dest_accumulation_modes
from helpers.data_format_inference import infer_data_formats
from helpers.format_config import DataFormat, InputOutputFormat
from helpers.golden_generators import (
    TILE_DIMENSIONS,
    UntilizeGolden,
    get_golden_generator,
)
from helpers.llk_params import (
    BlocksCalculationAlgorithm,
    DestAccumulation,
    DestSync,
    format_dict,
)
from helpers.param_config import (
    get_num_blocks_and_num_tiles_in_block,
    input_output_formats,
    parametrize,
)
from helpers.stimuli_config import StimuliConfig
from helpers.stimuli_generator import StimuliSpec, generate_stimuli
from helpers.test_config import TestConfig
from helpers.test_variant_parameters import (
    DEST_SYNC,
    NUM_FACES,
    PACK_UNTILIZE_DATUM_SIZES,
    TILE_COUNT,
    TILE_DST_CT_OFFSET,
    UNPACK_BLOCK,
    UNTILIZE_ROW_DATUMS,
    generate_input_dim,
)
from helpers.utils import passed_test


@parametrize(
    formats=input_output_formats(
        [
            DataFormat.Float16_b,
            DataFormat.Float16,
            DataFormat.Float32,  # Test Float32 with both 32bit mode dest (full precision) and 16bit mode dest (precision loss)
            DataFormat.Int32,
            DataFormat.Bfp8_b,
            DataFormat.Fp8_e4m3,
        ]  # Pack Untilize doesn't work for block float formats (Bfp8_b); we only include as input format in our test
    ),
    dest_acc=lambda formats: get_valid_dest_accumulation_modes(formats),
    input_dimensions=[[64, 64], [32, 128], [128, 128], [32, 64]],
    #  TODO add DestSync::Full tests when we have a solution for the static_assert in _llk_pack_untilize_init_ that requires block_ct_dim to be less or equal to 8,
    #  which is currently a limitation for testing DestSync::Full with the Untilize blocks calculation algorithm.
    dest_sync=[DestSync.Half],
    tile_dst_ct_offset=[0],  # Non-zero offsets are tracked in #1449
)
def test_pack_untilize(
    formats,
    dest_acc,
    input_dimensions,
    dest_sync,
    tile_dst_ct_offset,
):
    _check_pack_untilize(
        formats, dest_acc, input_dimensions, dest_sync, tile_dst_ct_offset
    )


_ALL_FORMATS = input_output_formats(
    [
        DataFormat.Float16_b,
        DataFormat.Float16,
        DataFormat.Float32,
        DataFormat.Int32,
        DataFormat.Bfp8_b,
        DataFormat.Fp8_e4m3,
    ]
)
_SMOKE_FORMATS = [
    InputOutputFormat(DataFormat.Float16_b, DataFormat.Float16_b),
    InputOutputFormat(DataFormat.Float32, DataFormat.Float32),
    InputOutputFormat(DataFormat.Float16_b, DataFormat.Fp8_e4m3),
]
# Full and split rows, output rows not contiguous in L1; the 68-tile row exceeds the packer's output offset window for 32-bit data.
_ROW_DIMENSIONS = [
    [32, 32],
    [64, 32],
    [32, 96],
    [32, 256],
    [32, 512],
    [32, 64],
    [32, 192],
    [32, 320],
    [64, 128],
    [32, 2176],
]


def _row_block_ct_dim(input_dimensions):
    return [
        {32: 1, 96: 0, 256: 0, 512: 0, 64: 1, 192: 3, 320: 5, 128: 2, 2176: 4}[
            input_dimensions[1]
        ]
    ]


# narrow_row: every tile row keeps its first row_datums datums; widths 5 and 21 give byte sizes mostly not a multiple of 16, and 20, 24, 28 are
# whole 16-byte units at some data sizes (the packer then steps each tile's row by its own width).
_NARROW_DIMENSIONS = [[32, 32], [64, 32], [32, 64], [32, 128]]
_NARROW_ROW_DATUMS = [5, 8, 16, 20, 21, 24, 28]


@skip_for_wormhole
@parametrize(
    formats=_SMOKE_FORMATS,
    dest_acc=lambda formats: get_valid_dest_accumulation_modes(formats),
    input_dimensions=_ROW_DIMENSIONS,
    block_ct_dim=_row_block_ct_dim,
)
def test_pack_untilize_rows(formats, dest_acc, input_dimensions, block_ct_dim):
    _check_pack_untilize_rows(formats, dest_acc, input_dimensions, block_ct_dim)


@pytest.mark.nightly
@skip_for_wormhole
@parametrize(
    formats=_ALL_FORMATS,
    dest_acc=lambda formats: get_valid_dest_accumulation_modes(formats),
    input_dimensions=_ROW_DIMENSIONS,
    block_ct_dim=_row_block_ct_dim,
)
def test_pack_untilize_rows_all_formats(
    formats, dest_acc, input_dimensions, block_ct_dim
):
    _check_pack_untilize_rows(formats, dest_acc, input_dimensions, block_ct_dim)


@skip_for_wormhole
@parametrize(
    formats=_SMOKE_FORMATS,
    dest_acc=lambda formats: get_valid_dest_accumulation_modes(formats),
    input_dimensions=_NARROW_DIMENSIONS,
    row_datums=_NARROW_ROW_DATUMS,
)
def test_pack_untilize_narrow_row(formats, dest_acc, input_dimensions, row_datums):
    _check_pack_untilize(
        formats, dest_acc, input_dimensions, DestSync.Half, 0, None, row_datums
    )


@pytest.mark.nightly
@skip_for_wormhole
@parametrize(
    formats=_ALL_FORMATS,
    dest_acc=lambda formats: get_valid_dest_accumulation_modes(formats),
    input_dimensions=_NARROW_DIMENSIONS,
    row_datums=_NARROW_ROW_DATUMS,
)
def test_pack_untilize_narrow_row_all_formats(
    formats, dest_acc, input_dimensions, row_datums
):
    _check_pack_untilize(
        formats, dest_acc, input_dimensions, DestSync.Half, 0, None, row_datums
    )


# The block unpack call on block rows of one and two tiles, which production takes for tiles under 32x32; two or more
# tiles so the tile stride is known.
@skip_for_wormhole
@parametrize(
    formats=[
        InputOutputFormat(DataFormat.Float16_b, DataFormat.Float16_b),
        InputOutputFormat(DataFormat.Float32, DataFormat.Float32),
        InputOutputFormat(DataFormat.Bfp8_b, DataFormat.Float16_b),
    ],
    dest_acc=lambda formats: get_valid_dest_accumulation_modes(formats),
    input_dimensions=[[64, 32], [32, 64], [64, 64], [32, 128]],
    block_ct_dim=[1, 2],
)
def test_pack_untilize_block_unpack(formats, dest_acc, input_dimensions, block_ct_dim):
    if input_dimensions[1] // 32 % block_ct_dim:
        pytest.skip("The block width does not divide the row")
    _check_pack_untilize(
        formats,
        dest_acc,
        input_dimensions,
        DestSync.Half,
        0,
        block_ct_dim,
        unpack_block=True,
    )


def _check_pack_untilize_rows(formats, dest_acc, input_dimensions, block_ct_dim):
    if dest_acc == DestAccumulation.Yes and block_ct_dim > 4:
        pytest.skip("A 32-bit DEST half holds four tiles")
    if (
        formats.output_format == DataFormat.Fp8_e4m3
        and block_ct_dim == 1
        and block_ct_dim * 32 < input_dimensions[1]
    ):
        pytest.skip(
            "An Fp8_e4m3 block row of one tile pads the next 32 bytes and is refused, https://github.com/tenstorrent/tt-metal/issues/59140"
        )
    _check_pack_untilize(
        formats, dest_acc, input_dimensions, DestSync.Half, 0, block_ct_dim or None
    )


def _check_pack_untilize(
    formats,
    dest_acc,
    input_dimensions,
    dest_sync,
    tile_dst_ct_offset,
    block_ct_dim=None,
    row_datums=32,
    unpack_block=False,
):
    if TestConfig.WITH_COVERAGE and input_dimensions == [64, 512]:
        pytest.skip(
            "Skipping large dimension test in coverage mode, check issue: #1063 on TT-LLK repo"
        )

    if get_chip_architecture() == ChipArchitecture.WORMHOLE and (
        formats.input_format == DataFormat.Fp8_e4m3
        or formats.output_format == DataFormat.Fp8_e4m3
    ):
        pytest.skip("Fp8_e4m3 not supported on wormhole")

    if formats.output_format == DataFormat.Bfp8_b:
        pytest.skip("Pack Untilize does not support Bfp8_b format")

    if (formats.input_format == DataFormat.Int32) ^ (
        formats.output_format == DataFormat.Int32
    ):
        pytest.skip("Pack Untilize does not support mixing Int32 with other formats")

    data_formats = infer_data_formats(
        formats.input_format,
        formats.output_format,
        dest_acc,
        False,
    )

    # Handling a hardware limitation: cannot convert 8-bit exponent datums to Float16 without storing them as intermediate Float32 in dest register.
    # For wormhole architecture, gasket cannot perform this conversion and packer takes input Float32 (from dest register) converting to Float16_A.
    # For blackhole architecture, gasket is able to convert Float32 to Float16_A before packing (reduces work on packer).`
    if (
        formats.input_format == DataFormat.Float16
        and data_formats.pack_src.is_32_bit()
        and dest_acc == DestAccumulation.No
    ):
        pytest.skip(
            "Due to hardware limitation, cannot convert 8-bit exponent datums to Float16 without storing them as intermediate Float32 in dest register. Therefore using dest_acc=No is not supported in this case."
        )

    # TODO: Checkout issue #1405 on tt-llk.
    if (
        get_chip_architecture() == ChipArchitecture.WORMHOLE
        and formats.input_format
        in (DataFormat.Float16_b, DataFormat.Float16, DataFormat.Bfp8_b)
        and formats.output_format == DataFormat.Float32
        and dest_acc == DestAccumulation.No
        and input_dimensions == [64, 512]
    ):
        pytest.skip("Wormhole pack_untilize does not support this format combination.")

    sfpu_false_spec = StimuliSpec.uniform(low=0.0, high=1.0)
    src_A, tile_cnt_A, src_B, tile_cnt_B = generate_stimuli(
        stimuli_format_A=formats.input_format,
        input_dimensions_A=input_dimensions,
        stimuli_format_B=formats.input_format,
        input_dimensions_B=input_dimensions,
        spec_A=sfpu_false_spec,
        spec_B=sfpu_false_spec,
    )

    generate_golden = get_golden_generator(UntilizeGolden)

    golden_tensor = generate_golden(src_A, formats.output_format, input_dimensions)
    if row_datums < 32:
        golden_tensor = golden_tensor.reshape(
            input_dimensions[0], input_dimensions[1] // 32, 32
        )[:, :, :row_datums].flatten()

    unpack_to_dest = (
        formats.input_format.is_32_bit() and dest_acc == DestAccumulation.Yes
    )

    # _llk_pack_untilize_init_ has a static_assert that checks if block_ct_dim is less or equal to 8.
    # TODO: Update this logic to accept more than 8 tiles per block if the static_assert changes in the future.
    if block_ct_dim is None:
        _, block_ct_dim = get_num_blocks_and_num_tiles_in_block(
            dest_sync,
            dest_acc,
            formats,
            input_dimensions,
            TILE_DIMENSIONS,
            BlocksCalculationAlgorithm.Untilize,
        )

    configuration = TestConfig(
        "sources/pack_untilize_test.cpp",
        formats,
        templates=[
            generate_input_dim(
                input_dimensions,
                input_dimensions,
                block_ct_dim,
            ),
            DEST_SYNC(dest_sync),
            TILE_DST_CT_OFFSET(tile_dst_ct_offset),
            UNTILIZE_ROW_DATUMS(row_datums),
            PACK_UNTILIZE_DATUM_SIZES(formats, dest_acc, unpack_to_dest),
            *([UNPACK_BLOCK(True)] if unpack_block else []),
        ],
        runtimes=[TILE_COUNT(tile_cnt_A), NUM_FACES(4)],
        variant_stimuli=StimuliConfig(
            src_A,
            formats.input_format,
            src_B,
            formats.input_format,
            formats.output_format,
            tile_count_A=tile_cnt_A,
            tile_count_B=tile_cnt_B,
            tile_count_res=tile_cnt_A,
            sfpu=False,
        ),
        dest_acc=dest_acc,
        unpack_to_dest=unpack_to_dest,
    )

    res_from_L1 = configuration.run().result
    if row_datums < 32:
        res_from_L1 = res_from_L1[: len(golden_tensor)]

    assert len(res_from_L1) == len(
        golden_tensor
    ), "Result tensor and golden tensor are not of the same length"

    res_tensor = torch.tensor(res_from_L1, dtype=format_dict[formats.output_format])

    assert passed_test(
        golden_tensor, res_tensor, formats.output_format
    ), "Assert against golden failed"
