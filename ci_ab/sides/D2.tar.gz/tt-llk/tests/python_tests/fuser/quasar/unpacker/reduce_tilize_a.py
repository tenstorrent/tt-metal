# SPDX-FileCopyrightText: © 2026 Tenstorrent AI ULC
#
# SPDX-License-Identifier: Apache-2.0

from typing import List

from fuser.base_unpacker import Unpacker
from fuser.block_data import BlockData
from fuser.fpu_node import FpuNode
from fuser.fuser_config import GlobalConfig
from fuser.golden.unpack.reduce_tilize_a import reduce_tilize_a_golden
from fuser.indexing import InvocationGranularity
from fuser.l1_operation import L1Operation
from fuser.operand import BfdResource, L1AccessMode


class UnpackReduceTilize(Unpacker):
    granularity = InvocationGranularity.TILE

    golden_fn = staticmethod(reduce_tilize_a_golden)

    def __init__(self, reduce_pool):
        self.reduce_pool = reduce_pool

    def get_headers(self) -> List[str]:
        return [
            "llk_unpack_common.h",
            "llk_unpack_reduce_col_tilizeA_strided.h",
        ]

    def perf_set_valid(
        self,
        operation: L1Operation,
        config: GlobalConfig,
        compute_unit: FpuNode,
        block: BlockData,
    ) -> str:
        num_faces = compute_unit.src_a.tile_shape.total_num_faces()
        return (
            f"_perf_unpack_loop_set_valid<false, true>(1);\n"
            f"_perf_unpack_loop_set_valid<true, false>({num_faces});\n"
        )

    def perf_clear_valid(
        self,
        operation: L1Operation,
        config: GlobalConfig,
        compute_unit: FpuNode,
        block: BlockData,
    ) -> str:
        num_faces = compute_unit.src_a.tile_shape.total_num_faces()
        return (
            f"_perf_math_loop_clear_valid<true, false>({num_faces});\n"
            f"_perf_math_loop_clear_valid<false, true>(1);\n"
        )

    def init(
        self,
        operation: L1Operation,
        config: GlobalConfig,
        compute_unit: FpuNode,
        block: BlockData,
    ) -> str:
        bfd_program = compute_unit.src_a.bfd_alloc_and_program(
            BfdResource.UNP0, L1AccessMode.STRIDED, result_name="bfd_a"
        ) + compute_unit.src_b.bfd_alloc_and_program(
            BfdResource.UNP1, result_name="bfd_b"
        )
        full_ct_dim = compute_unit.src_a.tile_count_x
        tensor_shape = compute_unit.src_a.tile_shape.cpp_value
        reduce_pool = self.reduce_pool.cpp_enum_value

        return (
            "{\n"
            + bfd_program
            + f"_llk_unpack_reduce_col_tilizeA_strided_init_<{reduce_pool}>"
            f"(bfd_a, bfd_b, {full_ct_dim}, {tensor_shape});\n"
            "}\n"
        )

    def unpack(
        self,
        operation: L1Operation,
        config: GlobalConfig,
        compute_unit: FpuNode,
        block: BlockData,
    ) -> str:
        tensor_shape = compute_unit.src_a.tile_shape.cpp_value
        full_ct_dim = compute_unit.src_a.tile_count_x
        row_stride = full_ct_dim * compute_unit.src_a.tile_shape.total_row_dim()
        tile_row = f"({block.tile_id_src_a}) / {full_ct_dim}"
        tile_col = f"({block.tile_id_src_a}) % {full_ct_dim}"
        l1_row_idx = f"{row_stride} * ({tile_row}) + ({tile_col})"

        return (
            f"_llk_unpack_reduce_col_tilizeA_strided_"
            f"({tensor_shape}, {l1_row_idx}, {block.tile_id_src_b});\n"
        )

    def uninit(
        self,
        operation: L1Operation,
        config: GlobalConfig,
        compute_unit: FpuNode,
        block: BlockData,
    ) -> str:
        return ""
