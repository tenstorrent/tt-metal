# SPDX-FileCopyrightText: © 2026 Tenstorrent AI ULC
#
# SPDX-License-Identifier: Apache-2.0

from typing import List

from fuser.base_unpacker import Unpacker
from fuser.block_data import BlockData
from fuser.fpu_node import FpuNode
from fuser.fuser_config import GlobalConfig
from fuser.golden.unpack.tilize_a import tilize_a_golden
from fuser.indexing import InvocationGranularity
from fuser.l1_operation import L1Operation
from fuser.operand import BfdResource
from helpers.llk_params import DestAccumulation


class UnpackerTilizeA(Unpacker):
    granularity = InvocationGranularity.ROW
    per_block_init = True

    golden_fn = staticmethod(tilize_a_golden)

    def perf_set_valid(
        self,
        operation: L1Operation,
        config: GlobalConfig,
        compute_unit: FpuNode,
        block: BlockData,
    ) -> str:
        set_b = "true" if config.dest_acc == DestAccumulation.Yes else "false"
        return f"_perf_unpack_loop_set_valid<true, {set_b}>({block.block_cols});\n"

    def perf_clear_valid(
        self,
        operation: L1Operation,
        config: GlobalConfig,
        compute_unit: FpuNode,
        block: BlockData,
    ) -> str:
        clear_b = "true" if config.dest_acc == DestAccumulation.Yes else "false"
        return f"_perf_math_loop_clear_valid<true, {clear_b}>({block.block_cols});\n"

    def get_headers(self) -> List[str]:
        return [
            "llk_unpack_common.h",
            "llk_unpack_tilize.h",
        ]

    def init(
        self,
        operation: L1Operation,
        config: GlobalConfig,
        compute_unit: FpuNode,
        block: BlockData,
    ) -> str:
        bfd_program = compute_unit.src_a.bfd_alloc_and_program(
            BfdResource.UNP0, result_name="bfd_id"
        )
        tensor_shape = compute_unit.src_a.tile_shape.cpp_value
        en_32bit_dest = config.dest_acc.cpp_enum_value
        full_ct_dim = compute_unit.src_a.tile_count_x
        block_ct_dim = block.block_cols

        return (
            "{\n"
            + bfd_program
            + f"_llk_unpack_tilize_init_<p_unpacr::UNP_A, {en_32bit_dest}>"
            f"(bfd_id, {full_ct_dim}, {block_ct_dim}, {tensor_shape});\n"
            "}\n"
        )

    def unpack(
        self,
        operation: L1Operation,
        config: GlobalConfig,
        compute_unit: FpuNode,
        block: BlockData,
    ) -> str:
        tensor_shape = compute_unit.src_a.tile_shape.cpp_value
        num_faces_r_dim = compute_unit.src_a.tile_shape.num_faces_r_dim
        face_r_dim = compute_unit.src_a.tile_shape.face_r_dim
        l1_row_idx = f"{block.tile_id_src_a} * {num_faces_r_dim} * {face_r_dim}"

        return (
            f"_llk_unpack_tilize_set_src_offset_<p_unpacr::UNP_A>"
            f"({tensor_shape}, {l1_row_idx});\n"
            f"_llk_unpack_tilize_<p_unpacr::UNP_A>(0);\n"
        )

    def uninit(
        self,
        operation: L1Operation,
        config: GlobalConfig,
        compute_unit: FpuNode,
        block: BlockData,
    ) -> str:
        return ""
