# SPDX-FileCopyrightText: © 2026 Tenstorrent AI ULC
#
# SPDX-License-Identifier: Apache-2.0

from typing import List

from fuser.base_unpacker import Unpacker
from fuser.block_data import BlockData
from fuser.fpu_node import FpuNode
from fuser.fuser_config import GlobalConfig
from fuser.golden.unpack.matmul import unpack_matmul_golden
from fuser.indexing import InvocationGranularity
from fuser.l1_operation import L1Operation
from fuser.operand import BfdResource


class MatmulUnpacker(Unpacker):
    reverse_operands = True
    granularity = InvocationGranularity.BLOCK
    per_block_init = True

    golden_fn = staticmethod(unpack_matmul_golden)

    def get_headers(self) -> List[str]:
        return [
            "llk_unpack_common.h",
            "llk_unpack_matmul.h",
        ]

    def perf_set_valid(
        self,
        operation: L1Operation,
        config: GlobalConfig,
        compute_unit: FpuNode,
        block: BlockData,
    ) -> str:
        num_cols = compute_unit.src_a.tile_shape.total_col_dim()
        kt_dim = compute_unit.src_a.dimensions[1] // num_cols
        rt_dim = block.block_rows
        ct_dim = block.block_cols
        return f"_perf_unpack_matmul_mock(1, {rt_dim}, {kt_dim}, {ct_dim});\n"

    def perf_clear_valid(
        self,
        operation: L1Operation,
        config: GlobalConfig,
        compute_unit: FpuNode,
        block: BlockData,
    ) -> str:
        num_cols = compute_unit.src_a.tile_shape.total_col_dim()
        kt_dim = compute_unit.src_a.dimensions[1] // num_cols
        rt_dim = block.block_rows
        ct_dim = block.block_cols
        return f"_perf_math_matmul_mock(1, {rt_dim}, {kt_dim}, {ct_dim});\n"

    def init(
        self,
        operation: L1Operation,
        config: GlobalConfig,
        compute_unit: FpuNode,
        block: BlockData,
    ) -> str:
        bfd_program = compute_unit.src_a.bfd_alloc_and_program(
            BfdResource.UNP1, result_name="bfd_a"
        ) + compute_unit.src_b.bfd_alloc_and_program(
            BfdResource.UNP0, result_name="bfd_b"
        )
        src_b_shape = compute_unit.src_a.tile_shape.cpp_value
        src_a_shape = compute_unit.src_b.tile_shape.cpp_value
        rt_dim = block.block_rows
        ct_dim = block.block_cols
        num_cols = compute_unit.src_a.tile_shape.total_col_dim()
        kt_dim = compute_unit.src_a.dimensions[1] // num_cols

        return (
            "{\n" + bfd_program + "_llk_unpack_matmul_init_<false>"
            f"(bfd_a, bfd_b, {ct_dim}, {rt_dim}, {kt_dim}, {src_b_shape}, {src_a_shape});\n"
            "}\n"
        )

    def unpack(
        self,
        operation: L1Operation,
        config: GlobalConfig,
        compute_unit: FpuNode,
        block: BlockData,
    ) -> str:
        rt_dim = block.block_rows
        ct_dim = block.block_cols
        src_b_shape = compute_unit.src_a.tile_shape.cpp_value
        src_a_shape = compute_unit.src_b.tile_shape.cpp_value
        num_cols = compute_unit.src_a.tile_shape.total_col_dim()
        kt_dim = compute_unit.src_a.dimensions[1] // num_cols
        full_ct_dim = (
            compute_unit.src_b.dimensions[1]
            // compute_unit.src_b.tile_shape.total_col_dim()
        )

        return (
            f"{{\n"
            f"    for (std::uint32_t kt = 0; kt < {kt_dim}; ++kt) {{\n"
            f"        std::uint32_t srca_tile_idx = ({block.tile_id_src_a}) + kt;\n"
            f"        std::uint32_t srcb_tile_idx = ({block.tile_id_src_b}) + kt * {full_ct_dim};\n"
            f"        _llk_unpack_matmul_({ct_dim}, {rt_dim}, {kt_dim}, srca_tile_idx, srcb_tile_idx, {src_b_shape}, {src_a_shape});\n"
            f"    }}\n"
            f"}}\n"
        )

    def uninit(
        self,
        operation: L1Operation,
        config: GlobalConfig,
        compute_unit: FpuNode,
        block: BlockData,
    ) -> str:
        return ""
