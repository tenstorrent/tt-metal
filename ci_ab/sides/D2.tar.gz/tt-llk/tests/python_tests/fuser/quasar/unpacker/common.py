# SPDX-FileCopyrightText: © 2026 Tenstorrent AI ULC
#
# SPDX-License-Identifier: Apache-2.0

from typing import TYPE_CHECKING

from fuser.fpu_node import FpuNode
from helpers.format_config import DataFormat

if TYPE_CHECKING:
    from fuser.fuser_config import GlobalConfig
    from fuser.l1_operation import L1Operation


def hw_configure_unpack(
    compute_node: FpuNode,
    dest_acc: str,
    unpack_A_src: DataFormat,
    unpack_A_dst: DataFormat,
    unpack_B_src: DataFormat,
    unpack_B_dst: DataFormat,
) -> str:
    return (
        f"_llk_unpack_hw_configure_<p_unpacr::UNP_A>(static_cast<DataFormat>({unpack_A_dst.cpp_underlying_value}));\n"
        f"_llk_unpack_hw_configure_<p_unpacr::UNP_B>(static_cast<DataFormat>({unpack_B_dst.cpp_underlying_value}));\n"
    )


def configure_unpack(
    compute_node: FpuNode,
    dest_acc: str,
    old_A_src: DataFormat,
    new_A_src: DataFormat,
    new_A_dst: DataFormat,
    old_B_src: DataFormat,
    new_B_src: DataFormat,
    new_B_dst: DataFormat,
    srca_changed: bool,
    srcb_changed: bool,
    srca_tile_changed: bool,
    srcb_tile_changed: bool,
) -> str:
    if srca_changed and srcb_changed:
        return f"_llk_unpack_configure_binary_<p_unpacr::UNP_A, p_unpacr::UNP_B>(static_cast<DataFormat>({new_A_dst.cpp_underlying_value}), static_cast<DataFormat>({new_B_dst.cpp_underlying_value}));\n"
    if srca_changed:
        return f"_llk_unpack_configure_unary_<p_unpacr::UNP_A>(static_cast<DataFormat>({new_A_dst.cpp_underlying_value}));\n"
    if srcb_changed:
        return f"_llk_unpack_configure_unary_<p_unpacr::UNP_B>(static_cast<DataFormat>({new_B_dst.cpp_underlying_value}));\n"
    return ""


def _upk_to_dest_sem_init(config: "GlobalConfig", operation: "L1Operation") -> str:
    from fuser.fpu_node import FpuNode
    from fuser.quasar.unpacker.unpack_a import _uses_upk_to_dest_semaphores

    if not _uses_upk_to_dest_semaphores(config):
        return ""
    if not any(
        isinstance(node, FpuNode) and node.unpack_to_dest.value
        for node in operation.math_nodes
    ):
        return ""
    return "_llk_sync_init_(semaphore::UNPACK_MATH, 1, 0);\n"


def dvalid_init(config: "GlobalConfig" = None, operation: "L1Operation" = None) -> str:
    from helpers.llk_params import PerfRunType

    if config.quasar_use_dvalid:
        if config.perf_run_type in (None, PerfRunType.L1_TO_L1):
            return "set_up_dest_dvalid_per_thread<dest_dvalid_client::UNPACK>({dest_dvalid_client::FPU, dest_dvalid_client::PACK});\n"
        return "set_up_zero_dest_dvalid_handshake_for_unpack();\n"
    return _upk_to_dest_sem_init(config, operation)


def sync_with_packer(config: "GlobalConfig", operation: "L1Operation") -> str:
    if operation.needs_pack_sync:
        return (
            "_llk_sync_wait_<p_stall::STALL_SYNC, p_stall::STALL_ON_ZERO>(semaphore::PACK_UNPACK);\n"
            "_llk_sync_get_<>(semaphore::PACK_UNPACK);\n"
        )
    return ""
