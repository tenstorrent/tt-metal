# SPDX-FileCopyrightText: © 2026 Tenstorrent AI ULC
#
# SPDX-License-Identifier: Apache-2.0

from typing import List

from fuser.base_unpacker import Unpacker
from fuser.block_data import BlockData
from fuser.fpu_node import FpuNode
from fuser.fuser_config import GlobalConfig
from fuser.golden.unpack.unpack import unpack_golden
from fuser.indexing import InvocationGranularity
from fuser.l1_operation import L1Operation
from fuser.operand import BfdResource


class ReduceUnpacker(Unpacker):
    granularity = InvocationGranularity.TILE
    golden_fn = staticmethod(unpack_golden)

    def __init__(self, reduce_dim, reduce_pool):
        self.reduce_dim = reduce_dim
        self.reduce_pool = reduce_pool

    def get_headers(self) -> List[str]:
        return [
            "llk_unpack_common.h",
            "llk_unpack_reduce.h",
        ]

    def perf_set_valid(
        self,
        operation: L1Operation,
        config: GlobalConfig,
        compute_unit: FpuNode,
        block: BlockData,
    ) -> str:
        num_faces = compute_unit.src_a.tile_shape.total_num_faces()
        return (
            f"_perf_unpack_loop_set_valid<false, true>(1);\n"
            f"_perf_unpack_loop_set_valid<true, false>({num_faces});\n"
        )

    def perf_clear_valid(
        self,
        operation: L1Operation,
        config: GlobalConfig,
        compute_unit: FpuNode,
        block: BlockData,
    ) -> str:
        num_faces = compute_unit.src_a.tile_shape.total_num_faces()
        return (
            f"_perf_math_loop_clear_valid<true, false>({num_faces});\n"
            f"_perf_math_loop_clear_valid<false, true>(1);\n"
        )

    def init(
        self,
        operation: L1Operation,
        config: GlobalConfig,
        compute_unit: FpuNode,
        block: BlockData,
    ) -> str:
        bfd_program = compute_unit.src_a.bfd_alloc_and_program(
            BfdResource.UNP0, result_name="bfd_a"
        ) + compute_unit.src_b.bfd_alloc_and_program(
            BfdResource.UNP1, result_name="bfd_b"
        )
        reduce_dim = self.reduce_dim.cpp_enum_value
        reduce_pool = self.reduce_pool.cpp_enum_value

        return (
            "{\n"
            + bfd_program
            + f"_llk_unpack_reduce_init_<{reduce_pool}, {reduce_dim}>"
            "(bfd_a, bfd_b, "
            f"{compute_unit.src_a.tile_shape.cpp_value}, "
            "1);\n}\n"
        )

    def unpack(
        self,
        operation: L1Operation,
        config: GlobalConfig,
        compute_unit: FpuNode,
        block: BlockData,
    ) -> str:
        return (
            f"_llk_unpack_reduce_({block.tile_id_src_a}, {block.tile_id_src_b}, "
            f"{compute_unit.src_a.tile_shape.cpp_value});\n"
        )

    def uninit(
        self,
        operation: L1Operation,
        config: GlobalConfig,
        compute_unit: FpuNode,
        block: BlockData,
    ) -> str:
        return ""
