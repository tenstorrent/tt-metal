# SPDX-FileCopyrightText: © 2026 Tenstorrent AI ULC
#
# SPDX-License-Identifier: Apache-2.0

import torch
from helpers.llk_params import DataFormat, format_dict
from helpers.logger import logger
from helpers.utils import passed_test, tolerances

from .fuser_config import FuserConfig
from .l1_operation import L1Operation
from .pack_node import PackNode

DEFAULT_BASE_ATOL = 0.05
DEFAULT_BASE_RTOL = 0.05
DEFAULT_BASE_PCC = 0.99
DEFAULT_L1_ATOL = 0.1
DEFAULT_L1_RTOL = 0.1


class GoldenCheck:
    def __init__(self, verbose: bool = True):
        self.verbose = verbose

    _FORMAT_PCC = {DataFormat.Bfp4_b: 0.98, DataFormat.MxFp4: 0.95}

    def _check_output(self, output) -> bool:
        res_tensor = torch.tensor(
            output.raw_data, dtype=format_dict[output.data_format]
        )
        l1_golden = torch.tensor(
            output.l1_golden, dtype=format_dict[output.data_format]
        )
        master_golden = torch.tensor(
            output.master_golden, dtype=format_dict[output.data_format]
        )

        res_tensor = res_tensor.flatten()
        l1_golden = l1_golden.flatten()
        master_golden = master_golden.flatten()

        l1_atol = output.atol if output.atol is not None else DEFAULT_L1_ATOL
        l1_rtol = output.rtol if output.rtol is not None else DEFAULT_L1_RTOL
        master_atol = output.atol if output.atol is not None else output.acc_atol
        master_rtol = output.rtol if output.rtol is not None else output.acc_rtol

        logger.info(
            f"L1 golden check for {output.name} (atol {l1_atol:g}, rtol {l1_rtol:g}):"
        )
        l1_passed = passed_test(
            l1_golden,
            res_tensor,
            output.data_format,
            print_pcc=True,
            custom_atol=l1_atol,
            custom_rtol=l1_rtol,
            tile_shape=output.tile_shape,
        )

        logger.info(
            f"Master golden check for {output.name} (format {output.data_format.name},"
            f" atol {master_atol:g}, rtol {master_rtol:g}, pcc {output.acc_pcc:.2f}):"
        )
        master_passed = passed_test(
            master_golden,
            res_tensor,
            output.data_format,
            print_pcc=True,
            custom_atol=master_atol,
            custom_rtol=master_rtol,
            custom_pcc_threshold=output.acc_pcc,
            tile_shape=output.tile_shape,
        )

        return l1_passed and master_passed

    def check_operation(self, operation: L1Operation) -> bool:
        if self.verbose:
            logger.info(f"{operation}")

        passed = True
        for pack_node in operation.pack_nodes:
            if not isinstance(pack_node, PackNode):
                continue
            if not self._check_output(pack_node.output):
                passed = False

        if self.verbose:
            if passed:
                logger.success("PASS")
            else:
                logger.error("FAIL")

        return passed

    @staticmethod
    def _accumulate_tolerance(operation: L1Operation) -> None:
        """Propagate tolerances through the pipeline stage by stage.

        Each operation builds on the error from its inputs: errors grow
        as they pass through more stages. We take the worst case tolerance
        across all inputs (max atol/rtol, min pcc) and combine it with the
        base tolerance for the output data format.

        Two different math nodes can share the same input tensor, so we
        deduplicate by identity to avoid counting its tolerance twice.
        """
        sources = []
        seen = set()
        for node in operation.math_nodes:
            if not hasattr(node, "src_a"):
                continue
            for src in (node.src_a, node.src_b):
                if src is not None and id(src) not in seen:
                    seen.add(id(src))
                    sources.append(src)

        max_input_rtol = max((s.acc_rtol for s in sources), default=0.0)
        max_input_atol = max((s.acc_atol for s in sources), default=0.0)

        for pack in operation.pack_nodes:
            if not isinstance(pack, PackNode):
                continue
            output = pack.output
            base_tol = tolerances.get(output.data_format)
            base_rtol = base_tol.rtol if base_tol else DEFAULT_BASE_RTOL
            base_atol = base_tol.atol if base_tol else DEFAULT_BASE_ATOL

            min_input_pcc = min((s.acc_pcc for s in sources), default=1.0)
            base_pcc = GoldenCheck._FORMAT_PCC.get(output.data_format, DEFAULT_BASE_PCC)

            # Relative errors multiply together because the new operation
            # introduces its own error on top of the error from previous stages.
            # e.g. input with 5% error through an op with 3% error gives
            # (1.05)*(1.03)-1 = 0.0815, not 8%.
            output.acc_rtol = (1 + max_input_rtol) * (1 + base_rtol) - 1

            # The input already carries some absolute error. The new operation can
            # scale that error (by 1 + base_rtol), then adds its own absolute error.
            # e.g. input atol=0.02 through an op with rtol=0.03, atol=0.01 gives
            # 0.02*(1.03) + 0.01 = 0.0306.
            output.acc_atol = max_input_atol * (1 + base_rtol) + base_atol

            # Correlation degrades multiplicatively through each stage.
            output.acc_pcc = min_input_pcc * base_pcc

    def check_pipeline(self, config: FuserConfig) -> bool:
        result = True
        for operation in config.pipeline:
            operation.golden(config.global_config)
            self._accumulate_tolerance(operation)
            passed = self.check_operation(operation)
            if not passed:
                result = False

        return result
