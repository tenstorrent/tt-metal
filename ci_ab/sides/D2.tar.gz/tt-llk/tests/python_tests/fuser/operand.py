# SPDX-FileCopyrightText: © 2026 Tenstorrent AI ULC
#
# SPDX-License-Identifier: Apache-2.0

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Tuple

import torch
from helpers.device_io import read_from_device, write_to_device
from helpers.llk_params import DataFormat, PartialFace, format_dict, format_tile_sizes
from helpers.pack import (
    pack_bfp8_b,
    pack_bfp16,
    pack_fp8_e4m3,
    pack_fp16,
    pack_fp32,
    pack_int8,
    pack_int16,
    pack_int32,
    pack_uint8,
    pack_uint16,
    pack_uint32,
)
from helpers.stimuli_generator import (
    StimuliSpec,
    default_spec_for_format,
    generate_face,
)
from helpers.tile_constants import (
    DEFAULT_TILE_C_DIM,
    DEFAULT_TILE_R_DIM,
    calculate_tile_size_bytes,
)
from helpers.tile_shape import TileShape, construct_tile_shape
from helpers.tilize_untilize import tilize_block, untilize_block
from helpers.unpack import unpack_res_tiles

L1_PACKERS = {
    DataFormat.Float16: pack_fp16,
    DataFormat.Float16_b: pack_bfp16,
    DataFormat.Float32: pack_fp32,
    DataFormat.Bfp8_b: pack_bfp8_b,
    DataFormat.Int32: pack_int32,
    DataFormat.UInt32: pack_uint32,
    DataFormat.Int16: pack_int16,
    DataFormat.UInt16: pack_uint16,
    DataFormat.Fp8_e4m3: pack_fp8_e4m3,
    DataFormat.Int8: pack_int8,
    DataFormat.UInt8: pack_uint8,
}


class BfdResource(Enum):
    UNP0 = "ckernel::trisc::BfdResource::Unp0"
    UNP1 = "ckernel::trisc::BfdResource::Unp1"
    PACK0 = "ckernel::trisc::BfdResource::Pack0"


class L1AccessMode(Enum):
    CONTINUOUS = "ckernel::trisc::L1AccessMode::Continuous"
    STRIDED = "ckernel::trisc::L1AccessMode::Strided"


@dataclass
class Operand:
    name: str
    dimensions: Tuple[int, int]
    data_format: DataFormat
    tile_shape: TileShape
    l1_address: Optional[int] = None
    is_output: bool = False
    _raw_data: Optional[torch.Tensor] = None
    _master_golden: Optional[torch.Tensor] = None
    intervals: Optional[List[Tuple[float, float]]] = None
    l1_golden: Optional[torch.Tensor] = None
    tile_count: int = field(init=False)
    tile_count_x: int = field(init=False)
    tile_count_y: int = field(init=False)
    tile_size: int = field(init=False)
    acc_atol: float = 0.0
    acc_rtol: float = 0.0
    acc_pcc: float = 1.0
    atol: Optional[float] = None
    rtol: Optional[float] = None

    def __post_init__(self):
        self.tile_count_x = self.dimensions[1] // self.tile_shape.total_col_dim()
        self.tile_count_y = self.dimensions[0] // self.tile_shape.total_row_dim()
        self.tile_count = self.tile_count_x * self.tile_count_y

        self.partial_face = (
            PartialFace.Yes
            if (
                self.tile_shape.total_row_dim() < 16
                or self.tile_shape.total_col_dim() < 16
            )
            else PartialFace.No
        )

        TILE_SIZES = {
            DataFormat.Bfp8_b: 68,
            DataFormat.Float32: 256,
        }

        self.tile_size = (
            TILE_SIZES.get(self.data_format, 128) * self.tile_shape.total_num_faces()
        ) // 4

    def generate_data(self):
        height, width = self.dimensions[0], self.dimensions[1]

        faces_needed = self.tile_count * self.tile_shape.total_num_faces()
        faces_data = []

        if self.intervals is not None:
            if (
                len(self.intervals) == 1
                and self.intervals[0][0] == self.intervals[0][1]
                and not self.data_format.is_integer()
            ):
                spec = StimuliSpec.constant(self.intervals[0][0])
            else:
                spec = StimuliSpec.uniform(intervals=self.intervals)
        else:
            spec = default_spec_for_format(self.data_format)

        for _ in range(faces_needed):
            face = generate_face(
                spec=spec,
                stimuli_format=self.data_format,
                face_r_dim=self.tile_shape.face_r_dim,
            )
            faces_data.extend(face.tolist())

        dtype = (
            format_dict[self.data_format]
            if self.data_format != DataFormat.Bfp8_b
            else torch.bfloat16
        )
        raw_data = torch.tensor(faces_data[: height * width], dtype=dtype).view(
            height, width
        )

        self._raw_data = raw_data

    def set_data(self, raw_data: torch.Tensor):
        self._raw_data = raw_data

    @property
    def raw_data(self) -> Optional[torch.Tensor]:
        if self._raw_data is None and not self.is_output:
            self.generate_data()
        return self._raw_data

    @property
    def master_golden(self) -> Optional[torch.Tensor]:
        if not self.is_output:
            return self.raw_data
        return self._master_golden

    def __str__(self) -> str:
        return f"{self.name}, {self.dimensions}, {self.data_format}, L1 Addr: {hex(self.l1_address)}"

    def calculate_l1_size(self) -> int:
        """Calculate the size in L1 memory for this operand."""
        tile_elements = self.tile_shape.total_tile_size()
        return self.data_format.num_bytes_per_tile(tile_elements) * self.tile_count

    def pack_for_l1(self) -> List[Tuple[int, List]]:
        """Pack operand data for writing to L1 memory.

        Returns:
            List of (address, packed_data) tuples, one per tile.
        """
        pack_function = L1_PACKERS.get(self.data_format)
        if not pack_function:
            raise ValueError(f"Unsupported data format: {self.data_format.name}")

        tile_elements = self.tile_shape.total_tile_size()
        tile_size = self.data_format.num_bytes_per_tile(tile_elements)

        tile_dims = (self.tile_shape.total_row_dim(), self.tile_shape.total_col_dim())
        num_faces = self.tile_shape.total_num_faces()

        buffer = (
            tilize_block(
                self.raw_data,
                dimensions=self.dimensions,
                stimuli_format=self.data_format,
                num_faces=num_faces,
                tile_dimensions=tile_dims,
            ).flatten()
            if not self.is_output
            else torch.zeros(self.dimensions).flatten()
        )

        packed_tiles = []

        for i in range(self.tile_count):
            start_idx = tile_elements * i
            tile_data = buffer[start_idx : start_idx + tile_elements]

            if self.data_format == DataFormat.Bfp8_b:
                packed = pack_function(
                    tile_data, num_faces=self.tile_shape.total_num_faces()
                )
            else:
                packed = pack_function(tile_data)

            addr = self.l1_address + i * tile_size
            packed_tiles.append((addr, packed))

        return packed_tiles

    @property
    def cpp_name(self) -> str:
        return f"{self.name}_buffer"

    def cpp_value(self, dest_acc: bool) -> str:
        buffer_size = calculate_tile_size_bytes(
            data_format=self.data_format,
            tile_dimensions=(
                self.tile_shape.total_row_dim(),
                self.tile_shape.total_col_dim(),
            ),
            format_tile_sizes=format_tile_sizes,
            use_srcs=True,
            dest_acc=dest_acc,
        )
        return f"[[maybe_unused]] const Operand {self.cpp_name}({hex(self.l1_address)}, {buffer_size});\n"

    def bfd_alloc_and_program(
        self,
        engine: BfdResource,
        mode: L1AccessMode = L1AccessMode.CONTINUOUS,
        *,
        result_name: Optional[str] = None,
    ) -> str:
        assignment = f"const auto {result_name} = " if result_name else ""
        data_format = (
            DataFormat.Int16
            if self.data_format == DataFormat.UInt16
            else self.data_format
        )
        return (
            f"{assignment}ckernel::trisc::bfd_alloc_and_program<{engine.value}, {mode.value}>("
            f"{self.tile_shape.cpp_value}, "
            f"{hex(self.l1_address)} / 16, "
            f"{data_format.cpp_underlying_value});\n"
        )


class OperandRegistry:
    def __init__(self):
        self.operands: dict[str, Operand] = {}

    def create(
        self,
        name: str,
        dimensions: Tuple[int, int],
        data_format: DataFormat,
        intervals: Optional[List[Tuple[float, float]]] = None,
        tile_dims: Optional[Tuple[int, int]] = None,
        atol: Optional[float] = None,
        rtol: Optional[float] = None,
    ) -> Operand:
        if name in self.operands:
            operand = self.operands[name]
            if (dimensions is not None and dimensions != operand.dimensions) or (
                data_format is not None and data_format != operand.data_format
            ):
                raise ValueError(
                    f"Operand '{name}' exists with different parameters: "
                    f"requested dimensions={dimensions}, data_format={data_format}; "
                    f"existing dimensions={operand.dimensions}, data_format={operand.data_format}"
                )

            return operand

        tile_shape = construct_tile_shape(
            tile_dims
            if tile_dims is not None
            else (DEFAULT_TILE_R_DIM, DEFAULT_TILE_C_DIM)
        )

        operand = Operand(
            name=name,
            dimensions=dimensions,
            data_format=data_format,
            is_output=False,
            intervals=intervals,
            tile_shape=tile_shape,
            atol=atol,
            rtol=rtol,
        )
        self.operands[name] = operand
        return operand

    def get(
        self,
        name: str,
    ) -> Operand:
        if name not in self.operands:
            raise ValueError(
                f"Operand '{name}' not found in registry. Define it in the 'operands' section with dims and format."
            )

        return self.operands[name]

    def get_all_outputs(self) -> list[Operand]:
        return [op for op in self.operands.values() if op.is_output]

    DEFAULT_L1_START_ADDRESS = 0x00021000
    DEFAULT_L1_END_ADDRESS = 0x00169FFF

    def allocate_l1_addresses(
        self,
        start_address: int = DEFAULT_L1_START_ADDRESS,
        end_address: int = DEFAULT_L1_END_ADDRESS,
    ) -> None:
        """
        Allocate L1 addresses for all operands.

        Addresses are allocated sequentially:
        1. All input operands
        2. All output operands
        """

        if (
            start_address < self.DEFAULT_L1_START_ADDRESS
            or start_address > self.DEFAULT_L1_END_ADDRESS
        ):
            raise ValueError(
                f"Start L1 address for operands must be between "
                f"{self.DEFAULT_L1_START_ADDRESS} and {self.DEFAULT_L1_END_ADDRESS}"
            )

        current_address = start_address

        for operand in self.operands.values():
            if not operand.is_output and operand.l1_address is None:
                operand.l1_address = current_address
                current_address += operand.calculate_l1_size()

        for operand in self.operands.values():
            if operand.is_output and operand.l1_address is None:
                operand.l1_address = current_address
                current_address += operand.calculate_l1_size()
                if current_address > end_address:
                    raise ValueError(
                        "There is not enough space on device for all operands"
                    )

    def write_inputs_to_l1(self, location: str = "0,0") -> None:
        """Write all input operands to L1 memory."""

        for operand in self.operands.values():
            for addr, packed_data in operand.pack_for_l1():
                write_to_device(location, addr, packed_data)

    def read_outputs_from_l1(self, location: str = "0,0") -> None:
        """Read output operands from L1 memory."""

        for output in self.get_all_outputs():
            if output.l1_address is None:
                raise ValueError(
                    f"Output operand '{output.name}' does not have an L1 address."
                )

            output_dimensions = output.dimensions
            output_format = output.data_format
            tile_cnt = output.tile_count
            tile_elements = output.tile_shape.total_tile_size()

            # Tiles are stored densely in L1 (one num_bytes_per_tile(tile_elements)
            # slot per tile). For full 32x32 tiles this equals the default stride
            # unpack_res_tiles assumes, but for sub-32x32 tiles (e.g. 16x32) the dense
            # stride is smaller. Passing it explicitly for sub-tiles keeps the 32x32
            # code path byte-identical while making unpack_res_tiles stride correctly
            # for tiny tiles (otherwise it strides at 32x32 and reads only the first
            # half of the tiles).
            tile_dense_bytes = output_format.num_bytes_per_tile(tile_elements)
            is_full_tile = (
                output.tile_shape.total_row_dim() == DEFAULT_TILE_R_DIM
                and output.tile_shape.total_col_dim() == DEFAULT_TILE_C_DIM
            )
            tile_stride_bytes = None if is_full_tile else tile_dense_bytes
            read_bytes_cnt = tile_dense_bytes * tile_cnt
            read_data = read_from_device(
                location, output.l1_address, num_bytes=read_bytes_cnt
            )

            res_from_l1 = unpack_res_tiles(
                read_data,
                output_format,
                tile_count=tile_cnt,
                sfpu=False,
                num_faces=output.tile_shape.total_num_faces(),
                face_r_dim=output.tile_shape.face_r_dim,
                tile_stride_bytes=tile_stride_bytes,
            )

            torch_format = format_dict[output_format]
            tilized_tensor = torch.tensor(res_from_l1, dtype=torch_format)

            raw_tensor = untilize_block(
                tilized_tensor,
                stimuli_format=output_format,
                dimensions=output_dimensions,
                num_faces=output.tile_shape.total_num_faces(),
                tile_dimensions=(
                    output.tile_shape.total_row_dim(),
                    output.tile_shape.total_col_dim(),
                ),
                face_r_dim=output.tile_shape.face_r_dim,
            )

            output._raw_data = raw_tensor

    def generate_cpp(self, dest_acc: bool):
        code = "// Inputs\n"
        for operand in self.operands.values():
            if not operand.is_output:
                code += operand.cpp_value(dest_acc)

        code += "// Outputs\n"
        for operand in self.operands.values():
            if operand.is_output:
                code += operand.cpp_value(dest_acc)

        return code
