# SPDX-FileCopyrightText: © 2026 Tenstorrent AI ULC
#
# SPDX-License-Identifier: Apache-2.0

from typing import List

from fuser.base_sfpu import Sfpu
from fuser.block_data import BlockData
from fuser.fuser_config import GlobalConfig
from fuser.golden.sfpu.binary import binary_golden
from fuser.indexing import InvocationGranularity
from fuser.l1_operation import L1Operation
from fuser.sfpu_node import SfpuNode
from helpers.llk_params import (
    ApproximationMode,
    MathOperation,
)


class BinarySfpu(Sfpu):
    granularity = InvocationGranularity.TILE
    input_count = 2
    golden_fn = staticmethod(binary_golden)

    def __init__(
        self,
        operation: MathOperation,
        approx_mode: ApproximationMode = ApproximationMode.No,
        iterations: int = 8,
        sign_magnitude: bool = True,
    ):
        if not operation in MathOperation.get_sfpu_binary_operations():
            raise ValueError(
                f"Operation {operation} is not a valid SFPU binary operation."
            )
        self.operation = operation
        self.approx_mode = approx_mode
        self.iterations = iterations
        self.sign_magnitude = sign_magnitude

    def get_headers(self) -> List[str]:
        return [
            "ckernel_defs.h",
            "ckernel_sfpu.h",
            "llk_math_common.h",
            "llk_math_eltwise_binary_sfpu.h",
            "sfpu_operations.h",
        ]

    def _format_arg(self, config: GlobalConfig) -> str:
        if self.operation == MathOperation.SfpuAddTopRow:
            return "0"
        return config.sentinel.sfpu_format

    def init(
        self,
        operation: L1Operation,
        config: GlobalConfig,
        compute_unit: SfpuNode,
        block: BlockData,
    ) -> str:
        stage = operation.stage_id
        op = f"ckernel::BinaryOp::{self.operation.cpp_enum_value}"
        approx_mode = self.approx_mode.cpp_enum_value
        dest_acc = config.dest_acc.cpp_enum_value
        iterations = self.iterations
        format = self._format_arg(config)

        return (
            f"    // Operation {stage}: Binary {self.operation.cpp_enum_value} SFPU\n"
            f"    test_utils::call_binary_sfpu_operation_init<{approx_mode}, {dest_acc}, {op}, {iterations}, {format}>();\n"
        )

    def calculate(
        self,
        operation: L1Operation,
        config: GlobalConfig,
        compute_unit: SfpuNode,
        block: BlockData,
    ) -> str:
        dest_sync = operation.dest_sync.cpp_enum_value
        op = f"ckernel::BinaryOp::{self.operation.cpp_enum_value}"
        approx_mode = self.approx_mode.cpp_enum_value
        dest_acc = config.dest_acc.cpp_enum_value
        iterations = self.iterations
        src1 = block.dest_src0
        src2 = block.dest_src1
        dst = block.tile_id_dest
        format = self._format_arg(config)
        vector_mode = self._vector_mode(operation)
        sign_magnitude = str(self.sign_magnitude).lower()

        return (
            f"    test_utils::call_binary_sfpu_operation<"
            f"{dest_sync}, {dest_acc}, "
            f"{approx_mode}, {op}, {iterations}, {format}, {sign_magnitude}"
            f">({src1} /* dst_index_in0 */, {src2} /* dst_index_in1 */, {dst} /* dst_index_out */, {vector_mode});\n"
        )

    def __str__(self) -> str:
        return f"BinarySfpu({self.operation})"
