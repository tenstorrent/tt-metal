# SPDX-FileCopyrightText: © 2026 Tenstorrent AI ULC
#
# SPDX-License-Identifier: Apache-2.0

from typing import List

from fuser.block_data import BlockData
from fuser.fpu_node import FpuNode
from fuser.fuser_config import GlobalConfig
from fuser.indexing import InvocationGranularity
from fuser.l1_operation import L1Operation

from .matmul import MatmulFpu


class MatmulNoMopFpu(MatmulFpu):
    granularity = InvocationGranularity.BLOCK
    per_block_init = True

    def get_headers(self) -> List[str]:
        return [
            "llk_math_common.h",
            "llk_math_matmul.h",
            "experimental/llk_math_matmul_custom_no_mop.h",
        ]

    def init(
        self,
        operation: L1Operation,
        config: GlobalConfig,
        compute_unit: FpuNode,
        block: BlockData,
    ) -> str:
        stage = operation.stage_id
        math_fidelity = compute_unit.math_fidelity.cpp_enum_value
        transpose = compute_unit.transpose_within_face.cpp_enum_value
        rt_dim = block.block_rows
        ct_dim = block.block_cols

        tile_r_dim_a = compute_unit.src_a.tile_shape.total_row_dim()
        tile_c_dim_a = compute_unit.src_a.tile_shape.total_col_dim()
        tile_r_dim_b = compute_unit.src_b.tile_shape.total_row_dim()
        tile_c_dim_b = compute_unit.src_b.tile_shape.total_col_dim()
        partial_face = compute_unit.src_a.partial_face.cpp_enum_value

        return (
            f"// Operation {stage}: MatmulNoMop FPU\n"
            f"_llk_math_matmul_init_no_mop_<{math_fidelity}>(\n"
            f"    {tile_r_dim_a}, {tile_c_dim_a}, {tile_r_dim_b}, {tile_c_dim_b}, {partial_face}, {transpose}, {ct_dim}, {rt_dim}\n"
            f");\n"
        )

    def calculate(
        self,
        operation: L1Operation,
        config: GlobalConfig,
        compute_unit: FpuNode,
        block: BlockData,
    ) -> str:
        math_fidelity = compute_unit.math_fidelity.cpp_enum_value
        rt_dim = block.block_rows
        ct_dim = block.block_cols
        num_cols = compute_unit.src_a.tile_shape.total_col_dim()
        kt_dim = compute_unit.src_a.dimensions[1] // num_cols
        tile_r_dim_a = compute_unit.src_a.tile_shape.total_row_dim()
        tile_c_dim_a = compute_unit.src_a.tile_shape.total_col_dim()
        tile_r_dim_b = compute_unit.src_b.tile_shape.total_row_dim()
        tile_c_dim_b = compute_unit.src_b.tile_shape.total_col_dim()
        partial_face = compute_unit.src_a.partial_face.cpp_enum_value

        return (
            f"for (std::uint32_t kt = 0; kt < {kt_dim}; kt++)\n"
            f"{{\n"
            f"    _llk_math_matmul_no_mop_<{math_fidelity}>("
            f"{block.tile_id_dest}, {ct_dim}, {rt_dim}, {tile_r_dim_a}, {tile_c_dim_a}, "
            f"{tile_r_dim_b}, {tile_c_dim_b}, {partial_face});\n"
            f"}}\n"
        )

    def uninit(
        self,
        operation: L1Operation,
        config: GlobalConfig,
        compute_unit: FpuNode,
        block: BlockData,
    ) -> str:
        return "_llk_math_matmul_uninit_no_mop_();\n"
