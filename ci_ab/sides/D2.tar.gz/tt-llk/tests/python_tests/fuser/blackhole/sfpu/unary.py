# SPDX-FileCopyrightText: © 2026 Tenstorrent AI ULC
#
# SPDX-License-Identifier: Apache-2.0

from typing import List

from fuser.base_sfpu import Sfpu
from fuser.block_data import BlockData
from fuser.fuser_config import GlobalConfig
from fuser.golden.sfpu.unary import unary_golden
from fuser.indexing import InvocationGranularity
from fuser.l1_operation import L1Operation
from fuser.sfpu_node import SfpuNode
from helpers.llk_params import (
    ApproximationMode,
    MathOperation,
)


class UnarySfpu(Sfpu):
    granularity = InvocationGranularity.TILE
    golden_fn = staticmethod(unary_golden)

    def __init__(
        self,
        operation: MathOperation,
        approx_mode: ApproximationMode = ApproximationMode.No,
        iterations: int = 8,
        fill_const_value=5,
    ):
        if not operation in MathOperation.get_sfpu_unary_operations():
            raise ValueError(
                f"Operation {operation} is not a valid SFPU unary operation."
            )
        self.iterations = iterations
        self.approx_mode = approx_mode
        self.operation = operation
        self.fill_const_value = fill_const_value

    def get_headers(self) -> List[str]:
        return [
            "ckernel_defs.h",
            "ckernel_sfpu.h",
            "llk_math_common.h",
            "llk_math_eltwise_unary_sfpu.h",
            "sfpu_operations.h",
        ]

    def init(
        self,
        operation: L1Operation,
        config: GlobalConfig,
        compute_unit: SfpuNode,
        block: BlockData,
    ) -> str:
        stage = operation.stage_id
        dest_acc = config.dest_acc.cpp_enum_value
        approx_mode = self.approx_mode.cpp_enum_value
        op = f"SfpuType::{self.operation.cpp_enum_value}"

        return (
            f"    // Operation {stage}: Unary {self.operation.cpp_enum_value} SFPU\n"
            f"    test_utils::call_unary_sfpu_operation_init<{op}, {approx_mode}, {dest_acc}, {self.iterations}>({config.sentinel.sfpu_format});\n"
        )

    def calculate(
        self,
        operation: L1Operation,
        config: GlobalConfig,
        compute_unit: SfpuNode,
        block: BlockData,
    ) -> str:
        dest_sync = operation.dest_sync.cpp_enum_value
        dest_acc = config.dest_acc.cpp_enum_value
        approx_mode = self.approx_mode.cpp_enum_value
        op = f"SfpuType::{self.operation.cpp_enum_value}"

        return (
            f"    test_utils::call_unary_sfpu_operation<"
            f"{dest_sync}, {dest_acc}, "
            f"{op}, {approx_mode}, {dest_acc}, {self.iterations}"
            f">({block.tile_id_dest}, {config.sentinel.sfpu_format}, {self.fill_const_value});\n"
        )

    def __str__(self) -> str:
        return f"UnarySfpu({self.operation})"
