# SPDX-FileCopyrightText: © 2026 Tenstorrent AI ULC
#
# SPDX-License-Identifier: Apache-2.0

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, List, Optional, Tuple, Union

from helpers.chip_architecture import ChipArchitecture
from helpers.data_format_inference import (
    infer_math_format,
    infer_pack_in,
    infer_unpack_out,
)
from helpers.format_config import DataFormat
from helpers.llk_params import EltwiseBinaryReuseDestType

if TYPE_CHECKING:
    from .fpu_node import FpuNode
    from .l1_operation import L1Operation
    from .fuser_config import GlobalConfig
    from .pack_node import PackNode

from .arch_common import fpu_common, pack_common, unpack_common
from .sfpu_node import SfpuNode


@dataclass
class FuserSentinel:
    """Tracks format state for unpack, math, and pack threads across a fused pipeline.

    Each format field is None until the first hw_configure call, then holds the
    currently configured DataFormat. Subsequent calls compare against the stored
    state and emit reconfig only when formats actually change.
    """

    _unpack_A_src: Optional[DataFormat] = field(default=None, init=False, repr=False)
    _unpack_A_dst: Optional[DataFormat] = field(default=None, init=False, repr=False)
    _unpack_B_src: Optional[DataFormat] = field(default=None, init=False, repr=False)
    _unpack_B_dst: Optional[DataFormat] = field(default=None, init=False, repr=False)

    _unpack_face_r_dim_a: Optional[int] = field(default=None, init=False, repr=False)
    _unpack_num_faces_a: Optional[int] = field(default=None, init=False, repr=False)
    _unpack_face_r_dim_b: Optional[int] = field(default=None, init=False, repr=False)
    _unpack_num_faces_b: Optional[int] = field(default=None, init=False, repr=False)

    _math_format: Optional[DataFormat] = field(default=None, init=False, repr=False)
    _sfpu_format: Optional[DataFormat] = field(default=None, init=False, repr=False)
    _dest_sources: dict = field(default_factory=dict, init=False, repr=False)

    _pack_src: Optional[DataFormat] = field(default=None, init=False, repr=False)
    _pack_dst: Optional[DataFormat] = field(default=None, init=False, repr=False)

    golden_math_format: Optional[DataFormat] = field(
        default=None, init=False, repr=False
    )
    golden_pack_src: Optional[DataFormat] = field(default=None, init=False, repr=False)

    def reset_unpack_formats(self):
        self._unpack_A_src = None
        self._unpack_A_dst = None
        self._unpack_B_src = None
        self._unpack_B_dst = None
        self._unpack_face_r_dim_a = None
        self._unpack_num_faces_a = None
        self._unpack_face_r_dim_b = None
        self._unpack_num_faces_b = None

    def reset_math_format(self):
        self._math_format = None

    def reset_pack_formats(self):
        self._pack_src = None
        self._pack_dst = None

    @staticmethod
    def _find_format_node(
        operation: "L1Operation",
    ) -> Optional["FpuNode"]:
        """Find the first FpuNode for format inference.

        In a pipeline with mixed FPU and SFPU nodes, only FPU nodes have src_a/src_b
        operands. SFPU nodes operate on data already in the dest register and don't
        drive format configuration.

        Returns:
            The first FpuNode, or None if all nodes are SFPU only.
        """
        from .fpu_node import FpuNode

        for node in operation.math_nodes:
            if isinstance(node, FpuNode) and node.src_a is not None:
                return node
        return None

    def prepare_operation(self, config, operation, blocks=None) -> None:
        from .pipeline_plan import plan_pipeline

        self._dest_sources = {}
        if blocks is None:
            blocks = plan_pipeline(operation, config.dest_acc.value)
        for block in blocks:
            for node, sources in block.dest_sources.items():
                self._dest_sources.setdefault(node, set()).update(sources)

    @staticmethod
    def _single_dest_format(formats, node) -> Optional[DataFormat]:
        if len(formats) > 1:
            raise ValueError(
                f"{type(node).__name__} requires multiple Dst formats: "
                f"{sorted(fmt.name for fmt in formats)}; split it into single-format nodes"
            )
        return next(iter(formats), None)

    def _dest_source_format(
        self,
        config: "GlobalConfig",
        operation: "L1Operation",
        compute_node,
    ) -> Optional[DataFormat]:
        output_format = operation._get_pack_nodes()[0].output.data_format
        formats = {
            self._infer_node_formats(config, source, output_format, operation)[4]
            for source in self._dest_sources.get(compute_node, ())
        }
        if config.dest_acc.value:
            formats = {
                DataFormat.Int32 if fmt.is_integer() else DataFormat.Float32
                for fmt in formats
            }
        return self._single_dest_format(formats, compute_node)

    def _get_src_formats(
        self,
        config: "GlobalConfig",
        compute_node: "FpuNode",
        output_format: DataFormat,
        operation: "L1Operation",
    ) -> Tuple[DataFormat, Optional[DataFormat]]:
        """Extract src_a and src_b data formats, handling DEST_TO_SRCA routing."""
        src_a_fmt = compute_node.src_a.data_format
        if compute_node.reuse_dest != EltwiseBinaryReuseDestType.NONE:
            dest_fmt = self._dest_source_format(config, operation, compute_node)
            if dest_fmt is None:
                dest_fmt = src_a_fmt
            if config.dest_acc.value:
                dest_fmt = (
                    DataFormat.Int32 if dest_fmt.is_integer() else DataFormat.Float32
                )
            dest_fmt = infer_unpack_out(dest_fmt, output_format, config.dest_acc)
            if compute_node.reuse_dest == EltwiseBinaryReuseDestType.DEST_TO_SRCA:
                return dest_fmt, src_a_fmt
            return src_a_fmt, dest_fmt
        if compute_node.src_b is not None:
            return src_a_fmt, compute_node.src_b.data_format
        return src_a_fmt, None

    def _infer_node_formats(
        self,
        config: "GlobalConfig",
        compute_node: "Union[FpuNode, SfpuNode]",
        output_format: DataFormat,
        operation: "L1Operation",
    ) -> Tuple[DataFormat, DataFormat, DataFormat, DataFormat, DataFormat, DataFormat]:
        """Infer all pipeline formats from a compute node's operands.

        Returns:
            (unpack_A_src, unpack_A_dst, unpack_B_src, unpack_B_dst, math_fmt, pack_src)
        """
        if isinstance(compute_node, SfpuNode):
            return self._infer_output_formats(
                config, output_format, operation._get_pack_nodes()[0].output.data_format
            )

        src_a_fmt, src_b_fmt = self._get_src_formats(
            config, compute_node, output_format, operation
        )
        if config.architecture == ChipArchitecture.QUASAR:
            # UInt16 is an SFPU access mode, not a Quasar unpack/math/pack encoding.
            src_a_fmt, src_b_fmt, output_format = (
                DataFormat.Int16 if fmt == DataFormat.UInt16 else fmt
                for fmt in (src_a_fmt, src_b_fmt, output_format)
            )
        unpack_to_dest = compute_node.unpack_to_dest.value
        dest_acc = config.dest_acc

        unpack_A_dst = infer_unpack_out(
            src_a_fmt, output_format, dest_acc, unpack_to_dest
        )
        if src_b_fmt is not None:
            unpack_B_src = src_b_fmt
            unpack_B_dst = infer_unpack_out(
                src_b_fmt, output_format, dest_acc, unpack_to_dest
            )
        else:
            unpack_B_src = src_a_fmt
            unpack_B_dst = unpack_A_dst

        math_fmt = infer_math_format(unpack_A_dst, unpack_B_dst)
        if math_fmt == DataFormat.Fp8_e4m3:
            math_fmt = DataFormat.Float16

        pack_src = infer_pack_in(
            src_a_fmt,
            output_format,
            math_fmt,
            dest_acc,
            unpack_to_dest,
            config.architecture,
        )
        if output_format == DataFormat.Fp8_e4m3:
            pack_src = (
                DataFormat.Float16_b if math_fmt.is_exponent_B() else DataFormat.Float16
            )

        return src_a_fmt, unpack_A_dst, unpack_B_src, unpack_B_dst, math_fmt, pack_src

    def _infer_output_formats(
        self,
        config: "GlobalConfig",
        output_format: DataFormat,
        input_format: Optional[DataFormat] = None,
    ) -> Tuple[DataFormat, DataFormat, DataFormat, DataFormat, DataFormat, DataFormat]:
        """Infer formats for SFPU only operations that have no input operands.

        Uses the output format as both input and output with unpacking_to_dest=True
        since SFPU operates directly on the dest register.

        Returns:
            (unpack_A_src, unpack_A_dst, unpack_B_src, unpack_B_dst, math_fmt, pack_src)
        """
        dest_acc = config.dest_acc
        if input_format is None:
            input_format = output_format

        unpack_dst = infer_unpack_out(
            input_format, output_format, dest_acc, unpacking_to_dest=True
        )

        math_fmt = infer_math_format(unpack_dst)
        if math_fmt == DataFormat.Fp8_e4m3:
            math_fmt = DataFormat.Float16

        pack_src = infer_pack_in(
            input_format,
            output_format,
            math_fmt,
            dest_acc,
            unpacking_to_dest=True,
            chip_arch=config.architecture,
        )
        if output_format == DataFormat.Fp8_e4m3:
            pack_src = (
                DataFormat.Float16_b if math_fmt.is_exponent_B() else DataFormat.Float16
            )

        return input_format, unpack_dst, input_format, unpack_dst, math_fmt, pack_src

    def _resolve_pack_formats(
        self,
        config: "GlobalConfig",
        operation: "L1Operation",
        pack_node: "PackNode",
    ) -> Tuple[DataFormat, DataFormat]:
        """Infer pack_src and pack_dst formats for a given pack node."""
        output_format = pack_node.output.data_format
        if (
            config.architecture == ChipArchitecture.QUASAR
            and output_format == DataFormat.UInt16
        ):
            output_format = DataFormat.Int16

        formats = {
            self._infer_node_formats(config, source, output_format, operation)[5]
            for source in self._dest_sources.get(pack_node, ())
        }
        pack_src = self._single_dest_format(formats, pack_node)
        if pack_src is None:
            _, _, _, _, _, pack_src = self._infer_output_formats(config, output_format)

        return pack_src, output_format

    # Properties for reading the current format state
    @property
    def unpack_a_src_format(self) -> str:
        return self._unpack_A_src.cpp_underlying_value

    @property
    def unpack_a_dst_format(self) -> str:
        return self._unpack_A_dst.cpp_underlying_value

    @property
    def unpack_b_src_format(self) -> str:
        return self._unpack_B_src.cpp_underlying_value

    @property
    def unpack_b_dst_format(self) -> str:
        return self._unpack_B_dst.cpp_underlying_value

    @property
    def math_format(self) -> str:
        return self._math_format.cpp_underlying_value

    @property
    def sfpu_format(self) -> str:
        return self._sfpu_format.cpp_underlying_value

    def configure_sfpu(self, config, operation, node) -> None:
        self._sfpu_format = self._dest_source_format(config, operation, node)

    def sfpu_math_reconfig(self, config, restore=False) -> str:
        if (
            config.skip_math_init
            or config.dest_acc.value
            or self._math_format == self._sfpu_format
        ):
            return ""
        old, new = self._math_format, self._sfpu_format
        if restore:
            old, new = new, old
        return fpu_common.configure_math(config.dest_acc.cpp_enum_value, old, new)

    @property
    def pack_src_format(self) -> str:
        return self._pack_src.cpp_underlying_value

    @property
    def pack_dst_format(self) -> str:
        return self._pack_dst.cpp_underlying_value

    def hw_configure_unpack(
        self,
        config: "GlobalConfig",
        operation: "L1Operation",
    ) -> str:
        """Emit _llk_unpack_hw_configure_ once for the first operation in the pipeline.

        Called at the top of each operation's unpack_body(). On the first call
        (when _unpack_A_src is None), emits the full hw_configure with tile shape
        parameters from the first node that has operand inputs.
        """
        compute_node = self._find_format_node(operation)
        if compute_node is None:
            return ""

        if self._unpack_A_src is not None:
            return ""

        output_format = operation._get_pack_nodes()[0].output.data_format
        unpack_A_src, unpack_A_dst, unpack_B_src, unpack_B_dst, _, _ = (
            self._infer_node_formats(config, compute_node, output_format, operation)
        )
        unpack_A_src, unpack_B_src = compute_node.unpacker.physical_order(
            unpack_A_src, unpack_B_src
        )
        unpack_A_dst, unpack_B_dst = compute_node.unpacker.physical_order(
            unpack_A_dst, unpack_B_dst
        )

        self._unpack_A_src = unpack_A_src
        self._unpack_A_dst = unpack_A_dst
        self._unpack_B_src = unpack_B_src
        self._unpack_B_dst = unpack_B_dst

        operand_a, operand_b = compute_node.unpacker.physical_operands(compute_node)
        self._unpack_face_r_dim_a = operand_a.tile_shape.face_r_dim
        self._unpack_num_faces_a = operand_a.tile_shape.total_num_faces()
        self._unpack_face_r_dim_b = operand_b.tile_shape.face_r_dim
        self._unpack_num_faces_b = operand_b.tile_shape.total_num_faces()

        return unpack_common.hw_configure_unpack(
            compute_node,
            config.dest_acc.cpp_enum_value,
            unpack_A_src,
            unpack_A_dst,
            unpack_B_src,
            unpack_B_dst,
        )

    def configure_unpack(
        self,
        config: "GlobalConfig",
        operation: "L1Operation",
        compute_node: "FpuNode",
    ) -> str:
        """Emit unpack reconfig calls when formats or tile shapes change between compute nodes.

        Called per node from FpuNode.unpack_configure() inside the tile loop. Compares
        the node's inferred formats and tile shape against the currently configured state
        and emits _llk_unpack_reconfig_data_format_src{a,b}_impl_ for channels that changed.
        When tile shapes differ, uses FACE_ROW_MAJOR to reprogram dim/stride registers.
        """
        if compute_node.src_a is None:
            return ""

        output_format = operation._get_pack_nodes()[0].output.data_format
        new_A_src, new_A_dst, new_B_src, new_B_dst, _, _ = self._infer_node_formats(
            config, compute_node, output_format, operation
        )
        new_A_src, new_B_src = compute_node.unpacker.physical_order(
            new_A_src, new_B_src
        )
        new_A_dst, new_B_dst = compute_node.unpacker.physical_order(
            new_A_dst, new_B_dst
        )

        operand_a, operand_b = compute_node.unpacker.physical_operands(compute_node)
        new_face_r_dim_a = operand_a.tile_shape.face_r_dim
        new_num_faces_a = operand_a.tile_shape.total_num_faces()
        new_face_r_dim_b = operand_b.tile_shape.face_r_dim
        new_num_faces_b = operand_b.tile_shape.total_num_faces()

        srca_fmt_changed = (
            self._unpack_A_src != new_A_src or self._unpack_A_dst != new_A_dst
        )
        srcb_fmt_changed = (
            self._unpack_B_src != new_B_src or self._unpack_B_dst != new_B_dst
        )
        srca_tile_changed = (
            self._unpack_face_r_dim_a != new_face_r_dim_a
            or self._unpack_num_faces_a != new_num_faces_a
        )
        srcb_tile_changed = (
            self._unpack_face_r_dim_b != new_face_r_dim_b
            or self._unpack_num_faces_b != new_num_faces_b
        )

        srca_changed = srca_fmt_changed or srca_tile_changed
        srcb_changed = srcb_fmt_changed or srcb_tile_changed

        if not (srca_changed or srcb_changed):
            return ""

        code = unpack_common.configure_unpack(
            compute_node,
            config.dest_acc.cpp_enum_value,
            self._unpack_A_src,
            new_A_src,
            new_A_dst,
            self._unpack_B_src,
            new_B_src,
            new_B_dst,
            srca_changed,
            srcb_changed,
            srca_tile_changed,
            srcb_tile_changed,
        )

        self._unpack_A_src = new_A_src
        self._unpack_A_dst = new_A_dst
        self._unpack_B_src = new_B_src
        self._unpack_B_dst = new_B_dst
        self._unpack_face_r_dim_a = new_face_r_dim_a
        self._unpack_num_faces_a = new_num_faces_a
        self._unpack_face_r_dim_b = new_face_r_dim_b
        self._unpack_num_faces_b = new_num_faces_b
        return code

    def hw_configure_math(
        self,
        config: "GlobalConfig",
        operation: "L1Operation",
    ) -> str:
        """Emit _llk_math_hw_configure_ once for the first operation in the pipeline.

        For SFPU only operations (no node with src_a), infers a format compatible
        with the output so the math hardware is always configured.
        """
        if self._math_format is not None:
            return ""

        output_format = operation._get_pack_nodes()[0].output.data_format
        compute_node = self._find_format_node(operation)
        if compute_node is not None:
            _, _, _, _, math_fmt, _ = self._infer_node_formats(
                config, compute_node, output_format, operation
            )
        else:
            _, _, _, _, math_fmt, _ = self._infer_output_formats(config, output_format)

        self._math_format = math_fmt

        return fpu_common.hw_configure_math(config.dest_acc.cpp_enum_value, math_fmt)

    def configure_math(
        self,
        config: "GlobalConfig",
        operation: "L1Operation",
        compute_node: "FpuNode",
    ) -> str:
        """Emit math reconfig when the math format changes between compute nodes.

        Called per node from FpuNode.math_configure() inside the tile loop.
        """
        if compute_node.src_a is None:
            return ""

        output_format = operation._get_pack_nodes()[0].output.data_format
        _, _, _, _, new_math, _ = self._infer_node_formats(
            config, compute_node, output_format, operation
        )

        if self._math_format == new_math:
            return ""

        code = fpu_common.configure_math(
            config.dest_acc.cpp_enum_value, self._math_format, new_math
        )

        self._math_format = new_math
        return code

    def hw_configure_pack(
        self,
        config: "GlobalConfig",
        operation: "L1Operation",
        pack_nodes: List["PackNode"],
    ) -> str:
        """Emit _llk_pack_hw_configure_ once for the first operation in the pipeline.

        Called at the top of each operation's pack_body(). On the first call
        (when _pack_src is None), emits the full hw_configure for the first
        pack_node's format and sets sentinel state. Subsequent operations
        rely on configure_pack() to emit reconfig as needed.
        """
        if self._pack_src is not None:
            return ""

        first = pack_nodes[0]
        pack_src, pack_dst = self._resolve_pack_formats(config, operation, first)

        code = pack_common.hw_configure_pack(
            first.output,
            config.dest_acc.cpp_enum_value,
            pack_src,
            pack_dst,
            pack_mode=operation.bh_tilize.pack_mode_value,
        )

        self._pack_src = pack_src
        self._pack_dst = pack_dst

        return code

    def configure_pack(
        self,
        config: "GlobalConfig",
        operation: "L1Operation",
        pack_node: "PackNode",
    ) -> str:
        """Update pack format state for a specific pack node and emit reconfig if needed.

        Called from PackNode.configure() before packer.init() and _relu_config()
        so that each pack node reads its own correct formats from the sentinel.
        """
        pack_src, pack_dst = self._resolve_pack_formats(config, operation, pack_node)

        if self._pack_src == pack_src and self._pack_dst == pack_dst:
            return ""

        code = pack_common.configure_pack(
            pack_node.output,
            config.dest_acc.cpp_enum_value,
            pack_src,
            pack_dst,
        )

        self._pack_src = pack_src
        self._pack_dst = pack_dst
        return code

    def configure_golden(
        self,
        config: "GlobalConfig",
        operation: "L1Operation",
        compute_node=None,
        output_format: DataFormat = DataFormat.Float16_b,
    ):
        """Compute and store format values for golden generation.

        Called per compute node during golden computation. When called without
        a compute_node (at operation start), initializes from the first format
        node or from the output format. Dst readers resolve the formats of their
        actual producers, and packs resolve their own input format.
        """
        from .fpu_node import FpuNode
        from .pack_node import PackNode

        if isinstance(compute_node, PackNode):
            self.golden_pack_src, _ = self._resolve_pack_formats(
                config, operation, compute_node
            )
            return

        if compute_node is None:
            fmt_node = self._find_format_node(operation)
            if fmt_node is not None:
                _, _, _, _, math_fmt, pack_src = self._infer_node_formats(
                    config, fmt_node, output_format, operation
                )
            else:
                _, _, _, _, math_fmt, pack_src = self._infer_output_formats(
                    config, output_format
                )
            self.golden_math_format = math_fmt
            self.golden_pack_src = pack_src
            return

        if not isinstance(compute_node, FpuNode) or compute_node.src_a is None:
            self.golden_math_format = self._dest_source_format(
                config, operation, compute_node
            )
            return

        _, _, _, _, math_fmt, pack_src = self._infer_node_formats(
            config, compute_node, output_format, operation
        )
        self.golden_math_format = math_fmt
        self.golden_pack_src = pack_src
