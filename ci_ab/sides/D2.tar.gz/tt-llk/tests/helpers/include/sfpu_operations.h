// SPDX-FileCopyrightText: © 2026 Tenstorrent USA, Inc.
//
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include <cstdint>

#include "ckernel_sfpu.h"
#include "llk_sfpu/ckernel_sfpu_add_top_row.h"
#include "llk_sfpu/llk_math_eltwise_binary_sfpu_macros.h"
#include "llk_sfpu/llk_math_eltwise_ternary_sfpu_macros.h"
#include "llk_sfpu/llk_math_eltwise_unary_sfpu_macros.h"
#include "sfpu/ckernel_sfpu_topk.h"

// To add a new metal SFPU operation:
// 1. Include the metal header below: #include "llk_sfpu/<operation>.h"
// 2. Add the operation enum to SfpuType in llk_sfpu_types.h
// 3. Add the if constexpr branches in call_unary_sfpu_operation_init() and call_unary_sfpu_operation() below
#include "ckernel_sfpu_where.h"
#include "llk_sfpu/ckernel_sfpu_abs.h"
#include "llk_sfpu/ckernel_sfpu_activations.h"
#include "llk_sfpu/ckernel_sfpu_add1.h"
#include "llk_sfpu/ckernel_sfpu_addcdiv.h"
#include "llk_sfpu/ckernel_sfpu_addcmul.h"
#include "llk_sfpu/ckernel_sfpu_atan2.h"
#include "llk_sfpu/ckernel_sfpu_binary.h"
#include "llk_sfpu/ckernel_sfpu_binary_bitwise.h"
#include "llk_sfpu/ckernel_sfpu_binary_comp.h"
#include "llk_sfpu/ckernel_sfpu_binary_fmod.h"
#include "llk_sfpu/ckernel_sfpu_binary_max_min.h"
#include "llk_sfpu/ckernel_sfpu_binary_remainder.h"
#include "llk_sfpu/ckernel_sfpu_bitwise_not.h"
#include "llk_sfpu/ckernel_sfpu_cast_fp32_to_fp16a.h"
#include "llk_sfpu/ckernel_sfpu_cbrt.h"
#include "llk_sfpu/ckernel_sfpu_clamp.h"
// Metal comparison-to-zero / unary-int-compare kernels (calculate_comp,
// calculate_comp_int, calculate_comp_uint16, calculate_eqz_uint32,
// calculate_nez_uint32, calculate_comp_unary_int + their *_init). Distinct from
// the tt-llk sfpu/ckernel_sfpu_comp.h (_calculate_zero_comp_ etc.) included
// below; the two share no symbol names so both can coexist.
#include "llk_sfpu/ckernel_sfpu_binop_with_unary.h"
#include "llk_sfpu/ckernel_sfpu_celu.h"
#include "llk_sfpu/ckernel_sfpu_comp.h"
#include "llk_sfpu/ckernel_sfpu_digamma.h"
#include "llk_sfpu/ckernel_sfpu_div_int32.h"
#include "llk_sfpu/ckernel_sfpu_div_int32_floor.h"
#include "llk_sfpu/ckernel_sfpu_elu.h"
#include "llk_sfpu/ckernel_sfpu_erf.h"
#include "llk_sfpu/ckernel_sfpu_erfc.h"
#include "llk_sfpu/ckernel_sfpu_erfinv.h"
#include "llk_sfpu/ckernel_sfpu_exp.h"
#include "llk_sfpu/ckernel_sfpu_exp2.h"
#include "llk_sfpu/ckernel_sfpu_expm1.h"
#include "llk_sfpu/ckernel_sfpu_fmod.h"
#include "llk_sfpu/ckernel_sfpu_gcd.h"
#include "llk_sfpu/ckernel_sfpu_gelu.h"
#include "llk_sfpu/ckernel_sfpu_hardmish.h"
#include "llk_sfpu/ckernel_sfpu_hardshrink.h"
#include "llk_sfpu/ckernel_sfpu_hardtanh.h"
#include "llk_sfpu/ckernel_sfpu_heaviside.h"
#include "llk_sfpu/ckernel_sfpu_i0.h"
#include "llk_sfpu/ckernel_sfpu_i1.h"
#include "llk_sfpu/ckernel_sfpu_identity.h"
#include "llk_sfpu/ckernel_sfpu_isclose.h"
#include "llk_sfpu/ckernel_sfpu_lcm.h"
#include "llk_sfpu/ckernel_sfpu_lerp.h"
#include "llk_sfpu/ckernel_sfpu_lgamma.h"
#include "llk_sfpu/ckernel_sfpu_log.h"
#include "llk_sfpu/ckernel_sfpu_log1p.h"
#include "llk_sfpu/ckernel_sfpu_logaddexp.h"
#include "llk_sfpu/ckernel_sfpu_logaddexp2.h"
#include "llk_sfpu/ckernel_sfpu_logical_not.h"
#include "llk_sfpu/ckernel_sfpu_logsigmoid.h"
#include "llk_sfpu/ckernel_sfpu_mask.h"
#include "llk_sfpu/ckernel_sfpu_mish.h"
#include "llk_sfpu/ckernel_sfpu_mul_int32.h"
#include "llk_sfpu/ckernel_sfpu_negative.h"
#include "llk_sfpu/ckernel_sfpu_polygamma.h"
#include "llk_sfpu/ckernel_sfpu_prelu.h"
#include "llk_sfpu/ckernel_sfpu_rdiv.h"
#include "llk_sfpu/ckernel_sfpu_recip.h"
#include "llk_sfpu/ckernel_sfpu_remainder.h"
#include "llk_sfpu/ckernel_sfpu_rpow.h"
#include "llk_sfpu/ckernel_sfpu_rsqrt.h"
#include "llk_sfpu/ckernel_sfpu_rsub_int32.h"
#include "llk_sfpu/ckernel_sfpu_selu.h"
#include "llk_sfpu/ckernel_sfpu_shift.h"
#include "llk_sfpu/ckernel_sfpu_sigmoid.h"
#include "llk_sfpu/ckernel_sfpu_sigmoid_appx.h"
#include "llk_sfpu/ckernel_sfpu_sign.h"
#include "llk_sfpu/ckernel_sfpu_signbit.h"
#include "llk_sfpu/ckernel_sfpu_silu.h"
#include "llk_sfpu/ckernel_sfpu_snake_beta.h"
#include "llk_sfpu/ckernel_sfpu_softplus.h"
#include "llk_sfpu/ckernel_sfpu_softshrink.h"
#include "llk_sfpu/ckernel_sfpu_softsign.h"
#include "llk_sfpu/ckernel_sfpu_sqrt.h"
#include "llk_sfpu/ckernel_sfpu_sqrt_custom.h"
#include "llk_sfpu/ckernel_sfpu_square.h"
#include "llk_sfpu/ckernel_sfpu_tanh.h"
#include "llk_sfpu/ckernel_sfpu_tanh_derivative.h"
#include "llk_sfpu/ckernel_sfpu_tanhshrink.h"
#include "llk_sfpu/ckernel_sfpu_trigonometry.h"
#include "llk_sfpu/ckernel_sfpu_typecast.h"
#include "llk_sfpu/ckernel_sfpu_unary_comp.h"
#include "llk_sfpu/ckernel_sfpu_unary_max_min.h"
#include "llk_sfpu/ckernel_sfpu_unary_power.h"
#include "llk_sfpu/ckernel_sfpu_unary_shift.h"
#include "llk_sfpu/ckernel_sfpu_xielu.h"
#include "sfpu/ckernel_sfpu_add_int.h"
#include "sfpu/ckernel_sfpu_comp.h"
#include "sfpu/ckernel_sfpu_expm1_cw.h"
#include "sfpu/ckernel_sfpu_fill.h"
#include "sfpu/ckernel_sfpu_isinf_isnan.h"
#include "sfpu/ckernel_sfpu_relu.h"
#include "sfpu/ckernel_sfpu_rounding_ops.h"
#include "sfpu/ckernel_sfpu_sub_int.h"
#include "sfpu/ckernel_sfpu_tanh_derivative.h"
#include "sfpu/ckernel_sfpu_threshold.h"

// Test-only SFPU loop/adapter wrappers (calculate_sqrt_custom, calculate_expm1_cw,
// calculate_mask_binary) used by the dispatch below.
#include "sfpu_test_helpers.h"

namespace ckernel::sfpu
{

// exp_with_base's scale, 0.5 (base b = e^0.5). bf16 for the calculate call's SFPMULI
// immediate; the same bits shifted into fp32 for exp_init, which bakes the scale into the
// approximate clamp path's constants. Mirrored as EXP_WITH_BASE_SCALE in
// sfpu_dispatch_constants.py, which the golden reads.
constexpr std::uint32_t EXP_WITH_BASE_SCALE_BF16 = 0x3F00u;
constexpr std::uint32_t EXP_WITH_BASE_SCALE_FP32 = EXP_WITH_BASE_SCALE_BF16 << 16;

// The approximate clamp path of calculate_exponential is hand-unrolled for 8 rows and
// ignores ITERATIONS (tt-llk#1486), so its callers run it per face over all four faces.
constexpr int EXP_APPROX_CLAMP_ITERATIONS = 8;

template <bool APPROXIMATION_MODE, bool IS_FP32_DEST_ACC_EN, int ITERATIONS, bool CLAMP_NEGATIVE, std::uint32_t EXP_BASE_SCALE_FACTOR>
inline __attribute__((always_inline)) void calculate_exponential_const_scale()
{
    calculate_exponential<APPROXIMATION_MODE, IS_FP32_DEST_ACC_EN, true /* SCALE_EN */, ITERATIONS, CLAMP_NEGATIVE>(EXP_BASE_SCALE_FACTOR);
}

} // namespace ckernel::sfpu

namespace test_utils
{
using namespace ckernel;
using namespace ckernel::sfpu;

//
// SFPU typecast dispatch.
//
// Unlike the other unary SFPU operations (which are keyed by a single SfpuType),
// typecast selects one of ~25 `calculate_typecast_*` primitives based on the
// (input, output) DataFormat pair. The two helpers below are a faithful,
// parametrized mirror of the production compute API `typecast_tile<IN, OUT>` /
// `typecast_tile_init<IN, OUT>` (tt_metal/hw/inc/api/compute/eltwise_unary/typecast.h),
// rewritten to take explicit template parameters instead of the ambient
// compute-kernel macros. They call the *exact same* `init_typecast_*` /
// `calculate_typecast_*` LLK primitives through the same SFPU_UNARY_* macros
// production uses. Pairs realised purely by unpacker/packer format conversion
// issue no SFPU call: they simply match no branch in the calculate helper (the
// init helper still falls through to the bare `SFPU_UNARY_INIT(typecast)`).
//
// These are reached through the shared `call_unary_sfpu_operation[_init]`
// dispatch below via `SfpuType::typecast` (with IN/OUT supplied as the trailing
// template parameters). Keep this dispatch in lockstep with typecast.h.
//
template <DataFormat IN, DataFormat OUT, bool APPROX_MODE, bool DST_ACCUM_MODE>
void call_unary_typecast_operation_init()
{
    if constexpr (IN == DataFormat::Float32 && OUT == DataFormat::Float16_b)
    {
        SFPU_UNARY_INIT_FN(typecast, sfpu::init_typecast_fp32_to_fp16b, (APPROX_MODE));
    }
    else if constexpr (IN == DataFormat::UInt16 && (OUT == DataFormat::UInt32 || OUT == DataFormat::Int32))
    {
        SFPU_UNARY_INIT_FN(typecast, sfpu::init_typecast_uint16_to_uint32, (APPROX_MODE));
    }
    else if constexpr (IN == DataFormat::UInt32 && OUT == DataFormat::UInt16)
    {
        SFPU_UNARY_INIT_FN(typecast, sfpu::init_typecast_uint32_to_uint16, (APPROX_MODE));
    }
    else if constexpr (IN == DataFormat::Int32 && OUT == DataFormat::UInt16)
    {
        SFPU_UNARY_INIT_FN(typecast, sfpu::init_typecast_int32_to_uint16, (APPROX_MODE));
    }
    else if constexpr (IN == DataFormat::UInt32 && OUT == DataFormat::Float32)
    {
        SFPU_UNARY_INIT_FN(typecast, sfpu::init_typecast_uint32_to_fp32, (APPROX_MODE));
    }
    else if constexpr (IN == DataFormat::Int32 && OUT == DataFormat::Float32)
    {
        SFPU_UNARY_INIT_FN(typecast, sfpu::init_typecast_int32_to_fp32, (APPROX_MODE));
    }
    else if constexpr (IN == DataFormat::UInt16 && OUT == DataFormat::Float32)
    {
        SFPU_UNARY_INIT_FN(typecast, sfpu::init_typecast_uint16_to_fp32, (APPROX_MODE));
    }
    else if constexpr (IN == DataFormat::UInt16 && (OUT == DataFormat::Float16_b || OUT == DataFormat::Bfp8_b || OUT == DataFormat::Bfp4_b))
    {
        SFPU_UNARY_INIT_FN(typecast, sfpu::init_typecast_uint16_to_fp16b, (APPROX_MODE));
    }
    else if constexpr (IN == DataFormat::Int32 && (OUT == DataFormat::Float16_b || OUT == DataFormat::Bfp8_b || OUT == DataFormat::Bfp4_b))
    {
        SFPU_UNARY_INIT_FN(typecast, sfpu::init_typecast_int32_to_fp16b, (APPROX_MODE));
    }
    else if constexpr (IN == DataFormat::UInt32 && (OUT == DataFormat::Float16_b || OUT == DataFormat::Bfp8_b || OUT == DataFormat::Bfp4_b))
    {
        SFPU_UNARY_INIT_FN(typecast, sfpu::init_typecast_uint32_to_fp16b, (APPROX_MODE));
    }
    else if constexpr (
        (IN == DataFormat::Float32 || IN == DataFormat::Float16_b || IN == DataFormat::Bfp8_b || IN == DataFormat::Bfp4_b) && OUT == DataFormat::UInt16)
    {
        SFPU_UNARY_INIT_FN(typecast, sfpu::init_typecast_fp32_to_uint16, (APPROX_MODE));
    }
    else if constexpr (
        (IN == DataFormat::Float32 || IN == DataFormat::Float16_b || IN == DataFormat::Bfp8_b || IN == DataFormat::Bfp4_b) && OUT == DataFormat::UInt8)
    {
        SFPU_UNARY_INIT_FN(typecast, sfpu::init_typecast_fp32_to_uint8, (APPROX_MODE));
    }
    else if constexpr ((IN == DataFormat::Int32 || IN == DataFormat::UInt32 || IN == DataFormat::UInt16) && OUT == DataFormat::UInt8)
    {
        SFPU_UNARY_INIT_FN(typecast, sfpu::init_typecast_uint_to_uint8, (APPROX_MODE));
    }
    else if constexpr (IN == DataFormat::UInt8 && OUT == DataFormat::Float32)
    {
        SFPU_UNARY_INIT_FN(typecast, sfpu::init_typecast_uint32_to_fp32, (APPROX_MODE));
    }
    else if constexpr (IN == DataFormat::UInt8 && (OUT == DataFormat::Float16_b || OUT == DataFormat::Bfp8_b || OUT == DataFormat::Bfp4_b))
    {
        SFPU_UNARY_INIT_FN(typecast, sfpu::init_typecast_uint32_to_fp16b, (APPROX_MODE));
    }
    else if constexpr (IN == DataFormat::UInt8 && OUT == DataFormat::UInt16)
    {
        SFPU_UNARY_INIT_FN(typecast, sfpu::init_typecast_uint32_to_uint16, (APPROX_MODE));
    }
    else
    {
        // Pairs handled purely by unpacker/packer (no SFPU math) or that need
        // no per-op programming still issue the bare init so the SFPU is in a
        // defined state, exactly like the production `else` branch.
        SFPU_UNARY_INIT(typecast);
    }
}

template <DstSync DST_SYNC_MODE, bool DST_ACCUM_MODE, DataFormat IN, DataFormat OUT, bool APPROX_MODE, int ITERATIONS = 8>
void call_unary_typecast_operation(std::uint32_t dst_index)
{
    if constexpr (IN == DataFormat::Float16_b && OUT == DataFormat::UInt16)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_typecast_fp32_to_uint16, (APPROX_MODE, ITERATIONS, DST_ACCUM_MODE), dst_index, VectorMode::RC);
    }
    else if constexpr (IN == DataFormat::UInt16 && OUT == DataFormat::Float16_b)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_typecast_uint16_to_fp16b, (APPROX_MODE, ITERATIONS), dst_index, VectorMode::RC);
    }
    else if constexpr (IN == DataFormat::Int32 && OUT == DataFormat::Float16_b)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_typecast_int32_to_fp16b, (APPROX_MODE, ITERATIONS), dst_index, VectorMode::RC);
    }
    else if constexpr (IN == DataFormat::Float16_b && OUT == DataFormat::Int32)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_typecast_fp32_to_int32, (APPROX_MODE, ITERATIONS), dst_index, VectorMode::RC);
    }
    else if constexpr (IN == DataFormat::Float32 && OUT == DataFormat::Float16_b)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_typecast_fp32_to_fp16b, (APPROX_MODE, ITERATIONS), dst_index, VectorMode::RC);
    }
    else if constexpr (IN == DataFormat::Float32 && OUT == DataFormat::UInt16)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_typecast_fp32_to_uint16, (APPROX_MODE, ITERATIONS, DST_ACCUM_MODE), dst_index, VectorMode::RC);
    }
    else if constexpr (IN == DataFormat::UInt16 && OUT == DataFormat::Float32)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_typecast_uint16_to_fp32, (APPROX_MODE, ITERATIONS, DST_ACCUM_MODE), dst_index, VectorMode::RC);
    }
    else if constexpr (IN == DataFormat::Float32 && OUT == DataFormat::Int32)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_typecast_fp32_to_int32, (APPROX_MODE, ITERATIONS), dst_index, VectorMode::RC);
    }
    else if constexpr (IN == DataFormat::Int32 && OUT == DataFormat::Float32)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_typecast_int32_to_fp32, (APPROX_MODE, ITERATIONS), dst_index, VectorMode::RC);
    }
    else if constexpr (IN == DataFormat::Bfp8_b && OUT == DataFormat::UInt16)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_typecast_fp32_to_uint16, (APPROX_MODE, ITERATIONS, DST_ACCUM_MODE), dst_index, VectorMode::RC);
    }
    else if constexpr (IN == DataFormat::UInt16 && OUT == DataFormat::Bfp8_b)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_typecast_uint16_to_fp16b, (APPROX_MODE, ITERATIONS), dst_index, VectorMode::RC);
    }
    else if constexpr (IN == DataFormat::Bfp8_b && OUT == DataFormat::Int32)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_typecast_fp32_to_int32, (APPROX_MODE, ITERATIONS), dst_index, VectorMode::RC);
    }
    else if constexpr (IN == DataFormat::Int32 && OUT == DataFormat::Bfp8_b)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_typecast_int32_to_fp16b, (APPROX_MODE, ITERATIONS), dst_index, VectorMode::RC);
    }
    else if constexpr (IN == DataFormat::Float16_b && OUT == DataFormat::UInt32)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_typecast_fp32_to_uint32, (APPROX_MODE, ITERATIONS), dst_index, VectorMode::RC);
    }
    else if constexpr (IN == DataFormat::UInt32 && OUT == DataFormat::Float16_b)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_typecast_uint32_to_fp16b, (APPROX_MODE, ITERATIONS), dst_index, VectorMode::RC);
    }
    else if constexpr (IN == DataFormat::Float32 && OUT == DataFormat::UInt32)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_typecast_fp32_to_uint32, (APPROX_MODE, ITERATIONS), dst_index, VectorMode::RC);
    }
    else if constexpr (IN == DataFormat::UInt32 && OUT == DataFormat::Float32)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_typecast_uint32_to_fp32, (APPROX_MODE, ITERATIONS), dst_index, VectorMode::RC);
    }
    else if constexpr (IN == DataFormat::Bfp8_b && OUT == DataFormat::UInt32)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_typecast_fp32_to_uint32, (APPROX_MODE, ITERATIONS), dst_index, VectorMode::RC);
    }
    else if constexpr (IN == DataFormat::UInt32 && OUT == DataFormat::Bfp8_b)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_typecast_uint32_to_fp16b, (APPROX_MODE, ITERATIONS), dst_index, VectorMode::RC);
    }
    else if constexpr (IN == DataFormat::UInt16 && OUT == DataFormat::UInt32)
    {
        SFPU_UNARY_CALL(
            DST_SYNC_MODE, DST_ACCUM_MODE, calculate_typecast_uint16_to_uint32, (APPROX_MODE, ITERATIONS, DST_ACCUM_MODE), dst_index, VectorMode::RC);
    }
    else if constexpr (IN == DataFormat::UInt16 && OUT == DataFormat::Int32)
    {
        // Calls same kernel as the UInt32 case.
        SFPU_UNARY_CALL(
            DST_SYNC_MODE, DST_ACCUM_MODE, calculate_typecast_uint16_to_uint32, (APPROX_MODE, ITERATIONS, DST_ACCUM_MODE), dst_index, VectorMode::RC);
    }
    else if constexpr (IN == DataFormat::UInt32 && OUT == DataFormat::UInt16)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_typecast_uint32_to_uint16, (APPROX_MODE, ITERATIONS), dst_index, VectorMode::RC);
    }
    else if constexpr (IN == DataFormat::Int32 && OUT == DataFormat::UInt16)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_typecast_int32_to_uint16, (APPROX_MODE, ITERATIONS), dst_index, VectorMode::RC);
    }
    else if constexpr (IN == DataFormat::Bfp4_b && OUT == DataFormat::UInt16)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_typecast_fp32_to_uint16, (APPROX_MODE, ITERATIONS, DST_ACCUM_MODE), dst_index, VectorMode::RC);
    }
    else if constexpr (IN == DataFormat::UInt16 && OUT == DataFormat::Bfp4_b)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_typecast_uint16_to_fp16b, (APPROX_MODE, ITERATIONS), dst_index, VectorMode::RC);
    }
    else if constexpr (IN == DataFormat::Bfp4_b && OUT == DataFormat::Int32)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_typecast_fp32_to_int32, (APPROX_MODE, ITERATIONS), dst_index, VectorMode::RC);
    }
    else if constexpr (IN == DataFormat::Int32 && OUT == DataFormat::Bfp4_b)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_typecast_int32_to_fp16b, (APPROX_MODE, ITERATIONS), dst_index, VectorMode::RC);
    }
    else if constexpr (IN == DataFormat::Bfp4_b && OUT == DataFormat::UInt32)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_typecast_fp32_to_uint32, (APPROX_MODE, ITERATIONS), dst_index, VectorMode::RC);
    }
    else if constexpr (IN == DataFormat::UInt32 && OUT == DataFormat::Bfp4_b)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_typecast_uint32_to_fp16b, (APPROX_MODE, ITERATIONS), dst_index, VectorMode::RC);
    }
    else if constexpr (
        (IN == DataFormat::Float32 || IN == DataFormat::Float16_b || IN == DataFormat::Bfp8_b || IN == DataFormat::Bfp4_b) && OUT == DataFormat::UInt8)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_typecast_fp32_to_uint8, (APPROX_MODE, ITERATIONS), dst_index, VectorMode::RC);
    }
    else if constexpr ((IN == DataFormat::Int32 || IN == DataFormat::UInt32 || IN == DataFormat::UInt16) && OUT == DataFormat::UInt8)
    {
        SFPU_UNARY_CALL(
            DST_SYNC_MODE, DST_ACCUM_MODE, calculate_typecast_uint_to_uint8, (APPROX_MODE, ITERATIONS, (IN == DataFormat::UInt16)), dst_index, VectorMode::RC);
    }
    else if constexpr (IN == DataFormat::UInt8 && OUT == DataFormat::Float32)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_typecast_uint32_to_fp32, (APPROX_MODE, ITERATIONS), dst_index, VectorMode::RC);
    }
    else if constexpr (IN == DataFormat::UInt8 && (OUT == DataFormat::Float16_b || OUT == DataFormat::Bfp8_b || OUT == DataFormat::Bfp4_b))
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_typecast_uint32_to_fp16b, (APPROX_MODE, ITERATIONS), dst_index, VectorMode::RC);
    }
    else if constexpr (IN == DataFormat::UInt8 && OUT == DataFormat::UInt16)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_typecast_uint32_to_uint16, (APPROX_MODE, ITERATIONS), dst_index, VectorMode::RC);
    }
}

/**
 * Calls only the init portion of a unary SFPU operation.
 * Must be paired with a subsequent call_unary_sfpu_operation() for the calculate step.
 * Delegates to llk_math_eltwise_unary_sfpu_init: the two-arg overload runs
 * _llk_math_eltwise_unary_sfpu_init_ then the per-operation init lambda;
 * the zero-arg overload runs only _llk_math_eltwise_unary_sfpu_init_.
 *
 * Note: `OPERATION` is a template parameter rather than a literal enumerator,
 * so the SFPU_UNARY_INIT* macros (which token-paste `::SfpuType::OP`) cannot be
 * used here — we call `llk_math_eltwise_unary_sfpu_init<OPERATION>(...)`
 * directly, which is exactly what those macros expand to.
 *
 * @tparam OPERATION The SFPU operation type to initialize
 * @tparam APPROX_MODE Whether to use approximation mode for the SFPU operation
 * @tparam is_fp32_dest_acc_en Whether the destination accumulator is in FP32 mode
 * @tparam ITERATIONS Number of SFPU iterations (typically 32 for full tile)
 * @param math_format Math format of the paired call_unary_sfpu_operation(); pass the same value so a
 *        format-selected body runs under its own init
 */
template <
    SfpuType OPERATION,
    bool APPROX_MODE,
    bool is_fp32_dest_acc_en,
    int ITERATIONS,
    bool FAST_MODE          = false,
    bool STABLE_SORT        = false,
    bool CLAMP_NEGATIVE     = false,
    DataFormat TYPECAST_IN  = DataFormat::Invalid,
    DataFormat TYPECAST_OUT = DataFormat::Invalid,
    bool FUSED_SORT         = false>
void call_unary_sfpu_operation_init(std::uint32_t math_format)
{
    // Once-per-kernel SFPU init (SFPU config reg + invariant ADDR_MOD_7). In metal this is hoisted into the
    // full-init entry points (compute_kernel_hw_startup / init_sfpu / unary_op_init_common); this standalone
    // LLK harness bypasses those, so it must run the once-init itself. Ops migrated to the self-contained
    // per-op init (SFPU_UNARY_INIT_SC*) rely on this running first; unmigrated ops still carry the invariant
    // inside their _llk_math_eltwise_unary_sfpu_init_ but re-running it here is harmless (idempotent).
    llk_math_sfpu_init_once();

    if constexpr (OPERATION == SfpuType::acosh || OPERATION == SfpuType::asinh)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(init_inverse_hyperbolic<APPROX_MODE, is_fp32_dest_acc_en>);
    }
    else if constexpr (OPERATION == SfpuType::atanh)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(init_atanh<APPROX_MODE, is_fp32_dest_acc_en>);
    }
    else if constexpr (OPERATION == SfpuType::cosine)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(cosine_init<APPROX_MODE>);
    }
    else if constexpr (OPERATION == SfpuType::tan)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(tangent_init<APPROX_MODE>);
    }
    else if constexpr (OPERATION == SfpuType::atan)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(atan_init<APPROX_MODE, is_fp32_dest_acc_en>);
    }
    else if constexpr (OPERATION == SfpuType::asin || OPERATION == SfpuType::acos)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION, is_fp32_dest_acc_en>();
    }
    else if constexpr (OPERATION == SfpuType::sinh)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(sinh_init<APPROX_MODE, is_fp32_dest_acc_en>);
    }
    else if constexpr (OPERATION == SfpuType::cosh)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(cosh_init<APPROX_MODE, is_fp32_dest_acc_en>);
    }
    else if constexpr (OPERATION == SfpuType::exp2)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(exp2_init<APPROX_MODE, is_fp32_dest_acc_en>);
    }
    else if constexpr (OPERATION == SfpuType::exponential)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(exp_init<APPROX_MODE, 0x3F800000 /* exp_base_scale_factor */, CLAMP_NEGATIVE, is_fp32_dest_acc_en>);
    }
    else if constexpr (OPERATION == SfpuType::exp_with_base)
    {
        // "exp with base b" = b^x = exp(x * ln b); implemented as the SCALE_EN path
        // of calculate_exponential (multiplies the input by a bf16 scale before exp).
        // The accurate paths apply the scale in the calculate call. The approximate
        // clamp path does not read it there: it bakes the scale into the constants this
        // init programs, so the init carries the same 0.5 -- with 1.0 here it computed
        // exp(x) against an exp(0.5 * x) golden.
        llk_math_eltwise_unary_sfpu_init<OPERATION>(exp_init<APPROX_MODE, EXP_WITH_BASE_SCALE_FP32, CLAMP_NEGATIVE, is_fp32_dest_acc_en>);
    }
    else if constexpr (OPERATION == SfpuType::erfinv)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(erfinv_init<APPROX_MODE>);
    }
    else if constexpr (OPERATION == SfpuType::erf)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(erf_init<APPROX_MODE>);
    }
    else if constexpr (OPERATION == SfpuType::erfc)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(erfc_init<APPROX_MODE>);
    }
    else if constexpr (OPERATION == SfpuType::expm1)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(expm1_init<APPROX_MODE, is_fp32_dest_acc_en>);
    }
    else if constexpr (OPERATION == SfpuType::cbrt)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(cube_root_init<APPROX_MODE>);
    }
    else if constexpr (OPERATION == SfpuType::i1)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(i1_init<APPROX_MODE>);
    }
    else if constexpr (OPERATION == SfpuType::signbit)
    {
        // calculate_signbit_int32 and calculate_signbit each run the SFPLOADMACRO program their own init writes.
        if (math_format == ckernel::to_underlying(DataFormat::Int32))
        {
            llk_math_eltwise_unary_sfpu_init<OPERATION>(signbit_int32_init);
        }
        else
        {
            llk_math_eltwise_unary_sfpu_init<OPERATION>(signbit_init);
        }
    }
    else if constexpr (OPERATION == SfpuType::lgamma)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(lgamma_stirling_init<APPROX_MODE>);
    }
    else if constexpr (OPERATION == SfpuType::digamma)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(digamma_init<APPROX_MODE>);
    }
    else if constexpr (OPERATION == SfpuType::fmod)
    {
        // divisor = 2.0f, 1/divisor = 0.5f (fixed dispatch constants).
        llk_math_eltwise_unary_sfpu_init<OPERATION>(init_fmod<APPROX_MODE>, 0x40000000u /* 2.0f */, 0x3f000000u /* 0.5f */);
    }
    else if constexpr (OPERATION == SfpuType::remainder)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(init_remainder<APPROX_MODE>, 0x40000000u /* 2.0f */, 0x3f000000u /* 0.5f */);
    }
    else if constexpr (OPERATION == SfpuType::rpow)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(sfpu_binary_pow_init<APPROX_MODE>);
    }
    else if constexpr (OPERATION == SfpuType::power)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(sfpu_unary_pow_init);
    }
    else if constexpr (OPERATION == SfpuType::unary_max)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(unary_max_min_init<true>);
    }
    else if constexpr (OPERATION == SfpuType::unary_min)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(unary_max_min_init<false>);
    }
    else if constexpr (OPERATION == SfpuType::unary_max_int32)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(unary_max_min_int32_init<true /* IS_MAX_OP */, false /* IS_UNSIGNED */>);
    }
    else if constexpr (OPERATION == SfpuType::unary_min_int32)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(unary_max_min_int32_init<false /* IS_MAX_OP */, false /* IS_UNSIGNED */>);
    }
    else if constexpr (OPERATION == SfpuType::unary_max_uint32)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(unary_max_min_int32_init<true /* IS_MAX_OP */, true /* IS_UNSIGNED */>);
    }
    else if constexpr (OPERATION == SfpuType::unary_min_uint32)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(unary_max_min_int32_init<false /* IS_MAX_OP */, true /* IS_UNSIGNED */>);
    }
    else if constexpr (OPERATION == SfpuType::polygamma)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(polygamma_init<APPROX_MODE>);
    }
    else if constexpr (OPERATION == SfpuType::xielu)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(xielu_init<APPROX_MODE>);
    }
    else if constexpr (OPERATION == SfpuType::sigmoid_appx)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(sigmoid_appx_init);
    }
    else if constexpr (OPERATION == SfpuType::sigmoid)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(sigmoid_init<APPROX_MODE>);
    }
    else if constexpr (OPERATION == SfpuType::mish)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(mish_init<APPROX_MODE>);
    }
    else if constexpr (OPERATION == SfpuType::rdiv)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(rdiv_init<APPROX_MODE>);
    }
    else if constexpr (OPERATION == SfpuType::gelu)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(gelu_init<APPROX_MODE, is_fp32_dest_acc_en>);
    }
    else if constexpr (OPERATION == SfpuType::gelu_appx)
    {
        // gelu_appx is the LUT branch of calculate_gelu; its init must load the
        // piecewise-linear LReg table, which only gelu_init<APPROXIMATION_MODE=true>
        // does — so force the approx init regardless of the harness APPROX_MODE.
        llk_math_eltwise_unary_sfpu_init<OPERATION>(gelu_init<true, is_fp32_dest_acc_en>);
    }
    else if constexpr (OPERATION == SfpuType::gelu_derivative)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(gelu_derivative_polynomial_init<APPROX_MODE>);
    }
    else if constexpr (OPERATION == SfpuType::softsign)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(init_softsign<APPROX_MODE>);
    }
    else if constexpr (OPERATION == SfpuType::gelu_tanh)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(gelu_tanh_init);
    }
    else if constexpr (OPERATION == SfpuType::hardsigmoid)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(hardsigmoid_init<APPROX_MODE>);
    }
    else if constexpr (OPERATION == SfpuType::log || OPERATION == SfpuType::log_with_base)
    {
        // log_init seeds the vConstFloatPrgm0-2 constants calculate_log reads; the
        // fp32/bf16 sets differ by dest-accum mode, so the flag must be forwarded.
        llk_math_eltwise_unary_sfpu_init<OPERATION>(log_init<APPROX_MODE, FAST_MODE, is_fp32_dest_acc_en>);
    }
    else if constexpr (OPERATION == SfpuType::silu)
    {
        // silu_init routes to sigmoid_init<false>, seeding the reciprocal's
        // vConstFloatPrgm0 that calculate_silu depends on.
        llk_math_eltwise_unary_sfpu_init<OPERATION>(silu_init<APPROX_MODE>);
    }
    else if constexpr (OPERATION == SfpuType::log1p)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(log1p_init<APPROX_MODE, FAST_MODE, is_fp32_dest_acc_en>);
    }
    else if constexpr (OPERATION == SfpuType::reciprocal)
    {
#ifdef ARCH_WORMHOLE
        constexpr bool round_to_bf16 = !APPROX_MODE && !is_fp32_dest_acc_en;
        llk_math_eltwise_unary_sfpu_init<OPERATION>(recip_init<APPROX_MODE, is_fp32_dest_acc_en, round_to_bf16>);
#else
        llk_math_eltwise_unary_sfpu_init<OPERATION>(recip_init<APPROX_MODE, is_fp32_dest_acc_en>);
#endif
    }
    else if constexpr (OPERATION == SfpuType::rsqrt)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(rsqrt_init<APPROX_MODE>);
    }
    else if constexpr (OPERATION == SfpuType::sine)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(sine_init<APPROX_MODE>);
    }
    else if constexpr (OPERATION == SfpuType::sqrt)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(sqrt_init<APPROX_MODE>);
    }
    else if constexpr (OPERATION == SfpuType::tanh)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(tanh_init<APPROX_MODE, is_fp32_dest_acc_en>);
    }
    else if constexpr (OPERATION == SfpuType::tanhshrink)
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION>(sfpu::tanhshrink_init<APPROX_MODE, is_fp32_dest_acc_en>);
    }
    else if constexpr (OPERATION == SfpuType::tanh_derivative_lut)
    {
        // Legacy LUT tanh': tanh_derivative_init loads a 6-entry piecewise-linear
        // LUT fitted for sech^2 -- slopes into LReg0/1/2, intercepts into LReg4/5/6 --
        // which _calculate_tanh_derivative_ then consumes as 1 - lut(x)^2. It is no
        // longer tanh's own table; the two are fitted separately and free to diverge.
        llk_math_eltwise_unary_sfpu_init<OPERATION>(tanh_derivative_init<APPROX_MODE>);
    }
    else if constexpr (OPERATION == SfpuType::tanh_derivative)
    {
        // Accurate sech^2: tanh_derivative_sech2_init programs vConstFloatPrgm0..2 with the
        // exp polynomial's C2..C4, which calculate_tanh_derivative_sech2 reads.
        llk_math_eltwise_unary_sfpu_init<OPERATION>(tanh_derivative_sech2_init<APPROX_MODE>);
    }
    else if constexpr (OPERATION == SfpuType::typecast)
    {
        // Typecast selects its concrete init from the (IN, OUT) format pair.
        call_unary_typecast_operation_init<TYPECAST_IN, TYPECAST_OUT, APPROX_MODE, is_fp32_dest_acc_en>();
    }
    else if constexpr (
        OPERATION == SfpuType::floor || OPERATION == SfpuType::ceil || OPERATION == SfpuType::trunc || OPERATION == SfpuType::frac ||
        OPERATION == SfpuType::round || OPERATION == SfpuType::add1 || OPERATION == SfpuType::relu_max || OPERATION == SfpuType::relu_min ||
        OPERATION == SfpuType::lrelu || OPERATION == SfpuType::hardtanh || OPERATION == SfpuType::clamp || OPERATION == SfpuType::identity ||
        OPERATION == SfpuType::cast_fp32_to_fp16a || OPERATION == SfpuType::sqrt_custom || OPERATION == SfpuType::expm1_cw)
    {
        // These ops need only the generic per-op init (SFPU config reg + ADDR_MOD_7 from
        // llk_math_sfpu_init_once() above, plus a dest RWC counter reset), so route them through
        // the bare `unused` init. The reason each op is safe to route this way varies:
        //   - floor/ceil/trunc/frac/round/relu_max/relu_min/hardtanh/clamp: their production/metal
        //     <op>_init() genuinely reduces to math::reset_counters, so the bare init here
        //     matches production behavior.
        //   - add1/identity/cast_fp32_to_fp16a/sqrt_custom/expm1_cw: the
        //     OPERATION-keyed bare init has no delegate branch.
        //   - lrelu: no linkable definition in this test build, since only the tt-llk common
        //     (not the metal llk_api) header is included.
        llk_math_eltwise_unary_sfpu_init<SfpuType::unused, is_fp32_dest_acc_en>();
    }
    else if constexpr (
        OPERATION == SfpuType::equal_zero || OPERATION == SfpuType::not_equal_zero || OPERATION == SfpuType::less_than_zero ||
        OPERATION == SfpuType::greater_than_zero || OPERATION == SfpuType::less_than_equal_zero || OPERATION == SfpuType::greater_than_equal_zero)
    {
        // Comparison-to-zero ops pair the generic per-op init with the matching metal
        // *_init from llk_sfpu/ckernel_sfpu_comp.h, mirroring production SFPU_UNARY_INIT
        // (eqz_tile_init -> equal_zero_init, etc.). All six of those *_init are byte-identical
        // (program ADDR_MOD_6 + reset the dest RWC counter), so one representative init covers
        // the whole group; OPERATION is still forwarded so the per-op init tag stays correct.
        llk_math_eltwise_unary_sfpu_init<OPERATION>(sfpu::equal_zero_init);
    }
    else if constexpr (
        OPERATION == SfpuType::topk_local_sort || OPERATION == SfpuType::topk_merge || OPERATION == SfpuType::topk_rebuild ||
        OPERATION == SfpuType::topk_defuse)
    {
        // The topk network needs its own init (replay state, dest-index tracking, constants); the
        // fused engine and the defuse sweep need the fused variant.
        if constexpr (FUSED_SORT || OPERATION == SfpuType::topk_defuse)
        {
            _init_topk_fused_();
        }
        else
        {
            _init_topk();
        }
    }
    else
    {
        llk_math_eltwise_unary_sfpu_init<OPERATION, is_fp32_dest_acc_en>();
    }
}

/**
 * Calls only the calculate portion of a unary SFPU operation.
 * Must be preceded by a call to call_unary_sfpu_operation_init() for the same operation.
 * Delegates to SFPU_UNARY_CALL from llk_math_eltwise_unary_sfpu_macros.h,
 * which runs the ckernel::_sfpu_check_<DST_SYNC_MODE, DST_ACCUM_MODE>
 * dst-bound LLK_ASSERT and then dispatches directly to
 * _llk_math_eltwise_unary_sfpu_params_. Face-looping versus single-call
 * behavior is selected by the explicit vector_mode parameter;
 * the default/non-face mode preserves the existing single-call full-tile behavior.
 *
 * DST_SYNC_MODE and DST_ACCUM_MODE are the first two template parameters, mirroring
 * the convention of the underlying SFPU macros and helpers (SFPU_UNARY_CALL,
 * _sfpu_check_, etc.) where the dst-sync/accum pair always leads. They are
 * forwarded to _sfpu_check_ so the dst-bound LLK_ASSERT is computed against
 * the kernel's actual sync/accumulation mode.
 *
 * @tparam DST_SYNC_MODE Kernel's DstSync mode (drives the dst-bound assert)
 * @tparam DST_ACCUM_MODE Kernel's dest-accumulation flag (drives the dst-bound assert)
 * @tparam OPERATION The SFPU operation type to execute
 * @tparam APPROX_MODE Whether to use approximation mode for the SFPU operation
 * @tparam is_fp32_dest_acc_en Whether the destination accumulator is in FP32 mode
 * @tparam ITERATIONS Number of SFPU iterations (typically 32 for full tile)
 * @param dst_index Destination tile index in the destination register
 * @param math_format Optional math format for operations that need format-specific behavior
 */
template <
    DstSync DST_SYNC_MODE,
    bool DST_ACCUM_MODE,
    SfpuType OPERATION,
    bool APPROX_MODE,
    bool is_fp32_dest_acc_en,
    int ITERATIONS,
    bool FAST_MODE          = false,
    bool STABLE_SORT        = false,
    bool CLAMP_NEGATIVE     = false,
    DataFormat TYPECAST_IN  = DataFormat::Invalid,
    DataFormat TYPECAST_OUT = DataFormat::Invalid,
    bool FUSED_SORT         = false>
void call_unary_sfpu_operation(std::uint32_t dst_index, std::uint32_t math_format = 0, float fill_const_value = 5.0f, VectorMode vector_mode = VectorMode::None)
{
    // Fixed dispatch constants shared with the golden (golden_generators.py:
    // _int_maxmin_scalar / _int_shift_amount). The two sides must move together, so
    // keep them named on both to avoid a silent golden desync.
    constexpr std::uint32_t MAXMIN_SCALAR = 1000u;
    // Shift amount for the unary shift ops. Overridable from params.h via the SFPU_SHIFT_AMOUNT
    // template parameter so the Python side can sweep it; a test that does not set it keeps the
    // original fixed 3. The golden reads the same value through UnarySFPUGolden's shift_amount
    // argument, so the two sides move together.
#ifdef SFPU_SHIFT_AMOUNT
    constexpr std::uint32_t SHIFT_AMOUNT = SFPU_SHIFT_AMOUNT;
#else
    constexpr std::uint32_t SHIFT_AMOUNT = 3u;
#endif
    // Polygamma order n and its scale (-1)^(n+1) * n!, as the fp32 bit patterns ttnn passes to
    // polygamma_tile. Overridable via the SFPU_POLYGAMMA_ORDER template parameter so the Python
    // side can sweep n = 1..11; a test that does not set it keeps trigamma (n = 1, scale = 1).
    // The golden reads the same order through UnarySFPUGolden's polygamma_order argument.
#ifdef SFPU_POLYGAMMA_N_BITS
    constexpr std::uint32_t POLYGAMMA_N_BITS     = SFPU_POLYGAMMA_N_BITS;
    constexpr std::uint32_t POLYGAMMA_SCALE_BITS = SFPU_POLYGAMMA_SCALE_BITS;
#else
    constexpr std::uint32_t POLYGAMMA_N_BITS     = 0x3f800000u; // n = 1.0f
    constexpr std::uint32_t POLYGAMMA_SCALE_BITS = 0x3f800000u; // scale = 1.0f
#endif
    // Integer threshold for relu_min's vInt branch, as a two's-complement uint32 (_relu_min_
    // declares the parameter std::uint32_t and immediately static_casts it to int). Overridable
    // via the SFPU_RELU_MIN_INT_THRESHOLD template parameter, on the same #ifdef arrangement as
    // SHIFT_AMOUNT, so the int32 sweep can drive a *negative* threshold -- the only way to reach
    // the sign+magnitude re-encoding branch in _relu_min_, which no production caller triggers.
    // A test that does not set it keeps the fixed 5. The golden reads the same value through
    // UnarySFPUGolden's relu_min_int_threshold argument, so the two sides move together.
#ifdef SFPU_RELU_MIN_INT_THRESHOLD
    constexpr std::uint32_t RELU_MIN_INT_THRESHOLD = SFPU_RELU_MIN_INT_THRESHOLD;
#else
    constexpr std::uint32_t RELU_MIN_INT_THRESHOLD = 5u;
#endif
    // Integer scalar that unary_eq/unary_ne (Int32) compare against via metal
    // calculate_comp_unary_int. Shared with the golden (golden_generators.py:
    // _unary_comp_int_scalar); the two sides must move together.
    constexpr int UNARY_COMP_INT_SCALAR = 5;
    // Clamp/Hardtanh fp32-encoded bounds. Shared with the golden
    // (sfpu_dispatch_constants.py: CLAMP_MIN / CLAMP_MAX); the two sides must move together.
    constexpr std::uint32_t CLAMP_MIN_FP32 = 0xBF800000u; // -1.0f
    constexpr std::uint32_t CLAMP_MAX_FP32 = 0x3F800000u; //  1.0f

    if constexpr (OPERATION == SfpuType::abs)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_abs, (APPROX_MODE, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::abs_int32)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_abs_int32, (APPROX_MODE, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::add1)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_add1, (APPROX_MODE, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::cast_fp32_to_fp16a)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, cast_fp32_to_fp16a, (APPROX_MODE, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::acosh)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_acosh, (APPROX_MODE, is_fp32_dest_acc_en, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::asinh)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_asinh, (APPROX_MODE, is_fp32_dest_acc_en, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::atanh)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_atanh, (APPROX_MODE, is_fp32_dest_acc_en, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::celu)
    {
        SFPU_UNARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_celu,
            (APPROX_MODE, is_fp32_dest_acc_en, ITERATIONS),
            dst_index,
            vector_mode,
            0x3f800000u /* alpha = 1.0f */,
            0x3f800000u /* 1/alpha = 1.0f */);
    }
    else if constexpr (OPERATION == SfpuType::cosine)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_cosine, (APPROX_MODE, is_fp32_dest_acc_en, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::tan)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_tangent, (APPROX_MODE, is_fp32_dest_acc_en, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::atan)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_atan, (APPROX_MODE, is_fp32_dest_acc_en, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::asin)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_asin, (APPROX_MODE, is_fp32_dest_acc_en, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::acos)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_acos, (APPROX_MODE, is_fp32_dest_acc_en, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::sinh)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_sinh, (APPROX_MODE, is_fp32_dest_acc_en, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::cosh)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_cosh, (APPROX_MODE, is_fp32_dest_acc_en, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::elu)
    {
        SFPU_UNARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_elu,
            (APPROX_MODE, is_fp32_dest_acc_en, ITERATIONS),
            dst_index,
            vector_mode,
            0x3f800000u /* alpha = 1.0f */);
    }
    else if constexpr (OPERATION == SfpuType::exp2)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_exp2, (APPROX_MODE, is_fp32_dest_acc_en, ITERATIONS), dst_index, vector_mode);
    }
    // VectorMode::RC: params drives 4 face iterations with 2×SETRWC between each —
    // the lambda processes 8 rows per face, giving 32 total.
    else if constexpr (OPERATION == SfpuType::exponential && APPROX_MODE && CLAMP_NEGATIVE)
    {
        SFPU_UNARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_exponential,
            (APPROX_MODE, is_fp32_dest_acc_en, false /* scale_en */, EXP_APPROX_CLAMP_ITERATIONS, CLAMP_NEGATIVE),
            dst_index,
            VectorMode::RC,
            p_sfpu::kCONST_1_FP16B /* exp_base_scale_factor */);
    }
    // Single call (else branch): calculate_exponential handles 8 or 32 iterations internally.
    else if constexpr (OPERATION == SfpuType::exponential)
    {
        SFPU_UNARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_exponential,
            (APPROX_MODE, is_fp32_dest_acc_en, false /* scale_en */, ITERATIONS, CLAMP_NEGATIVE),
            dst_index,
            vector_mode,
            p_sfpu::kCONST_1_FP16B /* exp_base_scale_factor */);
    }
    // exp_with_base, approximate clamp path: run as Exp's is, EXP_APPROX_CLAMP_ITERATIONS
    // per face over all four faces. Through one ITERATIONS call it processed 8 of a
    // tile's 32 rows and left the other 24 holding their input. This path takes its scale
    // from exp_init's constants (above), not from the call; the call's is passed only
    // because the adapter's signature carries it.
    else if constexpr (OPERATION == SfpuType::exp_with_base && APPROX_MODE && CLAMP_NEGATIVE)
    {
        SFPU_UNARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_exponential_const_scale,
            (APPROX_MODE, is_fp32_dest_acc_en, EXP_APPROX_CLAMP_ITERATIONS, CLAMP_NEGATIVE, EXP_WITH_BASE_SCALE_BF16),
            dst_index,
            VectorMode::RC);
    }
    // exp_with_base = b^x = exp(x * ln b): the only op that drives calculate_exponential
    // with SCALE_EN=true. The bf16 scale EXP_WITH_BASE_SCALE_BF16 == 0.5 selects base
    // b = e^0.5, so the golden is exp(0.5*x); 0.5 is exact in bf16 so no scale-rounding
    // error is added.
    //
    // The bf16-accurate path (_sfpu_exp_21f_bf16_tti_) lowers the scale via TTI_SFPMULI,
    // whose immediate operand must be a compile-time constant. Pass the scale through the
    // test-only adapter's template arguments so SFPU_UNARY_CALL preserves that constness.
    else if constexpr (OPERATION == SfpuType::exp_with_base)
    {
        SFPU_UNARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_exponential_const_scale,
            (APPROX_MODE, is_fp32_dest_acc_en, ITERATIONS, CLAMP_NEGATIVE, EXP_WITH_BASE_SCALE_BF16),
            dst_index,
            vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::fill)
    {
        if (math_format == ckernel::to_underlying(DataFormat::Int32))
        {
            SFPU_UNARY_CALL(
                DST_SYNC_MODE,
                DST_ACCUM_MODE,
                _calculate_fill_int_,
                (APPROX_MODE, ckernel::InstrModLoadStore::INT32, ITERATIONS),
                dst_index,
                vector_mode,
                static_cast<std::uint32_t>(fill_const_value));
        }
        else if (math_format == ckernel::to_underlying(DataFormat::UInt16))
        {
            SFPU_UNARY_CALL(
                DST_SYNC_MODE,
                DST_ACCUM_MODE,
                _calculate_fill_int_,
                (APPROX_MODE, ckernel::InstrModLoadStore::LO16, ITERATIONS),
                dst_index,
                vector_mode,
                static_cast<std::uint32_t>(fill_const_value));
        }
        else if (math_format == ckernel::to_underlying(DataFormat::UInt32))
        {
            SFPU_UNARY_CALL(
                DST_SYNC_MODE,
                DST_ACCUM_MODE,
                _calculate_fill_int_,
                (APPROX_MODE, ckernel::InstrModLoadStore::INT32, ITERATIONS),
                dst_index,
                vector_mode,
                static_cast<std::uint32_t>(fill_const_value));
        }
        else
        {
            SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, _calculate_fill_, (APPROX_MODE, ITERATIONS), dst_index, vector_mode, fill_const_value);
        }
    }
    else if constexpr (OPERATION == SfpuType::gelu)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_gelu, (APPROX_MODE, is_fp32_dest_acc_en, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::gelu_appx)
    {
        // Directly exercise the LUT approximation kernel (the APPROXIMATION_MODE=true
        // branch of calculate_gelu). Requires the LReg table loaded by gelu_init<true>.
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_gelu_appx, (ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::gelu_derivative)
    {
        SFPU_UNARY_CALL(
            DST_SYNC_MODE, DST_ACCUM_MODE, calculate_gelu_derivative_polynomial, (APPROX_MODE, is_fp32_dest_acc_en, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::gelu_tanh)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_gelu_tanh, (is_fp32_dest_acc_en, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::hardsigmoid)
    {
        SFPU_UNARY_CALL(
            DST_SYNC_MODE, DST_ACCUM_MODE, calculate_activation, (APPROX_MODE, ckernel::ActivationType::Hardsigmoid, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::log)
    {
        SFPU_UNARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_log,
            (APPROX_MODE, FAST_MODE, false /* HAS_BASE_SCALING */, is_fp32_dest_acc_en, ITERATIONS),
            dst_index,
            vector_mode,
            0u /* log_base_scale_factor */);
    }
    else if constexpr (OPERATION == SfpuType::log_with_base)
    {
        SFPU_UNARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_log,
            (APPROX_MODE, FAST_MODE, true /* HAS_BASE_SCALING */, is_fp32_dest_acc_en, ITERATIONS, true /* IS_BASE_TWO */),
            dst_index,
            vector_mode,
            0x3FB8AA3Bu /* 1/ln(2) in fp32 -> log2(x) */);
    }
    else if constexpr (OPERATION == SfpuType::log1p)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_log1p, (APPROX_MODE, FAST_MODE, is_fp32_dest_acc_en, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::negative)
    {
        if (math_format == ckernel::to_underlying(DataFormat::Int32))
        {
            SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, _calculate_negative_int_, (APPROX_MODE, ITERATIONS), dst_index, vector_mode);
        }
        else
        {
            SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, _calculate_negative_, (APPROX_MODE, ITERATIONS), dst_index, vector_mode);
        }
    }
    else if constexpr (OPERATION == SfpuType::reciprocal)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_reciprocal, (APPROX_MODE, is_fp32_dest_acc_en, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::rsqrt)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_rsqrt, (APPROX_MODE, ITERATIONS, is_fp32_dest_acc_en, FAST_MODE), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::silu)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_silu, (is_fp32_dest_acc_en, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::tanhshrink)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_tanhshrink, (is_fp32_dest_acc_en, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::floor)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, _calculate_floor_, (APPROX_MODE, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::round)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, _calculate_round_, (APPROX_MODE, ITERATIONS), dst_index, vector_mode, 0 /* decimals */);
    }
    else if constexpr (OPERATION == SfpuType::ceil)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, _calculate_ceil_, (APPROX_MODE, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::trunc)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, _calculate_trunc_, (APPROX_MODE, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::frac)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, _calculate_frac_, (APPROX_MODE, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::sine)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_sine, (APPROX_MODE, is_fp32_dest_acc_en, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::sqrt)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_sqrt, (APPROX_MODE, ITERATIONS, is_fp32_dest_acc_en, FAST_MODE), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::square)
    {
        SFPU_UNARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_square,
            (APPROX_MODE, is_fp32_dest_acc_en, ITERATIONS),
            dst_index,
            vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::signbit)
    {
        if (math_format == ckernel::to_underlying(DataFormat::Int32))
        {
            SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_signbit_int32, (APPROX_MODE, ITERATIONS), dst_index, vector_mode);
        }
        else
        {
            SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_signbit, (APPROX_MODE, ITERATIONS), dst_index, vector_mode);
        }
    }
    else if constexpr (OPERATION == SfpuType::tanh)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_tanh, (APPROX_MODE, is_fp32_dest_acc_en, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::threshold)
    {
        SFPU_UNARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            _calculate_threshold_,
            (APPROX_MODE, ITERATIONS, float),
            dst_index,
            vector_mode,
            5.0f /* threshold_value */,
            10.0f /* replacement_value */);
    }
    else if constexpr (OPERATION == SfpuType::topk_local_sort)
    {
        if constexpr (FUSED_SORT)
        {
            // A real kernel fuses each freshly loaded pair of tiles right before their local sort,
            // so the fused local-sort row includes the fuse sweep and the re-record it forces.
            SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, _topk_fuse_tile_, (true /* largest */), dst_index, vector_mode);
        }
        if constexpr (STABLE_SORT && is_fp32_dest_acc_en && !TOPK_UINT16_IN_FP32_DEST)
        {
            SFPU_UNARY_CALL_NO_TEMPLATE_ARGS(DST_SYNC_MODE, DST_ACCUM_MODE, _topk_canonicalize_negzero_value_tiles_, dst_index, vector_mode);
        }
        SFPU_UNARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            _bitonic_topk_phases_steps,
            (APPROX_MODE, is_fp32_dest_acc_en, STABLE_SORT, FUSED_SORT, false /* RANK_STAMPED */, TopkTieOrder::Ascending),
            dst_index,
            vector_mode,
            0 /* idir */,
            5 /* i_end_phase */,
            0 /* i_start_phase */,
            10 /* i_end_step */,
            0 /* i_start_step */);
    }
    else if constexpr (OPERATION == SfpuType::topk_defuse)
    {
        // Runs once per output tile at the end of a fused sort; timed on its own.
        SFPU_UNARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            _topk_defuse_tile_,
            (true /* largest */, 9u /* TOPK_SFPSTORE_MODE_PACK_UINT16 */),
            dst_index,
            vector_mode,
            1 /* num_tiles */);
    }
    else if constexpr (OPERATION == SfpuType::topk_merge)
    {
        // _bitonic_topk_merge is <APPROXIMATION_MODE, is_fp32_dest_acc_en, top_min, STABLE_SORT>:
        // the sort direction (top_min/idir) is the 3rd template parameter, so it must be bound
        // explicitly (false, matching the idir=0 used by the sibling topk calls here) for
        // STABLE_SORT to land in the 4th slot instead of silently binding to the direction.
        SFPU_UNARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            _bitonic_topk_merge,
            (APPROX_MODE, is_fp32_dest_acc_en, false /* top_min (idir) */, STABLE_SORT, FUSED_SORT, false /* RANK_STAMPED */, TopkTieOrder::Ascending),
            dst_index,
            vector_mode,
            5 /* m_iter */,
            10 /* k */);
    }
    else if constexpr (OPERATION == SfpuType::topk_rebuild)
    {
        SFPU_UNARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            _bitonic_topk_rebuild,
            (APPROX_MODE, is_fp32_dest_acc_en, STABLE_SORT, FUSED_SORT, false /* RANK_STAMPED */, TopkTieOrder::Ascending),
            dst_index,
            vector_mode,
            false /* idir */,
            5 /* m_iter */,
            10 /* k */,
            3 /* logk */,
            0 /* skip_second */);
    }
    else if constexpr (OPERATION == SfpuType::relu_max)
    {
        // The threshold as fp32 bits, which is the encoding relu_max_tile takes (relu6 passes
        // 0x40c00000u). Overridable through the SFPU_RELU_MAX_THRESHOLD template parameter, on
        // the same #ifdef arrangement as SFPU_RELU_MIN_INT_THRESHOLD, so the relu_max threshold
        // sweep can drive relu6's 6.0, a zero and a negative threshold. A test that does not set
        // it keeps the fixed 5.0; the golden reads the same value through UnarySFPUGolden's
        // relu_max_threshold argument, so the two sides move together.
#ifdef SFPU_RELU_MAX_THRESHOLD
        constexpr std::uint32_t RELU_MAX_THRESHOLD_BITS = SFPU_RELU_MAX_THRESHOLD;
#else
        constexpr std::uint32_t RELU_MAX_THRESHOLD_BITS = 0x40A00000u; // 5.0f
#endif
        SFPU_UNARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            _relu_max_,
            (sfpi::vFloat, APPROX_MODE, ITERATIONS, std::uint32_t),
            dst_index,
            vector_mode,
            RELU_MAX_THRESHOLD_BITS);
    }
    else if constexpr (OPERATION == SfpuType::relu_min)
    {
        if (math_format == ckernel::to_underlying(DataFormat::Int32))
        {
            SFPU_UNARY_CALL(
                DST_SYNC_MODE,
                DST_ACCUM_MODE,
                _relu_min_,
                (sfpi::vInt, APPROX_MODE, ITERATIONS, std::uint32_t),
                dst_index,
                vector_mode,
                RELU_MIN_INT_THRESHOLD /* threshold */);
        }
        else
        {
            SFPU_UNARY_CALL(
                DST_SYNC_MODE, DST_ACCUM_MODE, _relu_min_, (sfpi::vFloat, APPROX_MODE, ITERATIONS, float), dst_index, vector_mode, 5.0f /* threshold */);
        }
    }
    else if constexpr (OPERATION == SfpuType::lrelu)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, _calculate_lrelu_, (APPROX_MODE), dst_index, vector_mode, ITERATIONS, 0x3dcccccdu /* slope = 0.1f */);
    }
    else if constexpr (OPERATION == SfpuType::add_int32)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_add_int32, (APPROX_MODE, ITERATIONS), dst_index, vector_mode, 5u /* scalar */);
    }
    else if constexpr (OPERATION == SfpuType::sub_int32)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_sub_int32, (APPROX_MODE, ITERATIONS), dst_index, vector_mode, 5u /* scalar */);
    }
    else if constexpr (OPERATION == SfpuType::bitwise_not)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_bitwise_not, (APPROX_MODE, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::logical_not_unary)
    {
        // logical_not(x) = (x == 0) ? 1 : 0. Select the layout from the runtime input format,
        if (math_format == ckernel::to_underlying(DataFormat::UInt16))
        {
            SFPU_UNARY_CALL(
                DST_SYNC_MODE, DST_ACCUM_MODE, calculate_logical_not, (APPROX_MODE, ckernel::InstrModLoadStore::LO16, ITERATIONS), dst_index, vector_mode);
        }
        else if (math_format == ckernel::to_underlying(DataFormat::Int32) || math_format == ckernel::to_underlying(DataFormat::UInt32))
        {
            SFPU_UNARY_CALL(
                DST_SYNC_MODE, DST_ACCUM_MODE, calculate_logical_not, (APPROX_MODE, ckernel::InstrModLoadStore::INT32, ITERATIONS), dst_index, vector_mode);
        }
        else
        {
            SFPU_UNARY_CALL(
                DST_SYNC_MODE, DST_ACCUM_MODE, calculate_logical_not, (APPROX_MODE, ckernel::InstrModLoadStore::DEFAULT, ITERATIONS), dst_index, vector_mode);
        }
    }
    else if constexpr (OPERATION == SfpuType::heaviside)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_heaviside, (APPROX_MODE, ITERATIONS), dst_index, vector_mode, 0x3f000000u /* value = 0.5f */);
    }
    else if constexpr (OPERATION == SfpuType::softshrink)
    {
        SFPU_UNARY_CALL(
            DST_SYNC_MODE, DST_ACCUM_MODE, calculate_softshrink, (APPROX_MODE, ITERATIONS), dst_index, vector_mode, 0x3f000000u /* lambda = 0.5f */);
    }
    else if constexpr (OPERATION == SfpuType::softsign)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_softsign, (APPROX_MODE, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::sigmoid)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_sigmoid, (APPROX_MODE, is_fp32_dest_acc_en, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::mish)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_mish, (APPROX_MODE, is_fp32_dest_acc_en, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::selu)
    {
        // selu constants passed as fp32 bit patterns: scale ~= 1.0507, alpha ~= 1.6733.
        SFPU_UNARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_selu,
            (APPROX_MODE, is_fp32_dest_acc_en, ITERATIONS),
            dst_index,
            vector_mode,
            0x3f867d5fu /* scale */,
            0x3fd62d7du /* alpha */);
    }
    else if constexpr (OPERATION == SfpuType::i0)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_i0, (APPROX_MODE, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::rdiv)
    {
        SFPU_UNARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_rdiv,
            (APPROX_MODE, is_fp32_dest_acc_en, ckernel::RoundingMode::None, ITERATIONS),
            dst_index,
            vector_mode,
            0x40000000u /* value = 2.0f */);
    }
    else if constexpr (OPERATION == SfpuType::clamp)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_clamp, (APPROX_MODE, ITERATIONS), dst_index, vector_mode, CLAMP_MIN_FP32, CLAMP_MAX_FP32);
    }
    else if constexpr (OPERATION == SfpuType::hardtanh)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_hardtanh, (APPROX_MODE, ITERATIONS), dst_index, vector_mode, CLAMP_MIN_FP32, CLAMP_MAX_FP32);
    }
    else if constexpr (
        OPERATION == SfpuType::equal_zero || OPERATION == SfpuType::not_equal_zero || OPERATION == SfpuType::less_than_zero ||
        OPERATION == SfpuType::greater_than_zero || OPERATION == SfpuType::less_than_equal_zero || OPERATION == SfpuType::greater_than_equal_zero)
    {
        // Comparison-to-zero. The production comp.h API selects a format-specific
        // metal kernel by the input data type (eqz_tile / eqz_tile_int32 /
        // eqz_tile_uint16 / eqz_tile_uint32 ...); mirror that dispatch here so the
        // tt-llk harness exercises the same metal functions in
        // llk_sfpu/ckernel_sfpu_comp.h. The input format arrives as the runtime
        // math_format (see the fill/add_int branches for the same pattern).
        if (math_format == ckernel::to_underlying(DataFormat::Int32))
        {
            SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_comp_int, (APPROX_MODE, OPERATION, ITERATIONS), dst_index, vector_mode);
        }
        else if (math_format == ckernel::to_underlying(DataFormat::UInt16))
        {
            // uint16 comparison is only defined for eqz/nez (metal static_asserts this).
            if constexpr (OPERATION == SfpuType::equal_zero || OPERATION == SfpuType::not_equal_zero)
            {
                SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_comp_uint16, (APPROX_MODE, OPERATION, ITERATIONS), dst_index, vector_mode);
            }
        }
        else if (math_format == ckernel::to_underlying(DataFormat::UInt32))
        {
            // uint32 comparison is only defined for eqz/nez (dedicated metal kernels).
            if constexpr (OPERATION == SfpuType::equal_zero)
            {
                SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_eqz_uint32, (APPROX_MODE, ITERATIONS), dst_index, vector_mode);
            }
            else if constexpr (OPERATION == SfpuType::not_equal_zero)
            {
                SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_nez_uint32, (APPROX_MODE, ITERATIONS), dst_index, vector_mode);
            }
        }
        else
        {
            // Float (bf16 / fp32 / bfp8) comparison-to-zero: NaN-aware metal calculate_comp.
            SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_comp, (APPROX_MODE, OPERATION, ITERATIONS), dst_index, vector_mode);
        }
    }
    else if constexpr (
        OPERATION == SfpuType::isinf || OPERATION == SfpuType::isposinf || OPERATION == SfpuType::isneginf || OPERATION == SfpuType::isnan ||
        OPERATION == SfpuType::isfinite)
    {
        // Predicate ops: write 1.0f where the (isinf/isposinf/isneginf/isnan/isfinite)
        // test holds, else 0.0f. The concrete predicate is selected by OPERATION.
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, _calculate_sfpu_isinf_isnan_, (OPERATION, APPROX_MODE, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::erfinv)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_erfinv, (APPROX_MODE), dst_index, VectorMode::RC);
    }
    else if constexpr (OPERATION == SfpuType::erf)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_erf, (APPROX_MODE, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::erfc)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_erfc, (ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::expm1)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_expm1, (APPROX_MODE, is_fp32_dest_acc_en, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::cbrt)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_cube_root, (APPROX_MODE, is_fp32_dest_acc_en, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::i1)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_i1, (APPROX_MODE, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::sign)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_sign, (APPROX_MODE, ITERATIONS), dst_index, vector_mode, 0u /* exponent_size_8 */);
    }
    else if constexpr (OPERATION == SfpuType::tanh_derivative)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_tanh_derivative_sech2, (APPROX_MODE, is_fp32_dest_acc_en, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::tanh_derivative_lut)
    {
        // Legacy tt-llk primitive: computes 1 - tanh(x)^2 with tanh from the LUT
        // (WITH_PRECOMPUTED_TANH = 0). Distinct from the accurate sech2 variant above.
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, _calculate_tanh_derivative_, (APPROX_MODE, 0, ITERATIONS), dst_index, vector_mode, ITERATIONS);
    }
    else if constexpr (OPERATION == SfpuType::hardmish)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, hardmish, (APPROX_MODE, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::lgamma)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_lgamma_stirling, (APPROX_MODE, is_fp32_dest_acc_en, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::digamma)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_digamma, (APPROX_MODE, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::identity)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_identity, (APPROX_MODE, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::prelu)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_prelu, (APPROX_MODE, ITERATIONS), dst_index, vector_mode, 0x3e800000u /* slope = 0.25f */);
    }
    else if constexpr (OPERATION == SfpuType::rpow)
    {
        SFPU_UNARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_rpow,
            (APPROX_MODE, ITERATIONS, is_fp32_dest_acc_en),
            dst_index,
            vector_mode,
            0x40000000u /* base = 2.0f */);
    }
    else if constexpr (OPERATION == SfpuType::power)
    {
        SFPU_UNARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_unary_power,
            (APPROX_MODE, is_fp32_dest_acc_en, ITERATIONS),
            dst_index,
            vector_mode,
            0x40000000u /* exponent = 2.0f */);
    }
    else if constexpr (OPERATION == SfpuType::fmod)
    {
        // calculate_fmod() takes no runtime args: it reads vConstFloatPrgm0/1 programmed by
        // init_fmod() (see call_unary_sfpu_operation_init above), so no value/recip is passed.
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_fmod, (APPROX_MODE, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::remainder)
    {
        // Unlike calculate_fmod, calculate_remainder() takes no runtime args: it reads vConstFloatPrgm0/1 programmed
        // by init_remainder() (see call_unary_sfpu_operation_init above), so the call must not pass value/recip.
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_remainder, (APPROX_MODE, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::unary_gt)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_unary_gt, (APPROX_MODE, ITERATIONS), dst_index, vector_mode, 0x3f000000u /* value = 0.5f */);
    }
    else if constexpr (OPERATION == SfpuType::unary_ne)
    {
        // Int32 input compares against the integer scalar via metal calculate_comp_unary_int
        // (== production unary_ne_tile_int32); float input keeps the fp32 0.5 threshold path.
        // UNARY_COMP_INT_SCALAR is shared with the golden (golden_generators.py:
        // _unary_comp_int_scalar) — keep the two in sync.
        if (math_format == ckernel::to_underlying(DataFormat::Int32))
        {
            SFPU_UNARY_CALL(
                DST_SYNC_MODE,
                DST_ACCUM_MODE,
                calculate_comp_unary_int,
                (APPROX_MODE, SfpuType::unary_ne, ITERATIONS),
                dst_index,
                vector_mode,
                UNARY_COMP_INT_SCALAR);
        }
        else
        {
            SFPU_UNARY_CALL(
                DST_SYNC_MODE, DST_ACCUM_MODE, calculate_unary_ne, (APPROX_MODE, ITERATIONS), dst_index, vector_mode, 0x3f000000u /* value = 0.5f */);
        }
    }
    else if constexpr (OPERATION == SfpuType::unary_eq)
    {
        if (math_format == ckernel::to_underlying(DataFormat::Int32))
        {
            SFPU_UNARY_CALL(
                DST_SYNC_MODE,
                DST_ACCUM_MODE,
                calculate_comp_unary_int,
                (APPROX_MODE, SfpuType::unary_eq, ITERATIONS),
                dst_index,
                vector_mode,
                UNARY_COMP_INT_SCALAR);
        }
        else
        {
            SFPU_UNARY_CALL(
                DST_SYNC_MODE, DST_ACCUM_MODE, calculate_unary_eq, (APPROX_MODE, ITERATIONS), dst_index, vector_mode, 0x3f000000u /* value = 0.5f */);
        }
    }
    else if constexpr (OPERATION == SfpuType::unary_lt)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_unary_lt, (APPROX_MODE, ITERATIONS), dst_index, vector_mode, 0x3f000000u /* value = 0.5f */);
    }
    else if constexpr (OPERATION == SfpuType::unary_ge)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_unary_ge, (APPROX_MODE, ITERATIONS), dst_index, vector_mode, 0x3f000000u /* value = 0.5f */);
    }
    else if constexpr (OPERATION == SfpuType::unary_le)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_unary_le, (APPROX_MODE, ITERATIONS), dst_index, vector_mode, 0x3f000000u /* value = 0.5f */);
    }
    else if constexpr (OPERATION == SfpuType::unary_max)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_unary_max_min, (true, APPROX_MODE, ITERATIONS), dst_index, vector_mode, 0u /* value = 0.0f */);
    }
    else if constexpr (OPERATION == SfpuType::unary_min)
    {
        SFPU_UNARY_CALL(
            DST_SYNC_MODE, DST_ACCUM_MODE, calculate_unary_max_min, (false, APPROX_MODE, ITERATIONS), dst_index, vector_mode, 0u /* value = 0.0f */);
    }
    // Integer unary max/min against a fixed scalar (1000). IS_UNSIGNED selects the
    // uint32 vs int32 SFPSWAP handling. The golden compares against the same 1000.
    else if constexpr (OPERATION == SfpuType::unary_max_int32)
    {
        SFPU_UNARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_unary_max_min_int32,
            (true /* IS_MAX_OP */, false /* IS_UNSIGNED */, APPROX_MODE, ITERATIONS),
            dst_index,
            vector_mode,
            MAXMIN_SCALAR);
    }
    else if constexpr (OPERATION == SfpuType::unary_min_int32)
    {
        SFPU_UNARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_unary_max_min_int32,
            (false /* IS_MAX_OP */, false /* IS_UNSIGNED */, APPROX_MODE, ITERATIONS),
            dst_index,
            vector_mode,
            MAXMIN_SCALAR);
    }
    else if constexpr (OPERATION == SfpuType::unary_max_uint32)
    {
        SFPU_UNARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_unary_max_min_int32,
            (true /* IS_MAX_OP */, true /* IS_UNSIGNED */, APPROX_MODE, ITERATIONS),
            dst_index,
            vector_mode,
            MAXMIN_SCALAR);
    }
    else if constexpr (OPERATION == SfpuType::unary_min_uint32)
    {
        SFPU_UNARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_unary_max_min_int32,
            (false /* IS_MAX_OP */, true /* IS_UNSIGNED */, APPROX_MODE, ITERATIONS),
            dst_index,
            vector_mode,
            MAXMIN_SCALAR);
    }
    // Unary shift by a fixed immediate (SHIFT_AMOUNT bits). Integer-only kernels run
    // exclusively on the Int32 path here: the only wiring (test_eltwise_unary_sfpu_int)
    // drives shifts as Int32, and the golden (_left_shift/_right_shift) does unbounded
    // Python integer shifts with no 16-bit masking. UInt16/UInt32 shift branches were
    // dropped as dead+untested; re-add them together with a masked golden if needed.
    else if constexpr (OPERATION == SfpuType::left_shift)
    {
        SFPU_UNARY_CALL(
            DST_SYNC_MODE, DST_ACCUM_MODE, calculate_left_shift, (APPROX_MODE, DataFormat::Int32, ITERATIONS), dst_index, vector_mode, SHIFT_AMOUNT);
    }
    else if constexpr (OPERATION == SfpuType::right_shift)
    {
        SFPU_UNARY_CALL(
            DST_SYNC_MODE, DST_ACCUM_MODE, calculate_right_shift, (APPROX_MODE, DataFormat::Int32, ITERATIONS), dst_index, vector_mode, SHIFT_AMOUNT);
    }
    else if constexpr (OPERATION == SfpuType::polygamma)
    {
        SFPU_UNARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_polygamma,
            (APPROX_MODE, is_fp32_dest_acc_en, ITERATIONS),
            dst_index,
            vector_mode,
            POLYGAMMA_N_BITS,
            POLYGAMMA_SCALE_BITS);
    }
    else if constexpr (OPERATION == SfpuType::xielu)
    {
        SFPU_UNARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_xielu,
            (APPROX_MODE, is_fp32_dest_acc_en, ITERATIONS),
            dst_index,
            vector_mode,
            0x3f800000u /* alpha_p = 1.0f */,
            0x3f800000u /* alpha_n = 1.0f */);
    }
    else if constexpr (OPERATION == SfpuType::hardshrink)
    {
        SFPU_UNARY_CALL(
            DST_SYNC_MODE, DST_ACCUM_MODE, calculate_hardshrink, (APPROX_MODE, ITERATIONS), dst_index, vector_mode, 0x3f000000u /* lambda = 0.5f */);
    }
    else if constexpr (OPERATION == SfpuType::softplus)
    {
        SFPU_UNARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_softplus,
            (APPROX_MODE, is_fp32_dest_acc_en, ITERATIONS),
            dst_index,
            vector_mode,
            0x3f800000u /* beta = 1.0f */,
            0x3f800000u /* 1/beta = 1.0f */,
            0x41a00000u /* threshold = 20.0f */);
    }
    else if constexpr (OPERATION == SfpuType::sigmoid_appx)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_sigmoid_appx, (ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::sqrt_custom)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_sqrt_custom, (APPROX_MODE, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::expm1_cw)
    {
        SFPU_UNARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_expm1_cw, (APPROX_MODE, ITERATIONS), dst_index, vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::typecast)
    {
        call_unary_typecast_operation<DST_SYNC_MODE, DST_ACCUM_MODE, TYPECAST_IN, TYPECAST_OUT, APPROX_MODE, ITERATIONS>(dst_index);
    }
    else
    {
        LLK_ASSERT(false, "Unsupported operation");
    }
}

/**
 * Calls only the init portion of a binary SFPU operation.
 * Must be paired with a subsequent call_binary_sfpu_operation() for the calculate step.
 * Uses SFPU_BINARY_INIT* macros from llk_math_eltwise_binary_sfpu_macros.h, which
 * wrap `ckernel::llk_math_eltwise_binary_sfpu_init<::SfpuType::OP>(...)`.
 *
 * DST_ACCUM_MODE (is_fp32_dest_acc_en) must match the value passed to the paired
 * call_binary_sfpu_operation(): ops such as atan2 load an fp32- vs bf16-specific
 * reciprocal polynomial at init time that the calculate step then relies on.
 */
template <bool APPROXIMATION_MODE, bool DST_ACCUM_MODE, BinaryOp BINOP, int ITERATIONS = 32, std::uint32_t MATH_FORMAT = 0>
void call_binary_sfpu_operation_init()
{
    if constexpr (
        BINOP == BinaryOp::ADD || BINOP == BinaryOp::SUB || BINOP == BinaryOp::MUL || BINOP == BinaryOp::DIV || BINOP == BinaryOp::RSUB ||
        BINOP == BinaryOp::XLOGY)
    {
        // BinaryOps without a dedicated SfpuType use the baseline binary addrmod setup.
        SFPU_BINARY_INIT_FN(add1, sfpu_binary_init, (APPROXIMATION_MODE, BINOP));
    }
    else if constexpr (BINOP == BinaryOp::POW)
    {
        SFPU_BINARY_INIT_FN(power, sfpu_binary_init, (APPROXIMATION_MODE, BINOP));
    }
    else if constexpr (BINOP == BinaryOp::ADD_TOP_ROW)
    {
        SFPU_BINARY_INIT_FN_NO_ARGS(add1, init_add_top_row);
    }
    else if constexpr (BINOP == BinaryOp::RSHFT || BINOP == BinaryOp::LOGICAL_RSHFT)
    {
        SFPU_BINARY_INIT(right_shift);
    }
    else if constexpr (BINOP == BinaryOp::LSHFT)
    {
        SFPU_BINARY_INIT(left_shift);
    }
    else if constexpr (
        BINOP == BinaryOp::LT || BINOP == BinaryOp::GT || BINOP == BinaryOp::LE || BINOP == BinaryOp::GE || BINOP == BinaryOp::EQ || BINOP == BinaryOp::NE)
    {
        SFPU_BINARY_INIT(lt);
    }
    else if constexpr (BINOP == BinaryOp::MAX)
    {
        // binary_max_min uses SFPLOADMACRO templates programmed by its init.
        // The SfpuType must be max/min (not a generic placeholder): the LLK init
        // selects a max/min-specific address-mod setup (ADDR_MOD_6 with dest incr=2)
        // that the kernel's load/swap/store sequence depends on. Using add1 skips
        // that setup and leaves the output tile holding in0. Mirrors binary_max_tile_init.
        SFPU_BINARY_INIT_FN(max, binary_max_min_init, (true /* IS_MAX */));
    }
    else if constexpr (BINOP == BinaryOp::MIN)
    {
        // See MAX above: the min SfpuType drives the required address-mod setup.
        SFPU_BINARY_INIT_FN(min, binary_max_min_init, (false /* IS_MAX */));
    }
    else if constexpr (BINOP == BinaryOp::FMOD)
    {
        // fmod uses the reciprocal path; init loads the reciprocal polynomial.
        SFPU_BINARY_INIT_FN(add1, fmod_binary_init, (APPROXIMATION_MODE));
    }
    else if constexpr (BINOP == BinaryOp::LOGADDEXP)
    {
        // logaddexp's log1p reads its polynomial coefficients from the program
        // constant registers; the coefficient set differs by destination precision,
        // so the init is templated on DST_ACCUM_MODE. Baseline (add1) addrmod setup,
        // like fmod/remainder. Mirrors logaddexp_binary_tile_init().
        SFPU_BINARY_INIT_FN(add1, sfpu::calculate_sfpu_logaddexp_init, (DST_ACCUM_MODE));
    }
    else if constexpr (BINOP == BinaryOp::LOGADDEXP2)
    {
        // Same shape as logaddexp: log1p's coefficients live in the program constant
        // registers and differ by destination precision. The base-2 conversion is in the
        // kernel, not here, so this loads exactly the constants log1p expects.
        SFPU_BINARY_INIT_FN(add1, sfpu::calculate_sfpu_logaddexp2_init, (DST_ACCUM_MODE));
    }
    else if constexpr (BINOP == BinaryOp::REMAINDER)
    {
        // remainder_binary_init loads the reciprocal polynomial (Wormhole) or
        // vConstFloatPrgm0 (Blackhole); dest-acc mode is not a parameter.
        SFPU_BINARY_INIT_FN(add1, remainder_binary_init, (APPROXIMATION_MODE));
    }
    else if constexpr (BINOP == BinaryOp::DIV_INT32)
    {
        // Truncating int32 division writes an int32 quotient (calculate_div_int32_trunc),
        // so it needs the reciprocal-polynomial constants from div_trunc_init (shared with
        // DIV_INT32_FLOOR) rather than div_init's sfpu_reciprocal_init.
        SFPU_BINARY_INIT_FN(add1, div_trunc_init, (APPROXIMATION_MODE));
    }
    else if constexpr (BINOP == BinaryOp::DIV_INT32_FLOOR)
    {
        SFPU_BINARY_INIT_FN(add1, div_floor_init, (APPROXIMATION_MODE));
    }
    else if constexpr (BINOP == BinaryOp::GCD)
    {
        // gcd_init records the per-iteration REPLAY buffer used by the binary-GCD loop.
        SFPU_BINARY_INIT_FN_NO_ARGS(add1, sfpu::calculate_sfpu_gcd_init);
    }
    else if constexpr (BINOP == BinaryOp::LCM)
    {
        // lcm_init records the binary-GCD REPLAY buffer (shared with gcd) and loads
        // the reciprocal-polynomial constants used to divide by gcd(a, b).
        SFPU_BINARY_INIT_FN_NO_ARGS(lcm, sfpu::calculate_sfpu_lcm_init);
    }
    else if constexpr (BINOP == BinaryOp::ATAN2)
    {
        // atan2 has no dedicated SfpuType, so use the baseline add1 addrmod. Its init
        // just loads the reciprocal polynomial; the is_fp32_dest_acc_en variant selects
        // the fp32 vs bf16 reciprocal (matching the minimax branch in the kernel), so it
        // must match DST_ACCUM_MODE used by the paired call_binary_sfpu_operation().
        SFPU_BINARY_INIT_FN(add1, sfpu::calculate_sfpu_atan2_init, (APPROXIMATION_MODE, DST_ACCUM_MODE));
    }
    else if constexpr (BINOP == BinaryOp::MUL_INT32)
    {
        // mul_int32 is on the LLK init's ADDR_MOD_6 dest+=2 allow-list, so drive its
        // addrmod through SfpuType::mul_int32; the init loads the 11-bit chunk masks
        // and the 2**23 fp32-to-int bias constants into vConst registers.
        SFPU_BINARY_INIT_FN(mul_int32, sfpu::mul_int32_init, (APPROXIMATION_MODE));
    }
    // Integer relational eq/ne: no extra init function, just the eq_int/ne_int addrmod.
    else if constexpr (BINOP == BinaryOp::EQ_INT)
    {
        SFPU_BINARY_INIT(eq_int);
    }
    else if constexpr (BINOP == BinaryOp::NE_INT)
    {
        SFPU_BINARY_INIT(ne_int);
    }
    // Integer max/min: binary_max_min_int32_init programs the SFPLOADMACRO templates
    // and is keyed on the matching {max,min}_{int32,uint32} SfpuType addrmod allow-list.
    else if constexpr (BINOP == BinaryOp::MAX_INT32)
    {
        SFPU_BINARY_INIT_FN(max_int32, binary_max_min_int32_init, (true /* IS_MAX */, false /* IS_UNSIGNED */));
    }
    else if constexpr (BINOP == BinaryOp::MIN_INT32)
    {
        SFPU_BINARY_INIT_FN(min_int32, binary_max_min_int32_init, (false /* IS_MAX */, false /* IS_UNSIGNED */));
    }
    else if constexpr (BINOP == BinaryOp::MAX_UINT32)
    {
        SFPU_BINARY_INIT_FN(max_uint32, binary_max_min_int32_init, (true /* IS_MAX */, true /* IS_UNSIGNED */));
    }
    else if constexpr (BINOP == BinaryOp::MIN_UINT32)
    {
        SFPU_BINARY_INIT_FN(min_uint32, binary_max_min_int32_init, (false /* IS_MAX */, true /* IS_UNSIGNED */));
    }
    // Integer remainder / fmod: init loads the reciprocal-polynomial constants used by
    // the internal 32-bit remainder kernel (shared uint path).
    else if constexpr (BINOP == BinaryOp::REMAINDER_INT32)
    {
        SFPU_BINARY_INIT_FN(remainder_int32, remainder_int32_init, (APPROXIMATION_MODE));
    }
    else if constexpr (BINOP == BinaryOp::REMAINDER_UINT32)
    {
        SFPU_BINARY_INIT_FN(remainder_uint32, remainder_uint32_init, (APPROXIMATION_MODE));
    }
    else if constexpr (BINOP == BinaryOp::FMOD_INT32)
    {
        SFPU_BINARY_INIT_FN(fmod_int32, fmod_int32_init, (APPROXIMATION_MODE));
    }
    else
    {
        // BinaryOps without a dedicated SfpuType use the baseline binary addrmod setup.
        // BITWISE_AND/OR/XOR, RSUB_INT32, MASK, ISCLOSE and LOGSIGMOID land here: those
        // kernels need no per-op init beyond the standard binary addrmod configuration
        // (logsigmoid_init is a no-op).
        SFPU_BINARY_INIT(add1);
    }
}

template <BinaryOp BINOP>
constexpr SfpuType get_binary_comp_sfpu_type()
{
    if constexpr (BINOP == BinaryOp::LT)
    {
        return SfpuType::lt;
    }
    else if constexpr (BINOP == BinaryOp::GT)
    {
        return SfpuType::gt;
    }
    else if constexpr (BINOP == BinaryOp::LE)
    {
        return SfpuType::le;
    }
    else if constexpr (BINOP == BinaryOp::GE)
    {
        return SfpuType::ge;
    }
    else if constexpr (BINOP == BinaryOp::EQ)
    {
        return SfpuType::eq;
    }
    else
    {
        return SfpuType::ne;
    }
}

/**
 * Calls only the calculate portion of a binary SFPU operation.
 * Must be preceded by a call to call_binary_sfpu_operation_init() for the same operation.
 * Uses SFPU_BINARY_CALL from llk_math_eltwise_binary_sfpu_macros.h, which
 * runs the ckernel::_sfpu_binary_check_<DST_SYNC_MODE, DST_ACCUM_MODE>
 * dst-bound LLK_ASSERTs and then dispatches directly to
 * _llk_math_eltwise_binary_sfpu_params_. The callable receives
 * (dst_index_in0, dst_index_in1, dst_index_out) forwarded from the params
 * wrapper.
 *
 * DST_SYNC_MODE and DST_ACCUM_MODE are the first two template parameters (matching
 * the SFPU_BINARY_CALL / _sfpu_binary_check_ convention) so the dst-bound
 * LLK_ASSERTs run against the kernel's actual sync/accumulation mode.
 * @tparam SIGN_MAGNITUDE_FORMAT Int32 Dest holds SMAG32 (ADD/SUB only).
 */
template <
    DstSync DST_SYNC_MODE,
    bool DST_ACCUM_MODE,
    bool APPROXIMATION_MODE,
    BinaryOp BINOP,
    int ITERATIONS             = 32,
    std::uint32_t MATH_FORMAT  = 0,
    bool SIGN_MAGNITUDE_FORMAT = true>
void call_binary_sfpu_operation(
    const std::uint32_t dst_index_in0 = 0,
    const std::uint32_t dst_index_in1 = 1,
    const std::uint32_t dst_index_out = 0,
    ckernel::VectorMode vector_mode   = ckernel::VectorMode::RC)
{
    // NOTE: The functions invoked via SFPU_BINARY_CALL below run inside
    // _llk_math_eltwise_binary_sfpu_params_, which already loops over 4 faces
    // (for VectorMode::RC) and emits 2x TTI_SETRWC cr_d 8 between calls to
    // advance the dst-write counter. The per-call inner ITERATIONS must
    // therefore be 8 (one face's worth of SFPU rows), not 32 (a full tile),
    // matching how every production llk_math_eltwise_binary_sfpu_* wrapper
    // dispatches into _calculate_sfpu_binary_ / _calculate_*_shift_.
    static_assert(ITERATIONS == 8 || ITERATIONS == 32, "Binary SFPU tests support legacy 8/32 iteration values; execution uses 8 rows per face.");
    constexpr int PER_FACE_ITERATIONS = 8;
    if constexpr (BINOP == BinaryOp::DIV)
    {
        // Route DIV to the dedicated production kernel (calculate_sfpu_binary_div),
        // matching what div_binary_tile() dispatches. The generic calculate_sfpu_binary
        // DIV path is a legacy variant that production never uses, so isolating the real
        // kernel here lets the perf/functional harness measure and guard it directly.
        // is_fp32_dest_acc_en = DST_ACCUM_MODE selects the fp32 residual + bf16 rounding.
        SFPU_BINARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_sfpu_binary_div,
            (APPROXIMATION_MODE, BINOP, PER_FACE_ITERATIONS, DST_ACCUM_MODE),
            dst_index_in0,
            dst_index_in1,
            dst_index_out,
            vector_mode);
    }
    else if constexpr (BINOP == BinaryOp::LOGADDEXP)
    {
        // The fused overflow-safe kernel from ckernel_sfpu_logaddexp.h; DST_ACCUM_MODE
        // (is_fp32_dest_acc_en) selects the fp32 or bf16 exponential, the log1p coefficient
        // set that the paired init loaded, and the bf16 rounding before the store.
        SFPU_BINARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_sfpu_logaddexp,
            (APPROXIMATION_MODE, DST_ACCUM_MODE, PER_FACE_ITERATIONS),
            dst_index_in0,
            dst_index_in1,
            dst_index_out,
            vector_mode);
    }
    else if constexpr (BINOP == BinaryOp::LOGADDEXP2)
    {
        // Same kernel shape in base 2: 2^-|a - b| comes from exp on the fp32 path and from
        // exp2's bf16 body on the bf16 path, and the log1p result is scaled by log2(e), so
        // log1p sees the same (0, 1] argument range and needs no new coefficients. Measured
        // on the fp32 path: a variant with log2(e) folded into its own minimax fit came out
        // at the same 1.45e-06 worst relative error over 262144 pairs.
        SFPU_BINARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_sfpu_logaddexp2,
            (APPROXIMATION_MODE, DST_ACCUM_MODE, PER_FACE_ITERATIONS),
            dst_index_in0,
            dst_index_in1,
            dst_index_out,
            vector_mode);
    }
    else if constexpr (
        BINOP == BinaryOp::ADD || BINOP == BinaryOp::SUB || BINOP == BinaryOp::MUL || BINOP == BinaryOp::RSUB || BINOP == BinaryOp::XLOGY ||
        BINOP == BinaryOp::POW)
    {
        if constexpr (BINOP == BinaryOp::ADD && MATH_FORMAT == static_cast<std::uint32_t>(DataFormat::Int32))
        {
            SFPU_BINARY_CALL(
                DST_SYNC_MODE,
                DST_ACCUM_MODE,
                _add_int_,
                (APPROXIMATION_MODE, PER_FACE_ITERATIONS, ckernel::InstrModLoadStore::INT32, SIGN_MAGNITUDE_FORMAT),
                dst_index_in0,
                dst_index_in1,
                dst_index_out,
                vector_mode);
        }
        else if constexpr (BINOP == BinaryOp::SUB && MATH_FORMAT == static_cast<std::uint32_t>(DataFormat::Int32))
        {
            // Int32 SUB must use the integer path (_sub_int_); otherwise it would
            // fall through to calculate_sfpu_binary and subtract the raw integer
            // bit-patterns as floats. Mirrors the Int32 ADD path above.
            SFPU_BINARY_CALL(
                DST_SYNC_MODE,
                DST_ACCUM_MODE,
                _sub_int_,
                (APPROXIMATION_MODE, PER_FACE_ITERATIONS, ckernel::InstrModLoadStore::INT32, SIGN_MAGNITUDE_FORMAT),
                dst_index_in0,
                dst_index_in1,
                dst_index_out,
                vector_mode);
        }
        else
        {
            SFPU_BINARY_CALL(
                DST_SYNC_MODE,
                DST_ACCUM_MODE,
                calculate_sfpu_binary,
                (APPROXIMATION_MODE, BINOP, PER_FACE_ITERATIONS, DST_ACCUM_MODE),
                dst_index_in0,
                dst_index_in1,
                dst_index_out,
                vector_mode);
        }
    }
    else if constexpr (BINOP == BinaryOp::RSHFT)
    {
        // INT32, not INT32_2S_COMP, to match binary_shift.h: native Int32 tiles hold 2's complement
        // in Dst, so the shift operates on the bits directly. INT32_2S_COMP would ask for a
        // sign-magnitude conversion that no Blackhole caller wants and that the load/store mode
        // does not perform there anyway. Drive these ops with twos_complement=True.
        SFPU_BINARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_binary_right_shift,
            (APPROXIMATION_MODE, PER_FACE_ITERATIONS, ckernel::InstrModLoadStore::INT32, false),
            dst_index_in0,
            dst_index_in1,
            dst_index_out,
            vector_mode);
    }
    else if constexpr (BINOP == BinaryOp::LSHFT)
    {
        SFPU_BINARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_binary_left_shift,
            // See the RSHFT branch above for why this is INT32 rather than INT32_2S_COMP.
            (APPROXIMATION_MODE, PER_FACE_ITERATIONS, ckernel::InstrModLoadStore::INT32, false),
            dst_index_in0,
            dst_index_in1,
            dst_index_out,
            vector_mode);
    }
    else if constexpr (BINOP == BinaryOp::LOGICAL_RSHFT)
    {
        SFPU_BINARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_logical_right_shift,
            // See the RSHFT branch above for why this is INT32 rather than INT32_2S_COMP.
            (APPROXIMATION_MODE, PER_FACE_ITERATIONS, ckernel::InstrModLoadStore::INT32, false),
            dst_index_in0,
            dst_index_in1,
            dst_index_out,
            vector_mode);
    }
    else if constexpr (BINOP == BinaryOp::ADD_TOP_ROW)
    {
        // Use actual format when compiling for ADD_TOP_ROW tests, otherwise use Float32 as safe default for static assert
        constexpr DataFormat add_top_row_format = (BINOP == BinaryOp::ADD_TOP_ROW) ? static_cast<DataFormat>(MATH_FORMAT) : DataFormat::Float32;
        // Force VectorMode::RC_custom so the params wrapper drives all four faces (4 x 8 = 32 rows) of the tile.
        //  _llk_math_eltwise_binary_sfpu_params_ takes its single-call branch
        //  and does not emit the per-face TTI_SETRWC
        SFPU_BINARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_add_top_row,
            (add_top_row_format),
            dst_index_in0,
            dst_index_in1,
            dst_index_out,
            ckernel::VectorMode::RC_custom);
    }
    else if constexpr (
        BINOP == BinaryOp::LT || BINOP == BinaryOp::GT || BINOP == BinaryOp::LE || BINOP == BinaryOp::GE || BINOP == BinaryOp::EQ || BINOP == BinaryOp::NE)
    {
        constexpr SfpuType comp_type = get_binary_comp_sfpu_type<BINOP>();
        if constexpr (MATH_FORMAT == static_cast<std::uint32_t>(DataFormat::Int32))
        {
            SFPU_BINARY_CALL(
                DST_SYNC_MODE,
                DST_ACCUM_MODE,
                calculate_binary_comp_int32,
                (APPROXIMATION_MODE, PER_FACE_ITERATIONS, comp_type),
                dst_index_in0,
                dst_index_in1,
                dst_index_out,
                vector_mode);
        }
        else
        {
            SFPU_BINARY_CALL(
                DST_SYNC_MODE,
                DST_ACCUM_MODE,
                calculate_binary_comp_fp32,
                (APPROXIMATION_MODE, PER_FACE_ITERATIONS, comp_type),
                dst_index_in0,
                dst_index_in1,
                dst_index_out,
                vector_mode);
        }
    }
    else if constexpr (BINOP == BinaryOp::MAX || BINOP == BinaryOp::MIN)
    {
        // float elementwise max/min (SFPSWAP min/max). Operands read from two dst tiles.
        constexpr bool IS_MAX = (BINOP == BinaryOp::MAX);
        SFPU_BINARY_CALL(
            DST_SYNC_MODE, DST_ACCUM_MODE, calculate_binary_max_min, (IS_MAX, PER_FACE_ITERATIONS), dst_index_in0, dst_index_in1, dst_index_out, vector_mode);
    }
    else if constexpr (BINOP == BinaryOp::FMOD)
    {
        // float fmod (result sign follows dividend a); DST_ACCUM_MODE selects fp32 vs bf16 store.
        SFPU_BINARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_sfpu_binary_fmod,
            (APPROXIMATION_MODE, PER_FACE_ITERATIONS, DST_ACCUM_MODE),
            dst_index_in0,
            dst_index_in1,
            dst_index_out,
            vector_mode);
    }
    else if constexpr (BINOP == BinaryOp::REMAINDER)
    {
        // float remainder (result sign follows divisor b); DST_ACCUM_MODE selects fp32 vs bf16 store.
        SFPU_BINARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_sfpu_binary_remainder,
            (APPROXIMATION_MODE, PER_FACE_ITERATIONS, DST_ACCUM_MODE),
            dst_index_in0,
            dst_index_in1,
            dst_index_out,
            vector_mode);
    }
    else if constexpr (BINOP == BinaryOp::BITWISE_AND || BINOP == BinaryOp::BITWISE_OR || BINOP == BinaryOp::BITWISE_XOR)
    {
        // int32 bitwise AND/OR/XOR (raw two's-complement bit patterns in dest).
        constexpr BinaryBitwiseOp BW = (BINOP == BinaryOp::BITWISE_AND)  ? BinaryBitwiseOp::AND
                                       : (BINOP == BinaryOp::BITWISE_OR) ? BinaryBitwiseOp::OR
                                                                         : BinaryBitwiseOp::XOR;
        SFPU_BINARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_sfpu_binary_bitwise,
            (APPROXIMATION_MODE, BW, ckernel::InstrModLoadStore::INT32, PER_FACE_ITERATIONS),
            dst_index_in0,
            dst_index_in1,
            dst_index_out,
            vector_mode);
    }
    else if constexpr (BINOP == BinaryOp::DIV_INT32)
    {
        // int32 truncating division (rounds toward zero). calculate_div_int32_trunc writes a
        // true int32 quotient; the legacy calculate_div_int32 stored an fp32 result, which the
        // Int32 pack path reinterpreted as garbage bit patterns.
        SFPU_BINARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_div_int32_trunc,
            (APPROXIMATION_MODE, PER_FACE_ITERATIONS),
            dst_index_in0,
            dst_index_in1,
            dst_index_out,
            vector_mode);
    }
    else if constexpr (BINOP == BinaryOp::DIV_INT32_FLOOR)
    {
        // int32 floor division (rounds toward -inf).
        SFPU_BINARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_div_int32_floor,
            (APPROXIMATION_MODE, PER_FACE_ITERATIONS),
            dst_index_in0,
            dst_index_in1,
            dst_index_out,
            vector_mode);
    }
    else if constexpr (BINOP == BinaryOp::GCD)
    {
        // int32 gcd via the binary-GCD REPLAY loop recorded in gcd_init.
        SFPU_BINARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_sfpu_gcd, (PER_FACE_ITERATIONS), dst_index_in0, dst_index_in1, dst_index_out, vector_mode);
    }
    else if constexpr (BINOP == BinaryOp::LCM)
    {
        // int32 lcm = a/gcd(a,b) * b (binary-GCD + reciprocal); operands assumed < 2^15.
        SFPU_BINARY_CALL(DST_SYNC_MODE, DST_ACCUM_MODE, calculate_sfpu_lcm, (PER_FACE_ITERATIONS), dst_index_in0, dst_index_in1, dst_index_out, vector_mode);
    }
    else if constexpr (BINOP == BinaryOp::RSUB_INT32)
    {
        SFPU_BINARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_rsub_int,
            (APPROXIMATION_MODE, ckernel::InstrModLoadStore::INT32, PER_FACE_ITERATIONS),
            dst_index_in0,
            dst_index_in1,
            dst_index_out,
            vector_mode);
    }
    else if constexpr (BINOP == BinaryOp::MASK)
    {
        // float mask: out = (mask != 0) ? data : 0, with data at in0 and mask at in1.
        // Driven through the test-only adapter since calculate_mask uses fixed dst
        // offsets rather than the forwarded indices.
        SFPU_BINARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_mask_binary,
            (APPROXIMATION_MODE, PER_FACE_ITERATIONS),
            dst_index_in0,
            dst_index_in1,
            dst_index_out,
            vector_mode);
    }
    else if constexpr (BINOP == BinaryOp::ATAN2)
    {
        // atan2(y, x): in0 = y, in1 = x (calculate_sfpu_atan2 forwards them as
        // _sfpu_atan2_(in0, in1)). DST_ACCUM_MODE is is_fp32_dest_acc_en and selects
        // the higher-order fp32 minimax polynomial (vs the bf16 one) plus the final
        // convert-to-bf16 rounding, so it must match the init's variant.
        SFPU_BINARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_sfpu_atan2,
            (APPROXIMATION_MODE, PER_FACE_ITERATIONS, DST_ACCUM_MODE),
            dst_index_in0,
            dst_index_in1,
            dst_index_out,
            vector_mode);
    }
    else if constexpr (BINOP == BinaryOp::MUL_INT32)
    {
        // int32 multiply: out = in0 * in1 (low 32 bits). The kernel loads/stores via
        // plain INT32 (two's-complement dest bits), so the sign-magnitude packer only
        // round-trips non-negative results; the test keeps operands positive with a
        // product < 2^31 (see test_eltwise_binary_sfpu_int_uniform).
        SFPU_BINARY_CALL(
            DST_SYNC_MODE, DST_ACCUM_MODE, mul_int32, (APPROXIMATION_MODE, PER_FACE_ITERATIONS), dst_index_in0, dst_index_in1, dst_index_out, vector_mode);
    }
    else if constexpr (BINOP == BinaryOp::ISCLOSE)
    {
        // isclose: out = (|a - b| <= atol + rtol * |b|) ? 1 : 0, with a=in0, b=in1.
        // rtol/atol are passed as fp32 bit patterns via the params wrapper's runtime-arg
        // forwarding. Fixed to torch's defaults rtol=1e-5 (0x3727c5ac), atol=1e-8
        // (0x322bcc77); EQUAL_NAN=false, so any NaN operand yields 0. The test uses
        // large-margin stimuli so the exact tolerance (and fp32-vs-bf16 rounding of the
        // tol term) never flips the pass/fail decision.
        SFPU_BINARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_sfpu_isclose,
            (APPROXIMATION_MODE, PER_FACE_ITERATIONS, /*EQUAL_NAN=*/false),
            dst_index_in0,
            dst_index_in1,
            dst_index_out,
            vector_mode,
            /*rtol_bits=*/0x3727c5acu,
            /*atol_bits=*/0x322bcc77u);
    }
    else if constexpr (BINOP == BinaryOp::LOGSIGMOID)
    {
        // logsigmoid(x) = -softplus(-x), with x = in0 and exp(-x) = in1 (the compute
        // kernel is expected to supply exp(-x) as the second operand; the test bakes
        // it into the paired stimuli). No dedicated init (baseline add1 addrmod).
        SFPU_BINARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_logsigmoid,
            (APPROXIMATION_MODE, PER_FACE_ITERATIONS),
            dst_index_in0,
            dst_index_in1,
            dst_index_out,
            vector_mode);
    }
    // Integer relational eq/ne: XOR-based exact compare over Int32 dest bits.
    else if constexpr (BINOP == BinaryOp::EQ_INT || BINOP == BinaryOp::NE_INT)
    {
        constexpr SfpuType comp_type = (BINOP == BinaryOp::EQ_INT) ? SfpuType::eq : SfpuType::ne;
        SFPU_BINARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_binary_eq_int,
            (APPROXIMATION_MODE, PER_FACE_ITERATIONS, comp_type, DataFormat::Int32),
            dst_index_in0,
            dst_index_in1,
            dst_index_out,
            vector_mode);
    }
    // Integer max/min via SFPSWAP. IS_UNSIGNED selects int32 vs uint32 handling; the
    // sign-magnitude dest only round-trips non-negative results, so the tests keep
    // operands non-negative.
    else if constexpr (BINOP == BinaryOp::MAX_INT32 || BINOP == BinaryOp::MIN_INT32 || BINOP == BinaryOp::MAX_UINT32 || BINOP == BinaryOp::MIN_UINT32)
    {
        constexpr bool IS_MAX      = (BINOP == BinaryOp::MAX_INT32 || BINOP == BinaryOp::MAX_UINT32);
        constexpr bool IS_UNSIGNED = (BINOP == BinaryOp::MAX_UINT32 || BINOP == BinaryOp::MIN_UINT32);
        SFPU_BINARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_binary_max_min_int32,
            (IS_MAX, IS_UNSIGNED, PER_FACE_ITERATIONS),
            dst_index_in0,
            dst_index_in1,
            dst_index_out,
            vector_mode);
    }
    else if constexpr (BINOP == BinaryOp::REMAINDER_INT32)
    {
        // int32 remainder r = a - b * trunc(a/b) with sign following the dividend a.
        SFPU_BINARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_remainder_int32,
            (APPROXIMATION_MODE, PER_FACE_ITERATIONS),
            dst_index_in0,
            dst_index_in1,
            dst_index_out,
            vector_mode);
    }
    else if constexpr (BINOP == BinaryOp::REMAINDER_UINT32)
    {
        SFPU_BINARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_remainder_uint32,
            (APPROXIMATION_MODE, PER_FACE_ITERATIONS),
            dst_index_in0,
            dst_index_in1,
            dst_index_out,
            vector_mode);
    }
    else if constexpr (BINOP == BinaryOp::FMOD_INT32)
    {
        SFPU_BINARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_fmod_int32,
            (APPROXIMATION_MODE, PER_FACE_ITERATIONS),
            dst_index_in0,
            dst_index_in1,
            dst_index_out,
            vector_mode);
    }
    else
    {
        LLK_ASSERT(false, "Unsupported operation");
    }
}

// To add a new metal ternary SFPU operation:
// 1. Include the metal header above: #include "llk_sfpu/<operation>.h"
// 2. Add the operation enum to SfpuType in llk_sfpu_types.h
// 3. Add the if constexpr branches in call_ternary_sfpu_operation_init() and
//    call_ternary_sfpu_operation() below.

/**
 * Calls only the init portion of a ternary SFPU operation.
 * Must be paired with a subsequent call_ternary_sfpu_operation() for the calculate step.
 * Delegates to the SFPU_TERNARY_INIT* macros (llk_math_eltwise_ternary_sfpu_macros.h),
 * which run _llk_math_eltwise_ternary_sfpu_init_<OP>() and the optional per-op init.
 */
template <SfpuType OPERATION, bool APPROX_MODE, bool is_fp32_dest_acc_en>
void call_ternary_sfpu_operation_init()
{
    if constexpr (OPERATION == SfpuType::where)
    {
        SFPU_TERNARY_INIT_FN(where, sfpu::_init_where_, (APPROX_MODE));
    }
    else if constexpr (OPERATION == SfpuType::addcmul)
    {
        // addcmul has no per-op init beyond the shared addrmod setup.
        SFPU_TERNARY_INIT(addcmul);
    }
    else if constexpr (OPERATION == SfpuType::addcdiv)
    {
        // addcdiv uses sfpu_reciprocal internally; init_addcdiv forwards to sfpu_reciprocal_init.
        SFPU_TERNARY_INIT_FN(addcdiv, sfpu::init_addcdiv, (APPROX_MODE));
    }
    else if constexpr (OPERATION == SfpuType::lerp)
    {
        // lerp has no per-op init beyond the shared addrmod setup.
        SFPU_TERNARY_INIT(lerp);
    }
    else if constexpr (OPERATION == SfpuType::snake_beta)
    {
        // snake_beta uses sfpu_reciprocal internally; snake_beta_init forwards to sfpu_reciprocal_init.
        SFPU_TERNARY_INIT_FN(snake_beta, sfpu::snake_beta_init, (APPROX_MODE));
    }
    else
    {
        // Fail loudly on an unrecognized op instead of silently initializing it
        // as `where` (which would mis-compute). Mirrors call_ternary_sfpu_operation().
        LLK_ASSERT(false, "Unsupported ternary operation init");
    }
}

/**
 * Calls only the calculate portion of a ternary SFPU operation.
 * Must be preceded by a call to call_ternary_sfpu_operation_init() for the same operation.
 */
template <
    DstSync DST_SYNC_MODE,
    bool DST_ACCUM_MODE,
    SfpuType OPERATION,
    bool APPROX_MODE,
    bool is_fp32_dest_acc_en,
    DataFormat MATH_FORMAT,
    int ITERATIONS = 8>
void call_ternary_sfpu_operation(
    const std::uint32_t dst_index_in0 = 0,
    const std::uint32_t dst_index_in1 = 1,
    const std::uint32_t dst_index_in2 = 2,
    const std::uint32_t dst_index_out = 0,
    const std::uint32_t value         = 0x40000000u /* 2.0f */,
    ckernel::VectorMode vector_mode   = ckernel::VectorMode::RC)
{
    if constexpr (OPERATION == SfpuType::where)
    {
        SFPU_TERNARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            _calculate_where_,
            (APPROX_MODE, MATH_FORMAT, ITERATIONS),
            dst_index_in0,
            dst_index_in1,
            dst_index_in2,
            dst_index_out,
            vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::addcmul)
    {
        SFPU_TERNARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_addcmul,
            (APPROX_MODE, is_fp32_dest_acc_en, MATH_FORMAT, ITERATIONS),
            dst_index_in0,
            dst_index_in1,
            dst_index_in2,
            dst_index_out,
            vector_mode,
            value);
    }
    else if constexpr (OPERATION == SfpuType::addcdiv)
    {
        SFPU_TERNARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_addcdiv,
            (APPROX_MODE, is_fp32_dest_acc_en, MATH_FORMAT, ITERATIONS),
            dst_index_in0,
            dst_index_in1,
            dst_index_in2,
            dst_index_out,
            vector_mode,
            value);
    }
    else if constexpr (OPERATION == SfpuType::lerp)
    {
        SFPU_TERNARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_lerp,
            (APPROX_MODE, is_fp32_dest_acc_en, MATH_FORMAT, ITERATIONS),
            dst_index_in0,
            dst_index_in1,
            dst_index_in2,
            dst_index_out,
            vector_mode);
    }
    else if constexpr (OPERATION == SfpuType::snake_beta)
    {
        SFPU_TERNARY_CALL(
            DST_SYNC_MODE,
            DST_ACCUM_MODE,
            calculate_snake_beta,
            (APPROX_MODE, is_fp32_dest_acc_en, MATH_FORMAT, ITERATIONS),
            dst_index_in0,
            dst_index_in1,
            dst_index_in2,
            dst_index_out,
            vector_mode);
    }
    else
    {
        LLK_ASSERT(false, "Unsupported ternary operation");
    }
}

} // namespace test_utils
