// SPDX-FileCopyrightText: © 2026 Tenstorrent AI ULC
//
// SPDX-License-Identifier: Apache-2.0

// Driver for the generic MoE-gate top-k SFPU entry
// (tt_llk_blackhole/common/inc/sfpu/experimental/ckernel_sfpu_generic_moe_gate_topk.h
//  plus its _top8.h / _top16.h implementation halves).
//
// DEST contract (all offsets are the kernel's own constants, relative to the
// dst_index the SFPU window is opened at):
//   tile 0  scores  : the raw expert scores          (in, overwritten with winners)
//   tile 1  indices : expert ids                     (generated or caller-mapped)
//   tile 2  bias    : score + bias, the sort key     (in, clobbered as scratch)
//   tile 3  interm  : scratch for >256 experts / zero_tail
//
// For num_total_experts == 256 the experts occupy face 0 of the tile, and
// `_topk_moe_generate_indices_` numbers them id = 16 * row + column: it seeds
// LREG0 with LTILEID (2 * lane_id) and stores LREG0/LREG0+1 to the even/odd column
// halves of a row band, which is a consecutive numbering exactly when DEST address
// +0 selects a face's even columns and +2 its odd columns.
//
// Result, after `_generic_moe_gate_store_8_rows_even_odd_split_<0>`: the eight
// winners land in COLUMN 0 of DEST rows 0-7 of the scores and indices tiles.
// `_generic_moe_gate_top8_merge_instances_` reduces to one lane rather than
// all-reducing, so the other even columns keep partial merges (measured on
// Blackhole: they hold ids outside the top-8), and the odd columns are never
// written -- they still carry the generated expert id and the staged score. With
// `normalize` the score tile holds score_i * scale / (sum_of_selected_scores + eps).
//
// Scope: this drives the SFPU kernel only. In the compute API
// (api/compute/experimental/generic_moe_gate.h) tiles 0 and 2 are staged by the
// FPU kernel `_llk_math_deepseek_moe_gate_eltwise_binary_` (MOVA2D into tile 0 +
// ELWADD into tile 2). That is a separate, FPU-side LLK, so here both tiles are
// staged with plain A2D datacopy from two input tiles instead -- the SFPU kernel
// under test cannot tell the difference, and a failure cannot be blamed on the FPU
// half.
//
// The LLK header self-includes its prerequisites (sfpu/ckernel_sfpu_converter.h for
// `Converter::as_float` and ckernel_sfpu_recip.h for `sfpu_reciprocal`), so this
// driver just includes the header itself. Note the recip include is spelled
// unqualified there and the exp/recip kernels live one layer up in the metal tree
// (hw/ckernels/blackhole/metal/llk_api/llk_sfpu/), so the tt-llk test build has to
// put that directory on the include path -- see setup_compilation_options in
// helpers/test_config.py.

#include <cstdint>

#include "ckernel.h"
#include "llk_defs.h"
#include "params.h"

// Globals required by the test framework.
std::uint32_t unp_cfg_context          = 0;
std::uint32_t pack_sync_tile_dst_ptr   = 0;
std::uint32_t math_sync_tile_dst_index = 0;

static constexpr ckernel::DstSync DST_SYNC = ckernel::DstSync::SyncHalf;

// DEST tiles, matching the kernel's generic_moe_gate_*_tile constants.
static constexpr std::uint32_t MOE_GATE_SCORES_DST_TILE  = 0;
static constexpr std::uint32_t MOE_GATE_INDICES_DST_TILE = 1;
static constexpr std::uint32_t MOE_GATE_BIAS_DST_TILE    = 2;

// Input tiles in buffer_A: raw scores, then the biased sort key.
static constexpr std::uint32_t MOE_GATE_NUM_INPUT_TILES = 2;

#ifdef LLK_TRISC_UNPACK

#include "llk_unpack_A.h"
#include "llk_unpack_common.h"

void run_kernel(RUNTIME_PARAMETERS params)
{
#if defined(RUNTIME_FORMATS) && !defined(SPEED_OF_LIGHT)
    const FormatConfig& formats = params.formats;
#endif
    _llk_unpack_hw_configure_<is_fp32_dest_acc_en>(
        formats.unpack_A_src, formats.unpack_B_src, formats.unpack_A_dst, formats.unpack_B_dst, FACE_R_DIM, FACE_R_DIM, TILE_NUM_FACES, TILE_NUM_FACES);

    _llk_unpack_A_init_<BroadcastType::NONE, false, EltwiseBinaryReuseDestType::NONE, unpack_to_dest>(
        0 /* transpose_of_faces */, 0 /* within_face_16x16_transpose */, ckernel::DEFAULT_TENSOR_SHAPE, formats.unpack_A_src, formats.unpack_A_dst);

    for (std::uint32_t tile = 0; tile < MOE_GATE_NUM_INPUT_TILES; ++tile)
    {
        _llk_unpack_A_<BroadcastType::NONE, false, EltwiseBinaryReuseDestType::NONE, unpack_to_dest>(
            L1_ADDRESS(params.buffer_A[tile]), formats.unpack_A_src, formats.unpack_A_dst);
    }
}

#endif

#ifdef LLK_TRISC_MATH

#include "ckernel_sfpu.h"
#include "generic_moe_gate_test_helpers.h"
#include "llk_lib_math_wrappers.h"
#include "llk_math_eltwise_unary_sfpu.h"
#include "llk_math_eltwise_unary_sfpu_params.h"
#include "llk_sfpu/llk_math_eltwise_unary_sfpu_macros.h"
#include "sfpu/experimental/ckernel_sfpu_generic_moe_gate_topk.h"

using namespace ckernel;

void run_kernel(RUNTIME_PARAMETERS params)
{
#if defined(RUNTIME_FORMATS) && !defined(SPEED_OF_LIGHT)
    const FormatConfig& formats = params.formats;
#endif
    (void)params;

    _llk_math_hw_configure_<is_fp32_dest_acc_en>(formats.math, formats.math);
    _llk_math_pack_sync_init_<DST_SYNC, is_fp32_dest_acc_en>();

    _llk_math_eltwise_unary_datacopy_init_wrapper_<DataCopyType::A2D, is_fp32_dest_acc_en, BroadcastType::NONE, false /* is_int_fpu_en */, PackMode::Default>(
        TILE_NUM_FACES, formats.math);

    _llk_math_eltwise_unary_sfpu_init_<SfpuType::unused>();
    ckernel::sfpu::_init_generic_moe_gate_topk_();

    _llk_math_wait_for_dest_available_<DST_SYNC>();

    // Stage the two inputs the SFPU kernel expects: raw scores in tile 0 and the
    // biased sort key in tile 2. (Tile 1 is written by the kernel itself.)
    _llk_math_eltwise_unary_datacopy_<DataCopyType::A2D, DST_SYNC, is_fp32_dest_acc_en, BroadcastType::NONE, unpack_to_dest>(
        MOE_GATE_SCORES_DST_TILE, formats.math, formats.math);
    _llk_math_eltwise_unary_datacopy_<DataCopyType::A2D, DST_SYNC, is_fp32_dest_acc_en, BroadcastType::NONE, unpack_to_dest>(
        MOE_GATE_BIAS_DST_TILE, formats.math, formats.math);

    if constexpr (!MOE_GATE_GENERATE_INDICES)
    {
        SFPU_UNARY_CALL(DST_SYNC, is_fp32_dest_acc_en, _moe_gate_test_seed_indices_, (0), MOE_GATE_SCORES_DST_TILE, VectorMode::RC_custom);
    }

    // RC_custom: the kernel walks DEST itself off the tile-0 base.
    SFPU_UNARY_CALL(
        DST_SYNC,
        is_fp32_dest_acc_en,
        _generic_moe_gate_topk_,
        (MOE_GATE_NORMALIZE,
         MOE_GATE_NUM_SELECTED_EXPERTS,
         MOE_GATE_NUM_TOTAL_EXPERTS,
         MOE_GATE_ZERO_TAIL,
         MOE_GATE_FULL_SORT,
         MOE_GATE_GENERATE_INDICES,
         false /* do_extra_scale */,
         MOE_GATE_SCORES_INCLUDE_BIAS),
        MOE_GATE_SCORES_DST_TILE,
        VectorMode::RC_custom,
        MOE_GATE_EPS_BITS,
        MOE_GATE_SCALE_BITS,
        MOE_GATE_EXTRA_SCALE_BITS);

    _llk_math_dest_section_done_<DST_SYNC, is_fp32_dest_acc_en>();
}

#endif

#ifdef LLK_TRISC_PACK

#include "llk_lib_pack_wrappers.h"
#include "llk_pack_common.h"

void run_kernel(RUNTIME_PARAMETERS params)
{
#if defined(RUNTIME_FORMATS) && !defined(SPEED_OF_LIGHT)
    const FormatConfig& formats = params.formats;
#endif
    constexpr std::uint32_t TILE_SIZE = FACE_R_DIM * FACE_C_DIM * TILE_NUM_FACES;

    _llk_pack_hw_configure_wrapper_<is_fp32_dest_acc_en, PackMode::Default>(formats.pack_src, formats.pack_dst, TILE_SIZE);
    _llk_pack_init_wrapper_<PackMode::Default, false /* zero_output */>(formats.pack_dst, FACE_R_DIM, TILE_C_DIM, TILE_NUM_FACES);
    _llk_pack_dest_init_wrapper_<DST_SYNC, is_fp32_dest_acc_en, PackMode::Default>();

    _llk_packer_wait_for_math_done_();

    // Winner scores: float, packed with the configured format.
    _llk_pack_<DST_SYNC, is_fp32_dest_acc_en, ckernel::PackMode::Default>(MOE_GATE_SCORES_DST_TILE, L1_ADDRESS(params.buffer_Res[0]));

    // Winner indices: the kernel keeps them in the LO16 of the DEST word, so they
    // have to be packed as UInt16 (same trick as the bitonic topk test).
    const std::uint32_t index_format = ckernel::to_underlying(DataFormat::UInt16);
    _llk_pack_reconfig_data_format_wrapper_<is_fp32_dest_acc_en, false /* is_tile_dim_reconfig_en */>(
        index_format, index_format, TILE_SIZE, FACE_R_DIM, TILE_C_DIM, TILE_NUM_FACES, false /* partial_face */, false /* narrow_tile */, 1 /* num_tiles */);
    _llk_pack_init_wrapper_<PackMode::Default, false /* zero_output */>(index_format);
    _llk_pack_<DST_SYNC, is_fp32_dest_acc_en, ckernel::PackMode::Default>(MOE_GATE_INDICES_DST_TILE, L1_ADDRESS(params.buffer_Res[1]));

    _llk_pack_dest_section_done_<DST_SYNC, is_fp32_dest_acc_en>();
}

#endif
