// SPDX-FileCopyrightText: © 2026 Tenstorrent AI ULC
//
// SPDX-License-Identifier: Apache-2.0

// Standalone tt-llk test for the experimental Quasar block reduce_max_row kernel. Drives the LLK
// lib directly. A block of params.TILE_CNT operand tiles is row-max reduced into a
// single result tile.
#include <algorithm>
#include <cstdint>
#include <cstdio>

#include "ckernel.h"
#include "llk_defs.h"
#include "llk_memory_checks.h"
#include "quasar_test_common.h"
#include "sfpu_stub.h"
#include "tensor_shape.h"

#ifdef LLK_TRISC_UNPACK

#include "experimental/llk_unpack_AB_reduce_runtime_custom.h"
#include "llk_bfd_alloc.h"
#include "llk_unpack_common.h"
#include "params.h"

void run_kernel(RUNTIME_PARAMETERS params)
{
#if defined(RUNTIME_FORMATS) && !defined(SPEED_OF_LIGHT)
    const FormatConfig& formats = params.formats;
#endif
#ifndef SPEED_OF_LIGHT
    const std::uint32_t TILE_CNT = params.TILE_CNT;
    const Operand& buffer_A      = params.buffer_A;
    const Operand& buffer_B      = params.buffer_B;
#endif
    // no op for unpack thread.
    set_up_dest_dvalid_per_thread<dest_dvalid_client::UNPACK>({dest_dvalid_client::FPU, dest_dvalid_client::PACK});

    const auto tensor_shape_A = TENSOR_SHAPE_FROM_PARAMS(params);

    // Allocate + program a buffer descriptor per unpacker from the per-TRISC BFD partition
    // (SrcA operand tiles -> Unp0/UNPACR0, SrcB scaler face -> Unp1/UNPACR1).
    const auto bfd_a = ckernel::trisc::bfd_alloc_and_program<ckernel::trisc::BfdResource::Unp0>(tensor_shape_A, L1_ADDRESS(buffer_A[0]), formats.unpack_A_src);
    const auto bfd_b = ckernel::trisc::bfd_alloc_and_program<ckernel::trisc::BfdResource::Unp1>(tensor_shape_A, L1_ADDRESS(buffer_B[0]), formats.unpack_B_src);

    // Configure unpacker engines with their SrcReg (destination) formats.
    _llk_unpack_configure_binary_<p_unpacr::UNP_A, p_unpacr::UNP_B>(
        static_cast<DataFormat>(formats.unpack_A_dst), static_cast<DataFormat>(formats.unpack_B_dst));

    // Block of TILE_CNT operand tiles (SrcA) + one scaler face (SrcB) -> one reduced result tile.
    _llk_unpack_AB_reduce_block_max_row_init_runtime_(TILE_CNT, false /*respect_trigger*/, bfd_a, bfd_b, tensor_shape_A);
    _llk_unpack_AB_reduce_block_max_row_runtime_(TILE_CNT, 0 /*operand tile start*/, 0 /*scaler tile*/, bfd_b, tensor_shape_A);
}

#endif

#ifdef LLK_TRISC_MATH

#include "experimental/llk_math_reduce_runtime_custom.h"
#include "llk_math_common.h"
#include "params.h"

using namespace ckernel;

void run_kernel(RUNTIME_PARAMETERS params)
{
#if defined(RUNTIME_FORMATS) && !defined(SPEED_OF_LIGHT)
    const FormatConfig& formats = params.formats;
#endif
#ifndef SPEED_OF_LIGHT
    const std::uint32_t TILE_CNT = params.TILE_CNT;
#endif
    set_up_dest_dvalid_per_thread<dest_dvalid_client::FPU>({dest_dvalid_client::FPU, dest_dvalid_client::PACK});

    DataFormat src_format = static_cast<DataFormat>(formats.math);

    const auto tensor_shape_A = TENSOR_SHAPE_FROM_PARAMS(params);

    _llk_math_srcAB_hw_configure_<false /*EN_IMPLIED_MATH_FORMAT*/, is_fp32_dest_acc_en>(src_format, src_format);

    _llk_math_reduce_block_max_row_init_runtime_<is_fp32_dest_acc_en>(TILE_CNT, tensor_shape_A);
    _llk_math_reduce_block_max_row_runtime_<is_fp32_dest_acc_en>(0 /*dst_index*/, tensor_shape_A);

    _llk_math_set_dvalid_<p_cleardvalid::FPU, dest_sync>();
}

#endif

#ifdef LLK_TRISC_PACK

#include "llk_bfd_alloc.h"
#include "llk_pack.h"
#include "llk_pack_common.h"
#include "params.h"

void run_kernel(RUNTIME_PARAMETERS params)
{
#if defined(RUNTIME_FORMATS) && !defined(SPEED_OF_LIGHT)
    const FormatConfig& formats = params.formats;
#endif
#ifndef SPEED_OF_LIGHT
    const Operand& buffer_Res = params.buffer_Res;
#endif
    set_up_dest_dvalid_per_thread<dest_dvalid_client::PACK>({dest_dvalid_client::FPU, dest_dvalid_client::PACK});

    const auto tensor_shape_A = TENSOR_SHAPE_FROM_PARAMS(params);

    // Allocate + program the pack buffer descriptor from the per-TRISC BFD partition (Pack0 -> PACR0).
    const auto bfd_pack =
        ckernel::trisc::bfd_alloc_and_program<ckernel::trisc::BfdResource::Pack0>(tensor_shape_A, L1_ADDRESS(buffer_Res[0]), formats.pack_dst);
    _llk_pack_hw_configure_<p_pacr::PACK0, is_fp32_dest_acc_en>(static_cast<DataFormat>(formats.pack_src), ckernel::ReluConfig::none());
    _llk_pack_init_(bfd_pack, tensor_shape_A, 1 /*num_tiles_per_pack*/);
    _llk_pack_reduce_mask_config_<ReduceDim::REDUCE_ROW>(tensor_shape_A);

    // Block reduce produces a single result tile.
    _llk_pack_(0 /* start_math_dest_tile_idx */, 0 /* start_l1_tile_idx */, tensor_shape_A);

    _llk_pack_dest_dvalid_section_done_<dest_sync, is_fp32_dest_acc_en>();
    _llk_pack_reduce_mask_clear_();
}
#endif
