// SPDX-FileCopyrightText: © 2026 Tenstorrent AI ULC
//
// SPDX-License-Identifier: Apache-2.0

// Reads the SrcA tile descriptor back on device after a tilize init+uninit pair.
//
// The pre-tilize descriptor uses a num_faces that differs from the tilize operand's.
// The other teardown tests use the same one for both, so a teardown that rewrites the
// descriptor and one that leaves it alone give the same value there.
//
// WH: init never writes the word, so uninit must leave it bit-identical.
// BH: init writes Z-dim, so uninit re-establishes it; Y-dim untouched.
// Both: uninit must also restore the canonical Tile_x_dim_cntx0 and clear the unpack-config
// tileize_mode bit that init set, both asserted below.

#include <cstdint>

#include "ckernel.h"
#include "llk_defs.h"

// Globals referenced by the LLK config helpers (configure_unpack_AB / sync_regfile_write).
std::uint32_t unp_cfg_context          = 0;
std::uint32_t pack_sync_tile_dst_ptr   = 0;
std::uint32_t math_sync_tile_dst_index = 0;

#ifdef LLK_TRISC_UNPACK

#include "llk_lib_unpack_wrappers.h"
#include "llk_unpack_common.h"
#include "params.h"

// Drain the config writes before reading them back (mirrors
// unpack_canonical_baseline_check_test.cpp).
static inline void drain_cfg_writes()
{
    tensix_sync();
    for (std::uint32_t i = 0; i < 10; i++)
    {
        asm volatile("nop");
    }
}

static inline std::uint32_t read_tileize_mode(volatile std::uint32_t tt_reg_ptr* cfg)
{
    return (cfg[THCON_SEC0_REG2_Tileize_mode_ADDR32] & THCON_SEC0_REG2_Tileize_mode_MASK) >> THCON_SEC0_REG2_Tileize_mode_SHAMT;
}

void run_kernel(RUNTIME_PARAMETERS params)
{
#if defined(RUNTIME_FORMATS) && !defined(SPEED_OF_LIGHT)
    const FormatConfig& formats = params.formats;
#endif
    const std::uint32_t tilize_num_faces = params.num_faces;
    const std::uint32_t face_r_dim       = params.TEST_FACE_R_DIM;

    // Pre-tilize baseline deliberately differs from the tilize operand's num_faces,
    // so a teardown that stamps the tilize operand's value is detectable. Both
    // values are legal descriptor Z-dims (<1, 2, 4>).
    const std::uint32_t pre_num_faces = (tilize_num_faces == 4) ? 2 : 4;

    _llk_unpack_hw_configure_<is_fp32_dest_acc_en>(
        formats.unpack_A_src, formats.unpack_B_src, formats.unpack_A_dst, formats.unpack_B_dst, face_r_dim, face_r_dim, pre_num_faces, pre_num_faces);

    drain_cfg_writes();

    volatile std::uint32_t tt_reg_ptr* cfg = get_cfg_pointer();

    const std::uint32_t pre_desc_word = cfg[THCON_SEC0_REG0_TileDescriptor_ADDR32 + 1];

    _llk_unpack_tilize_init_wrapper_(formats.unpack_A_src, formats.unpack_A_dst, 1 /* ct_dim */, face_r_dim, false /* narrow_tile */, tilize_num_faces);

    drain_cfg_writes();

    // Init must leave the bit set, so a clear bit after uninit is the uninit's doing.
    LLK_ASSERT(read_tileize_mode(cfg) == 1, "tilize init must set tileize_mode");

    _llk_unpack_tilize_uninit_wrapper_(formats.unpack_A_dst, tilize_num_faces, face_r_dim);

    drain_cfg_writes();

    const std::uint32_t post_desc_word = cfg[THCON_SEC0_REG0_TileDescriptor_ADDR32 + 1];

    LLK_ASSERT(read_tileize_mode(cfg) == 0, "tilize uninit must clear tileize_mode");

    // Tile_x_dim_cntx0 IS tilize's to restore.
    const std::uint32_t post_tile_x = cfg[THCON_SEC0_REG5_Tile_x_dim_cntx0_ADDR32];
    LLK_ASSERT(post_tile_x == canonical_unpA_tile_x_dim_cntx(face_r_dim), "tilize uninit must restore the canonical Tile_x_dim_cntx0");

#ifdef ARCH_WORMHOLE
    // Tilize does not own the descriptor on WH: the word must be bit-identical.
    LLK_ASSERT(post_desc_word == pre_desc_word, "WH tilize uninit must leave the SrcA tile-descriptor Y/Z-dim word untouched");
#else
    const std::uint32_t post_z_dim = UPPER_HALFWORD(post_desc_word);
    const std::uint32_t post_y_dim = LOWER_HALFWORD(post_desc_word);

    // BH tilize init writes the descriptor, so uninit must re-establish the
    // tilize operand's baseline; y_dim is still not tilize's to touch.
    LLK_ASSERT(post_z_dim == tilize_num_faces, "BH tilize uninit must re-establish descriptor Z-dim = tilize operand num_faces");
    LLK_ASSERT(post_y_dim == LOWER_HALFWORD(pre_desc_word), "tilize uninit must not disturb the descriptor Y-dim");
#endif
}

#endif

#ifdef LLK_TRISC_MATH

#include "params.h"

void run_kernel(RUNTIME_PARAMETERS)
{
}

#endif

#ifdef LLK_TRISC_PACK

#include "params.h"

void run_kernel(RUNTIME_PARAMETERS)
{
}

#endif
