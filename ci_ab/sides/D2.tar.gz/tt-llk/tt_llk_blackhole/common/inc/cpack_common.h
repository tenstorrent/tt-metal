// SPDX-FileCopyrightText: © 2025 Tenstorrent AI ULC
//
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include <array>
#include <cstdint>
#include <type_traits>

#include "ckernel.h"
#include "ckernel_defs.h"
#include "ckernel_globals.h"
#include "llk_assert.h"
#include "llk_defs.h"
#include "llk_memory_checks.h"

namespace ckernel::packer
{
using DataFormatType = std::underlying_type_t<DataFormat>;

constexpr std::uint32_t replay_buf_offset = 16; // split replay buffer usage between fpu/sfpu
                                                // fist 16 for sfpu, next 16 for fpu
constexpr std::uint32_t NUM_PACKERS = 1;        // Number of packers

// Pack config
typedef struct
{
    // word 0
    std::uint32_t row_ptr_section_size : 16;
    std::uint32_t exp_section_size     : 16;
    // word 1
    std::uint32_t l1_dest_addr : 32;
    // word 2
    std::uint32_t uncompress              : 1;
    std::uint32_t add_l1_dest_addr_offset : 1;
    std::uint32_t disable_pack_zero_flag  : 1;
    std::uint32_t reserved_0              : 1;
    std::uint32_t out_data_format : DATA_FORMAT_BIT_COUNT;
    std::uint32_t in_data_format : DATA_FORMAT_BIT_COUNT;
    std::uint32_t dis_shared_exp_assembler            : 1;
    std::uint32_t auto_set_last_pacr_intf_sel         : 1;
    std::uint32_t enable_out_fifo                     : 1;
    std::uint32_t sub_l1_tile_header_size             : 1;
    std::uint32_t src_if_sel                          : 1;
    std::uint32_t pack_start_intf_pos                 : 4;
    std::uint32_t all_pack_disable_zero_compress_ovrd : 1;
    std::uint32_t add_tile_header_size                : 1;
    std::uint32_t pack_dis_y_pos_start_offset         : 1;
    std::uint32_t l1_src_addr                         : 8;
    //   The bit unp_lf8_4b_exp is configured in the unpack, remove word 3 to avoid potential race condition
    //   //word 3
    //   uint32_t downsample_mask : 16;
    //   uint32_t downsample_shift_count  : 3;
    //   uint32_t pack_l1_acc : 1; //Not new to BH, but moved
    //   //uint32_t read_mode : 1; //Removed in BH
    //   uint32_t exp_threshold_en  : 1;
    //   uint32_t reserved_2 : 1;
    //   uint32_t unp_lf8_4b_exp: 1;
    //   uint32_t pac_lf8_4b_exp: 1;
    //   uint32_t exp_threshold : 8;
} pack_config_t;

static_assert(sizeof(pack_config_t) == (sizeof(std::uint32_t) * 3));

typedef union
{
    std::uint32_t val[3];
    pack_config_t f;
} pack_config_u;

// Relu Config
typedef struct
{
    std::uint32_t ALU_ACC_CTRL_Zero_Flag_disabled_src      : 1;
    std::uint32_t ALU_ACC_CTRL_Zero_Flag_disabled_dst      : 1;
    std::uint32_t STACC_RELU_ApplyRelu                     : 4;
    std::uint32_t STACC_RELU_ReluThreshold                 : 16;
    std::uint32_t DISABLE_RISC_BP_Disable_main             : 1;
    std::uint32_t DISABLE_RISC_BP_Disable_trisc            : 3;
    std::uint32_t DISABLE_RISC_BP_Disable_ncrisc           : 1;
    std::uint32_t DISABLE_RISC_BP_Disable_bmp_clear_main   : 1;
    std::uint32_t DISABLE_RISC_BP_Disable_bmp_clear_trisc  : 3;
    std::uint32_t DISABLE_RISC_BP_Disable_bmp_clear_ncrisc : 1;
} relu_config_t;

static_assert(sizeof(relu_config_t) == (sizeof(std::uint32_t)));

typedef union
{
    std::uint32_t val[1];
    relu_config_t r;
} relu_config_u;

// Dest rd control
typedef struct
{
    std::uint32_t PCK_DEST_RD_CTRL_Read_32b_data  : 1;
    std::uint32_t PCK_DEST_RD_CTRL_Read_unsigned  : 1;
    std::uint32_t PCK_DEST_RD_CTRL_Read_int8      : 1;
    std::uint32_t PCK_DEST_RD_CTRL_Round_10b_mant : 1;
    std::uint32_t PCK_DEST_RD_CTRL_Reserved       : 28;
} dest_rd_ctrl_t;

static_assert(sizeof(dest_rd_ctrl_t) == (sizeof(std::uint32_t)));

typedef union
{
    std::uint32_t val;
    dest_rd_ctrl_t f;
} dest_rd_ctrl_u;

// PACK_EDGE_OFFSET_SEC[0:3] register structure
//
// Lower 16b represent a mask that is applied on a single row of one face on the packer output
// Higher 16b contain information about which TILE_ROW_SET_MAPPING register is used for each packer (only in PACK_EDGE_OFFSET_SEC0)
//
// There are 4 PACK_EDGE_OFFSET_SEC[0:3] registers and 4 TILE_ROW_SET_MAPPING[0:3] registers.
// TILE_ROW_SET_MAPPING[0:3] have 2 bits for each row inside a face that determine which PACK_EDGE_OFFSET_SEC[0:3] mask is used.
// Only PACK_EDGE_OFFSET_SEC0 register has higher 16b configured to determine TILE_ROW_SET_MAPPING[0:3] registers used for each packer.
// Other PACK_EDGE_OFFSET_SEC[1:3] registers are used only for the masks in the lower 16b.
typedef struct
{
    std::uint32_t mask                      : 16;
    std::uint32_t mode                      : 1;
    std::uint32_t tile_row_set_select_pack0 : 2;
    std::uint32_t tile_row_set_select_pack1 : 2;
    std::uint32_t tile_row_set_select_pack2 : 2;
    std::uint32_t tile_row_set_select_pack3 : 2;
    std::uint32_t reserved                  : 7;
} pck_edge_offset_t;

static_assert(sizeof(pck_edge_offset_t) == (sizeof(std::uint32_t)));

typedef union
{
    std::uint32_t val;
    pck_edge_offset_t f;
} pck_edge_offset_u;

// Pack counters
typedef struct
{
    std::uint32_t pack_per_xy_plane        : 8;
    std::uint32_t pack_reads_per_xy_plane  : 8;
    std::uint32_t pack_xys_per_til         : 7;
    std::uint32_t pack_yz_transposed       : 1;
    std::uint32_t pack_per_xy_plane_offset : 8;
} pack_counters_t;

static_assert(sizeof(pack_counters_t) == (sizeof(std::uint32_t)));

typedef union
{
    std::uint32_t val;
    pack_counters_t f;
} pack_counters_u;

// Set unpacker offsets to 0, except for unpacker 0, channel 1, X, which is the tile X dimension
inline void packer_addr_counter_init()
{
    TTI_SETADCXY(0b100, 0, 0, 0, 0, 0b1011);
    TTI_SETADCZW(0b100, 0, 0, 0, 0, 0b1111);
}

/**
 * \brief Returns true if `out_l1` is a valid output of the FP32 late-conversion column.
 */
__attribute__((noinline, optimize("no-jump-tables"))) bool is_packer_fp32_late_column_output(const DataFormat out_l1)
{
    switch (out_l1)
    {
        case DataFormat::Float32:
        case DataFormat::Float16_b:
        case DataFormat::Float16:
        case DataFormat::Lf8:
        case DataFormat::Bfp8:
        case DataFormat::Bfp4:
        case DataFormat::Bfp2:
        case DataFormat::Bfp8_b:
        case DataFormat::Bfp4_b:
        case DataFormat::Bfp2_b:
            return true;
        default:
            return false;
    }
}

/**
 * \brief Returns true if `out_l1` is a valid output of the combined late-conversion column.
 *
 * Combined column: "From TF32 or BF16 or E8M6 or FP16 or E5M7 or E5M6 or FP8".
 * This is exactly the FP32 column plus Tf32.
 */
__attribute__((noinline)) bool is_packer_combined_late_column_output(const DataFormat out_l1)
{
    return out_l1 == DataFormat::Tf32 || is_packer_fp32_late_column_output(out_l1);
}

/**
 * \brief Returns true if conversion is supported by EARLY packer conversion stage.
 *
 * Validates supported dst-register to intermediate-format pairs for Blackhole's early conversion
 * stage. For this API, `out_l1` is interpreted as the requested intermediate format code.
 */
__attribute__((noinline, optimize("no-jump-tables"))) bool is_packer_to_L1_early_conversion_supported(const DataFormat in_reg, const DataFormat out_l1)
{
    switch (in_reg)
    {
        case DataFormat::Float32:
            return out_l1 == DataFormat::Float32 ||   // FP32 (identity)
                   out_l1 == DataFormat::Tf32 ||      // TF32
                   out_l1 == DataFormat::Float16_b || // BF16
                   out_l1 == DataFormat::Bfp8_b ||    // E8M6 (encoded as BFP8)
                   out_l1 == DataFormat::Int32 ||     // INT32 (bitcast)
                   out_l1 == DataFormat::Int8 ||      // INT8
                   out_l1 == DataFormat::UInt8;       // UINT8

        case DataFormat::Float16_b:
            return out_l1 == DataFormat::Tf32 ||      // TF32
                   out_l1 == DataFormat::Float16_b || // BF16
                   out_l1 == DataFormat::Bfp8_b ||    // E8M6 (encoded as BFP8)
                   out_l1 == DataFormat::Int8;        // INT8

        case DataFormat::Float16:
            return out_l1 == DataFormat::Float16 || // FP16
                   out_l1 == DataFormat::Bfp8 ||    // E5M7/E5M6 (encoded as BFP8a)
                   out_l1 == DataFormat::Lf8 ||     // FP8 (e5m2)
                   out_l1 == DataFormat::Int8;      // INT8

        case DataFormat::Int32:
            return out_l1 == DataFormat::Float32 ||   // FP32 (bitcast)
                   out_l1 == DataFormat::Tf32 ||      // TF32 (bitcast+round)
                   out_l1 == DataFormat::Float16_b || // BF16 (top 16b bitcast)
                   out_l1 == DataFormat::Int32 ||     // INT32 (identity)
                   out_l1 == DataFormat::Int8 ||      // INT8
                   out_l1 == DataFormat::UInt8;       // UINT8

        case DataFormat::UInt16: // INT16 identity path
            return out_l1 == DataFormat::UInt16;

        default:
            return false;
    }
}

/**
 * \brief Returns true if conversion is supported by LATE packer conversion stage.
 *
 * Validates supported intermediate (LateFromFormat) to L1 pairs for Blackhole's late conversion
 * stage.
 */
__attribute__((noinline, optimize("no-jump-tables"))) bool is_packer_to_L1_late_conversion_supported(const DataFormat in_reg, const DataFormat out_l1)
{
    switch (in_reg)
    {
        case DataFormat::Float32: // From FP32 column
            return is_packer_fp32_late_column_output(out_l1);

        // Combined column (TF32 / BF16 / E8M6 / FP16 / E5M7 / E5M6 / FP8).
        // Bfp4/Bfp2 and Bfp4_b/Bfp2_b are kept for backward compatibility with existing code.
        case DataFormat::Tf32:
        case DataFormat::Float16_b:
        case DataFormat::Bfp8_b:
        case DataFormat::Bfp4_b:
        case DataFormat::Bfp2_b:
        case DataFormat::Float16:
        case DataFormat::Bfp8:
        case DataFormat::Bfp4:
        case DataFormat::Bfp2:
        case DataFormat::Lf8:
            return is_packer_combined_late_column_output(out_l1);

        case DataFormat::Int32: // From INT32 column
            return out_l1 == DataFormat::Int32;

        case DataFormat::UInt16: // From INT16 column
            return out_l1 == DataFormat::UInt16;

        case DataFormat::Int8: // From INT8/UINT8 column
        case DataFormat::UInt8:
            return out_l1 == DataFormat::Int8 || out_l1 == DataFormat::UInt8;

        case DataFormat::UInt32:
            return out_l1 == DataFormat::UInt32;

        default:
            return false;
    }
}

/**
 * \brief Returns true if either EARLY or LATE packer conversion stage supports the conversion.
 */
__attribute__((noinline)) bool is_packer_to_L1_conversion_supported(const DataFormat in_reg, const DataFormat out_l1)
{
    return is_packer_to_L1_early_conversion_supported(in_reg, out_l1) || is_packer_to_L1_late_conversion_supported(in_reg, out_l1);
}

template <PackMode pack_mode = PackMode::Default>
inline void set_packer_strides(const std::uint32_t pack_src_format, const std::uint32_t tile_c_dim)
{
    std::uint32_t x_stride = datum_size_in_bytes(pack_src_format);
    std::uint32_t y_stride = FACE_C_DIM * x_stride;
    std::uint32_t w_stride = TILE_NUM_FACES * FACE_C_DIM * FACE_R_DIM * x_stride;

    // Untilize mode has 2 packer interfaces active, so z counter needs to jump by 2
    // faces, since z counter is only 1 bit (can't be programmed to inc by 2)
    const std::uint32_t z_stride = ((pack_mode != PackMode::Default) && (tile_c_dim == TILE_C_DIM)) ? 2 * FACE_R_DIM * y_stride : FACE_R_DIM * y_stride;

    TT_SETDMAREG(0, LOWER_HALFWORD((y_stride << PCK0_ADDR_CTRL_XY_REG_0_Ystride_SHAMT)), 0, LO_16(p_gpr_pack::TMP0)); // x-stride not used!
    TT_SETDMAREG(0, UPPER_HALFWORD((y_stride << PCK0_ADDR_CTRL_XY_REG_0_Ystride_SHAMT)), 0, HI_16(p_gpr_pack::TMP0));
    TT_SETDMAREG(0, LOWER_HALFWORD((z_stride << PCK0_ADDR_CTRL_ZW_REG_0_Zstride_SHAMT)), 0, LO_16(p_gpr_pack::TMP1));
    TT_SETDMAREG(0, UPPER_HALFWORD((w_stride << PCK0_ADDR_CTRL_ZW_REG_0_Wstride_SHAMT)), 0, HI_16(p_gpr_pack::TMP1));
    TTI_STALLWAIT(p_stall::STALL_CFG, p_stall::THCON);
    TTI_WRCFG(p_gpr_pack::TMP0, p_cfg::WRCFG_32b, PCK0_ADDR_CTRL_XY_REG_0_Xstride_ADDR32);
    TTI_WRCFG(p_gpr_pack::TMP1, p_cfg::WRCFG_32b, PCK0_ADDR_CTRL_ZW_REG_0_Zstride_ADDR32);
    // Channel-1 (L1 output) strides are zero for every pack mode: output placement comes from
    // L1_Dest_addr and the packer's write pointer. Only the fast-untilize strided pack sets a
    // channel-1 (Y) stride, in its own init.
    TTI_WRCFG(p_gpr::ZERO, p_cfg::WRCFG_32b, PCK0_ADDR_CTRL_XY_REG_1_Xstride_ADDR32);
    TTI_WRCFG(p_gpr::ZERO, p_cfg::WRCFG_32b, PCK0_ADDR_CTRL_ZW_REG_1_Zstride_ADDR32);
    TTI_NOP;
    TTI_NOP;
}

inline void reconfigure_packer_l1_acc(const std::uint32_t pack_l1_acc)
{
    // Stall to avoid clobbering current packer configuration, then enable/disable L1 accumulation
    TTI_STALLWAIT(p_stall::STALL_CFG, p_stall::PACK);
    cfg_reg_rmw_tensix<THCON_SEC0_REG1_Pack_L1_Acc_RMW>(pack_l1_acc);
}

/**
 * @brief Configure packer exponent thresholding for the current destination and output formats.
 *
 * We use packer exponent thresholding to zero out datums that are too small to be repesentable
 * This is specifically done in FP32 (Dest) -> BFPxA (L1) case.
 *
 * This implies that exponent thresholding should be reconfigured whenever packer formats change.
 *
 * @tparam is_fp32_dest_acc_en True when Dest register is FP32.
 * @param pack_dst_format Pack output data format.
 */
template <bool is_fp32_dest_acc_en>
inline void reconfigure_exp_threshold(const std::uint32_t pack_dst_format)
{
    bool enable             = false;
    std::uint32_t threshold = 0;

    // Workaround for HW bug: tenstorrent/budabackend#1394
    if constexpr (is_fp32_dest_acc_en)
    {
        if (IS_BFP_A_FORMAT(pack_dst_format))
        {
            // After early format conversion the exponent is EXP_B; packing to BFP-A uses EXP_A.
            // Zero out values too small to represent in EXP_A.
            //
            // For a given EXP_B number to be representable in EXP_A, it must satisfy:
            // EXP_BIAS_B = 127, EXP_BIAS_A = 15, and EXP_MIN_A = 1 - EXP_BIAS_A = -14
            //   EXP_B - EXP_BIAS_B >= EXP_MIN_A
            //   EXP_B - 127 >= -14
            //   EXP_B >= 113
            // The packer compares against threshold 113 and forces datums with EXP_B < 113 to zero.
            enable    = true;
            threshold = 113;
        }
    }

    static_assert(
        THCON_SEC0_REG1_Exp_threshold_en_ADDR32 == THCON_SEC0_REG1_Exp_threshold_ADDR32,
        "THCON_SEC0_REG1_Exp_threshold_en and Exp_threshold must share ADDR32 for combined RMW");

    constexpr std::uint32_t THRESHOLD_RMW_MASK = THCON_SEC0_REG1_Exp_threshold_en_MASK | THCON_SEC0_REG1_Exp_threshold_MASK;

    std::uint32_t threshold_rmw_data = (threshold << THCON_SEC0_REG1_Exp_threshold_SHAMT) | (enable << THCON_SEC0_REG1_Exp_threshold_en_SHAMT);

    cfg_reg_rmw_tensix<THCON_SEC0_REG1_Exp_threshold_ADDR32, 0, THRESHOLD_RMW_MASK>(threshold_rmw_data);
}

template <bool is_fp32_dest_acc_en>
inline void set_packer_config(
    const std::uint32_t pack_src_format, const std::uint32_t pack_dst_format, const std::uint32_t num_faces = 4, const bool partial_face = false)
{
    LLK_ASSERT(num_faces == 1 || num_faces == 2 || num_faces == 4, "num_faces must be 1, 2, or 4");
    // Get pointer to registers for current state ID
    volatile std::uint32_t tt_reg_ptr* cfg = get_cfg_pointer();

    const std::uint32_t pack_output_src_format = masked_data_format(pack_src_format);
    const std::uint32_t pack_output_dst_format = masked_data_format(pack_dst_format);
    // Gasket converts Float16_b -> Float16 before the packer, so hardware in_data_format must be Float16 for Fp8 output.
    const std::uint32_t pack_hw_src_format =
        ((pack_dst_format & 0x1F) == to_underlying(DataFormat::Fp8_e4m3)) ? to_underlying(DataFormat::Float16) : pack_output_src_format;

    // Set packer config
    pack_config_u config;
    for (std::uint32_t i = 0; i < 3; i++)
    {
        config.val[i] = 0;
    }

    config.f.exp_section_size =
        ((pack_output_dst_format == to_underlying(DataFormat::Lf8)) || (pack_output_dst_format == to_underlying(DataFormat::Int8)))
            ? 0
            : (partial_face ? 1 : num_faces); // set to num_faces as exp section size is not used for non-bfp formats except for lf8/int8

    config.f.uncompress      = 1;
    config.f.out_data_format = pack_output_dst_format;
    config.f.in_data_format  = pack_hw_src_format;

    reconfigure_exp_threshold<is_fp32_dest_acc_en>(pack_output_dst_format);

    // Program:
    // THCON_SEC0_REG1_Row_start_section_size = cfg_reg_array[1][0 +: 16];
    // THCON_SEC0_REG1_Exp_section_size = cfg_reg_array[1][16 +: 16];
    // This is filled with garbage, and will be set up on every pack:
    //           THCON_SEC0_REG1_L1_Dest_addr = cfg_reg_array[1][32 +: 32];
    // THCON_SEC0_REG1_Disable_zero_compress = cfg_reg_array[1][64 +: 1];
    // THCON_SEC0_REG1_Add_l1_dest_addr_offset = cfg_reg_array[1][65 +: 1];
    // THCON_SEC0_REG1_Unused0 = cfg_reg_array[1][66 +: 2];
    // THCON_SEC0_REG1_Out_data_format = cfg_reg_array[1][68 +: 4];
    // THCON_SEC0_REG1_In_data_format = cfg_reg_array[1][72 +: 4];
    // THCON_SEC0_REG1_Unused00 = cfg_reg_array[1][76 +: 4];
    // THCON_SEC0_REG1_Source_interface_selection = cfg_reg_array[1][80 +: 1];
    // THCON_SEC0_REG1_Packs_per_xy_plane = cfg_reg_array[1][81 +: 7];
    // THCON_SEC0_REG1_L1_source_addr = cfg_reg_array[1][88 +: 8];
    // THCON_SEC0_REG1_Downsample_mask = cfg_reg_array[1][96 +: 16];
    // THCON_SEC0_REG1_Downsample_shift_count = cfg_reg_array[1][112 +: 3];
    // THCON_SEC0_REG1_Read_mode = cfg_reg_array[1][115 +: 1];
    // THCON_SEC0_REG1_Exp_threshold_en = cfg_reg_array[1][116 +: 1];
    // THCON_SEC0_REG1_Unused1 = cfg_reg_array[1][117 +: 3];
    // THCON_SEC0_REG1_Exp_threshold = cfg_reg_array[1][120 +: 8];
    // for (uint i=0; i<4; i++) cfg[THCON_SEC0_REG1_Row_start_section_size_ADDR32+i]=config.val[i];
    cfg[THCON_SEC0_REG1_Row_start_section_size_ADDR32 + 0] = config.val[0];
    cfg[THCON_SEC0_REG1_Row_start_section_size_ADDR32 + 2] = config.val[2];
    // cfg[THCON_SEC0_REG1_Row_start_section_size_ADDR32+3]=config.val[3];

    // Reset L1 accumulation flag
    reconfigure_packer_l1_acc(0);

    dest_rd_ctrl_u dest_rd_ctrl;
    dest_rd_ctrl.val = 0;

    bool is_32b_format = pack_src_format == to_underlying(DataFormat::Int32) || pack_src_format == to_underlying(DataFormat::UInt32) ||
                         pack_src_format == to_underlying(DataFormat::Float32);
    bool is_int8_format = pack_src_format == to_underlying(DataFormat::Int8) || pack_src_format == to_underlying(DataFormat::UInt8);

    dest_rd_ctrl.f.PCK_DEST_RD_CTRL_Read_32b_data = is_32b_format || is_fp32_dest_acc_en;
    dest_rd_ctrl.f.PCK_DEST_RD_CTRL_Read_int8     = !(is_fp32_dest_acc_en || is_32b_format) && is_int8_format;

    if (pack_dst_format == to_underlying(DataFormat::UInt8))
    {
        dest_rd_ctrl.f.PCK_DEST_RD_CTRL_Read_unsigned = 1;
    }

    // Round to 10 bit mantissa from fp32 dest
    if ((is_fp32_dest_acc_en && (pack_src_format == to_underlying(DataFormat::Float16))) ||
        (!IS_A_FORMAT(pack_src_format) && (pack_dst_format & 0x1F) == to_underlying(DataFormat::Fp8_e4m3)))
    {
        dest_rd_ctrl.f.PCK_DEST_RD_CTRL_Round_10b_mant = 1;
    }
    cfg[PCK_DEST_RD_CTRL_Read_32b_data_ADDR32] = dest_rd_ctrl.val;

    // Save to GPR for quick data format reconfig
    regfile[p_gpr_pack::EXP0_SEC_SIZE_BFP] = (partial_face ? 1 : num_faces) << THCON_SEC0_REG8_Exp_section_size_SHAMT;
    sync_regfile_write(p_gpr_pack::EXP0_SEC_SIZE_BFP);
}

// Forward declaration: defined later in this file. Needed here so that the non-dependent call
// inside `reconfig_packer_data_format`'s LLK_ASSERT is found via unqualified lookup at
// the template's first-phase name lookup (ADL cannot find it from a std::uint32_t argument).
__attribute__((noinline)) bool is_pack_reads_per_xy_plane(const std::uint32_t expected, const std::uint32_t nop_count = 10);

template <bool is_fp32_dest_acc_en>
__attribute__((noinline)) inline void reconfig_packer_data_format(
    const std::uint32_t pack_src_format,
    const std::uint32_t pack_dst_format,
    const std::uint32_t tile_size,
    const std::uint32_t tile_c_dim,
    const std::uint32_t num_faces,
    const bool partial_face)
{
    LLK_ASSERT(num_faces == 1 || num_faces == 2 || num_faces == 4, "num_faces must be 1, 2, or 4");
    const std::uint32_t pack_output_src_format = masked_data_format(pack_src_format);
    const std::uint32_t pack_output_dst_format = masked_data_format(pack_dst_format);
    // Gasket converts Float16_b -> Float16 before the packer, so hardware in_data_format must be Float16 for Fp8 output.
    const std::uint32_t pack_hw_src_format =
        ((pack_dst_format & 0x1F) == to_underlying(DataFormat::Fp8_e4m3)) ? to_underlying(DataFormat::Float16) : pack_output_src_format;

    LLK_ASSERT(
        is_packer_to_L1_conversion_supported(static_cast<DataFormat>(pack_output_src_format), static_cast<DataFormat>(pack_output_dst_format)),
        "Unsupported packer to L1 conversion.");

    // Configure packers
    pack_config_u config;
    config.val[2] = 0; // Only need to modify word[2][15:0]

    config.f.uncompress      = 1;
    config.f.out_data_format = pack_output_dst_format;
    config.f.in_data_format  = pack_hw_src_format;
    TT_SETDMAREG(0, LOWER_HALFWORD(config.val[2]), 0, LO_16(p_gpr_pack::TMP_LO));
    TTI_STALLWAIT(p_stall::STALL_CFG, p_stall::PACK | p_stall::THCON);
    TTI_WRCFG(p_gpr_pack::TMP_LO, p_cfg::WRCFG_32b, THCON_SEC0_REG1_Row_start_section_size_ADDR32 + 2);

    LLK_ASSERT(
        is_pack_reads_per_xy_plane(1),
        "reconfig_packer_data_format: pack_reads_per_xy_plane counter must be 1 before packer reconfig "
        "(invariant violated; reduce mask should have been cleared via _llk_pack_reduce_mask_clear_). Please uncomment "
        "DEVICE_PRINT #2111 for debugging.");

    dest_rd_ctrl_u dest_rd_ctrl;
    dest_rd_ctrl.val = 0;

    bool is_32b_format = pack_src_format == to_underlying(DataFormat::Int32) || pack_src_format == to_underlying(DataFormat::UInt32) ||
                         pack_src_format == to_underlying(DataFormat::Float32);
    bool is_int8_format = pack_src_format == to_underlying(DataFormat::Int8) || pack_src_format == to_underlying(DataFormat::UInt8);

    dest_rd_ctrl.f.PCK_DEST_RD_CTRL_Read_32b_data = is_32b_format || is_fp32_dest_acc_en;
    dest_rd_ctrl.f.PCK_DEST_RD_CTRL_Read_int8     = !(is_fp32_dest_acc_en || is_32b_format) && is_int8_format;

    if (pack_dst_format == to_underlying(DataFormat::UInt8))
    {
        dest_rd_ctrl.f.PCK_DEST_RD_CTRL_Read_unsigned = 1;
    }
    // Round to 10 bit mantissa from fp32 dest
    if ((is_fp32_dest_acc_en && (pack_src_format == to_underlying(DataFormat::Float16))) ||
        (!IS_A_FORMAT(pack_src_format) && (pack_dst_format & 0x1F) == to_underlying(DataFormat::Fp8_e4m3)))
    {
        dest_rd_ctrl.f.PCK_DEST_RD_CTRL_Round_10b_mant = 1;
    }
    static_assert(
        PCK_DEST_RD_CTRL_Read_32b_data_ADDR32 == PCK_DEST_RD_CTRL_Read_unsigned_ADDR32,
        "PCK_DEST_RD_CTRL_Read_32b_data and Read_unsigned must share ADDR32 for combined RMW");
    static_assert(
        PCK_DEST_RD_CTRL_Read_32b_data_ADDR32 == PCK_DEST_RD_CTRL_Round_10b_mant_ADDR32,
        "PCK_DEST_RD_CTRL_Read_32b_data and Round_10b_mant must share ADDR32 for combined RMW");
    cfg_reg_rmw_tensix<
        PCK_DEST_RD_CTRL_Read_32b_data_ADDR32,
        PCK_DEST_RD_CTRL_Read_32b_data_SHAMT,
        PCK_DEST_RD_CTRL_Read_32b_data_MASK | PCK_DEST_RD_CTRL_Read_unsigned_MASK | PCK_DEST_RD_CTRL_Round_10b_mant_MASK>(dest_rd_ctrl.val);

    if (IS_BFP_FORMAT(pack_output_dst_format))
    {
        cfg_reg_rmw_tensix<THCON_SEC0_REG1_Exp_section_size_RMW>((partial_face ? 1 : num_faces));
    }
    else if ((pack_output_dst_format == to_underlying(DataFormat::Lf8)) || (pack_output_dst_format == to_underlying(DataFormat::Int8)))
    {
        TTI_WRCFG(p_gpr::ZERO, p_cfg::WRCFG_32b, THCON_SEC0_REG1_Row_start_section_size_ADDR32);
    }

    bool is_fp8_e4m3 = (pack_dst_format & 0x1F) == static_cast<DataFormatType>(DataFormat::Fp8_e4m3);
    cfg_reg_rmw_tensix<THCON_SEC0_REG1_Pac_LF8_4b_exp_RMW>(is_fp8_e4m3);

    TT_SETDMAREG(0, LOWER_HALFWORD(tile_size), 0, LO_16(p_gpr_pack::TILE_HEADER));

    reconfigure_exp_threshold<is_fp32_dest_acc_en>(pack_output_dst_format);

    cfg_reg_rmw_tensix<ALU_FORMAT_SPEC_REG2_Dstacc_RMW>(is_fp8_e4m3 ? to_underlying(DataFormat::Float16) : pack_output_src_format);

    // Set packer strides
    set_packer_strides<PackMode::Default>(pack_output_src_format, tile_c_dim);

    // Program the packer X (datum) counter. _llk_pack_init_ owns this counter ("inits own SETADCXX"),
    // but reconfig also programs it here: a reconfig is not always followed by an init, and on Blackhole
    // the value is a mode-independent constant (single row, FACE_C_DIM - 1), so it is safe to set here.
    TTI_SETADCXX(p_setadc::PAC, FACE_C_DIM - 1, 0x0);
}

template <bool is_fp32_dest_acc_en, PackMode pack_mode = PackMode::Default>
inline void configure_pack(
    const std::uint32_t pack_src_format,
    const std::uint32_t pack_dst_format,
    const std::uint32_t tile_size,
    [[maybe_unused]] const std::uint32_t face_r_dim = FACE_R_DIM,
    const std::uint32_t tile_c_dim                  = TILE_C_DIM,
    const std::uint32_t num_faces                   = 4,
    const bool partial_face                         = false,
    const std::uint32_t relu_config                 = 0)
{
    LLK_ASSERT(num_faces == 1 || num_faces == 2 || num_faces == 4, "num_faces must be 1, 2, or 4");
    LLK_ASSERT(
        is_packer_to_L1_conversion_supported(static_cast<DataFormat>(pack_src_format & 0xF), static_cast<DataFormat>(pack_dst_format & 0xF)),
        "Unsupported packer to L1 conversion.");
    // Get pointer to registers for current state ID
    volatile std::uint32_t* cfg = get_cfg_pointer();

    // Drain the packer before any of the configuration below is rewritten, whatever the formats. The raw
    // cfg[] stores in this function and in set_packer_config are RISC MMIO, which no STALLWAIT can hold
    // back: the STALLWAIT only keeps new packer instructions out, and tensix_sync() blocks this RISC until
    // the packer has gone idle, which is what orders those stores behind a pack still in flight. Without
    // it the pack samples the new format/width mid-tile.
    TTI_STALLWAIT(p_stall::STALL_PACK, p_stall::PACK);
    tensix_sync();

    const std::uint32_t pack_output_src_format = masked_data_format(pack_src_format);

    set_packer_strides<pack_mode>(pack_src_format, tile_c_dim);

    // NOTE: the packer X (datum) counter (SETADCXX PAC) is intentionally NOT programmed here. It is
    // owned by _llk_pack_init_, which runs after hw-configure and sets its own value per the
    // "inits own SETADCXX" contract.

    t6_mutex_acquire(mutex::REG_RMW);

    // Set Fp8 E4M3 mode for packer
    bool is_fp8_e4m3 = (pack_dst_format & 0x1F) == (std::uint32_t)DataFormat::Fp8_e4m3;
    cfg_reg_rmw_tensix<THCON_SEC0_REG1_Pac_LF8_4b_exp_RMW>(is_fp8_e4m3);

    cfg_reg_rmw_tensix<ALU_FORMAT_SPEC_REG2_Dstacc_RMW>(is_fp8_e4m3 ? to_underlying(DataFormat::Float16) : pack_output_src_format);

    // Establish the no-override baseline for the Dstacc ALU format-select fields (ADDR32=0), consumed
    // by the packer: clear Dstacc_val/override so the base REG2_Dstacc format programmed above is
    // used. The SrcA/SrcB override fields in the same word are owned by the math thread
    // (_llk_math_hw_configure_); the two writers touch disjoint bits and rely on per-byte RMWCIB
    // atomicity, so this write does not depend on the surrounding REG_RMW mutex for cross-thread safety.
    constexpr std::uint32_t dstacc_fmt_override_mask = ALU_FORMAT_SPEC_REG_Dstacc_val_MASK | ALU_FORMAT_SPEC_REG_Dstacc_override_MASK;
    cfg_reg_rmw_tensix<ALU_FORMAT_SPEC_REG_Dstacc_val_ADDR32, 0, dstacc_fmt_override_mask>(0);

    // Config RELU
    relu_config_u hw_relu_config;
    hw_relu_config.r.STACC_RELU_ApplyRelu     = relu_config & 0xffff;
    hw_relu_config.r.STACC_RELU_ReluThreshold = (relu_config >> 16) & 0xffff;

    static_assert(STACC_RELU_ApplyRelu_ADDR32 == STACC_RELU_ReluThreshold_ADDR32, "STACC_RELU_ApplyRelu and ReluThreshold must share ADDR32 for combined RMW");

    constexpr std::uint32_t hw_relu_mask = STACC_RELU_ApplyRelu_MASK | STACC_RELU_ReluThreshold_MASK;
    cfg_reg_rmw_tensix<STACC_RELU_ApplyRelu_ADDR32, 0, hw_relu_mask>(hw_relu_config.val[0]);

    t6_mutex_release(mutex::REG_RMW);

    set_packer_config<is_fp32_dest_acc_en>(pack_src_format, pack_dst_format, num_faces, partial_face);

    // PACK_COUNTERS_SEC0_pack_per_xy_plane = cfg_reg_array[3][0 +: 8];
    // PACK_COUNTERS_SEC0_pack_reads_per_xy_plane = cfg_reg_array[3][8 +: 8];
    // PACK_COUNTERS_SEC0_pack_xys_per_tile = cfg_reg_array[3][16 +: 7];
    // PACK_COUNTERS_SEC0_pack_yz_transposed = cfg_reg_array[3][23 +: 1];
    pack_counters_u pack_counters;
    pack_counters.val = 0;
    // Number of reads per face used for resetting tile position generator for edge masks.
    pack_counters.f.pack_reads_per_xy_plane = 1;
    for (std::uint32_t i = 0; i < NUM_PACKERS; i++)
    {
        cfg[PACK_COUNTERS_SEC0_pack_per_xy_plane_ADDR32 + i] = pack_counters.val; // disable auto last generation
    }

    pck_edge_offset_u pck_edge_offset;
    pck_edge_offset.val    = 0;
    pck_edge_offset.f.mask = 0xffff;

    cfg[PCK_EDGE_OFFSET_SEC0_mask_ADDR32]                = pck_edge_offset.val;
    cfg[TILE_ROW_SET_MAPPING_0_row_set_mapping_0_ADDR32] = 0x0; // All packers use row set mapping 0, edge offset 0 mask

    regfile[p_gpr_pack::TILE_HEADER]     = tile_size;
    regfile[p_gpr_pack::TILE_HEADER + 1] = 0;
    regfile[p_gpr_pack::TILE_HEADER + 2] = 0;
    regfile[p_gpr_pack::TILE_HEADER + 3] = 0;
    sync_regfile_write(p_gpr_pack::TILE_HEADER + 3);
}

inline std::uint8_t get_packer_dest_offset_index()
{
    return (dest_offset_id ? p_gpr_pack::DEST_OFFSET_HI : p_gpr_pack::DEST_OFFSET_LO);
}

inline std::uint32_t get_packer_dest_offset()
{
    return (dest_offset_id ? DEST_REGISTER_HALF_SIZE : 0x0);
}

inline void flip_packer_dest_offset_id()
{
    dest_offset_id = 1 - dest_offset_id;
}

// Flip packer dest register offset to 0 or DEST_REGISTER_HALF_SIZE
// flip-flopping between two halves
template <DstSync Dst>
inline void select_packer_dest_registers()
{
    if constexpr (Dst == DstSync::SyncFull)
    {
        TTI_WRCFG(p_gpr_pack::DEST_OFFSET_LO, p_cfg::WRCFG_32b, DEST_TARGET_REG_CFG_PACK_SEC0_Offset_ADDR32);
    }
    else
    {
        TT_WRCFG(get_packer_dest_offset_index(), p_cfg::WRCFG_32b, DEST_TARGET_REG_CFG_PACK_SEC0_Offset_ADDR32);
    }
    TTI_DMANOP;
    TTI_DMANOP;
}

// Program packer destination addresses from GPRs
// keep_output_addr: leave OUTPUT_ADDR holding the plain address, which fast tilize advances from.
template <bool keep_output_addr = true>
inline void program_packer_destination(std::uint32_t addr)
{
    LLK_ASSERT(is_valid_L1_address(addr), "L1 address must be in valid L1 memory region");
    // No packer-drain STALLWAIT is needed before reprogramming the destination: the pack thread issues its
    // instruction stream in order, so each tile's PACR has already started -- and latched L1_Dest_addr,
    // sampled at PACR start -- before the next call's WRCFG reprograms it, and the Last=1 PACR that ends each
    // pack MOP drains the packer and forces the next pack to re-sample L1_Dest_addr. The STALLWAIT below is
    // only the GPR-producer fence: it ensures the SETDMAREG write to OUTPUT_ADDR retires before WRCFG reads it.
    if constexpr (!keep_output_addr)
    {
        // Byte 3 (bit 31) is the row pack init's; another pack program between two row packs replaces the row pack's MOP,
        // so the init runs again before the next one.
        TT_RMWCIB0(0xff, addr & 0xff, THCON_SEC0_REG1_L1_Dest_addr_ADDR32);
        TT_RMWCIB1(0xff, (addr >> 8) & 0xff, THCON_SEC0_REG1_L1_Dest_addr_ADDR32);
        TT_RMWCIB2(0xff, (addr >> 16) & 0xff, THCON_SEC0_REG1_L1_Dest_addr_ADDR32);
        return;
    }
    std::uint32_t new_l1_addr = (1 << 31) | addr;
    TT_SETDMAREG(0, LOWER_HALFWORD(addr), 0, LO_16(p_gpr_pack::OUTPUT_ADDR));
    TT_SETDMAREG(0, UPPER_HALFWORD(new_l1_addr), 0, HI_16(p_gpr_pack::OUTPUT_ADDR));

    TTI_STALLWAIT(p_stall::STALL_CFG, p_stall::THCON);
    TTI_WRCFG(p_gpr_pack::OUTPUT_ADDR, 0, THCON_SEC0_REG1_L1_Dest_addr_ADDR32);

    TT_SETDMAREG(0, UPPER_HALFWORD(addr), 0, HI_16(p_gpr_pack::OUTPUT_ADDR));
    TTI_DMANOP; // One NOP should be enough for WRCFG due to SETDMAREG above.
}

// RT: If multiple contexts are used, for issue #https://github.com/tenstorrent/tt-llk-bh/issues/20
// then this function needs to be re-written
template <std::uint32_t block_ct_dim, std::uint32_t full_ct_dim, bool diagonal = false>
inline void program_packer_untilized_destination(const std::uint32_t addr, const std::uint32_t pack_dst_format)
{
    // const uint32_t block_size = SCALE_DATUM_SIZE(pack_dst_format, full_ct_dim * TILE_C_DIM * (TILE_R_DIM/4));
    // constexpr uint32_t offset0 = 0;
    // const uint32_t offset1 = (1*block_size)/16;
    // const uint32_t offset2 = (2*block_size)/16;
    // const uint32_t offset3 = (3*block_size)/16;

    // TT_SETDMAREG(0, LOWER_HALFWORD(addr+offset0), 0, LO_16(p_gpr_pack::OUTPUT_ADDR+0));
    // TT_SETDMAREG(0, UPPER_HALFWORD(addr+offset0), 0, HI_16(p_gpr_pack::OUTPUT_ADDR+0));
    // TT_SETDMAREG(0, LOWER_HALFWORD(addr+offset1), 0, LO_16(p_gpr_pack::OUTPUT_ADDR+1));
    // TT_SETDMAREG(0, UPPER_HALFWORD(addr+offset1), 0, HI_16(p_gpr_pack::OUTPUT_ADDR+1));
    // TT_SETDMAREG(0, LOWER_HALFWORD(addr+offset2), 0, LO_16(p_gpr_pack::OUTPUT_ADDR+2));
    // TT_SETDMAREG(0, UPPER_HALFWORD(addr+offset2), 0, HI_16(p_gpr_pack::OUTPUT_ADDR+2));
    // TT_SETDMAREG(0, LOWER_HALFWORD(addr+offset3), 0, LO_16(p_gpr_pack::OUTPUT_ADDR+3));
    // TT_SETDMAREG(0, UPPER_HALFWORD(addr+offset3), 0, HI_16(p_gpr_pack::OUTPUT_ADDR+3));
    // TTI_STALLWAIT(p_stall::STALL_CFG, p_stall::THCON);

    // TTI_WRCFG(p_gpr_pack::OUTPUT_ADDR, 0, THCON_SEC0_REG1_L1_Dest_addr_ADDR32);
    // TTI_WRCFG(p_gpr_pack::OUTPUT_ADDR+1, 0, THCON_SEC0_REG8_L1_Dest_addr_ADDR32);
    // TTI_WRCFG(p_gpr_pack::OUTPUT_ADDR+2, 0, THCON_SEC1_REG1_L1_Dest_addr_ADDR32);
    // TTI_WRCFG(p_gpr_pack::OUTPUT_ADDR+3, 0, THCON_SEC1_REG8_L1_Dest_addr_ADDR32);
    // TTI_NOP; TTI_NOP;
}

inline void program_packer_dest_offset_registers(std::uint32_t dest_tile_offset)
{
    TT_SETDMAREG(0, LOWER_HALFWORD(dest_tile_offset), 0, LO_16(p_gpr_pack::TEMP_TILE_OFFSET));
    TT_SETDMAREG(0, UPPER_HALFWORD(dest_tile_offset), 0, HI_16(p_gpr_pack::TEMP_TILE_OFFSET));
    TTI_STALLWAIT(p_stall::STALL_CFG, p_stall::THCON | p_stall::PACK);
    TTI_WRCFG(p_gpr_pack::TEMP_TILE_OFFSET, p_cfg::WRCFG_32b, PCK0_ADDR_BASE_REG_0_Base_ADDR32);
    TTI_DMANOP;
    TTI_DMANOP;
}

// READERS FOR CONFIG STRUCTS

inline pack_config_t read_pack_config_helper(std::uint32_t reg_addr, const volatile std::uint32_t tt_reg_ptr* cfg)
{
    pack_config_u config = {.val = 0};

    config.val[0] = cfg[reg_addr];
    config.val[1] = cfg[reg_addr + 1];
    config.val[2] = cfg[reg_addr + 2];

    return config.f;
}

__attribute__((noinline)) std::array<pack_config_t, NUM_PACKERS> read_pack_config()
{
    std::array<pack_config_t, NUM_PACKERS> config_vec;

    // Get pointer to registers for current state ID
    volatile std::uint32_t tt_reg_ptr* cfg = get_cfg_pointer();

    config_vec[0] = read_pack_config_helper(THCON_SEC0_REG1_Row_start_section_size_ADDR32, cfg);

    return config_vec;
}

inline relu_config_t read_relu_config()
{
    relu_config_u config;

    // Get pointer to registers for current state ID
    volatile std::uint32_t tt_reg_ptr* cfg = get_cfg_pointer();
    config.val[0]                          = cfg[ALU_ACC_CTRL_Zero_Flag_disabled_src_ADDR32];

    return config.r;
}

inline dest_rd_ctrl_t read_dest_rd_ctrl()
{
    dest_rd_ctrl_u dest;

    // Get pointer to registers for current state ID
    volatile std::uint32_t tt_reg_ptr* cfg = get_cfg_pointer();

    dest.val = cfg[PCK_DEST_RD_CTRL_Read_32b_data_ADDR32];

    return dest.f;
}

inline pck_edge_offset_t read_pack_edge_offset_helper(std::uint32_t reg_addr, const volatile std::uint32_t tt_reg_ptr* cfg)
{
    pck_edge_offset_u edge = {.val = 0};

    edge.val = cfg[reg_addr];

    return edge.f;
}

inline std::array<pck_edge_offset_t, NUM_PACKERS> read_pack_edge_offset()
{
    std::array<pck_edge_offset_t, NUM_PACKERS> edge_vec;

    // Get pointer to registers for current state ID
    volatile std::uint32_t tt_reg_ptr* cfg = get_cfg_pointer();

    edge_vec[0] = read_pack_edge_offset_helper(PCK_EDGE_OFFSET_SEC0_mask_ADDR32, cfg);

    return edge_vec;
}

inline pack_counters_t read_pack_counters_helper(std::uint32_t reg_addr, const volatile std::uint32_t tt_reg_ptr* cfg)
{
    pack_counters_u counters = {.val = 0};
    counters.val             = cfg[reg_addr];

    return counters.f;
}

__attribute__((noinline)) std::array<pack_counters_t, NUM_PACKERS> read_pack_counters()
{
    std::array<pack_counters_t, NUM_PACKERS> config_vec;

    // Get pointer to registers for current state ID
    volatile std::uint32_t tt_reg_ptr* cfg = get_cfg_pointer();

    config_vec[0] = read_pack_counters_helper(PACK_COUNTERS_SEC0_pack_per_xy_plane_ADDR32, cfg);

    return config_vec;
}

/**
 * Validates that all packers' config matches the expected formats.
 * On mismatch, issues DEVICE_PRINT (when enabled) and LLK_ASSERT. Typically invoked via
 * `LLK_ASSERT_BLOCK(are_packers_configured_correctly(...))` in llk_pack_tile_api.h.
 *
 * The pack_reads_per_xy_plane counter is validated separately via is_pack_reads_per_xy_plane
 * (invoked at reconfig time), since its expected value depends on whether a reduce mask is
 * currently programmed, not on the per-pack call site.
 *
 * @param pack_src_format   Expected input data format for all packers
 * @param pack_dst_format   Expected output data format for all packers
 * @param nop_count         Number of nop operations to ensure configuration writes complete (default 10)
 */
__attribute__((noinline)) void are_packers_configured_correctly(
    const std::uint32_t pack_src_format, const std::uint32_t pack_dst_format, const std::uint32_t nop_count = 10)
{
    // Ensure configuration writes complete before subsequent operations
    tensix_sync();
    for (std::uint32_t i = 0; i < nop_count; i++)
    {
        asm volatile("nop");
    }

    static_assert(NUM_PACKERS == 1, "NUM_PACKERS must be 1");
    const pack_config_t config = read_pack_config()[0];
    // Must match set_packer_config / reconfig_packer_data_format: gasket feeds Float16 into the packer for Fp8_e4m3 L1 output.
    const std::uint32_t pack_output_src_format = masked_data_format(pack_src_format);
    const std::uint32_t pack_output_dst_format = masked_data_format(pack_dst_format);

    // Special case for Fp8_e4m3: Gasket feeds Float16 into the packer for L1 output.
    const std::uint32_t pack_hw_src_format =
        ((pack_dst_format & 0x1F) == to_underlying(DataFormat::Fp8_e4m3)) ? to_underlying(DataFormat::Float16) : pack_output_src_format;

    if (config.in_data_format != pack_hw_src_format)
    {
        // DEVICE_PRINT("#1101 are_packers_configured_correctly: pack_src_format mismatch. expected: {}, actual: {}\n", pack_hw_src_format,
        // config.in_data_format);
        LLK_ASSERT(
            (config.in_data_format == pack_hw_src_format),
            "are_packers_configured_correctly: pack_src_format mismatch. Uncomment DEVICE_PRINT #1101 to inspect "
            "expected/actual.");
    }
    if (config.out_data_format != pack_output_dst_format)
    {
        // DEVICE_PRINT("#1102 are_packers_configured_correctly: pack_dst_format mismatch. expected: {}, actual: {}\n", pack_output_dst_format,
        // config.out_data_format);
        LLK_ASSERT(
            (config.out_data_format == pack_output_dst_format),
            "are_packers_configured_correctly: pack_dst_format mismatch. Uncomment DEVICE_PRINT #1102 to inspect "
            "expected/actual.");
    }
}

/**
 * Validates that the packer pack_reads_per_xy_plane counter matches the expected value.
 * Intended to be called from reconfig paths to assert the invariant: between non-reduce
 * operations the counter is 1; the reduce layer owns transitions to FACE_R_DIM via
 * `_llk_pack_reduce_mask_config_` and back to 1 via `_llk_pack_reduce_mask_clear_`.
 *
 * @param expected   Expected value of pack_reads_per_xy_plane
 * @param nop_count  Number of nop operations to ensure configuration writes complete (default 10)
 * @return true if the packer counter matches expected, false otherwise.
 */
__attribute__((noinline)) bool is_pack_reads_per_xy_plane(const std::uint32_t expected, const std::uint32_t nop_count)
{
    // Ensure configuration writes complete before reading back
    tensix_sync();
    for (std::uint32_t i = 0; i < nop_count; i++)
    {
        asm volatile("nop");
    }

    static_assert(NUM_PACKERS == 1, "NUM_PACKERS must be 1");
    const pack_counters_t counters = read_pack_counters()[0];
    if (counters.pack_reads_per_xy_plane != expected)
    {
        // Debug: print the mismatched packer counter value.
        // DEVICE_PRINT(
        //     "#2111 is_pack_reads_per_xy_plane: mismatch on packer 0 (expected={}) actual [P0={}]\n",
        //     expected,
        //     counters.pack_reads_per_xy_plane);
        return false;
    }
    return true;
}

} // namespace ckernel::packer
