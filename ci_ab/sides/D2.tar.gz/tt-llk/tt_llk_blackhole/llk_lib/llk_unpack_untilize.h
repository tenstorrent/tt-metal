// SPDX-FileCopyrightText: © 2025 Tenstorrent AI ULC
//
// SPDX-License-Identifier: Apache-2.0

// DEPRECATED: The unpack-based untilize LLK has poor performance and is deprecated in favor of the
// pack_untilize LLK (llk_pack_untilize.h). It is retained only for the legacy untilize compute API and
// is scheduled for removal; see tt-metal#22904.

#pragma once

#include <cstdint>

#include "ckernel.h"
#include "ckernel_defs.h"
#include "ckernel_globals.h"
#include "ckernel_ops.h"
#include "ckernel_template.h"
#include "cunpack_common.h"
#include "llk_unpack_common.h"

using namespace ckernel;
using namespace ckernel::unpacker;

/**
 * @brief Program the unpacker MOP/replay buffer for an untilize operation.
 *
 * Builds a replay buffer that unpacks SrcA rows while advancing the per-tile offset address and
 * resetting the Z counter, and configures the unpack template to reload the offset address into
 * the correct config context between iterations.
 */
inline void _llk_unpack_untilize_mop_config_()
{
    constexpr std::uint32_t replay_buf_len = 6;
    load_replay_buf(
        0,
        replay_buf_len,
        // Lambda function to set up replay buffer
        []
        {
            TTI_DMANOP; // WRCFG that sets offset in previous loop needs additional cycle to complete
            TTI_UNPACR(SrcA, 0b01000001 /*CH1_Y+=1, CH0_Z+=1*/, 0, 0, 0, 1, 0, p_unpacr::RAREFYB_DISABLE, 0, 0, 0, 0, 1);
            TTI_UNPACR(SrcA, 0b01000001 /*CH1_Y+=1, CH0_Z+=1*/, 0, 0, 0, 1, 0, p_unpacr::RAREFYB_DISABLE, 0, 0, 0, 0, 1);
            TTI_ADDDMAREG(0, p_gpr_unpack::TILE_OFFSET, p_gpr_unpack::TILE_OFFSET, p_gpr_unpack::TILE_SIZE);
            // Need to stall WRCFG on the addition from ADDDMAREG
            TTI_STALLWAIT(p_stall::STALL_CFG, p_stall::THCON);
            // Resets SrcA Z counter CR, which should point to initial Z counter value
            TTI_ADDRCRZW(0b001, 0, 0, 0, 0, 0b0001 /*CH0_Z*/);
        });

    static constexpr std::uint32_t load_offset_addr_cntx0 = TT_OP_WRCFG(p_gpr_unpack::TILE_OFFSET, p_cfg::WRCFG_32b, THCON_SEC0_REG7_Offset_address_ADDR32);
    static constexpr std::uint32_t load_offset_addr_cntx1 =
        TT_OP_WRCFG(p_gpr_unpack::TILE_OFFSET, p_cfg::WRCFG_32b, THCON_SEC0_REG7_Offset_cntx1_address_ADDR32);

    ckernel_unpack_template tmp = ckernel_unpack_template(
        true,  // src B
        false, // halo - just used for 4 unpacks
        lltt::replay_insn(0, replay_buf_len),
        0,
        0,
        0,
        lltt::replay_insn(0, replay_buf_len),
        load_offset_addr_cntx0,
        load_offset_addr_cntx1);
    tmp.program();
}

/**
 * @brief Initialize the unpacker for an untilize operation.
 *
 * Disables face transpose, saves the unpacker stride/tile-dim config into scratch GPRs, programs
 * the 1x16-row stride and tile dimensions for untilize, loads the tile size and clears the tile
 * offset GPR, then programs the untilize MOP.
 *
 * @param unpack_dst_format: Destination data format the operand is converted to.
 * @param tile_size: Size of one tile, stored to the tile-size GPR for per-tile offset stepping.
 * @param face_r_dim: Rows per face.
 * @note Call @ref _llk_unpack_untilize_uninit_ to restore the default unpacker config.
 * @ref _llk_unpack_untilize_pass_ is the matching execute call.
 * @ref _llk_math_eltwise_unary_datacopy_init_ (A2D) is the matching init on the math thread.
 */
inline void _llk_unpack_untilize_init_(const std::uint32_t unpack_dst_format, const std::uint32_t tile_size, const std::uint32_t face_r_dim = FACE_R_DIM)
{
    // Always include setup calls first for safety (as recommended by maintainer)
    // Disable transpose when unused
    cfg_reg_rmw_tensix<THCON_SEC0_REG2_Haloize_mode_RMW>(0);

    // Save state of unpacker config for quick restore
    TTI_RDCFG(p_gpr_unpack::SR_UNPACK_UNTILIZER_STATE_0,
              UNP0_ADDR_CTRL_XY_REG_1_Ystride_ADDR32); // Save unpack stride config
    TTI_RDCFG(p_gpr_unpack::SR_UNPACK_UNTILIZER_STATE_1,
              THCON_SEC0_REG5_Tile_x_dim_cntx0_ADDR32); // Save tile x dim per context
    TTI_RDCFG(p_gpr_unpack::SR_UNPACK_UNTILIZER_STATE_2,
              THCON_SEC0_REG0_TileDescriptor_ADDR32 + 1); // Save descriptor 1

    // Core untilize initialization logic
    const DataFormat dst_format           = static_cast<DataFormat>(unpack_dst_format & 0x3);
    const std::uint32_t unpA_ch1_x_stride = dst_format == DataFormat::Float32 ? 4 : dst_format == DataFormat::Float16 ? 2 : 1;
    const std::uint32_t unpA_ch1_y_stride = FACE_R_DIM * unpA_ch1_x_stride;

    // Set address control for unpacker A
    TT_SETADCXX(p_setadc::UNP_A, face_r_dim * FACE_C_DIM - 1, 0x0);

    // Configure unpacker registers
    // Get pointer to registers for current state ID
    TTI_STALLWAIT(p_stall::STALL_CFG, p_stall::UNPACK);
    cfg_reg_rmw_tensix<UNP0_ADDR_CTRL_XY_REG_1_Ystride_ADDR32, UNP0_ADDR_CTRL_XY_REG_1_Ystride_SHAMT, UNP0_ADDR_CTRL_XY_REG_1_Ystride_MASK>(unpA_ch1_y_stride);
    cfg_reg_rmw_tensix<THCON_SEC0_REG0_TileDescriptor_ADDR32 + 1, 0, 0xFFFF>(FACE_C_DIM);

    // Configure tile dimensions
    // TTI_REG2FLOP(1,0,0,0,THCON_SEC0_REG5_Tile_x_dim_cntx0_ADDR32-THCON_CFGREG_BASE_ADDR32, p_gpr_unpack::FACE_DIM_1x16); //GPR preloaded with  16 | (16 <<
    // 16)
    TTI_WRCFG(p_gpr_unpack::FACE_DIM_1x16, p_cfg::WRCFG_32b, THCON_SEC0_REG5_Tile_x_dim_cntx0_ADDR32); // GPR preloaded with  16 | (16 << 16)

    // Set tile size in DMA registers
    TT_SETDMAREG(0, LOWER_HALFWORD(tile_size), 0, LO_16(p_gpr_unpack::TILE_SIZE));
    TT_SETDMAREG(0, UPPER_HALFWORD(tile_size), 0, HI_16(p_gpr_unpack::TILE_SIZE));
    // Reset TILE_OFFSET reg if some other API used it, it was used by tilize (not anymore) but better to clear it just in case
    TTI_SETDMAREG(0, LOWER_HALFWORD(0), 0, LO_16(p_gpr_unpack::TILE_OFFSET));
    TTI_SETDMAREG(0, UPPER_HALFWORD(0), 0, HI_16(p_gpr_unpack::TILE_OFFSET));

    // Configure MOP (Memory Operation Program) for untilize
    _llk_unpack_untilize_mop_config_();
}

/**
 * @brief Restore unpacker state after an untilize operation.
 *
 * Waits for the unpacker to go idle, reinitializes the address counters, and reverts the
 * X-dimension datum count, tile X-dim, descriptor and Y stride back to the default face layout.
 *
 * @param unpack_dst_format: Destination data format used to recompute the restored Y stride.
 * @param face_r_dim: Rows per face, used to compute the restored datum count and Y stride.
 * @note Call @ref _llk_unpack_untilize_init_ before this function.
 */
inline void _llk_unpack_untilize_uninit_(const std::uint32_t unpack_dst_format, const std::uint32_t face_r_dim)
{
    const DataFormat dst_format           = static_cast<DataFormat>(unpack_dst_format & 0x3);
    const std::uint32_t unpA_ch1_x_stride = dst_format == DataFormat::Float32 ? 4 : dst_format == DataFormat::Float16 ? 2 : 1;
    const std::uint32_t unpA_ch1_y_stride = FACE_C_DIM * face_r_dim * unpA_ch1_x_stride;

    // Check that unpacker is done (all contexts freed up) before starting hw configuration
    wait_for_idle();

    // Reset address counters
    unpacker_addr_counter_init();

    // Wait for cfg to be free to edit
    TTI_STALLWAIT(p_stall::STALL_CFG, p_stall::UNPACK);

    TTI_STALLWAIT(p_stall::STALL_CFG, p_stall::THCON);
    TTI_WRCFG(p_gpr_unpack::FACE_DIM_16x16, p_cfg::WRCFG_32b, THCON_SEC0_REG5_Tile_x_dim_cntx0_ADDR32);
    cfg_reg_rmw_tensix<THCON_SEC0_REG0_TileDescriptor_ADDR32 + 1, 0, 0xFFFF>(1);
    cfg_reg_rmw_tensix<UNP0_ADDR_CTRL_XY_REG_1_Ystride_ADDR32, UNP0_ADDR_CTRL_XY_REG_1_Ystride_SHAMT, UNP0_ADDR_CTRL_XY_REG_1_Ystride_MASK>(unpA_ch1_y_stride);

    TTI_NOP;
}

/**
 * @brief Run one untilize pass (top or bottom faces) over a row of tiles.
 *
 * Selects the top or bottom faces by the template flag, programs the base address, and unpacks the
 * block row by row into SrcA, running the MOP in chunks sized to the 2-row face stride and
 * resetting the tile offset between rows, with semaphore sync and config-context switching.
 *
 * @tparam first_pass: Select the top faces (true) or bottom faces (false) of each tile.
 * @param base_address: L1 base address of the tile row to untilize.
 * @param block_tile_cols: Number of tile columns in the block row.
 * @note Call @ref _llk_unpack_untilize_init_ before this function, and
 *       @ref _llk_unpack_untilize_uninit_ after the final pass to restore modified state.
 */
template <bool first_pass = true>
inline void _llk_unpack_untilize_pass_(const std::uint32_t base_address, const std::uint32_t block_tile_cols)
{
    std::uint32_t rem_blocks_in_row = block_tile_cols;

    // Program srcA and srcB base addresses
    volatile std::uint32_t tt_reg_ptr *cfg = get_cfg_pointer(); // get pointer to registers for current state ID

    TTI_SETADCXY(0b001, 0, 0, 0, 0, 0b0010); // Clear l1 addr y cnt
    if constexpr (first_pass)
    {
        // Select top faces in the 1st pass
        TTI_SETADC(p_setadc::UNP0, p_setadc::CH_0, p_setadc::SET_Z, 0);
    }
    else
    {
        // Select bottom faces in the 2nd pass
        TTI_SETADC(p_setadc::UNP0, p_setadc::CH_0, p_setadc::SET_Z, 2);
    }

    // Wait for free context
    wait_for_next_context(2);

    // Validate and configure address
    _llk_unpack_configure_single_address_(base_address, cfg);

    // Trisc::SEMPOST for context acquire
    semaphore_post(semaphore::UNPACK_SYNC);

    // Stall unpacker until pending CFG writes from Trisc have completed
    TTI_STALLWAIT(p_stall::STALL_UNPACK, p_stall::TRISC_CFG);

    std::uint32_t face_2xr_cnt = 0;
    for (std::uint32_t r = 0; r < FACE_HEIGHT; r++)
    {
        rem_blocks_in_row = block_tile_cols; // reset remaining blocks in row

        do
        {
            if ((face_2xr_cnt + rem_blocks_in_row) >= (FACE_HEIGHT / 2))
            {
                // Run MOP
                TT_MOP(0, 8 - face_2xr_cnt - 1, unp_cfg_context == 0 ? 0 : 0xff);               // Run the MOP
                TTI_UNPACR(SrcA, 0b0, 0, 0, 0, 1, 1, p_unpacr::RAREFYB_DISABLE, 0, 0, 0, 0, 1); // set data valid
                TTI_UNPACR_NOP(SrcB, 0, 0, p_unpacr_nop::SET_DVALID, 0, p_unpacr_nop::WAIT_LIKE_UNPACR, 0, 0, p_unpacr_nop::UNP_ZEROSRC);
                TTI_SETADCXY(0b001, 0, 0, 0, 0, 0b1000); // Clear srcA addr y cnt
                rem_blocks_in_row -= (8 - face_2xr_cnt);
                face_2xr_cnt = 0;
            }
            else
            {
                TT_MOP(0, rem_blocks_in_row - 1, unp_cfg_context == 0 ? 0 : 0xff); // Run the MOP
                face_2xr_cnt += rem_blocks_in_row;
                rem_blocks_in_row = 0;
                // if (face_2xr_cnt==FACE_HEIGHT/2) {
                //   TTI_UNPACR(SrcA, 0b0, 0, 0, 0, 0, 1, p_unpacr::RAREFYB_DISABLE, 0, 0, 0, 0, 1); //set data valid
                //   TTI_SETADCXY(0b001, 0, 0, 0, 0, 0b1000); // Clear srcA addr y cnt
                //   face_2xr_cnt = 0;
                //}
            }
        } while (rem_blocks_in_row > 0);

        TTI_MULDMAREG(0, p_gpr_unpack::TILE_OFFSET, p_gpr_unpack::TILE_OFFSET, p_gpr::ZERO); // TILE_OFFSET=TILE_OFFSET*0
        TTI_STALLWAIT(p_stall::STALL_CFG, p_stall::THCON);
        if (0 == unp_cfg_context)
        {
            TTI_WRCFG(p_gpr::ZERO, p_cfg::WRCFG_32b, THCON_SEC0_REG7_Offset_address_ADDR32);
        }
        else
        {
            TTI_WRCFG(p_gpr::ZERO, p_cfg::WRCFG_32b, THCON_SEC0_REG7_Offset_cntx1_address_ADDR32);
        }
        TTI_INCADCXY(0b001, 0, 0, 1, 0); // inc l1 addr y cnt
    }

    // T6::SEMGET for context release
    t6_semaphore_get(semaphore::UNPACK_SYNC);

    // Switch unpacker config context
    switch_config_context(unp_cfg_context);
}
