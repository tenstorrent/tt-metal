// SPDX-FileCopyrightText: © 2026 Tenstorrent AI ULC
//
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include <cstdint>

#include "../registers.h"
#include "cfg_defines.h"

namespace hal::cfg::detail
{

// Layout of the memory at TENSIX_CFG_BASE:
//
//     uint32_t Config[2][CFG_STATE_SIZE * 4];
//     uint32_t ConfigDualWrite[CFG_STATE_SIZE * 4];
//     struct {uint16_t Value, Padding;} ThreadConfig[3][THD_STATE_SIZE];
inline constexpr std::uint32_t StateCfgWordCount    = CFG_STATE_SIZE * 4; ///< Number of 32-bit words in one state-CFG bank.
inline constexpr std::uint32_t StateCfgBankCount    = 2;                  ///< Number of state-CFG banks.
inline constexpr std::uint32_t ConfigDualWriteWords = StateCfgWordCount;  ///< Size of the dual-write MMIO window in 32-bit words.
inline constexpr std::uint32_t ThreadCfgWordCount   = THD_STATE_SIZE;     ///< Number of thread-CFG words in one thread's bank.
inline constexpr std::uint32_t ThreadCfgWordMask    = 0xffffu;            ///< Value mask for a 16-bit thread-CFG word.
inline constexpr std::uint32_t CregSelectorMax      = 0x7ffu;             ///< Largest encoded debug CREG read selector.

/** @brief Word offset of the first thread-CFG bank from TENSIX_CFG_BASE. */
inline constexpr std::uint32_t ThreadCfgBase = StateCfgBankCount * StateCfgWordCount + ConfigDualWriteWords;

/**
 * @brief Select the register-word capacity of a CFG bank from its scope.
 *
 * @param scope: RegisterScope::State or RegisterScope::Thread.
 * @return Number of CFG words in one bank of the selected register space.
 */
inline constexpr std::uint32_t cfg_word_count(RegisterScope scope)
{
    return scope == RegisterScope::Thread ? ThreadCfgWordCount : StateCfgWordCount;
}

static_assert(ChickenBits::sfpu_scbd_disable.addr32(Sec::S0) < StateCfgWordCount, "state CFG descriptor lies outside a hardware CFG bank");
static_assert(TensixCsrConfig::RawBusyStatus.addr32(Sec::S0) < ThreadCfgWordCount, "thread CFG descriptor lies outside a hardware thread bank");

} // namespace hal::cfg::detail
