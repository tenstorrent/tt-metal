// SPDX-FileCopyrightText: © 2026 Tenstorrent AI ULC
//
// SPDX-License-Identifier: Apache-2.0
//
// offsets source: tt_metal/hw/inc/internal/tt-1xx/blackhole/cfg_defines.h
#pragma once

#include <cstdint>

#include "detail/for_each.h"
#include "detail/invalid_index.h"
#include "field.h"
#include "thcon.h"

namespace hal
{
namespace cfg
{
namespace detail
{

inline constexpr std::uint32_t UnpackerCount         = 2;
inline constexpr std::uint32_t UnpackerRegisterCount = 2;

} // namespace detail

// ============================================================
// UNPACKER
// ============================================================

enum class UnpackerReg : std::uint8_t
{
    Reg0,
    Reg1,
};

enum class BlobContext : std::uint8_t
{
    Context01,
    Context23,
};

class UnpackerAddrCtrlEntry
{
public:
    const Field& Xstride;
    const Field& Ystride;
    const Field& Zstride;
    const Field& Wstride;
};

class UnpackerAddrCtrlFields
{
public:
    std::uint32_t unpacker;

private:
    template <std::uint32_t UnpackerIndex, std::uint32_t RegIndex>
    class Fields
    {
    public:
        static_assert(UnpackerIndex < detail::UnpackerCount, "unpacker index out of range");
        static_assert(RegIndex < detail::UnpackerRegisterCount, "unpacker register index out of range");

        static constexpr std::uint32_t XyWord = 44 + 12 * RegIndex + 2 * UnpackerIndex;
        // Field {scope, word_size, base, word, shamt0, width, count, sec_bits}
        static constexpr Field Xstride {
            RegisterScope::State, 32, XyWord, 0, 0, 16, 1, 0}; // Address = Base + X*Xstride + Y*Ystride + Z*Zstride + W*Wstride (16b)
        static constexpr Field Ystride {
            RegisterScope::State, 32, XyWord, 0, 16, 16, 1, 0}; // Address = Base + X*Xstride + Y*Ystride + Z*Zstride + W*Wstride (16b)
        static constexpr Field Zstride {
            RegisterScope::State, 32, XyWord + 1, 0, 0, 16, 1, 0}; // Address = Base + X*Xstride + Y*Ystride + Z*Zstride + W*Wstride (16b)
        static constexpr Field Wstride {
            RegisterScope::State, 32, XyWord + 1, 0, 16, 16, 1, 0}; // Address = Base + X*Xstride + Y*Ystride + Z*Zstride + W*Wstride (16b)
    };

    template <std::uint32_t UnpackerIndex, std::uint32_t RegIndex>
    static constexpr UnpackerAddrCtrlEntry make()
    {
        return {
            Fields<UnpackerIndex, RegIndex>::Xstride,
            Fields<UnpackerIndex, RegIndex>::Ystride,
            Fields<UnpackerIndex, RegIndex>::Zstride,
            Fields<UnpackerIndex, RegIndex>::Wstride,
        };
    }

    template <std::uint32_t UnpackerIndex>
    static constexpr UnpackerAddrCtrlEntry select(UnpackerReg reg)
    {
        return reg == UnpackerReg::Reg0   ? make<UnpackerIndex, 0 /*RegIndex*/>()
               : reg == UnpackerReg::Reg1 ? make<UnpackerIndex, 1 /*RegIndex*/>()
                                          : detail::invalid_index<UnpackerAddrCtrlEntry>();
    }

public:
    template <std::uint32_t RegIndex>
    constexpr UnpackerAddrCtrlEntry operator[](detail::CompileTimeIndex<RegIndex>) const
    {
        static_assert(RegIndex < detail::UnpackerRegisterCount, "unpacker register index out of range");
        return unpacker == 0   ? make<0 /*UnpackerIndex*/, RegIndex>()
               : unpacker == 1 ? make<1 /*UnpackerIndex*/, RegIndex>()
                               : detail::invalid_index<UnpackerAddrCtrlEntry>();
    }

    constexpr UnpackerAddrCtrlEntry operator[](UnpackerReg reg) const
    {
        return unpacker == 0   ? select<0 /*UnpackerIndex*/>(reg)
               : unpacker == 1 ? select<1 /*UnpackerIndex*/>(reg)
                               : detail::invalid_index<UnpackerAddrCtrlEntry>();
    }

    template <typename Function>
    constexpr void forEach(Function&& function) const
    {
        detail::for_each_index<detail::UnpackerRegisterCount>(static_cast<Function&&>(function));
    }
};

class UnpackerAddrBaseFields
{
public:
    std::uint32_t unpacker;

private:
    template <std::uint32_t UnpackerIndex, std::uint32_t RegIndex>
    class Fields
    {
    public:
        static_assert(UnpackerIndex < detail::UnpackerCount, "unpacker index out of range");
        static_assert(RegIndex < detail::UnpackerRegisterCount, "unpacker register index out of range");

        // Field {scope, word_size, base, word, shamt0, width, count, sec_bits}
        static constexpr Field Value {
            RegisterScope::State, 32, 48 + 12 * UnpackerIndex + RegIndex, 0, 0, 18, 1, 0}; // Base 0 (of 0-8) used in X-Y addressing (18b)
    };

    template <std::uint32_t UnpackerIndex>
    static constexpr const Field& select(UnpackerReg reg)
    {
        return reg == UnpackerReg::Reg0   ? Fields<UnpackerIndex, 0 /*RegIndex*/>::Value
               : reg == UnpackerReg::Reg1 ? Fields<UnpackerIndex, 1 /*RegIndex*/>::Value
                                          : detail::invalid_index<const Field&>();
    }

public:
    template <std::uint32_t RegIndex>
    constexpr const Field& operator[](detail::CompileTimeIndex<RegIndex>) const
    {
        static_assert(RegIndex < detail::UnpackerRegisterCount, "unpacker register index out of range");
        return unpacker == 0   ? Fields<0 /*UnpackerIndex*/, RegIndex>::Value
               : unpacker == 1 ? Fields<1 /*UnpackerIndex*/, RegIndex>::Value
                               : detail::invalid_index<const Field&>();
    }

    constexpr const Field& operator[](UnpackerReg reg) const
    {
        return unpacker == 0 ? select<0 /*UnpackerIndex*/>(reg) : unpacker == 1 ? select<1 /*UnpackerIndex*/>(reg) : detail::invalid_index<const Field&>();
    }

    template <typename Function>
    constexpr void forEach(Function&& function) const
    {
        detail::for_each_index<detail::UnpackerRegisterCount>(static_cast<Function&&>(function));
    }
};

class UnpackerBlobsYStartFields
{
public:
    std::uint32_t unpacker;

private:
    // Field {scope, word_size, base, word, shamt0, width, count, sec_bits}
    static constexpr Field Context01 {RegisterScope::State, 32, 51, 0, 0, 32, 1, 0}; // Context 0&1 blobs y_start (32b)
    static constexpr Field Context23 {RegisterScope::State, 32, 52, 0, 0, 32, 1, 0}; // Context 2&3 blobs y_start (32b)

public:
    constexpr const Field& operator[](BlobContext context) const
    {
        return unpacker != 0                       ? detail::invalid_index<const Field&>()
               : context == BlobContext::Context01 ? Context01
               : context == BlobContext::Context23 ? Context23
                                                   : detail::invalid_index<const Field&>();
    }
};

class UnpackerContextEntry
{
public:
    const Field& Base;
};

namespace detail
{

template <std::uint32_t UnpackerIndex>
inline constexpr std::uint32_t UnpackerContextCount = UnpackerIndex == 0 ? 8 : 2;

template <std::uint32_t UnpackerIndex, std::uint32_t ContextIndex>
class UnpackerContextDescriptor
{
public:
    static_assert(UnpackerIndex < UnpackerCount, "unpacker index out of range");
    static_assert(ContextIndex < UnpackerContextCount<UnpackerIndex>, "unpacker context index out of range");

private:
    static constexpr const Field* Sources[8] = {
        &ThconReg3Fields::Base_address,
        &ThconReg3Fields::Base_cntx1_address,
        &ThconReg3Fields::Base_cntx2_address,
        &ThconReg3Fields::Base_cntx3_address,
        &ThconReg4Fields::Base_cntx4_address,
        &ThconReg4Fields::Base_cntx5_address,
        &ThconReg4Fields::Base_cntx6_address,
        &ThconReg4Fields::Base_cntx7_address,
    };
    static constexpr const Field& source = *Sources[ContextIndex];
    static constexpr Sec section         = UnpackerIndex == 0 ? Sec::S0 : Sec::S1;

public:
    // Resolve the THCON section into a standalone field so Base itself can be
    // used as a single non-type template argument.
    static constexpr Field Base {
        source.scope,
        source.word_size,
        source.addr32(section),
        0,
        source.shamt(section),
        source.width,
        1,
        0,
    }; // Unpacker source/tile context base address (aligned to 16B word) (32b)
};

} // namespace detail

class UnpackerContextFields
{
public:
    std::uint32_t unpacker;

private:
    template <std::uint32_t UnpackerIndex, std::uint32_t ContextIndex = 0>
    static constexpr UnpackerContextEntry select(std::uint32_t context)
    {
        if constexpr (ContextIndex < detail::UnpackerContextCount<UnpackerIndex>)
        {
            return context == ContextIndex ? UnpackerContextEntry {detail::UnpackerContextDescriptor<UnpackerIndex, ContextIndex>::Base}
                                           : select<UnpackerIndex, ContextIndex + 1>(context);
        }
        else
        {
            return detail::invalid_index<UnpackerContextEntry>();
        }
    }

public:
    constexpr UnpackerContextEntry operator[](std::uint32_t context) const
    {
        return unpacker == 0   ? select<0 /*UnpackerIndex*/>(context)
               : unpacker == 1 ? select<1 /*UnpackerIndex*/>(context)
                               : detail::invalid_index<UnpackerContextEntry>();
    }
};

template <std::uint32_t UnpackerIndex>
class StaticUnpackerContextFields
{
public:
    static_assert(UnpackerIndex < detail::UnpackerCount, "unpacker index out of range");

    template <std::uint32_t ContextIndex>
    constexpr UnpackerContextEntry operator[](detail::CompileTimeIndex<ContextIndex>) const
    {
        static_assert(ContextIndex < detail::UnpackerContextCount<UnpackerIndex>, "unpacker context index out of range");
        return {detail::UnpackerContextDescriptor<UnpackerIndex, ContextIndex>::Base};
    }

    constexpr UnpackerContextEntry operator[](std::uint32_t context) const
    {
        return UnpackerContextFields {UnpackerIndex}[context];
    }

    template <typename Function>
    constexpr void forEach(Function&& function) const
    {
        detail::for_each_index<detail::UnpackerContextCount<UnpackerIndex>>(static_cast<Function&&>(function));
    }
};

template <typename ContextFields>
class BasicUnpackerEntry
{
public:
    UnpackerAddrCtrlFields AddrCtrl;
    UnpackerAddrBaseFields AddrBase;
    ContextFields Cntx;
    const Field& ForcedSharedExp;
    const Field& AddDestAddrCntr;
    const Field& NopRegClrVal;
    UnpackerBlobsYStartFields BlobsYStart;
};

using UnpackerEntry = BasicUnpackerEntry<UnpackerContextFields>;

template <std::uint32_t UnpackerIndex>
using StaticUnpackerEntry = BasicUnpackerEntry<StaticUnpackerContextFields<UnpackerIndex>>;

class UnpackerFields
{
private:
    template <std::uint32_t UnpackerIndex>
    class Fields
    {
    public:
        static_assert(UnpackerIndex < detail::UnpackerCount, "unpacker index out of range");

        // Field {scope, word_size, base, word, shamt0, width, count, sec_bits}
        static constexpr Field ForcedSharedExp {
            RegisterScope::State, 32, 50 + 12 * UnpackerIndex, 0, 0, 8, 1, 0}; // Forced shared exponent used when shared exponent reads are disabled for BFP
                                                                               // formats (8b)
        static constexpr Field AddDestAddrCntr {
            RegisterScope::State, 32, 50 + 12 * UnpackerIndex, 0, 8, 1, 1, 0}; // Combine the per-context destination address with the address counter (1b)
        static constexpr Field NopRegClrVal {RegisterScope::State, 32, 53 + 10 * UnpackerIndex, 0, 0, 32, 1, 0}; // Immediate value used by UNPACR_NOP to clear
                                                                                                                 // SRCA (unpacker 0) or SRCB (unpacker 1) (32b)
    };

    template <std::uint32_t UnpackerIndex, typename ContextFields>
    static constexpr BasicUnpackerEntry<ContextFields> make(ContextFields context)
    {
        return {
            {UnpackerIndex},
            {UnpackerIndex},
            context,
            Fields<UnpackerIndex>::ForcedSharedExp,
            Fields<UnpackerIndex>::AddDestAddrCntr,
            Fields<UnpackerIndex>::NopRegClrVal,
            {UnpackerIndex},
        };
    }

public:
    template <std::uint32_t UnpackerIndex>
    constexpr StaticUnpackerEntry<UnpackerIndex> operator[](detail::CompileTimeIndex<UnpackerIndex>) const
    {
        static_assert(UnpackerIndex < detail::UnpackerCount, "unpacker index out of range");
        return make<UnpackerIndex>(StaticUnpackerContextFields<UnpackerIndex> {});
    }

    constexpr UnpackerEntry operator[](std::uint32_t unpacker) const
    {
        return unpacker == 0   ? make<0 /*UnpackerIndex*/>(UnpackerContextFields {0 /*unpacker*/})
               : unpacker == 1 ? make<1 /*UnpackerIndex*/>(UnpackerContextFields {1 /*unpacker*/})
                               : detail::invalid_index<UnpackerEntry>();
    }

    /**
     * @brief Invoke @p function once for each unpacker at compile time.
     *
     * The callback receives `std::integral_constant<std::uint32_t, I>`, so
     * the index is valid both as an array subscript and in a field expression
     * used as a non-type template argument.
     */
    template <typename Function>
    constexpr void forEach(Function&& function) const
    {
        detail::for_each_index<detail::UnpackerCount>(static_cast<Function&&>(function));
    }
};

/**
 * @brief Compile-time field access for unpacker 0 and unpacker 1 registers.
 *
 * Select the logical unpacker with the first numeric index. Address-control and
 * address-base registers use `UnpackerReg::Reg0` or `UnpackerReg::Reg1`.
 *
 * - `Unpacker[unpacker].AddrCtrl[reg]` exposes `Xstride`, `Ystride`,
 *   `Zstride`, and `Wstride`. Each stride is 16 bits and implements
 *   `Address = Base + X*Xstride + Y*Ystride + Z*Zstride + W*Wstride`.
 * - `Unpacker[unpacker].AddrBase[reg]` is the 18-bit address-space base used
 *   in X-Y addressing.
 * - `Unpacker[unpacker].Cntx[context].Base` is the source/tile base address
 *   for that THCON context. Unpacker 0 has eight contexts; unpacker 1 has two.
 * - `Unpacker[unpacker].ForcedSharedExp` is the 8-bit shared exponent used
 *   when shared-exponent reads are disabled for BFP formats.
 * - `Unpacker[unpacker].AddDestAddrCntr` combines the per-context destination
 *   address with the address counter. It is valid when instruction thread
 *   override mode enables multiple contexts.
 * - `Unpacker[unpacker].NopRegClrVal` is the 32-bit immediate used by
 *   `UNPACR_NOP` to clear SRCA for unpacker 0 or SRCB for unpacker 1.
 * - `Unpacker[0].BlobsYStart[BlobContext::Context01]` and
 *   `Unpacker[0].BlobsYStart[BlobContext::Context23]` select the 32-bit
 *   `blobs_y_start` registers for contexts 0&1 and 2&3. These registers are
 *   used for uncompressed tiles with blobs per XY plane and inline
 *   haloization. Each 4-bit slice sets y_start for one of up to eight blobs.
 *   Unpacker 1 has no blobs-y-start registers.
 *
 * Invalid unpacker indices, enum values, or blob access through unpacker 1
 * fail compilation in a constant-expression/template context and trap at
 * runtime.
 *
 * @code{.cpp}
 * write<Access::TensixCfgUnit,
 *       Unpacker[0].AddrCtrl[UnpackerReg::Reg0].Xstride,
 *       Sec::S0>(x_stride);
 * write<Access::TensixCfgUnit,
 *       Unpacker[1].AddrBase[UnpackerReg::Reg1],
 *       Sec::S0>(base);
 * write<Access::TensixCfgUnit,
 *       Unpacker[0].BlobsYStart[BlobContext::Context01],
 *       Sec::S0>(blobs_y_start);
 *
 * Unpacker.forEach([&](auto U) {
 *     Unpacker[U].Cntx.forEach([&](auto C) {
 *         write<Access::MMIO, Unpacker[U].Cntx[C].Base, Sec::S0>(base[U][C]);
 *     });
 * });
 * @endcode
 */
inline constexpr UnpackerFields Unpacker {};

} // namespace cfg
} // namespace hal
