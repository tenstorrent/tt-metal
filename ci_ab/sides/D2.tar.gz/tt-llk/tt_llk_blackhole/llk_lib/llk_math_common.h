// SPDX-FileCopyrightText: © 2025 Tenstorrent AI ULC
//
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include <cstdint>

#include "ckernel_defs.h"
#include "ckernel_include.h"
#include "ckernel_ops.h"
#include "cmath_common.h"

using namespace ckernel::math;

/**
 * @brief Configure the math (FPU) thread's ALU control registers for the given source data formats.
 *
 * Sets ZEROACC bank auto-detect, enables INT8 math when either source is Int8/Int32, and programs FP32 dest
 * accumulation mode. Applies HW-bug workarounds (disables debug feature bit 11) for INT8 math and for the
 * UInt16-with-FP32-dest combination.
 *
 * @tparam is_fp32_dest_acc_en: Enable FP32 accumulation in the destination register.
 * @param srca_data_format: Data format of source A (DataFormat enum underlying value).
 * @param srcb_data_format: Data format of source B (DataFormat enum underlying value).
 * @note The SFPU reads ALU_FORMAT_SPEC_REG1_SrcB (the SrcB ALU format, programmed unpack-side on Blackhole, not here) to
 *       interpret data it loads from DEST. For SFPU work, ensure that format's exponent family (BF16 vs FP16) matches
 *       the data in DEST (tt-llk #951).
 */
template <bool is_fp32_dest_acc_en = false>
inline void _llk_math_hw_configure_(const std::uint32_t srca_data_format, const std::uint32_t srcb_data_format)
{
    // SFPU_Fp32_enabled (written below) is read by SFPLOAD/SFPSTORE (MOD0_FMT_SRCB), so the SFPU must drain too.
    TTI_STALLWAIT(p_stall::STALL_CFG, p_stall::MATH | p_stall::WAIT_SFPU);
    // Configure ZEROACC to auto-detect destination bank (non-legacy mode).
    cfg_reg_rmw_tensix<DEST_ACCESS_CFG_zeroacc_absolute_tile_mode_RMW>(0);
    std::uint32_t int8_math_enabled = is_int8_or_int32_format(srca_data_format) || is_int8_or_int32_format(srcb_data_format);
    cfg_reg_rmw_tensix<ALU_ACC_CTRL_INT8_math_enabled_RMW>(int8_math_enabled);

    cfg_reg_rmw_tensix<ALU_ACC_CTRL_Fp32_enabled_RMW>(is_fp32_dest_acc_en);
    cfg_reg_rmw_tensix<ALU_ACC_CTRL_SFPU_Fp32_enabled_RMW>(is_fp32_dest_acc_en);

    // Establish the no-override baseline for the SrcA/SrcB ALU format-select fields (ADDR32=0),
    // consumed by the FPU (SrcA) and SFPU (SrcB) on this thread: clear SrcA_val/override and
    // SrcB_val/override so the base (or Blackhole per-bank implied) SrcA/SrcB formats are used. The
    // Dstacc override fields in the same word are owned by the pack thread (configure_pack); the two
    // writers touch disjoint bits and rely on per-byte RMWCIB atomicity, so no cross-thread mutex is
    // needed.
    constexpr std::uint32_t src_fmt_override_mask =
        ALU_FORMAT_SPEC_REG_SrcA_val_MASK | ALU_FORMAT_SPEC_REG_SrcA_override_MASK | ALU_FORMAT_SPEC_REG_SrcB_val_MASK | ALU_FORMAT_SPEC_REG_SrcB_override_MASK;
    cfg_reg_rmw_tensix<ALU_FORMAT_SPEC_REG_SrcA_val_ADDR32, 0, src_fmt_override_mask>(0);

    // Establish the operand-driven baseline for the Src zero-substitution flag. This is a SrcA+SrcB format
    // change, so refresh both format caches before applying (the no-arg configurator and the compute-op
    // asserts read them; refreshing here is what keeps them from ever going stale).
    src_zero_flag_srca_fmt = srca_data_format;
    src_zero_flag_srcb_fmt = srcb_data_format;
    _configure_default_zero_flag_state_();
}

/**
 * @brief Enable or disable the destination read-address remap (stride-of-16) used by untilize mode.
 *
 * Waits for all in-flight DEST accesses and pending packs to finish before toggling the remap_addrs and
 * swizzle_32b config bits, since changing them mid-access would corrupt reads.
 *
 * @param remap_enable: True to enable the stride-of-16 remap (untilize), false to restore linear addressing.
 */
inline void _llk_math_reconfig_remap_(const bool remap_enable)
{
    // Need to wait for all DEST accesses to be finished before changing
    // remap_addrs and swizzle_32b bits
    tensix_sync();
    while (semaphore_read(semaphore::MATH_PACK) > 0)
    {
    } // Wait for previous packs to finish before claiming all dest

    // Untilize mode needs dest read access with a stride of 16
    // Following bits are needed for enabling stride of 16
    cfg_reg_rmw_tensix<DEST_ACCESS_CFG_remap_addrs_RMW>(remap_enable);
    cfg_reg_rmw_tensix<DEST_ACCESS_CFG_swizzle_32b_RMW>(remap_enable);
}

/**
 * @brief Block the math thread until the destination register is available for writing.
 *
 * @tparam Dst: Destination sync mode, values = <SyncHalf/SyncFull>
 */
template <DstSync Dst>
inline void _llk_math_wait_for_dest_available_()
{
    // These lightweight functions for sync with packer imply
    // no mode change - entire epoch is either double buffer or single buffer
    math_dest_wait();
}

/**
 * @brief Signal completion of a destination section by setting the math semaphores, flipping banks in half-sync mode.
 *
 * In SyncHalf mode this resets the per-tile sync index and flips to the other DEST half so the packer can drain
 * the just-finished half while math proceeds in the other.
 *
 * @tparam Dst: Destination sync mode, values = <SyncHalf/SyncFull>
 * @tparam is_fp32_dest_acc_en: Whether FP32 accumulation in the destination register is enabled.
 */
template <DstSync Dst, bool is_fp32_dest_acc_en>
inline void _llk_math_dest_section_done_()
{
    set_math_semaphores();
    if constexpr (Dst == DstSync::SyncHalf)
    {
        math_sync_tile_dst_index = 0;
        dest_section_flip();
    }
}

/**
 * @brief Clear the acquired DST section from MATH instead of clearing it on PACK release.
 *
 * Call immediately after acquiring the section, before any DST writes, and use PACK release without clearing throughout the kernel.
 * DST writes must stay between acquire and commit; commit drains them before the next acquisition.
 * Unpack-to-DST must wait for MATH's ready signal; there must be no independent DST writer.
 */
template <DstSync Dst, bool is_fp32_dest_acc_en>
inline void _llk_math_clear_dest_section_()
{
    // Startup or the preceding commit has already drained this thread's DST writes.
    if constexpr (Dst == DstSync::SyncFull)
    {
        TTI_ZEROACC(p_zeroacc::CLR_ALL, is_fp32_dest_acc_en, 0, ADDR_MOD_1, 0);
    }
    else
    {
        static_assert(Dst == DstSync::SyncHalf);
        TT_ZEROACC(p_zeroacc::CLR_HALF, is_fp32_dest_acc_en, 0, ADDR_MOD_1, dest_offset_id % 2);
    }
    // Do not let SFPU writes or an unpack-to-DST ready signal overtake the clear.
    TTI_STALLWAIT(p_stall::STALL_SFPU | p_stall::STALL_SYNC, p_stall::MATH);
}

/**
 * @brief Initialize the math/pack synchronization semaphore and reset the destination section base.
 *
 * Waits for any in-flight packs to finish, then seeds the MATH_PACK semaphore (max count 1 for SyncFull, 2 for
 * SyncHalf double-buffering) and resets the DEST offset and section base.
 *
 * @tparam Dst: Destination sync mode, values = <SyncHalf/SyncFull>
 * @tparam is_fp32_dest_acc_en: Whether FP32 accumulation in the destination register is enabled.
 */
template <DstSync Dst, bool is_fp32_dest_acc_en>
inline void _llk_math_pack_sync_init_()
{
    tensix_sync();
    while (semaphore_read(semaphore::MATH_PACK) > 0)
    {
    } // Wait for previous packs to finish before claiming all dest
    if constexpr (Dst == DstSync::SyncFull)
    {
        TTI_SEMINIT(1, 0, p_stall::SEMAPHORE_1);
        reset_dest_offset_id();
        set_dest_section_base<StartZero>();
    }
    else
    {
        static_assert(Dst == DstSync::SyncHalf);
        TTI_SEMINIT(2, 0, p_stall::SEMAPHORE_1);
        reset_dest_offset_id();
        set_dest_section_base<StartZero>();
    }
}

// Following functions do not need to program ALU_FORMAT_SPEC_REG0_SrcA/ALU_FORMAT_SPEC_REG1_SrcB
// for blackhole since ALU format is inferred
/**
 * @brief Reconfigure the math thread for a new source A data format.
 *
 * On Blackhole the ALU source format is inferred, so this only re-derives the INT8 math enable bit from the new
 * format. It does so by default so an int8-boundary reconfig cannot leave the bit stale (tt-metal#34499); pass
 * skip_int8 = true (making it a no-op) only when the caller guarantees no Int8/UInt8/Int32 boundary is crossed.
 *
 * @tparam is_fp32_dest_acc_en: Whether FP32 accumulation in the destination register is enabled (required when the new format is Int8/UInt8/Int32).
 * @tparam skip_int8: Skip re-deriving the INT8 math enable bit from the new format.
 * @param srca_data_format: New data format of source A (DataFormat enum underlying value).
 */
template <bool is_fp32_dest_acc_en, bool skip_int8 = false>
inline void _llk_math_reconfig_data_format_srca_(const std::uint32_t srca_data_format)
{
    if constexpr (!skip_int8)
    {
        LLK_ASSERT(
            is_fp32_dest_acc_en || !is_int8_or_int32_format(srca_data_format),
            "Reconfiguring math to/from Int8/UInt8/Int32 formats requires FP32 Dest mode enabled");
        // Only INT8_math_enabled is written here; it is FPU-only (the SFPU never reads it, and on Blackhole SrcB
        // format is inferred rather than rewritten here), so draining the FPU (MATH) suffices -- no WAIT_SFPU.
        // (Wormhole's twin uses WAIT_SFPU because there the reconfig also rewrites the SFPU-read SrcB format.)
        TTI_STALLWAIT(p_stall::STALL_CFG, p_stall::MATH);
        std::uint32_t int8_math_enabled = is_int8_or_int32_format(srca_data_format);
        cfg_reg_rmw_tensix<ALU_ACC_CTRL_INT8_math_enabled_RMW>(int8_math_enabled);
    }

    // Re-establish the operand-driven baseline for the new SrcA format. This reconfig is the only place the
    // SrcA format changes, so refresh its cache here -- unconditionally, even when the flag value is
    // unchanged -- which is what keeps the cache coherent for the no-arg configurator and the compute asserts.
    src_zero_flag_srca_fmt = srca_data_format;
    _configure_default_zero_flag_state_();
}

/**
 * @brief Reconfigure the math thread for a new source B data format.
 *
 * On Blackhole the ALU source format is inferred, so this only re-derives the INT8 math enable bit from the new
 * format. It does so by default so an int8-boundary reconfig cannot leave the bit stale (tt-metal#34499); pass
 * skip_int8 = true (making it a no-op) only when the caller guarantees no Int8/UInt8/Int32 boundary is crossed.
 *
 * @tparam is_fp32_dest_acc_en: Whether FP32 accumulation in the destination register is enabled (required when the new format is Int8/UInt8/Int32).
 * @tparam skip_int8: Skip re-deriving the INT8 math enable bit from the new format.
 * @param srcb_data_format: New data format of source B (DataFormat enum underlying value).
 */
template <bool is_fp32_dest_acc_en, bool skip_int8 = false>
inline void _llk_math_reconfig_data_format_srcb_(const std::uint32_t srcb_data_format)
{
    if constexpr (!skip_int8)
    {
        LLK_ASSERT(
            is_fp32_dest_acc_en || !is_int8_or_int32_format(srcb_data_format),
            "Reconfiguring math to/from Int8/UInt8/Int32 formats requires FP32 Dest mode enabled");
        // Only INT8_math_enabled is written here; it is FPU-only (the SFPU never reads it, and on Blackhole SrcB
        // format is inferred rather than rewritten here), so draining the FPU (MATH) suffices -- no WAIT_SFPU.
        // (Wormhole's twin uses WAIT_SFPU because there the reconfig also rewrites the SFPU-read SrcB format.)
        TTI_STALLWAIT(p_stall::STALL_CFG, p_stall::MATH);
        std::uint32_t int8_math_enabled = is_int8_or_int32_format(srcb_data_format);
        cfg_reg_rmw_tensix<ALU_ACC_CTRL_INT8_math_enabled_RMW>(int8_math_enabled);
    }

    // Re-establish the operand-driven baseline for the new SrcB format. This reconfig is the only place the
    // SrcB format changes, so refresh its cache here -- unconditionally, even when the flag value is
    // unchanged -- which is what keeps the cache coherent for the no-arg configurator and the compute asserts.
    src_zero_flag_srcb_fmt = srcb_data_format;
    _configure_default_zero_flag_state_();
}

/**
 * @brief Reconfigure the math thread for new source A and source B data formats.
 *
 * On Blackhole the ALU source format is inferred, so this only re-derives the INT8 math enable bit from both new
 * formats. It does so by default so an int8-boundary reconfig cannot leave the bit stale (tt-metal#34499); pass
 * skip_int8 = true (making it a no-op) only when the caller guarantees no Int8/UInt8/Int32 boundary is crossed.
 *
 * @tparam is_fp32_dest_acc_en: Whether FP32 accumulation in the destination register is enabled (required when either new format is Int8/UInt8/Int32).
 * @tparam skip_int8: Skip re-deriving the INT8 math enable bit from the new formats.
 * @param srca_data_format: New data format of source A (DataFormat enum underlying value).
 * @param srcb_data_format: New data format of source B (DataFormat enum underlying value).
 */
template <bool is_fp32_dest_acc_en, bool skip_int8 = false>
inline void _llk_math_reconfig_data_format_(const std::uint32_t srca_data_format, const std::uint32_t srcb_data_format)
{
    if constexpr (!skip_int8)
    {
        LLK_ASSERT(
            is_fp32_dest_acc_en || !(is_int8_or_int32_format(srca_data_format) || is_int8_or_int32_format(srcb_data_format)),
            "Reconfiguring math to/from Int8/UInt8/Int32 formats requires FP32 Dest mode enabled");
        // Only INT8_math_enabled is written here; it is FPU-only (the SFPU never reads it, and on Blackhole SrcB
        // format is inferred rather than rewritten here), so draining the FPU (MATH) suffices -- no WAIT_SFPU.
        // (Wormhole's twin uses WAIT_SFPU because there the reconfig also rewrites the SFPU-read SrcB format.)
        TTI_STALLWAIT(p_stall::STALL_CFG, p_stall::MATH);
        std::uint32_t int8_math_enabled = is_int8_or_int32_format(srca_data_format) || is_int8_or_int32_format(srcb_data_format);
        cfg_reg_rmw_tensix<ALU_ACC_CTRL_INT8_math_enabled_RMW>(int8_math_enabled);
    }

    // Re-establish the operand-driven baseline for the new formats. This reconfig changes both SrcA and
    // SrcB, so refresh both caches here (unconditionally) to keep them coherent for the no-arg configurator
    // and the compute asserts.
    src_zero_flag_srca_fmt = srca_data_format;
    src_zero_flag_srcb_fmt = srcb_data_format;
    _configure_default_zero_flag_state_();
}

/**
 * @brief Read the FPU sticky special-value flags (e.g. NaN/Inf detection) accumulated since the last clear.
 *
 * @return Raw value of the FPU sticky bits register.
 */
inline std::uint32_t _llk_math_get_compute_special_value_flags_()
{
    return reg_read(RISCV_DEBUG_REG_FPU_STICKY_BITS);
}

/**
 * @brief Clear the FPU sticky special-value flags register.
 *
 * @note Read with @ref _llk_math_get_compute_special_value_flags_ to observe flags accumulated after this clear.
 */
inline void _llk_math_clear_compute_special_value_flags_()
{
    reg_write(RISCV_DEBUG_REG_FPU_STICKY_BITS, 0);
}
