"""CPU-only real vLLM media parsing/processing; never constructs the TT model."""

import argparse
import asyncio
import base64
import functools
import hashlib
import json
import threading
import time
import traceback
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from types import SimpleNamespace

import av
import numpy as np
import torch
from PIL import Image

parser = argparse.ArgumentParser()
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--weights", type=Path, required=True)
args = parser.parse_args()
args.output.mkdir(parents=True, exist_ok=False)
report = {"started_at": time.time(), "cpu_only": True, "checks": {}, "device_calls": []}


def forbidden(name):
    def fail(*a, **kw):
        report["device_calls"].append(name)
        raise RuntimeError(f"Device access forbidden in CPU smoke: {name}")
    return fail


try:
    import ttnn
    for module in (ttnn, getattr(ttnn, "device", None)):
        if module is not None:
            for name in ("open_device", "open_mesh_device", "CreateDevice", "CreateDevices"):
                if hasattr(module, name):
                    setattr(module, name, forbidden(name))
    from vllm.config import ModelConfig
    from vllm.entrypoints.chat_utils import parse_chat_messages_async
    from vllm.entrypoints.openai.chat_completion.protocol import ChatCompletionRequest
    from vllm.multimodal import MULTIMODAL_REGISTRY
    from vllm.multimodal.inputs import MultiModalFeatureSpec
    from vllm.multimodal.processing import TimingContext
    from vllm.multimodal.processing.inputs import ProcessorInputs
    from vllm.tokenizers import cached_tokenizer_from_config
    from vllm_tt_plugin.multimodal import gather_multimodal_inputs
    from vllm_tt_plugin.platform import register_tt_models
    from models.demos.qwen38_27b_qb2.tt.generator_vllm_multimodal import (
        Qwen38ForConditionalGeneration,
    )
    Qwen38ForConditionalGeneration.__init__ = forbidden("TT model constructor")
    register_tt_models()
    model_config = ModelConfig(
        model=str(args.weights),
        tokenizer=str(args.weights),
        hf_overrides={"architectures": ["TTQwen38ForConditionalGeneration"]},
        max_model_len=262144,
        limit_mm_per_prompt={"image": 4, "video": 1},
        mm_processor_kwargs={"max_pixels": 2097152},
        allowed_media_domains=["127.0.0.1"],
    )
    tokenizer = cached_tokenizer_from_config(model_config)
    processor = MULTIMODAL_REGISTRY.create_processor(model_config, tokenizer=tokenizer)
    report["processor_class"] = f"{type(processor).__module__}.{type(processor).__name__}"
    report["checks"]["registration"] = "passed"

    image_path = args.output / "image.png"
    pixels = np.zeros((96, 128, 3), dtype=np.uint8)
    pixels[:, :64] = (230, 30, 20)
    pixels[:, 64:] = (20, 50, 230)
    Image.fromarray(pixels).save(image_path)
    video_path = args.output / "video.mp4"
    with av.open(str(video_path), "w") as container:
        stream = container.add_stream("libx264", rate=4)
        stream.width = 128
        stream.height = 96
        stream.pix_fmt = "yuv420p"
        for index in range(8):
            frame_pixels = np.roll(pixels, index * 8, axis=1)
            frame = av.VideoFrame.from_ndarray(frame_pixels, format="rgb24")
            for packet in stream.encode(frame):
                container.mux(packet)
        for packet in stream.encode():
            container.mux(packet)

    class Handler(SimpleHTTPRequestHandler):
        def log_message(self, *a):
            pass

    server = ThreadingHTTPServer(("127.0.0.1", 0), functools.partial(Handler, directory=str(args.output)))
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    snapshots = {}
    request_rows = []
    event_loop = asyncio.new_event_loop()
    try:
        for modality, fixture, mime in (("image", image_path, "image/png"), ("video", video_path, "video/mp4")):
            for transport in ("url", "base64"):
                label = f"input-{modality}-{transport}"
                url = (
                    f"http://127.0.0.1:{server.server_port}/{fixture.name}"
                    if transport == "url" else
                    f"data:{mime};base64," + base64.b64encode(fixture.read_bytes()).decode()
                )
                request = ChatCompletionRequest(
                    model="Qwen/Qwen3.8-27B",
                    messages=[{"role": "user", "content": [
                        {"type": "text", "text": "Describe the colors."},
                        {"type": f"{modality}_url", f"{modality}_url": {"url": url}},
                    ]}],
                    max_tokens=16,
                )
                conversation, mm_data, _ = event_loop.run_until_complete(parse_chat_messages_async(
                    request.messages, model_config, "string",
                    media_io_kwargs={"video": {"num_frames": 8}},
                ))
                prompt = tokenizer.apply_chat_template(
                    conversation, tokenize=False, add_generation_prompt=True,
                    enable_thinking=False,
                )
                processed = processor.apply(
                    ProcessorInputs(
                        prompt=prompt,
                        mm_data_items=processor.info.get_data_parser().parse_mm_data(mm_data),
                    ),
                    timing_ctx=TimingContext(enabled=False),
                )
                features = []
                for key, items in processed["mm_kwargs"].items():
                    for i, item in enumerate(items):
                        features.append(MultiModalFeatureSpec(
                            data=item, modality=key,
                            identifier=processed["mm_hashes"][key][i],
                            mm_position=processed["mm_placeholders"][key][i],
                        ))
                features.sort(key=lambda f: f.mm_position.offset)
                row = SimpleNamespace(
                    req_id=label, prompt_token_ids=processed["prompt_token_ids"],
                    output_token_ids=[], mm_features=features,
                )
                request_rows.append(row)
                kwargs = gather_multimodal_inputs([row], video_inputs=True, chunked_context=True)
                grid_key = "image_grid_thw" if modality == "image" else "video_grid_thw"
                pixel_key = "pixel_values" if modality == "image" else "pixel_values_videos"
                tensors = kwargs[pixel_key][0]
                grids = kwargs[grid_key][0]
                if not tensors or any(t is None for t in tensors):
                    raise RuntimeError(f"{label}: missing real processed pixel tensors")
                if kwargs["mm_request_ids"] != [label]:
                    raise RuntimeError(f"{label}: request alignment lost")
                snapshot = {
                    "tokens": list(processed["prompt_token_ids"]),
                    "grids": [g.tolist() for g in grids],
                    "pixels_sha256": [hashlib.sha256(t.contiguous().view(torch.uint8).numpy().tobytes()).hexdigest() for t in tensors],
                    "pixels_shapes": [list(t.shape) for t in tensors],
                }
                snapshots[label] = snapshot
                report["checks"][label] = {
                    "status": "passed", "prompt_tokens": len(snapshot["tokens"]),
                    "grids": snapshot["grids"], "pixels_shapes": snapshot["pixels_shapes"],
                    "raw_patches": sum(int(g.prod()) for g in grids),
                }
                print(label, report["checks"][label], flush=True)
        for modality in ("image", "video"):
            if snapshots[f"input-{modality}-url"] != snapshots[f"input-{modality}-base64"]:
                raise RuntimeError(f"{modality} URL/data-URL preprocessing differs")
            report["checks"][f"{modality}_transport_equivalence"] = "passed"
        mixed_rows = [SimpleNamespace(req_id="text", prompt_token_ids=[1, 2, 3], output_token_ids=[], mm_features=[])]
        for i in range(15):
            row = request_rows[(i * 3) % len(request_rows)]
            mixed_rows.append(SimpleNamespace(req_id=f"mixed-{i}", prompt_token_ids=row.prompt_token_ids,
                                              output_token_ids=[], mm_features=row.mm_features))
        kwargs = gather_multimodal_inputs(mixed_rows, video_inputs=True, chunked_context=True)
        if kwargs["mm_request_ids"] != [r.req_id for r in mixed_rows]:
            raise RuntimeError("B16 mixed request alignment lost")
        for row_index, row in enumerate(mixed_rows):
            expected = [dict(modality=f.modality, identifier=f.identifier, offset=f.mm_position.offset,
                             length=f.mm_position.length) for f in row.mm_features]
            if kwargs["mm_item_spans"][row_index] != expected:
                raise RuntimeError("B16 mixed media identity/order lost")
        report["checks"]["b16_mixed_media_gather"] = "passed"
    finally:
        event_loop.close()
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)
    # Negative admission checks inject only the parent HF/cache outputs to avoid
    # allocating oversized media. The concrete bounded processor hooks execute.
    from unittest.mock import patch
    from vllm.model_executor.models.qwen3_vl import Qwen3VLMultiModalProcessor
    from vllm.multimodal.inputs import PlaceholderRange
    observed = {}
    def parent_hf(self, prompt, mm_data, mm_kwargs, tok_kwargs):
        observed.update(mm_kwargs)
        return {"image_grid_thw": torch.tensor([[1, 2, 2]])}
    with patch.object(Qwen3VLMultiModalProcessor, "_call_hf_processor", parent_hf):
        processor._call_hf_processor("", {}, {"max_pixels": 2**30}, {})
    if observed["max_pixels"] != 2097152 or "size" in observed:
        raise RuntimeError(f"Incorrect bounded HF overrides: {observed}")
    report["checks"]["max_pixels_clamped_preserving_hf_size"] = {"status": "passed", "injected": "parent HF output"}
    rejected = False
    with patch.object(Qwen3VLMultiModalProcessor, "_call_hf_processor", return_value={
        "image_grid_thw": torch.tensor([[1, 128, 258]])
    }):
        try:
            processor._call_hf_processor("", {}, {"do_resize": False}, {})
        except ValueError:
            rejected = True
    if not rejected:
        raise RuntimeError("Actual grid budget bypassed through do_resize=False")
    report["checks"]["resize_bypass_grid_rejected"] = {"status": "passed", "injected": "oversized parent HF grid, no pixels allocated"}
    def cache_apply(placeholders):
        with patch.object(Qwen3VLMultiModalProcessor, "apply", return_value={
            "mm_placeholders": placeholders, "mm_kwargs": None,
        }):
            return processor.apply(None, TimingContext(enabled=False))
    def reject_cached(placeholders):
        try:
            cache_apply(placeholders)
        except ValueError:
            return
        raise RuntimeError("Cached oversized placeholders bypassed budget")
    reject_cached({"video": [PlaceholderRange(offset=0, length=8193)]})
    report["checks"]["cached_8193_embeddings_rejected"] = {"status": "passed", "injected": "parent processor cache output with missing pixels"}
    four_images = [PlaceholderRange(offset=i * 2048, length=2048) for i in range(4)]
    cache_apply({"image": four_images})
    over_images = four_images[:3] + [PlaceholderRange(offset=6144, length=2049)]
    reject_cached({"image": over_images})
    report["checks"]["four_image_aggregate_budget"] = {"status": "passed", "injected": "parent processor cache placeholders"}
    video_mask = torch.zeros(20000, dtype=torch.bool)
    video_mask[:8192] = True
    cache_apply({"image": four_images, "video": [PlaceholderRange(offset=8192, length=20000, is_embed=video_mask)]})
    video_mask_over = video_mask.clone()
    video_mask_over[8192] = True
    reject_cached({"video": [PlaceholderRange(offset=0, length=20000, is_embed=video_mask_over)]})
    report["checks"]["video_timestamp_mask_counts_only_embeddings"] = {"status": "passed", "injected": "parent processor cache output, real PlaceholderRange mask"}
    report["status"] = "passed"
except Exception as exc:
    report["status"] = "failed"
    report["error"] = f"{type(exc).__name__}: {exc}"
    report["traceback"] = traceback.format_exc()
finally:
    report["completed_at"] = time.time()
    (args.output / "result.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2), flush=True)
    if report.get("status") != "passed":
        raise SystemExit(1)
