import ast,contextlib,hashlib,importlib.metadata,json,logging,sys,types
from pathlib import Path
import pytest
source=Path('/home/ttuser/qwen38-artifacts-20261007/multimodal-model-source-v4')
output=Path('/home/ttuser/qwen38-artifacts-20261007/multimodal-native-cpu-gate-v4')
output.mkdir(exist_ok=False)
report={'device_open_calls':[], 'full_model_construction_calls':[], 'versions':{p:importlib.metadata.version(p) for p in ('torch','transformers','vllm','pytest')},'source_root':str(source)}
import ttnn
report['ttnn_path']=ttnn.__file__
def forbid_device(*args,**kwargs):
 report['device_open_calls'].append('called');raise AssertionError('Device opens prohibited in CPU gate')
for name in ('open_device','open_mesh_device','CreateDevice','CreateDevices'):
 if hasattr(ttnn,name):setattr(ttnn,name,forbid_device)
from transformers.models.qwen3_5 import modeling_qwen3_5
def forbid_language(*args,**kwargs):
 report['full_model_construction_calls'].append('called');raise AssertionError('Full language model construction prohibited')
for cls in (modeling_qwen3_5.Qwen3_5ForConditionalGeneration,modeling_qwen3_5.Qwen3_5TextModel):cls.__init__=forbid_language
from vllm.model_executor.models import ModelRegistry
from vllm_tt_plugin.platform import register_tt_models
register_tt_models()
from vllm.config import ModelConfig
config=ModelConfig(model='/home/ttuser/qwen38-artifacts-20261007/checkpoint-pinned-1d4bf0f2',hf_overrides={'architectures':['TTQwen38ForConditionalGeneration']},max_model_len=32768,limit_mm_per_prompt={'image':4,'video':1})
adapter,arch=ModelRegistry.resolve_model_cls(['TTQwen38ForConditionalGeneration'],config)
report.update(architecture=arch,adapter_module=adapter.__module__,native_import_and_registry_passed=True)
node=next(n for n in ast.parse((source/'conftest.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='expect_error')
plugin=types.ModuleType('qwen38_repository_error_fixture');plugin.__dict__.update(pytest=pytest,contextlib=contextlib,logger=logging.getLogger('expected-errors'))
exec(compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),'conftest.py','exec'),plugin.__dict__)
root='models/demos/qwen38_27b_qb2/tests/unit'
names=['test_multimodal.py','test_multimodal_adapter.py','test_vision_probe_manifest.py','test_serving_prefill_trace.py','test_batched_prefill.py','test_decode_buckets.py','test_prefill_sampling_trace.py','test_serving_precision.py']
args=[f'{root}/{name}' for name in names]+['--confcutdir='+root,'-c','/dev/null','--rootdir=.','-p','no:cacheprovider','--junitxml='+str(output/'cpu.xml'),'-q']
report['pytest_arguments']=args
code=int(pytest.main(args,plugins=[plugin]));report['pytest_exit_code']=code
report['passed']=code==0 and not report['device_open_calls'] and not report['full_model_construction_calls']
report['source_files']={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (source/'models/demos/qwen38_27b_qb2/tt').glob('*.py')}
(output/'result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ('passed','pytest_exit_code','device_open_calls','full_model_construction_calls')}),flush=True)
raise SystemExit(code)
