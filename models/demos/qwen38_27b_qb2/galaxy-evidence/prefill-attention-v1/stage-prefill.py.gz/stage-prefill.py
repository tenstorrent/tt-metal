import base64
import json
import subprocess
from pathlib import Path

repo = Path('/private/tmp/tt-metal-qwen38-long-context')
names = ['models/demos/qwen38_27b_qb2/' + n for n in (
 'tt/decoder.py','tt/decoder_tp.py','tt/model.py','tt/prefill_attention.py',
 'tests/prefill_attention_batch.py','tests/test_prefill_attention_batch.py',
 'tests/unit/test_prefill_attention_batch.py','demo/run_prefill_attention_batch.py')]
payload = {n: base64.b64encode((repo / n).read_bytes()).decode() for n in names}
remote = r'''
import base64, hashlib, json, os, shutil, subprocess, time
from pathlib import Path
art=Path('/home/ttuser/qwen38-artifacts-20261007')
task=Path('/home/ttuser/kimi-prefill.Ubx2wY/runtime/qwen38-27b-20261006')
source,control,output=[art/n for n in ('prefill-attention-source-v1','prefill-attention-control-v1','prefill-attention-v1')]
assert not any(p.exists() for p in (source,control,output))
assert shutil.disk_usage(art).free>20*1024**3
assert shutil.disk_usage('/dev/shm').free>64*1024**3
def props(unit):
 raw=subprocess.check_output(['systemctl','--user','show',unit,'-p','MainPID','-p','ActiveState','-p','SubState','-p','InvocationID','-p','Result','-p','LoadState'],text=True,timeout=20)
 return dict(line.split('=',1) for line in raw.splitlines() if '=' in line)
predecessor='qwen38-projection-sweep-v4-20261010.service'
expected_invocation='dd0ad89df8004f78aa4270a047e35f91'
current=props(predecessor)
assert current['InvocationID']==expected_invocation and current['MainPID']!='0' and current['ActiveState']=='active'
shutil.copytree(art/'compact-followup-source-v2',source,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache','.benchmarks','generated'))
control.mkdir()
for name,value in PAYLOAD.items():
 (source/name).write_bytes(base64.b64decode(value))
model=source/'models/demos/qwen38_27b_qb2'
python=str(task/'python_env/bin/python')
env=dict(os.environ,TT_METAL_HOME=str(task/'metal'),LD_LIBRARY_PATH=f'{task}/metal-install/lib:{task}/metal-build/lib',
 PYTHONPATH=f'{source}:{task}/metal:{task}/metal/tools',ARCH_NAME='blackhole',OMP_NUM_THREADS='1',TT_METAL_INSPECTOR_RPC='0')
for key in ('TT_METAL_SIMULATOR','TT_METAL_DISABLE_SFPLOADMACRO','TT_METAL_SLOW_DISPATCH_MODE','QWEN_GDN_EPILOGUE_LAYER'):
 env.pop(key,None)
with (control/'preflight.log').open('w') as log:
 subprocess.run([python,'-m','pytest',str(model/'tests/unit'),'-c',str(source/'pytest.ini'),f'--rootdir={source}',
 '-o','addopts=','-q',f'--junitxml={control}/unit.xml'],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
 subprocess.run([python,'-m','pytest',str(model/'tests/test_prefill_attention_batch.py'),'--collect-only','-q',
 '-c',str(source/'pytest.ini'),f'--rootdir={source}','-o','addopts='],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
print((control/'preflight.log').read_text()[-1400:],flush=True)
files=[source/n for n in ('conftest.py','pytest.ini','scripts/run_safe_pytest.sh')]
files.extend(p for p in model.rglob('*') if p.suffix in ('.py','.cpp','.h','.hpp','.json'))
manifest={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(control/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
command=['systemd-run','--user','--unit=qwen38-prefill-attention-v1-20261010',
 '--property=RuntimeMaxSec=28h','--property=TimeoutStopSec=210','--property=KillMode=control-group',
 '--property=MemoryMax=96G','--property=CPUQuota=800%',
 f'--property=StandardOutput=append:{control}/run.log',f'--property=StandardError=append:{control}/run.log',
 f'--working-directory={source}',f'--setenv=PYTHONPATH={source}','--setenv=PYTHONUNBUFFERED=1',
 python,'-m','models.demos.qwen38_27b_qb2.demo.run_prefill_attention_batch',
 '--task',str(task),'--source',str(source),'--weights',str(art/'checkpoint-pinned-1d4bf0f2'),
 '--output',str(output),'--manifest',str(control/'source-manifest.json'),
 '--after-unit',predecessor,'--after-invocation',expected_invocation,
 '--after-receipt',str(art/'projection-sweep-v4/queue.json')]
launch=dict(command=command,created_at=time.time(),source_parent='f24aacc9f6b',changed_files=list(PAYLOAD),
 reason='Batched page fill and chunked SDPA boundary after prioritized native decode experiments',
 native_install_changed=False,promoted_to_serving=False,default_enabled=False,
 engineering_target_boundary_speedup=[1.25,1.5],full_model_gain_unmeasured=True,
 estimated_hardware_minutes=[10,30],estimate_not_guaranteed=True,survives_disconnect=True,resumes_after_reboot=False,
 source_manifest_sha256=hashlib.sha256((control/'source-manifest.json').read_bytes()).hexdigest())
(control/'launch.json').write_text(json.dumps(launch,indent=2)+'\n')
subprocess.run(command,check=True,timeout=30)
active=props('qwen38-prefill-attention-v1-20261010.service')
(control/'launch-unit.json').write_text(json.dumps(active,indent=2)+'\n')
assert active['ActiveState']=='active' and active['MainPID']!='0'
print('prefill',active,flush=True)
'''
subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','IdentityAgent=none','-o','IdentitiesOnly=yes',
 '-i','/Users/anatarajan/.ssh/id_ed25519','ttuser@10.228.203.98','python3 -'],
 input='PAYLOAD='+repr(payload)+'\n'+remote,text=True,check=True,timeout=900)
