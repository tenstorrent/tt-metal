import subprocess
remote=r'''
import hashlib,json,sys,time,subprocess
from pathlib import Path
art=Path('/home/ttuser/qwen38-artifacts-20261007')
sys.path.insert(0,str(art/'export-recovery-source-v2'))
from models.demos.qwen38_27b_qb2.demo.watch_profile_export import properties,empty_cgroup
from models.demos.qwen38_27b_qb2.tests.profile_export_recovery import require_unstarted_failure,replacement_command,terminal
unit=lambda s:'qwen38-'+s+'-20261010.service'
p=properties(unit('prefill-attention-v4'));assert terminal(p,'1fef76e1882c4ac1b2c9b2ff5e8dc2b1');empty_cgroup(p)
r=json.loads((art/'prefill-attention-v4/prefill-attention.json').read_text())
assert r['state']=='failed' and r['cleanup_completed'] is True and r['cases'][-1]['active_arm']=='before'
assert r['error']['type']=='AssertionError' and r['error']['message'].startswith('Prefill attention failed selected-row dense reference')
q=json.loads((art/'projection-sweep-v7/queue.json').read_text());assert q['state']=='completed' and q['cleanup_completed'] is True
rows=[('compact-long-horizon-v4','compact-long-horizon-control-v4','4e1de31068f34e1c95bfef609775e511','compact-long-horizon-v6','compact-long-horizon-control-v6'),('gdn-resident-hardware-v2','gdn-resident-hardware-control-v2','bc1621a45a50411c9b8be8ac3150a2fa','gdn-resident-hardware-v3','gdn-resident-hardware-control-v3'),('gdn-compact-gates-v2','gdn-compact-gates-control-v2','69bd534cec5a4302a3e384afd926c429','gdn-compact-gates-v3','gdn-compact-gates-control-v3')]
audit=[]
for old,oc,inv,new,nc in rows:
 p=properties(unit(old));q=json.loads((art/old/'queue.json').read_text());require_unstarted_failure(p,q,inv);empty_cgroup(p)
 assert not (art/new).exists() and not (art/nc).exists() and properties(unit(new))['LoadState']=='not-found'
 command=json.loads((art/oc/'launch.json').read_text())['command']
 manifest=Path(command[command.index('--manifest')+1]);source=Path(command[command.index('--source')+1])
 for n,h in json.loads(manifest.read_text()).items():assert hashlib.sha256((source/n).read_bytes()).hexdigest()==h,n
 audit.append(dict(properties=p,queue=q,manifest_sha256=hashlib.sha256(manifest.read_bytes()).hexdigest()))
parent=unit('projection-sweep-v7');inv='fe9095edf11a4a5f8035ce8ef9c9602a';receipt=str(art/'projection-sweep-v7/queue.json')
for (old,oc,oldinv,new,nc),original in zip(rows,audit):
 p=properties(unit(old));require_unstarted_failure(p,json.loads((art/old/'queue.json').read_text()),oldinv);empty_cgroup(p)
 control=art/nc;control.mkdir()
 cmd=replacement_command(json.loads((art/oc/'launch.json').read_text())['command'],old_unit=unit(old),new_unit=unit(new),old_output=str(art/old),new_output=str(art/new),old_log=str(art/oc/'run.log'),new_log=str(control/'run.log'),after_unit=parent,after_invocation=inv,after_receipt=receipt)
 (control/'launch.json').write_text(json.dumps(dict(command=cmd,created_at=time.time(),previous_launch=str(art/oc/'launch.json'),frozen_source_unchanged=True,reason='Independent recurrence experiments follow successful projection; failed prefill baseline retained and not promoted'),indent=2)+'\n')
 (control/'predecessor-audit.json').write_text(json.dumps(original,indent=2)+'\n')
 subprocess.run(cmd,check=True,timeout=30)
 p=properties(unit(new));assert p['ActiveState']=='active' and p['MainPID']!='0'
 (control/'launch-unit.json').write_text(json.dumps(p,indent=2)+'\n');print(json.dumps(dict(unit=unit(new),properties=p)),flush=True)
 parent,inv,receipt=unit(new),p['InvocationID'],str(art/new/'queue.json')
'''
subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','IdentityAgent=none','-o','IdentitiesOnly=yes','-i','/Users/anatarajan/.ssh/id_ed25519','ttuser@10.228.203.98','python3 -'],input=remote,text=True,check=True,timeout=180)
