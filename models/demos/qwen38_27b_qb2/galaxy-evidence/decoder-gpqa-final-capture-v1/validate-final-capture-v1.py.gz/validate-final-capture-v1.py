import ast
import hashlib
import json
from pathlib import Path
import subprocess

path = Path('/private/tmp/qwen38-collect-decoder-gpqa-result-v1.py')
tree = ast.parse(path.read_text())
source = next(n.value.value for n in tree.body if isinstance(n, ast.Assign)
              and any(isinstance(t, ast.Name) and t.id == 'REMOTE' for t in n.targets))
original = source
replacements = {
    'accuracy-decoder-v1': 'accuracy-head-v1',
    'ecb6408f79414ed0974c6352f006bce5': 'ff89c12d6a9b4feaa268d7eff48b4132',
    'qwen38-decoder-gpqa-audit-v2-20261009.service': 'qwen38-gpqa-completion-audit-v1-20261009.service',
    '0213267c7b54413792a6882351321291': '7172e4b27dbd47868376e12d70fa2815',
    "art/'decoder-gpqa-audit-v2'": "art/'gpqa-completion-audit-v1'",
    "auditroot/'results/status.json'": "auditroot/'status.json'",
    "auditroot/'results/audit.json'": "auditroot/'audit.json'",
}
for old, new in replacements.items():
    if old not in source:
        raise ValueError('Missing expected adaptation: ' + old)
    source = source.replace(old, new)
compile(source, 'completed_control_reader.py', 'exec')
command = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', '-o', 'IdentityAgent=none',
           '-o', 'IdentitiesOnly=yes', '-i', '/Users/anatarajan/.ssh/id_ed25519',
           'ttuser@10.228.203.98', 'python3 -']
result = subprocess.run(command, input=source, text=True, capture_output=True, timeout=60)
if result.returncode:
    print(result.stderr)
    result.check_returncode()
reply = json.loads(result.stdout)
if reply['state'] != 'completed' or reply['result']['correct'] != 166 or reply['qualification']['harness_correct'] != 166:
    raise ValueError('Completed-control validation did not reproduce the frozen 166/198 result')
import base64
import gzip
for name, encoded in reply['files'].items():
    data = base64.b64decode(encoded, validate=True)
    if name.endswith('.gz'):
        gzip.decompress(data)
    if name.endswith('.json'):
        json.loads(data)
record = dict(state='completed_control_reader_passed',
              original_reader_sha256=hashlib.sha256(original.encode()).hexdigest(),
              validation_reader_sha256=hashlib.sha256(source.encode()).hexdigest(),
              path_and_invocation_adaptations=replacements,
              original_current_run_unchanged=True, hardware_opened=False,
              reference='Completed head-only precision control; not the live all-BFP8 run',
              reproduced_correct=166, total=198, validated_artifact_count=len(reply['files']))
output = Path('/private/tmp/qwen38-final-capture-validation-v1.json')
with output.open('x') as stream:
    stream.write(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
