import ast
import base64
import hashlib
import json
from pathlib import Path
import subprocess

collector = Path('/private/tmp/qwen38-collect-decoder-gpqa-result-v1.py').read_text()
tree = ast.parse(collector)
reader = next(n.value.value for n in tree.body if isinstance(n, ast.Assign)
              and any(isinstance(t, ast.Name) and t.id == 'REMOTE' for t in n.targets))
files = {'read_result.py': reader.encode(),
         'controller.py': Path('/private/tmp/qwen38-final-capture-controller-v1.py').read_bytes()}
for name, content in files.items():
    compile(content, name, 'exec')
manifest = {name: hashlib.sha256(content).hexdigest() for name, content in files.items()}
files['source-manifest.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
payload = {name: base64.b64encode(content).decode() for name, content in files.items()}
remote = r'''
import base64,hashlib,json,pathlib,subprocess,time
art=pathlib.Path('/home/ttuser/qwen38-artifacts-20261007')
root=art/'decoder-gpqa-capture-source-v1'
if (art/'decoder-gpqa-capture-v1').exists():raise FileExistsError('Capture destination already exists')
root.mkdir(mode=0o700)
for name,encoded in PAYLOAD.items():
 (root/name).write_bytes(base64.b64decode(encoded))
for name,digest in json.loads((root/'source-manifest.json').read_text()).items():
 if hashlib.sha256((root/name).read_bytes()).hexdigest()!=digest:raise ValueError('Frozen capture source mismatch')
preflight=subprocess.run(['/usr/bin/python3',str(root/'read_result.py')],text=True,capture_output=True,timeout=90,check=True)
observation=json.loads(preflight.stdout)
if observation.get('state') not in ('waiting','completed'):raise ValueError('Unexpected preflight observation')
(root/'preflight.json').write_text(json.dumps({k:v for k,v in observation.items() if k!='files'},indent=2)+'\n')
command=['systemd-run','--user','--unit=qwen38-decoder-gpqa-capture-v1-20261009',
 '--property=RuntimeMaxSec=10h','--property=TimeoutStopSec=20','--property=KillMode=control-group',
 '--property=MemoryMax=512M','--property=CPUQuota=100%','--property=TasksMax=32','--property=UMask=0077',
 f'--property=StandardOutput=append:{root}/run.log',f'--property=StandardError=append:{root}/run.log',
 '--setenv=PYTHONUNBUFFERED=1','--setenv=PYTHONDONTWRITEBYTECODE=1',
 '/usr/bin/python3',str(root/'controller.py')]
(root/'launch.json').write_text(json.dumps({'created_at':time.time(),'command':command,'original_run_unchanged':True},indent=2)+'\n')
subprocess.run(command,check=True)
print((root/'preflight.json').read_text())
print(subprocess.check_output(['systemctl','--user','show','qwen38-decoder-gpqa-capture-v1-20261009.service','-p','MainPID','-p','ActiveState','-p','InvocationID'],text=True))
'''
compile(remote, 'remote_stage.py', 'exec')
command = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', '-o', 'IdentityAgent=none',
           '-o', 'IdentitiesOnly=yes', '-i', '/Users/anatarajan/.ssh/id_ed25519',
           'ttuser@10.228.203.98', 'python3 -']
subprocess.run(command, input='PAYLOAD=' + repr(payload) + '\n' + remote, text=True, check=True, timeout=120)
