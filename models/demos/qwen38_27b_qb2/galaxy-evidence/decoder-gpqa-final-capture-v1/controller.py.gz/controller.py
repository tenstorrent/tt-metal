"""Wait for the immutable full-result reader, then retain only public metadata."""

import base64
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ART = Path('/home/ttuser/qwen38-artifacts-20261007')
SOURCE = ART / 'decoder-gpqa-capture-source-v1'
ROOT = ART / 'decoder-gpqa-capture-v1'


def main():
    ROOT.mkdir()
    state = dict(state='waiting', started_at=time.time(), hardware_opened=False,
                 survives_disconnect=True, resumes_after_reboot=False,
                 mutates_original_run=False, changes_scores=False)

    def save():
        state['updated_at'] = time.time()
        target = ROOT / 'status.tmp'
        target.write_text(json.dumps(state, indent=2) + '\n')
        target.replace(ROOT / 'status.json')

    try:
        manifest = json.loads((SOURCE / 'source-manifest.json').read_text())
        for name, digest in manifest.items():
            if hashlib.sha256((SOURCE / name).read_bytes()).hexdigest() != digest:
                raise ValueError('Frozen capture source changed: ' + name)
        deadline = time.monotonic() + 9 * 3600
        while True:
            if time.monotonic() >= deadline:
                raise TimeoutError('Original evaluation/completion audit exceeded capture wait')
            save()
            result = subprocess.run(['/usr/bin/python3', str(SOURCE / 'read_result.py')],
                                    text=True, capture_output=True, timeout=90)
            if result.returncode:
                (ROOT / 'reader-error.log').write_text(result.stdout + result.stderr)
                raise RuntimeError('Read-only result collector failed; original run left unchanged')
            reply = json.loads(result.stdout)
            if reply.get('state') == 'waiting':
                state.update(last_observation=reply)
                save()
                time.sleep(30)
                continue
            if reply.get('state') != 'completed':
                raise ValueError('Unknown collector state')
            state.update(state='capturing', qualification=reply['qualification'])
            save()
            destination = ROOT / 'result'
            destination.mkdir()
            hashes = {}
            for name, encoded in reply['files'].items():
                if Path(name).name != name or name in ('.', '..'):
                    raise ValueError('Unexpected evidence path')
                data = base64.b64decode(encoded, validate=True)
                with (destination / name).open('xb') as stream:
                    stream.write(data)
                    stream.flush()
                    os.fsync(stream.fileno())
                hashes[name] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
            (ROOT / 'capture-manifest.json').write_text(json.dumps(hashes, indent=2) + '\n')
            state.update(state='completed', result=reply['result'], finished_at=time.time())
            save()
            break
    except BaseException as error:
        state.update(state='failed', error=type(error).__name__, detail=str(error)[:2000], finished_at=time.time())
        raise
    finally:
        save()


if __name__ == '__main__':
    main()
