
import base64,collections,datetime,gzip,hashlib,json,pathlib,statistics,subprocess
art=pathlib.Path('/home/ttuser/qwen38-artifacts-20261007')
base=art/'accuracy-decoder-v1/native-control/evaluation'
gpqa=base/'gpqa'
auditroot=art/'decoder-gpqa-audit-v2'
services={}
for unit,invocation in [
 ('qwen38-accuracy-decoder-v1-20261009.service','ecb6408f79414ed0974c6352f006bce5'),
 ('qwen38-decoder-gpqa-audit-v2-20261009.service','0213267c7b54413792a6882351321291')]:
 output=subprocess.check_output(['systemctl','--user','show',unit,'-p','MainPID','-p','ActiveState','-p','LoadState','-p','Result','-p','InvocationID'],text=True,timeout=15)
 props=dict(line.split('=',1) for line in output.splitlines() if '=' in line)
 services[unit]=props
 if props.get('InvocationID') and props['InvocationID']!=invocation:
  raise ValueError('Original service invocation changed: '+unit)
 if props.get('MainPID')!='0' or props.get('ActiveState') not in ('inactive','failed'):
  print(json.dumps({'state':'waiting','services':services,'progress':json.loads((gpqa/'gpqa-progress.json').read_text())}))
  raise SystemExit(0)
 if props.get('LoadState') not in ('loaded','not-found') or props.get('Result')!='success':
  raise ValueError('Original job did not complete successfully: '+unit)
queue=json.loads((art/'accuracy-decoder-v1/queue.json').read_text())
deployment=json.loads((base/'deployment.json').read_text())
auditstatus=json.loads((auditroot/'results/status.json').read_text())
audit=json.loads((auditroot/'results/audit.json').read_text())
summary=json.loads((gpqa/'summary.json').read_text())
protocol=json.loads((gpqa/'protocol.json').read_text())
if queue.get('state')!='completed' or deployment.get('owned_processes_stopped') is not True or auditstatus.get('state')!='completed':
 raise ValueError('Expected a completed queue, owned-worker shutdown and completed audit')
if audit.get('all_private_responses_match_scored_receipts') is not True or audit.get('selected_count')!=198:
 raise ValueError('Completed audit does not cover every saved response')
rows_bytes=(gpqa/'gpqa-responses.jsonl').read_bytes()
rows=[json.loads(line) for line in rows_bytes.splitlines() if line.strip()]
if sorted(row['id'] for row in rows)!=list(range(198)):
 raise ValueError('Final scored responses do not cover each question exactly once')
if hashlib.sha256(rows_bytes).hexdigest()!=audit['receipt_sha256'] or hashlib.sha256((gpqa/'summary.json').read_bytes()).hexdigest()!=audit['summary_sha256']:
 raise ValueError('Final result bytes differ from the independent audit')
if protocol['input_sha256']!='73f40d9f36c2cf2070120e34c425f0a10aafaa7edd8c1f6878b002e7bf756114':
 raise ValueError('Input selection differs from the matched control')
def load_rows(path):
 rows=[json.loads(line) for line in path.read_bytes().splitlines() if line.strip()]
 if sorted(row['id'] for row in rows)!=list(range(198)):
  raise ValueError('Control does not cover each question exactly once')
 return {row['id']:row for row in rows}
current={row['id']:row for row in rows}
comparisons={}
for label,root in [('native-bfp4','overnight-v2'),('bfp4-with-bfp8-head','accuracy-head-v1')]:
 prior=art/root/'native-control/evaluation/gpqa'
 prior_protocol=json.loads((prior/'protocol.json').read_text())
 for key in ('input_sha256','gpqa','checkpoint_revision','dataset_revision','harness_revision','server_capacity','data_parallel_size'):
  if prior_protocol[key]!=protocol[key]:raise ValueError('Protocol differs for '+label+': '+key)
 baseline=load_rows(prior/'gpqa-responses.jsonl')
 counts=collections.Counter((bool(baseline[k]['correct']),bool(current[k]['correct'])) for k in current)
 comparisons[label]={
  'total':198,'both_correct':counts[True,True],
  'baseline_only_correct':counts[True,False],'bfp8_only_correct':counts[False,True],
  'neither_correct':counts[False,False],
  'baseline_result':json.loads((prior/'summary.json').read_text())['gpqa_result'],
  'baseline_response_sha256':hashlib.sha256((prior/'gpqa-responses.jsonl').read_bytes()).hexdigest(),
  'per_question':[{'id':k,'baseline_correct':baseline[k]['correct'],'bfp8_correct':current[k]['correct'],
   'baseline_finish':baseline[k]['finish_reason'],'bfp8_finish':current[k]['finish_reason']} for k in sorted(current)]}
def distribution(values):
 values=sorted(x for x in values if x is not None)
 if not values:return {'n':0}
 cuts=statistics.quantiles(values,n=100,method='inclusive')
 return {'n':len(values),'mean':statistics.mean(values),'median':statistics.median(values),'p90':cuts[89],'p95':cuts[94],'min':values[0],'max':values[-1]}
report={'state':'completed','checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'qualification':audit['qualification'],'result':summary['gpqa_result'],
 'same_gpqa_protocol':True,'input_sha256':protocol['input_sha256'],
 'comparisons':comparisons,'timing':{
  'percentile_method':'inclusive linear interpolation on completed client request metrics',
  'ttft_ms':distribution([row['ttft_ms'] for row in rows]),
  'decode_tokens_per_s':distribution([row['decode_tokens_per_s'] for row in rows]),
  'request_elapsed_s':distribution([row['elapsed_s'] for row in rows]),
  'completion_tokens':distribution([row['usage']['completion_tokens'] for row in rows]),
  'total_completion_tokens':sum(row['usage']['completion_tokens'] for row in rows)},
 'services':services,'interpretation':'One sampled run per policy, not proof of numerical causality. Client timing includes serving and queue effects; aggregate output includes the whole evaluation interval. Native execution does not qualify the built container.'}
files={}
paths={'summary.json':gpqa/'summary.json','protocol.json':gpqa/'protocol.json','responses.jsonl.gz':gpqa/'gpqa-responses.jsonl',
 'completion-audit.json.gz':auditroot/'results/audit.json','completion-audit-status.json':auditroot/'results/status.json',
 'deployment.json':base/'deployment.json','accuracy-queue.json.gz':art/'accuracy-decoder-v1/queue.json',
 'evaluator.log.gz':base/'evaluator.log','server.log.gz':base/'server.log'}
for name,path in paths.items():
 if path.stat().st_size>64*1024**2:raise ValueError('Unexpectedly large evidence file: '+name)
 data=path.read_bytes()
 if name.endswith('.gz'):data=gzip.compress(data,mtime=0)
 files[name]=base64.b64encode(data).decode()
files['comparison-and-timing.json']=base64.b64encode((json.dumps(report,indent=2)+'\n').encode()).decode()
print(json.dumps({'state':'completed','files':files,'result':summary['gpqa_result'],'qualification':audit['qualification']}))
