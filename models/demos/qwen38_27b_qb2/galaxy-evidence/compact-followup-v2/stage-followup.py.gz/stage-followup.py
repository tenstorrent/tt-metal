import base64
import json
import subprocess
from pathlib import Path

repo = Path('/private/tmp/tt-metal-qwen38-long-context')
names = ['models/demos/qwen38_27b_qb2/' + n for n in (
    'demo/run_compact_followup.py', 'tests/test_full_trace_profile.py', 'tests/unit/test_compact_followup.py', 'tests/full_trace_profile.py', 'tests/unit/test_full_trace_profile.py', 'demo/run_bounded_layer_profile.py', 'tests/bounded_profile.py', 'tests/unit/test_bounded_profile.py', 'tests/unit/test_profile_queue.py')]
payload = {n: base64.b64encode((repo / n).read_bytes()).decode() for n in names}
remote = r'''
import base64, hashlib, json, os, shutil, subprocess, time
from pathlib import Path
art=Path('/home/ttuser/qwen38-artifacts-20261007')
task=Path('/home/ttuser/kimi-prefill.Ubx2wY/runtime/qwen38-27b-20261006')
source,control,output=[art/n for n in ('compact-followup-source-v2','compact-followup-control-v2','compact-followup-v2')]
profile=Path('/dev/shm/qwen38-compact-profile-v1-20261010')
assert not any(p.exists() for p in (source,control,output,profile))
assert shutil.disk_usage(art).free>20*1024**3
assert shutil.disk_usage('/dev/shm').free>64*1024**3
def props(unit):
 raw=subprocess.check_output(['systemctl','--user','show',unit,'-p','MainPID','-p','ActiveState','-p','SubState','-p','InvocationID','-p','Result','-p','LoadState'],text=True,timeout=20)
 return dict(line.split('=',1) for line in raw.splitlines() if '=' in line)
compact='qwen38-compact-gdn-v2-20261010.service'
projection='qwen38-projection-sweep-v3-20261010.service'
def check_waiters():
 current=props(compact)
 follower=props(projection)
 receipt=json.loads((art/'projection-sweep-v3/queue.json').read_text())
 assert current['InvocationID']=='43f1990817724573a9b130ed61f3ff0e' and current['MainPID']!='0' and current['ActiveState']=='active'
 assert follower['InvocationID']=='b8a146f6117847b2afba2ccbe1bee1f4' and follower['MainPID']!='0' and follower['ActiveState']=='active'
 assert receipt['state']=='waiting' and receipt['hardware_started'] is False
 return current,follower
check_waiters()
shutil.copytree(art/'compact-gdn-source-v2',source,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache','.benchmarks','generated'))
control.mkdir()
for name,value in PAYLOAD.items():
 (source/name).write_bytes(base64.b64decode(value))
model=source/'models/demos/qwen38_27b_qb2'
python=str(task/'python_env/bin/python')
env=dict(os.environ,TT_METAL_HOME=str(task/'metal'),LD_LIBRARY_PATH=f'{task}/metal-install/lib:{task}/metal-build/lib',
 PYTHONPATH=f'{source}:{task}/metal:{task}/metal/tools',ARCH_NAME='blackhole',OMP_NUM_THREADS='1',TT_METAL_INSPECTOR_RPC='0')
for key in ('TT_METAL_SIMULATOR','TT_METAL_DISABLE_SFPLOADMACRO','TT_METAL_SLOW_DISPATCH_MODE','QWEN_GDN_EPILOGUE_LAYER'):
 env.pop(key,None)
with (control/'preflight.log').open('w') as log:
 subprocess.run([python,'-m','pytest',str(model/'tests/unit'),'-c',str(source/'pytest.ini'),f'--rootdir={source}',
 '-o','addopts=','-q',f'--junitxml={control}/unit.xml'],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
 subprocess.run([python,'-m','pytest',str(model/'tests/test_full_trace_profile.py'),'--collect-only','-q',
 '-c',str(source/'pytest.ini'),f'--rootdir={source}','-o','addopts='],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
print((control/'preflight.log').read_text()[-1400:],flush=True)
files=[source/n for n in ('conftest.py','pytest.ini','scripts/run_safe_pytest.sh')]
files.extend(p for p in model.rglob('*') if p.suffix in ('.py','.cpp','.h','.hpp','.json'))
manifest={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(control/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
original_manifest=json.loads((art/'compact-gdn-control-v2/source-manifest.json').read_text())
prefix='models/demos/qwen38_27b_qb2/'
for folder in ('tt/','config/'):
 assert {k:v for k,v in manifest.items() if k.startswith(prefix+folder)}=={k:v for k,v in original_manifest.items() if k.startswith(prefix+folder)}
current,follower=check_waiters()
newcontrol=art/'projection-sweep-control-v4'
assert not newcontrol.exists() and not (art/'projection-sweep-v4').exists()
newcontrol.mkdir()
command=['systemd-run','--user','--unit=qwen38-compact-followup-v2-20261010',
 '--property=RuntimeMaxSec=36h','--property=TimeoutStopSec=210','--property=KillMode=control-group',
 '--property=MemoryMax=256G','--property=CPUQuota=1600%',
 f'--property=StandardOutput=append:{control}/run.log',f'--property=StandardError=append:{control}/run.log',
 f'--working-directory={source}',f'--setenv=PYTHONPATH={source}','--setenv=PYTHONUNBUFFERED=1',
 python,'-m','models.demos.qwen38_27b_qb2.demo.run_compact_followup',
 '--task',str(task),'--source',str(source),'--weights',str(art/'checkpoint-pinned-1d4bf0f2'),
 '--output',str(output),'--profile-output',str(profile),'--manifest',str(control/'source-manifest.json'),
 '--compact-manifest',str(art/'compact-gdn-control-v2/source-manifest.json'),'--compact-results',str(art/'compact-gdn-v2'),
 '--after-unit',compact,'--after-invocation',current['InvocationID']]
launch=dict(command=command,created_at=time.time(),source_parent='3d89998949a',changed_files=list(PAYLOAD),
 reason='Qualify >=1% measured compact B16/32K gain, then profile matching unprofiled/profiled full traces',
 kernel_code_changed=False,promoted_to_serving=False,hardware_plan=['8-TP4 G0','Full 198-question GPQA, 65536 output budget','B16/32K unprofiled full trace','Matched profiled full trace'],
 estimated_hardware_minutes=[130,200],estimate_not_guaranteed=True,survives_disconnect=True,resumes_after_reboot=False,
 source_manifest_sha256=hashlib.sha256((control/'source-manifest.json').read_bytes()).hexdigest(),
 projection_reorder=dict(unit=projection,previous=follower,hardware_started=False))
(control/'launch.json').write_text(json.dumps(launch,indent=2)+'\n')
# Only the exact task-owned waiting controller is stopped, never its active predecessor.
subprocess.run(['systemctl','--user','stop',projection],check=True,timeout=60)
stopped=props(projection)
assert stopped['MainPID']=='0' and stopped['ActiveState'] in ('inactive','failed')
(newcontrol/'previous-waiter.json').write_text(json.dumps(dict(before=follower,after=stopped,reason=launch['reason']),indent=2)+'\n')
subprocess.run(command,check=True,timeout=30)
active=props('qwen38-compact-followup-v2-20261010.service')
(control/'launch-unit.json').write_text(json.dumps(active,indent=2)+'\n')
assert active['ActiveState']=='active' and active['MainPID']!='0'
print('followup',active,flush=True)
projection_command=json.loads((art/'projection-sweep-control-v3/launch.json').read_text())['command']
projection_command=[s.replace('--unit=qwen38-projection-sweep-v3-20261010','--unit=qwen38-projection-sweep-v4-20261010').replace('projection-sweep-control-v3/run.log','projection-sweep-control-v4/run.log') for s in projection_command]
for name,value in [('--output',str(art/'projection-sweep-v4')),('--after-unit','qwen38-compact-followup-v2-20261010.service'),('--after-invocation',active['InvocationID']),('--after-receipt',str(output/'queue.json'))]:
 projection_command[projection_command.index(name)+1]=value
(newcontrol/'launch.json').write_text(json.dumps(dict(command=projection_command,created_at=time.time(),frozen_source_unchanged=True,reason='Profile compact whole-model bottlenecks before projection sweep'),indent=2)+'\n')
subprocess.run(projection_command,check=True,timeout=30)
state=props('qwen38-projection-sweep-v4-20261010.service')
(newcontrol/'launch-unit.json').write_text(json.dumps(state,indent=2)+'\n')
print('projection',state,flush=True)
'''
subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','IdentityAgent=none','-o','IdentitiesOnly=yes',
 '-i','/Users/anatarajan/.ssh/id_ed25519','ttuser@10.228.203.98','python3 -'],
 input='PAYLOAD='+repr(payload)+'\n'+remote,text=True,check=True,timeout=900)
