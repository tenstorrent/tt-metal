import base64
import subprocess
from pathlib import Path

repo=Path('/private/tmp/tt-metal-qwen38-long-context')
prefix='models/demos/qwen38_27b_qb2/'
names=['demo/recover_full_profile_export.py','demo/watch_profile_export.py','tests/profile_export_recovery.py','tests/unit/test_profile_export_recovery.py']
payload={prefix+n:base64.b64encode((repo/prefix/n).read_bytes()).decode() for n in names}
remote=r'''
from pathlib import Path
import base64,hashlib,json,os,shutil,subprocess,sys,time
art=Path('/home/ttuser/qwen38-artifacts-20261007');task=Path('/home/ttuser/kimi-prefill.Ubx2wY/runtime/qwen38-27b-20261006')
source=art/'export-recovery-source-v2';control=art/'export-recovery-control-v2';output=art/'export-recovery-v2';validation=art/'export-recovery-validation-v2'
assert not any(p.exists() for p in (source,control,output,validation))
assert shutil.disk_usage(art).free>24*1024**3
parent='qwen38-compact-followup-v3-20261010.service';invocation='28c688b7780445999483523a9cbc75fc'
def props(unit):
 raw=subprocess.check_output(['systemctl','--user','show',unit,'-p','LoadState','-p','MainPID','-p','ActiveState','-p','InvocationID','-p','Result'],text=True,timeout=20)
 return dict(line.split('=',1) for line in raw.splitlines() if '=' in line)
pred=props(parent)
assert pred['ActiveState']=='active' and pred['MainPID']!='0' and pred['InvocationID']==invocation,pred

old_unit='qwen38-compact-export-fallback-v1-20261010.service'
old=props(old_unit)
assert old['InvocationID']=='3dd7ca4a80ca4a8eb46a619125e8b508' and old['ActiveState']=='active'
old_receipt=json.loads((art/'export-recovery-v1/queue.json').read_text())
assert old_receipt['state']=='waiting' and old_receipt['hardware_started'] is False
subprocess.run(['systemctl','--user','stop',old_unit],check=True,timeout=40)
assert props(old_unit)['MainPID']=='0'

shutil.copytree(art/'gdn-compact-gates-source-v1',source,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache','.benchmarks','generated'))
control.mkdir()
for name,encoded in PAYLOAD.items():
 p=source/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(base64.b64decode(encoded))
python=str(task/'python_env/bin/python');model=source/prefix
env=dict(os.environ,TT_METAL_HOME=str(task/'metal'),LD_LIBRARY_PATH=f'{task}/metal-install/lib:{task}/metal-build/lib',PYTHONPATH=f'{source}:{task}/metal:{task}/metal/tools',ARCH_NAME='blackhole',OMP_NUM_THREADS='4',TT_METAL_INSPECTOR_RPC='0')
with (control/'preflight.log').open('w') as log:
 subprocess.run([python,'-m','pytest',str(model/'tests/unit'),'-c',str(source/'pytest.ini'),f'--rootdir={source}','-o','addopts=','-q',f'--junitxml={control}/unit.xml'],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
files=[source/name for name in PAYLOAD]
manifest={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(control/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
unit='qwen38-compact-export-fallback-v2-20261010.service'
exporter=task/'metal-build/tools/profiler/bin/tracy-csvexport'
plan=dict(unit=unit,parent_unit=parent,parent_invocation=invocation,parent_receipt=str(art/'compact-followup-v3/queue.json'),qualification=str(art/'compact-followup-v3/qualification/queue.json'),profiled='/dev/shm/qwen38-compact-profile-v2-20261010/profiled',baseline='/dev/shm/qwen38-compact-profile-v2-20261010/unprofiled',exporter=str(exporter),python=python,validation_receipt=str(validation/'queue.json'),followers=[])
rows=[
 ('projection-sweep-v6','projection-sweep-control-v6','960d702be457402a92d32d88b4a4a591'),
 ('prefill-attention-v3','prefill-attention-control-v3','d7501d6753824d31846a13ecef289c32'),
 ('compact-long-horizon-v3','compact-long-horizon-control-v3','6f0ee1599ae144d6a6843b49bf22455b'),
 ('gdn-resident-hardware-v1','gdn-resident-hardware-control-v1','9a87b6620b6c4892b407a17f7c54f04e'),
 ('gdn-compact-gates-v1','gdn-compact-gates-control-v1','37fb5d460eed4792841823a8ba71d855')]
for name,oldcontrol,oldinv in rows:
 launch=art/oldcontrol/'launch.json';command=json.loads(launch.read_text())['command'];oldunit=f'qwen38-{name}-20261010.service'
 observed=props(oldunit);assert observed['InvocationID']==oldinv and observed['MainPID']!='0',observed
 receipt=json.loads((art/name/'queue.json').read_text());assert receipt['state']=='waiting' and receipt['hardware_started'] is False
 source_manifest=Path(command[command.index('--manifest')+1])
 plan['followers'].append(dict(old_unit=oldunit,old_invocation=oldinv,old_output=str(art/name),old_log=str(art/oldcontrol/'run.log'),launch=str(launch),launch_sha256=hashlib.sha256(launch.read_bytes()).hexdigest(),manifest_sha256=hashlib.sha256(source_manifest.read_bytes()).hexdigest(),new_unit=f'qwen38-{name}-export-recovery1-20261010.service',new_output=str(art/(name+'-export-recovery1')),new_control=str(art/(oldcontrol+'-export-recovery1'))))
(control/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
base=['systemd-run','--user','--property=RuntimeMaxSec=28h','--property=TimeoutStopSec=210','--property=KillMode=control-group','--property=MemoryMax=16G','--property=CPUQuota=400%',f'--working-directory={source}',f'--setenv=PYTHONPATH={source}:{task}/metal:{task}/metal/tools',f'--setenv=TT_METAL_HOME={task}/metal',f'--setenv=LD_LIBRARY_PATH={task}/metal-install/lib:{task}/metal-build/lib','--setenv=ARCH_NAME=blackhole','--setenv=OMP_NUM_THREADS=4','--setenv=PYTHONUNBUFFERED=1']
validate=base+[f'--unit=qwen38-export-recovery-validation-v2-20261010',f'--property=StandardOutput=append:{control}/validation.log',f'--property=StandardError=append:{control}/validation.log',python,'-m',prefix.replace('/','.')+'demo.recover_full_profile_export','--original','/dev/shm/qwen38-p0-priority-v1-20261010/profiled','--baseline','/dev/shm/qwen38-p0-priority-v1-20261010/unprofiled','--output',str(validation),'--exporter',str(exporter),'--python',python]
validate=[v.replace('--property=RuntimeMaxSec=28h','--property=RuntimeMaxSec=1h') for v in validate]
command=base+[f'--unit={unit.removesuffix(".service")}',f'--property=StandardOutput=append:{control}/run.log',f'--property=StandardError=append:{control}/run.log',python,'-m',prefix.replace('/','.')+'demo.watch_profile_export','--plan',str(control/'plan.json'),'--output',str(output)]
(control/'launch.json').write_text(json.dumps(dict(command=command,validation_command=validate,created_at=time.time(),parent=pred,physical_devices_accessed=False,scope='CPU-only filtered export after original controller exits; retry only unstarted dependency failures in fresh units'),indent=2)+'\n')
subprocess.run(validate,check=True,timeout=30)
subprocess.run(command,check=True,timeout=30)
active={name:props(name) for name in (unit,'qwen38-export-recovery-validation-v2-20261010.service')}
(control/'launch-units.json').write_text(json.dumps(active,indent=2)+'\n')
print(json.dumps(active,indent=2))
print((control/'preflight.log').read_text()[-1200:])
'''
subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','IdentityAgent=none','-o','IdentitiesOnly=yes','-i','/Users/anatarajan/.ssh/id_ed25519','ttuser@10.228.203.98','python3 -'],input='PAYLOAD='+repr(payload)+'\nprefix='+repr(prefix)+'\n'+remote,text=True,check=True,timeout=750)
