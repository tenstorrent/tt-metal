import json,os,time
from pathlib import Path
p=Path(__file__).parent
assert os.environ['TT_METAL_SIMULATOR']==str(p/'libttsim_bh.so')
import torch
import ttnn
torch.set_num_threads(1)
print('SIMULATOR_LIBRARY',os.environ['TT_METAL_SIMULATOR'],flush=True)
print('SIMULATOR_VISIBLE_DEVICES',ttnn.GetNumAvailableDevices(),flush=True)
assert ttnn.GetNumAvailableDevices()==1, 'Expected one simulated device, never the physical Galaxy'
mesh=ttnn.open_mesh_device(ttnn.MeshShape(1,1))
try:
 torch.manual_seed(721)
 a=torch.randn(32,64).bfloat16();w=torch.randn(64,32).bfloat16()
 def put(t,dtype):return ttnn.from_torch(t,device=mesh,dtype=dtype,layout=ttnn.TILE_LAYOUT,memory_config=ttnn.DRAM_MEMORY_CONFIG,mesh_mapper=ttnn.ReplicateTensorToMesh(mesh))
 x=put(a,ttnn.bfloat16);y=put(w,ttnn.bfloat4_b)
 cfg=ttnn.BlackholeComputeKernelConfig(math_fidelity=ttnn.MathFidelity.LoFi,fp32_dest_acc_en=True,math_approx_mode=False,packer_l1_acc=True)
 z=ttnn.matmul(x,y,compute_kernel_config=cfg,dtype=ttnn.bfloat16)
 def host(t):return ttnn.to_torch(ttnn.get_device_tensors(t)[0]).float()
 actual=host(z);quantized=host(y);reference=a.float()@quantized
 result=dict(state='completed',simulator=os.environ['TT_METAL_SIMULATOR'],visible_devices=1,finite=bool(torch.isfinite(actual).all()),execution_relative_rms=float((actual-reference).square().mean().sqrt()/reference.square().mean().sqrt()),quantized_weight_relative_rms=float((quantized-w.float()).square().mean().sqrt()/w.float().square().mean().sqrt()))
 assert result['finite']
 print('SIMULATOR_SMOKE',json.dumps(result),flush=True)
 (p/'smoke.json').write_text(json.dumps(result,indent=2)+'\n')
finally:
 ttnn.close_mesh_device(mesh)
