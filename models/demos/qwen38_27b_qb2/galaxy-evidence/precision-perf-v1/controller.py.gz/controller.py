import hashlib,json,subprocess,time
from pathlib import Path
from models.demos.qwen38_27b_qb2.demo.run_chunked_prefill_followup import predecessor_ready
from models.demos.qwen38_27b_qb2.demo.run_long_context_capacity import environment,save
from models.demos.qwen38_27b_qb2.demo.run_bounded_layer_profile import run_capture
from models.demos.qwen38_27b_qb2.tests.sweep_report import make_plan,save_report

ART=Path('/home/ttuser/qwen38-artifacts-20261007')
TASK=Path('/home/ttuser/kimi-prefill.Ubx2wY/runtime/qwen38-27b-20261006')
SOURCE=ART/'precision-perf-source-v1';CONTROL=ART/'precision-perf-control-v1';ROOT=ART/'precision-perf-v1'
UNIT='qwen38-chunked-state-v2-20261009.service';INVOCATION='4c0c8fa5f3b249f79fee72c77d1c137f'
ROOT.mkdir()
state=dict(state='waiting',predecessor_unit=UNIT,predecessor_invocation=INVOCATION,hardware_opened=False,cleanup_completed=False,survives_disconnect=True,resumes_after_reboot=False,runs=[],is_gpqa_score=False,serving_qualified=False)
status=ROOT/'queue.json';save(status,state)
try:
 deadline=time.monotonic()+11*3600
 while True:
  if time.monotonic()>deadline:raise TimeoutError('Predecessor wait exceeded bound')
  try:raw=subprocess.check_output(['systemctl','--user','show',UNIT,'-p','MainPID','-p','InvocationID','-p','LoadState','-p','ActiveState','-p','Result'],text=True,timeout=15)
  except (subprocess.CalledProcessError,subprocess.TimeoutExpired) as error:
   state['observation_error']=type(error).__name__;save(status,state);time.sleep(30);continue
  props=dict(line.split('=',1) for line in raw.splitlines() if '=' in line);state['predecessor']=props;save(status,state)
  p=ART/'chunked-state-v2/queue.json';receipt=json.loads(p.read_text()) if p.exists() else None
  if predecessor_ready(props,receipt,INVOCATION):break
  time.sleep(30)
 for rel,digest in json.loads((CONTROL/'source-manifest.json').read_text()).items():
  if hashlib.sha256((SOURCE/rel).read_bytes()).hexdigest()!=digest:raise ValueError('Frozen performance source changed: '+rel)
 model=SOURCE/'models/demos/qwen38_27b_qb2'
 for label,precision in [('bfp4-lofi','precision_accurate_decode_bfp8_head.json'),('bfp4-hifi2','precision_accurate_decode_hifi2.json'),('bfp8-hifi2','precision_accurate_decode_bfp8_all.json')]:
  root=ROOT/label;root.mkdir();plan=make_plan(1,batches=(16,),input_lengths=(16384,32768));save_report(plan,root)
  assert len(plan['cells'])==2 and all(row['status']=='queued' for row in plan['cells'])
  env=environment(TASK,SOURCE,ART/'checkpoint-pinned-1d4bf0f2');env.update(QWEN_PRECISION_CONFIG=str(model/'config'/precision),QWEN_SWEEP_RESULTS=str(root))
  for key in ['TT_METAL_SIMULATOR','TT_METAL_KERNEL_PATH','TT_METAL_DISABLE_SFPLOADMACRO','TT_VISIBLE_DEVICES']:env.pop(key,None)
  command=['/bin/bash',str(SOURCE/'scripts/run_safe_pytest.sh'),str(model/'tests/test_galaxy_perf_sweep.py'),f'--rootdir={SOURCE}','-c',str(SOURCE/'pytest.ini'),'-vv','-s','--timeout=2700',f'--junitxml={root}/hardware.xml']
  row=dict(name=label,precision_file=precision,state='running',started_at=time.time(),command=command);state['runs'].append(row);state.update(state='running',hardware_opened=None,active_variant=label);save(status,state)
  wrapper=root/'exec.py';wrapper.write_text("import os,sys\nf=open(sys.argv[1],'a');os.dup2(f.fileno(),1);os.dup2(f.fileno(),2);os.execvpe(sys.argv[2],sys.argv[2:],os.environ)\n")
  try:
   run_capture([str(TASK/'python_env/bin/python'),str(wrapper),str(root/'run.log'),*command],cwd=SOURCE,env=env,root=root,timeout=3000)
   report=json.loads((root/'sweep.json').read_text())
   if report.get('state')!='completed' or report.get('cleanup_completed') is not True or any(c['status']!='completed' for c in report['cells']):raise ValueError('Sweep did not complete both cells and clean up')
   row.update(state='completed',finished_at=time.time(),cleanup_completed=True,precision=report['precision'],cells=[dict(input_tokens=c['input_tokens'],batch_per_replica=c['batch_per_replica'],summary=c['summary']) for c in report['cells']])
  except BaseException as error:
   row.update(state='failed',error=type(error).__name__,detail=str(error)[:1000]);raise
  finally:save(status,state)
 state.update(state='completed',cleanup_completed=True,finished_at=time.time())
except BaseException as error:
 state.update(state='failed',error=type(error).__name__,detail=str(error)[:2000]);raise
finally:save(status,state)
