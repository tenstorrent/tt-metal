import http.server
import json
from pathlib import Path
import shutil
import ssl
import subprocess
import time

root=Path('/home/ttuser/qwen38-release-build-20261009-v7')
work=root/'transfer-v7'
assert work.is_dir() and (work/"cert.pem").is_file() and (work/"key.pem").is_file()
archive=root/'artifact/qwen38-image.oci.tar'
digest='603a03b83772c8f47f7817d838316657ef6b4a77e972d9f9580559d4db2550dd'

class Handler(http.server.BaseHTTPRequestHandler):
 def do_HEAD(self):
  if self.client_address[0]!='10.228.203.98' or self.path!='/sha256/'+digest:
   self.send_error(404);return
  self.send_response(200);self.send_header('Content-Length',str(archive.stat().st_size));self.end_headers()
 def do_GET(self):
  if self.client_address[0]!='10.228.203.98' or self.path!='/sha256/'+digest:
   self.send_error(404);return
  self.send_response(200)
  self.send_header('Content-Type','application/octet-stream')
  self.send_header('Content-Length',str(archive.stat().st_size))
  self.end_headers()
  with archive.open('rb') as f:shutil.copyfileobj(f,self.wfile,4*1024**2)
server=http.server.HTTPServer(('10.228.203.34',18444),Handler)
server.socket.settimeout(60)
ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
ctx.minimum_version=ssl.TLSVersion.TLSv1_2
ctx.load_cert_chain(work/'cert.pem',work/'key.pem')
server.socket=ctx.wrap_socket(server.socket,server_side=True)
(root/'transfer-status-v7.json').write_text(json.dumps(dict(state='serving',started_at=time.time(),allowed_client='10.228.203.98',only_artifact=str(archive),tls=True),indent=2))
server.serve_forever()
