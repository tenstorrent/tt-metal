from pathlib import Path
import json,hashlib,signal,subprocess,time,xml.etree.ElementTree as ET
from models.demos.qwen38_27b_qb2.demo.run_bounded_layer_profile import run_capture
from models.demos.qwen38_27b_qb2.demo.run_long_context_capacity import environment,save
p=Path('/home/ttuser/qwen38-artifacts-20261007')
src=p/'gdn-resident-schedule-source-v1';ctl=p/'gdn-resident-schedule-control-v1';out=p/'gdn-resident-schedule-v1';task=Path('/home/ttuser/kimi-prefill.Ubx2wY/runtime/qwen38-27b-20261006')
status=dict(state='preflight',started_at=time.time(),cleanup_completed=False,survives_disconnect=True,resumes_after_reboot=False,full_model_qualified=False,promoted_to_serving=False,hardware_lock='/tmp/tt-device.lock')
def interrupted(signum,frame):raise InterruptedError(f'Signal {signum}')
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
def check_junit(path,expected=None):
 suites=ET.parse(path).getroot().findall('.//testsuite');n=sum(int(s.get('tests',0)) for s in suites)
 assert n>0 and (expected is None or n==expected)
 assert all(not int(s.get(k,0)) for s in suites for k in ('failures','errors','skipped'))
 return n
save(out/'queue.json',status)
try:
 for name,digest in json.loads((ctl/'source-manifest.json').read_text()).items():
  assert hashlib.sha256((src/name).read_bytes()).hexdigest()==digest,name
 env=environment(task,src,p/'checkpoint-pinned-1d4bf0f2')
 for key in ('TT_METAL_SIMULATOR','TT_METAL_KERNEL_PATH','TT_METAL_PROFILE_PERF_COUNTERS','TT_METAL_DISABLE_SFPLOADMACRO','TT_VISIBLE_DEVICES'):env.pop(key,None)
 env.update(TT_METAL_TRACE_ALLOC_TRACKING='1')
 model=src/'models/demos/qwen38_27b_qb2'
 unit=[str(task/'python_env/bin/python3.10'),'-m','pytest',str(model/'tests/unit/test_gdn_resident_schedule.py'),f'--rootdir={src}','-c',str(src/'pytest.ini'),'-q',f'--junitxml={ctl}/unit.xml']
 status.update(state='cpu_tests',unit_command=unit);save(out/'queue.json',status)
 with (ctl/'unit.log').open('w') as f:subprocess.run(unit,cwd=src,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180,check=True)
 status['cpu_tests_passed']=check_junit(ctl/'unit.xml')
 env.update(QWEN_GDN_RESIDENT_SCHEDULE='1',QWEN_GDN_RESIDENT_SCHEDULE_RECEIPT=str(out/'schedule.json'))
 command=['/bin/bash',str(src/'scripts/run_safe_pytest.sh'),str(model/'tests/test_gdn_resident_schedule.py'),f'--rootdir={src}','-c',str(src/'pytest.ini'),'-vv','-s','--tb=short','--timeout=900',f'--junitxml={out}/hardware.xml']
 status.update(state='hardware_or_waiting_for_lock',command=command);save(out/'queue.json',status)
 run_capture(command,cwd=src,env=env,root=out,timeout=1200)
 receipt=json.loads((out/'schedule.json').read_text());assert receipt['state']=='completed' and receipt['passed'] and receipt['cleanup_completed']
 assert receipt['device_ids']==[0,4,12,8] and [c['batch'] for c in receipt['cases']]==[16,32]
 assert receipt['trace_allocation_tracking'] and len(receipt['compute_sha256'])==4
 for case in receipt['cases']:
  assert case['passed'] and case['steps']==64 and case['readonly_inputs'] and case['stable_addresses']
  assert case['timing']['timing_stable'] and len(case['timing']['arms'])==5
  assert all(len(arm['call_us'])==5 and arm['steps']==2592 for arm in case['timing']['arms'])
  for check in case['checks']:
   assert len(check['ranks'])==16 and all(r['state_exact'] and r['output_exact'] and r['state_dense']['passed'] and r['output_dense']['passed'] for r in check['ranks'])
 check_junit(out/'hardware.xml',1)
 status.update(state='completed',cleanup_completed=True,exact_component_match=True,traced_comparison_completed=True)
except BaseException as error:
 status.update(state='failed',error=type(error).__name__,detail=str(error)[:3000]);raise
finally:
 status['finished_at']=time.time();save(out/'queue.json',status)
