import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

art = Path('/home/ttuser/qwen38-artifacts-20261007')
task = Path('/home/ttuser/kimi-prefill.Ubx2wY/runtime/qwen38-27b-20261006')
source = art / 'hf-layer-source-v2'
control = art / 'hf-layer-control-v2'
root = art / 'post-head-cpu-v2'
root.mkdir()
state = dict(state='waiting_for_hardware_lock', started_at=time.time(), stages=[], hardware_opened=False,
             survives_disconnect=True, resumes_after_reboot=False)

def save():
    p = root / 'status.json.tmp'
    p.write_text(json.dumps(state, indent=2) + '\n')
    p.replace(root / 'status.json')

save()
try:
    manifest = json.loads((control / 'source-manifest.json').read_text())
    for relative, expected in manifest.items():
        if hashlib.sha256((source / relative).read_bytes()).hexdigest() != expected:
            raise ValueError('Frozen source changed: ' + relative)
    env = dict(os.environ, TT_METAL_HOME=str(task/'metal'),
               LD_LIBRARY_PATH=f'{task}/metal-install/lib:{task}/metal-build/lib',
               PYTHONPATH=f'{source}:{task}/metal:{task}/metal/tools', ARCH_NAME='blackhole',
               OMP_NUM_THREADS='8', MKL_NUM_THREADS='8', CUDA_VISIBLE_DEVICES='',
               PYTHONUNBUFFERED='1', TT_METAL_INSPECTOR_RPC='0',
               HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
    with open('/tmp/tt-device.lock', 'a') as lock:
        deadline = time.monotonic() + 600
        while True:
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                if time.monotonic() >= deadline:
                    raise TimeoutError('Hardware lock was not available for CPU-only reference')
                time.sleep(5)
        command = [str(task/'python_env/bin/python'), str(source/'models/demos/qwen38_27b_qb2/demo/probe_hf_head.py'),
                   '--weights', str(art/'checkpoint-pinned-1d4bf0f2'),
                   '--qualification', str(art/'overnight-v2/native-g0/receipts/full-model.json'),
                   '--output', str(art/'hf-head-reference-v2'), '--threads', '8', '--steps', '8']
        row = dict(name='hf-head-reference', state='running', started_at=time.time(), command=command, timeout_seconds=2400)
        state.update(state='running', stages=[row]); save()
        with (root/'hf-head-reference.log').open('w') as log:
            result = subprocess.run(command, env=env, cwd=source, stdout=log, stderr=subprocess.STDOUT, timeout=2400)
        row.update(state='completed' if result.returncode == 0 else 'failed', exit_code=result.returncode, finished_at=time.time())
        if result.returncode:
            raise subprocess.CalledProcessError(result.returncode, command)
    state.update(state='completed', passed=True, finished_at=time.time())
except BaseException as error:
    if state['stages'] and state['stages'][-1]['state'] == 'running':
        state['stages'][-1].update(state='failed', error=type(error).__name__, finished_at=time.time())
    state.update(state='failed', passed=False, error=type(error).__name__, detail=str(error)[:2000], finished_at=time.time())
    raise
finally:
    save()
