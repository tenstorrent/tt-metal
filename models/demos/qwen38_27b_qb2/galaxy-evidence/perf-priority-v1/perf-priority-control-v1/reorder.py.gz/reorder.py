
from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess,time
art=Path('/home/ttuser/qwen38-artifacts-20261007')
control=art/'perf-priority-control-v1'
source=art/'perf-priority-source-v1'
task=Path('/home/ttuser/kimi-prefill.Ubx2wY/runtime/qwen38-27b-20261006')
expected=[('qwen38-gdn-epilogue-hardware-v1-20261009.service','16c50a2f3e4e428fbefe4c87c662cacb'),('qwen38-bfp8-gdn-v2-20261009.service','c3f1a7cad8e64f04bf68976b09a505fc'),('qwen38-image-hardware-v3-20261009.service','93f5759d1e4049508202587de2adf31b')]
container='qwen38-image-hardware-v3'
container_id='1a553b1ce324cf5f90eda8829554ace0ffec95e4b4051d2955e8ff7e2abc5470'
def properties(unit):
 raw=subprocess.check_output(['systemctl','--user','show',unit,'-p','MainPID','-p','ActiveState','-p','LoadState','-p','Result','-p','InvocationID'],text=True,timeout=30)
 return dict(line.split('=',1) for line in raw.splitlines() if '=' in line)
state=dict(state='validating',cleanup_completed=False,reason='performance_priority',hardware_health_proven=False,device_reset_required=True,physical_devices_accessed=False,invocation=os.environ['INVOCATION_ID'],units={},created_at=time.time())
def save():
 path=control/'release.json';temp=path.with_suffix('.tmp');temp.write_text(json.dumps(state,indent=2)+'\n');temp.replace(path)
save()
try:
 for unit,invocation in expected:
  props=properties(unit);assert props['InvocationID']==invocation and props['MainPID']!='0' and props['ActiveState']=='active',props
  state['units'][unit]=dict(before=props)
 for relative in ('gdn-epilogue-hardware-v1/queue.json','bfp8-gdn-v2/queue.json'):
  receipt=json.loads((art/relative).read_text());assert receipt['state']=='waiting' and receipt['hardware_started'] is False,receipt
 info=json.loads(subprocess.check_output(['docker','inspect',container],text=True,timeout=30))[0]
 assert info['Id']==container_id and info['Config']['Labels'].get('qwen38.task')==container
 (control/'container-before.json').write_text(json.dumps(info,indent=2)+'\n')
 # Capture diagnostics before removing only this task's container.
 log=subprocess.run(['docker','logs','--tail','200',container],capture_output=True,text=True,timeout=30)
 (control/'container-tail.log').write_text(log.stdout+log.stderr)
 state['state']='stopping_owned_jobs';save()
 for unit,invocation in expected:
  subprocess.run(['systemctl','--user','stop',unit],check=True,timeout=300)
  props=properties(unit)
  assert props['MainPID']=='0' and props['ActiveState'] in ('inactive','failed') and props['InvocationID'] in ('',invocation),props
  state['units'][unit]['after']=props;save()
 existing=subprocess.check_output(['docker','ps','-aq','--no-trunc','--filter','id='+container_id],text=True,timeout=30).strip()
 same_label=subprocess.check_output(['docker','ps','-aq','--filter','label=qwen38.task='+container],text=True,timeout=30).strip()
 assert not existing and not same_label,(existing,same_label)
 with open('/tmp/tt-device.lock','a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  Path('/tmp/tt-device.dirty').write_text('Task-owned container interrupted for performance priority; next runner resets under lock\n')
 state.update(state='launching_followers',owned_container_removed=True,cleanup_completed=True);save()
 old=json.loads((art/'bfp8-gdn-control-v2/launch.json').read_text())['command']
 command=[arg.replace('qwen38-bfp8-gdn-v2-20261009','qwen38-perf-priority-v1-20261009').replace('append:'+str(art/'bfp8-gdn-control-v2')+'/run.log','append:'+str(control)+'/perf.log') for arg in old]
 for flag,value in [('--source',str(source)),('--output',str(art/'perf-priority-v1')),('--manifest',str(control/'source-manifest.json')),('--after-unit','qwen38-perf-reorder-v1-20261009.service'),('--after-invocation',os.environ['INVOCATION_ID']),('--after-receipt',str(control/'release.json'))]:command[command.index(flag)+1]=value
 command=[arg.replace(str(art/'bfp8-gdn-source-v1'),str(source)) for arg in command]
 command+=['--after-clean-release','--profiles-first','--epilogue-first']
 (control/'perf-launch.json').write_text(json.dumps(dict(command=command,created_at=time.time()),indent=2)+'\n')
 subprocess.run(command,check=True,timeout=30)
 perf=properties('qwen38-perf-priority-v1-20261009.service');assert perf['MainPID']!='0' and perf['ActiveState']=='active',perf
 state['perf']=perf;save()
 # Requeue packaging behind perf/GPQA and reuse its task-owned compiled cache.
 oldroot=art/'image-hardware-control-v3';new=art/'image-hardware-control-v4';new.mkdir()
 text=(oldroot/'controller.py').read_text()
 assert 'cache = root / "cache"' in text and 'cache.mkdir()' in text
 text=text.replace('cache = root / "cache"','cache = Path('+repr(str(art/'image-hardware-v3/cache'))+')').replace('cache.mkdir()','cache.mkdir(exist_ok=True)')
 (new/'controller.py').write_text(text)
 shutil.copy2(oldroot/'openbench.py',new/'openbench.py')
 (new/'cleanup.py').write_text((oldroot/'cleanup.py').read_text().replace('qwen38-image-hardware-v3','qwen38-image-hardware-v4'))
 (new/'evaluation-command.json').write_text((oldroot/'evaluation-command.json').read_text().replace('image-hardware-control-v3','image-hardware-control-v4').replace('openbench-container-v3','openbench-container-v4'))
 command=json.loads((oldroot/'launch.json').read_text())['command']
 command=[arg.replace('image-hardware-control-v3','image-hardware-control-v4').replace('image-hardware-v3','image-hardware-v4') for arg in command]
 command=[arg.replace('RuntimeMaxSec=15h','RuntimeMaxSec=30h') for arg in command]
 for flag,value in [('--predecessor-unit','qwen38-perf-priority-v1-20261009.service'),('--predecessor-invocation',perf['InvocationID']),('--predecessor-receipt',str(art/'perf-priority-v1/queue.json'))]:command[command.index(flag)+1]=value
 # Retain the existing nine-hour predecessor wait; typical perf chain is shorter.
 (new/'launch.json').write_text(json.dumps(dict(command=command,created_at=time.time(),cache_reused=str(art/'image-hardware-v3/cache'),reason='performance_priority'),indent=2)+'\n')
 subprocess.run(command,check=True,timeout=30)
 state['container_follower']=properties('qwen38-image-hardware-v4-20261009.service')
 assert state['container_follower']['MainPID']!='0' and state['container_follower']['ActiveState']=='active'
 state.update(state='completed',finished_at=time.time());save()
except BaseException as error:
 state.update(state='failed',error=type(error).__name__,detail=str(error)[:3000]);save();raise
