"""Lossless archival of a closed historical trace, then bounded counter continuation."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

ART = Path('/home/ttuser/qwen38-artifacts-20261007')
TASK = Path('/home/ttuser/kimi-prefill.Ubx2wY/runtime/qwen38-27b-20261006')
CONTROL = ART / 'gdn-counter-space-recovery-v1'
SOURCE = ART / 'gdn-counter-source-v4'
OLD = ART / 'layer-profile-v5/tracy/.logs/tracy_ops_times.csv'
ARCHIVE = OLD.with_suffix(OLD.suffix + '.gz')
TEMP = ARCHIVE.with_suffix(ARCHIVE.suffix + '.partial')
STATUS = CONTROL / 'status.json'
state = dict(state='preflight', source=str(OLD), archive=str(ARCHIVE), reversible=True,
             restore_command=f'pigz -d -- {ARCHIVE}', native_installation_changed=False,
             started_at=time.time(), free_before_bytes=shutil.disk_usage(ART).free)


def save(**updates):
    state.update(updates, updated_at=time.time())
    temporary = STATUS.with_suffix('.tmp')
    temporary.write_text(json.dumps(state, indent=2) + '\n')
    temporary.replace(STATUS)
    print(json.dumps(updates), flush=True)


def fingerprint(path):
    st = path.stat()
    return (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns)


def no_users():
    result = subprocess.run(['/usr/bin/fuser', str(OLD)], capture_output=True, text=True, timeout=10)
    if result.returncode != 1 or result.stdout.strip() or result.stderr.strip():
        raise RuntimeError('Historical trace is still in use or fuser failed')


def digest(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        while block := stream.read(8 * 1024**2):
            result.update(block)
    return result.hexdigest()


def run():
    props = subprocess.run(['systemctl', '--user', 'show', 'qwen38-gdn-counter-v4-20261011.service',
                            '-p', 'MainPID', '-p', 'ActiveState'], capture_output=True, text=True,
                           check=True, timeout=15).stdout
    if 'MainPID=0' not in props or 'ActiveState=failed' not in props:
        raise RuntimeError('Counter predecessor is not authoritatively terminal')
    previous = json.loads((ART / 'gdn-counter-v4/pass-03/phase.json').read_text())
    if not previous.get('passed') or not previous.get('cleanup_completed'):
        raise RuntimeError('Previous device run did not close cleanly')
    historical = json.loads((ART / 'layer-profile-v5/profile.json').read_text())
    if historical.get('state') != 'completed' or historical.get('passed') is not True:
        raise RuntimeError('Historical trace is not from a completed device test')
    if OLD.is_symlink() or not OLD.is_file() or TEMP.exists() or ARCHIVE.exists():
        raise RuntimeError('Expected a unique regular unarchived historical trace')
    no_users()
    original = fingerprint(OLD)
    save(state='compressing', source_fingerprint=original, source_mode=OLD.stat().st_mode & 0o777,
         source_bytes=original[2], compression=['pigz', '-1', '-p', '2', '-c'])
    with TEMP.open('xb') as target:
        process = subprocess.Popen(['nice', '-n', '10', 'pigz', '-1', '-p', '2', '-c', str(OLD)], stdout=target)
        try:
            deadline = time.monotonic() + 1800
            while process.poll() is None:
                if time.monotonic() > deadline:
                    raise TimeoutError('Archival compression deadline')
                if TEMP.stat().st_size > 8 * 1024**3 or shutil.disk_usage(ART).free < 4 * 1024**3:
                    raise RuntimeError('Archive headroom guard reached; original is preserved')
                time.sleep(5)
            if process.returncode:
                raise RuntimeError('Lossless compression failed')
            target.flush()
            os.fsync(target.fileno())
        finally:
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=10)
    save(state='verifying_archive', archive_bytes=TEMP.stat().st_size)
    original_sha = digest(OLD)
    expanded_sha = hashlib.sha256()
    expanded_size = 0
    with gzip.open(TEMP, 'rb') as stream:
        while block := stream.read(8 * 1024**2):
            expanded_sha.update(block)
            expanded_size += len(block)
    if expanded_sha.hexdigest() != original_sha or expanded_size != original[2] or fingerprint(OLD) != original:
        raise RuntimeError('Archive did not reproduce the unchanged original')
    no_users()
    os.chmod(TEMP, state['source_mode'])
    os.utime(TEMP, ns=(OLD.stat().st_atime_ns, original[3]))
    TEMP.rename(ARCHIVE)
    save(state='verified_archive_ready', source_sha256=original_sha,
         archive_sha256=digest(ARCHIVE), full_decompression_verified=True)
    # All original bytes remain in the verified archive and can be restored with
    # the recorded command. Nothing outside this one closed profiling CSV changes.
    OLD.unlink()
    save(state='archived', free_after_bytes=shutil.disk_usage(ART).free)
    if shutil.disk_usage(ART).free < 32 * 1024**3:
        raise RuntimeError('Insufficient headroom for continuation; archive retained')

    sys.path.insert(0, str(SOURCE))
    from models.demos.qwen38_27b_qb2.tests.gdn_counter_profile import analyze_pass, compare_outputs, counter_names
    from models.demos.qwen38_27b_qb2.tests.gdn_phase_profile import required_markers
    from tracy import perf_counter_analysis
    current = ART / 'gdn-counter-v4/pass-03'
    suites = ET.parse(current / 'hardware.xml').getroot().findall('.//testsuite')
    if sum(int(s.get('tests', 0)) for s in suites) != 1 or any(int(s.get(k, 0)) for s in suites for k in ('failures','errors','skipped')):
        raise RuntimeError('Instruction test XML did not pass')
    compare_outputs(json.loads((ART / 'gdn-counter-v1/before/phase.json').read_text()), previous)
    if previous['counter_mask'] != 32:
        raise RuntimeError('Unexpected native instruction mask')
    required = required_markers(pipeline=True)
    markers = set()
    with (current / 'tracy/.logs/profile_log_device.csv').open() as stream:
        for line in stream:
            markers.update(label for label in required if label in line)
    if markers != required:
        raise RuntimeError('Instruction phase markers incomplete')
    header = TASK / 'metal/tt_metal/hw/inc/internal/tt-1xx/blackhole/hw_counters.h'
    analysis = analyze_pass(current, counter_names(header.read_text(), ['instrn']), perf_counter_analysis.COUNTER_TYPE_NAMES)
    (CONTROL / 'instruction-counters.json').write_text(json.dumps(analysis, indent=2) + '\n')
    save(state='instruction_analysis_recovered', instruction_hardware_rerun=False,
         instruction_exact_output_match=True, instruction_active_core_calls=analysis['active_core_calls'],
         original_failed_queue_sha256=digest(ART/'gdn-counter-v4/queue.json'))
    command = [str(TASK / 'python_env/bin/python3.10'), '-m',
               'models.demos.qwen38_27b_qb2.demo.run_gdn_counter_profile',
               '--task', str(TASK), '--source', str(SOURCE),
               '--weights', str(ART / 'checkpoint-pinned-1d4bf0f2'),
               '--output', str(ART / 'gdn-counter-v5'),
               '--manifest', str(ART / 'gdn-counter-control-v4/source-manifest.json'),
               '--baseline', str(ART / 'gdn-counter-v1/before'),
               '--groups', 'l1_0,l1_1,l1_2,l1_3,l1_4,l1_5']
    save(state='remaining_counter_passes', continuation_command=command,
         reset_requested=False, completed_groups=['fpu','pack','unpack','instrn'])
    with (CONTROL / 'counter-continuation.log').open('x') as log:
        subprocess.run(command, cwd=SOURCE, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=7200)
    save(state='completed', finished_at=time.time())


try:
    run()
except BaseException as error:
    save(state='failed', error=type(error).__name__, detail=str(error)[:2000])
    raise
