import base64
import subprocess
from pathlib import Path

repo = Path('/private/tmp/tt-metal-qwen38-long-context')
names = ['models/demos/qwen38_27b_qb2/'+name for name in (
    'tests/projection_sweep.py', 'tests/test_projection_sweep.py',
    'tests/unit/test_projection_sweep.py', 'demo/run_projection_sweep.py',
)]
payload = {name:base64.b64encode((repo/name).read_bytes()).decode() for name in names}
remote = r'''
import base64,hashlib,json,os,shutil,subprocess,time
from pathlib import Path
art=Path('/home/ttuser/qwen38-artifacts-20261007')
task=Path('/home/ttuser/kimi-prefill.Ubx2wY/runtime/qwen38-27b-20261006')
def props(unit):
 raw=subprocess.check_output(['systemctl','--user','show',unit,'-p','MainPID','-p','ActiveState','-p','LoadState','-p','Result','-p','InvocationID'],text=True,timeout=20)
 return dict(line.split('=',1) for line in raw.splitlines() if '=' in line)
def unit(stem):return 'qwen38-'+stem+'-20261010.service'
parent='compact-followup-v3'
parent_state=props(unit(parent))
assert parent_state['MainPID']!='0' and parent_state['ActiveState']=='active' and parent_state['InvocationID']=='28c688b7780445999483523a9cbc75fc'
followers={'projection-sweep-v5':'6f7c63955e144aa79693e4d8260cef7c','prefill-attention-v2':'258b685967ee458f84d0d0c809700fad','compact-long-horizon-v2':'474d01e736f645718edb4dc861d2fbc6'}
def pending(stem,inv):
 p=props(unit(stem));q=json.loads((art/stem/'queue.json').read_text())
 assert p['MainPID']!='0' and p['ActiveState']=='active' and p['InvocationID']==inv,(stem,p)
 assert q['state']=='waiting' and q['hardware_started'] is False,(stem,q)
 return dict(unit=p,queue=q)
audit={'before':{stem:pending(stem,inv) for stem,inv in followers.items()},'parent':parent_state,'after_stop':{}}
source,control,output=[art/n for n in ('projection-sweep-source-v2','projection-sweep-control-v6','projection-sweep-v6')]
assert not any(p.exists() for p in (source,control,output))
assert shutil.disk_usage(art).free>20*1024**3
shutil.copytree(art/'compact-long-horizon-source-v2',source,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache','.benchmarks','generated'))
control.mkdir()
for name,data in PAYLOAD.items():(source/name).write_bytes(base64.b64decode(data))
model=source/'models/demos/qwen38_27b_qb2'
original=json.loads((art/'compact-gdn-control-v3/source-manifest.json').read_text())
expected={n:d for n,d in original.items() if n.startswith(('models/demos/qwen38_27b_qb2/tt/','models/demos/qwen38_27b_qb2/config/'))}
actual={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for folder in ('tt','config') for p in (model/folder).rglob('*') if p.is_file() and p.suffix in ('.py','.cpp','.h','.hpp','.json')}
assert actual==expected
python=str(task/'python_env/bin/python')
env=dict(os.environ,TT_METAL_HOME=str(task/'metal'),LD_LIBRARY_PATH=f'{task}/metal-install/lib:{task}/metal-build/lib',PYTHONPATH=f'{source}:{task}/metal:{task}/metal/tools',ARCH_NAME='blackhole',OMP_NUM_THREADS='1',TT_METAL_INSPECTOR_RPC='0')
for key in ('TT_METAL_SIMULATOR','TT_METAL_DISABLE_SFPLOADMACRO','TT_METAL_SLOW_DISPATCH_MODE','QWEN_PREFILL_BATCHED_ATTENTION'):env.pop(key,None)
with (control/'preflight.log').open('w') as log:
 subprocess.run([python,'-m','pytest',str(model/'tests/unit'),'-c',str(source/'pytest.ini'),f'--rootdir={source}','-o','addopts=','-q',f'--junitxml={control}/unit.xml'],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
 subprocess.run([python,'-m','pytest',str(model/'tests/test_projection_sweep.py'),'--collect-only','-q','-c',str(source/'pytest.ini'),f'--rootdir={source}','-o','addopts='],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
print((control/'preflight.log').read_text()[-1400:],flush=True)
files=[source/n for n in ('conftest.py','pytest.ini','scripts/run_safe_pytest.sh')]
files.extend(p for p in model.rglob('*') if p.suffix in ('.py','.cpp','.h','.hpp','.json'))
manifest={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(control/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for stem in reversed(list(followers)):
 pending(stem,followers[stem])
 subprocess.run(['systemctl','--user','stop',unit(stem)],check=True,timeout=210)
 p=props(unit(stem));q=json.loads((art/stem/'queue.json').read_text())
 assert p['MainPID']=='0' and p['ActiveState'] in ('inactive','failed') and q['hardware_started'] is False
 audit['after_stop'][stem]=dict(unit=p,queue=q)
 (control/'requeue-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
launch=json.loads((art/'projection-sweep-control-v5/launch.json').read_text())
command=[s.replace('--unit=qwen38-projection-sweep-v5-20261010','--unit=qwen38-projection-sweep-v6-20261010').replace(str(art/'projection-sweep-control-v5/run.log'),str(control/'run.log')) for s in launch['command']]
for name,value in [('--source',str(source)),('--output',str(output)),('--manifest',str(control/'source-manifest.json'))]:command[command.index(name)+1]=value
command=[f'--working-directory={source}' if s.startswith('--working-directory=') else f'--setenv=PYTHONPATH={source}' if s.startswith('--setenv=PYTHONPATH=') else s for s in command]
launch.update(command=command,created_at=time.time(),source_parent='0b651abce7e',changed_files=list(PAYLOAD),source_manifest_sha256=hashlib.sha256((control/'source-manifest.json').read_bytes()).hexdigest(),frozen_source_unchanged=False,model_matches_compact_v3=True,physical_cases=66,expected_physical_minutes=[15,45],expected_incremental_model_saving_ms=[1.5,3.5],expected_gain_is_estimate=True,reason='Measure compact-L1 output projection as well as expanded-DRAM output and compact MLP down, each with matched controls')
(control/'launch.json').write_text(json.dumps(launch,indent=2)+'\n')
subprocess.run(command,check=True,timeout=30)
active=props(unit('projection-sweep-v6'));assert active['MainPID']!='0' and active['ActiveState']=='active'
(control/'launch-unit.json').write_text(json.dumps(active,indent=2)+'\n');print('projection',active,flush=True)
def follower(old,new,parent,inv):
 def control_path(stem):
  base,version=stem.rsplit('-v',1);return art/(base+'-control-v'+version)
 oldc=control_path(old);newc=control_path(new);assert not newc.exists() and not (art/new).exists();newc.mkdir()
 previous=json.loads((oldc/'launch.json').read_text())
 cmd=[s.replace('--unit=qwen38-'+old+'-20261010','--unit=qwen38-'+new+'-20261010').replace(str(oldc/'run.log'),str(newc/'run.log')) for s in previous['command']]
 for name,value in [('--output',str(art/new)),('--after-unit',unit(parent)),('--after-invocation',inv),('--after-receipt',str(art/parent/'queue.json'))]:cmd[cmd.index(name)+1]=value
 previous.update(command=cmd,created_at=time.time(),reason='Rewire waiting follower behind layout-matched projection sweep',frozen_source_unchanged=True)
 (newc/'launch.json').write_text(json.dumps(previous,indent=2)+'\n');subprocess.run(cmd,check=True,timeout=30)
 state=props(unit(new));assert state['MainPID']!='0' and state['ActiveState']=='active'
 (newc/'launch-unit.json').write_text(json.dumps(state,indent=2)+'\n');print(new,state,flush=True);return state
pstate=follower('prefill-attention-v2','prefill-attention-v3','projection-sweep-v6',active['InvocationID'])
follower('compact-long-horizon-v2','compact-long-horizon-v3','prefill-attention-v3',pstate['InvocationID'])
'''
subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','IdentityAgent=none','-o','IdentitiesOnly=yes','-i','/Users/anatarajan/.ssh/id_ed25519','ttuser@10.228.203.98','python3 -'],input='PAYLOAD='+repr(payload)+'\n'+remote,text=True,check=True,timeout=900)
