# Qwen long-context layer profile

Warm eager two-layer diagnostic with real weights and synthetic populated caches; not natural prompt activations, model accuracy, traced TPOT or a complete P0 pass.

Durations remain separate per device. Inclusive stages overlap; exclusive stages partition each device total. Firmware sums may include overlapping execution. Per-RISC durations include waits and alone cannot establish a bandwidth or compute bottleneck. Absent compute timings are marked not applicable only when source/hash lists are empty and all compute binary sizes are zero; they are not zero-time measurements. Device-op rows are not program counts.

All device timings present: True. Full P0 gate: still pending.

| Input tokens | Batch | Device | Device-op rows | Sum firmware (ms) | Sum kernel (ms) |
|---:|---:|---:|---:|---:|---:|
| 32768 | 16 | 0 | 161 | 4.141 | 2.827 |
| 32768 | 16 | 4 | 161 | 4.130 | 2.814 |
| 32768 | 16 | 8 | 161 | 4.175 | 2.836 |
| 32768 | 16 | 12 | 161 | 4.125 | 2.821 |

## Most expensive device ops per geometry

### Input 32768, batch 16, device 8

Device with the largest firmware-duration sum; other ranks remain in the CSV/JSON.

| Exclusive stage | Op | Calls | Sum firmware (ms) | Sum kernel (ms) |
|---|---|---:|---:|---:|
| P0_S32768_B16_L3_paged_decode | SdpaDecodeDeviceOperation | 1 | 0.790 | 0.789 |
| P0_S32768_B16_L3_paged_decode | SliceDeviceOperation | 1 | 0.742 | 0.002 |
| P0_S32768_B16_MODEL | MatmulDeviceOperation | 4 | 0.507 | 0.494 |
| P0_S32768_B16_MODEL | ShardedToInterleavedDeviceOperation | 4 | 0.372 | 0.016 |
| P0_S32768_B16_L0__delta_recurrence | ChunkGdnPrepOperation | 2 | 0.157 | 0.156 |
| P0_S32768_B16_L0__delta_recurrence | SliceDeviceOperation | 12 | 0.142 | 0.108 |
| P0_S32768_B16_L0__delta_recurrence | ChunkGdnScanOperation | 2 | 0.118 | 0.117 |
| P0_S32768_B16_L0__delta_recurrence | ConcatDeviceOperation | 2 | 0.103 | 0.081 |
| P0_S32768_B16_L0__delta_recurrence | CopyDeviceOperation | 1 | 0.098 | 0.066 |
| P0_S32768_B16_L0_packed_decode_conv | TilizeWithValPaddingDeviceOperation | 3 | 0.076 | 0.073 |
| P0_S32768_B16_L3__linear_mlp_gate_up | MatmulDeviceOperation | 1 | 0.063 | 0.063 |
| P0_S32768_B16_L0__linear_mlp_gate_up | MatmulDeviceOperation | 1 | 0.063 | 0.063 |
| P0_S32768_B16_L0__delta_recurrence | ReshapeViewDeviceOperation | 8 | 0.055 | 0.049 |
| P0_S32768_B16_L3__rope_decode | ReshapeViewDeviceOperation | 4 | 0.041 | 0.039 |
| P0_S32768_B16_L0__linear_linear_attn_packed | MatmulDeviceOperation | 1 | 0.038 | 0.037 |
| P0_S32768_B16_L3__linear_mlp_down_proj | MatmulDeviceOperation | 1 | 0.036 | 0.036 |
| P0_S32768_B16_L0__linear_mlp_down_proj | MatmulDeviceOperation | 1 | 0.036 | 0.036 |
| P0_S32768_B16_L0__delta | FillPadDeviceOperation | 3 | 0.034 | 0.032 |
| P0_S32768_B16_L0__delta | SigmoidGatedRmsNormOperation | 1 | 0.033 | 0.033 |
| P0_S32768_B16_L0__delta | SliceDeviceOperation | 5 | 0.031 | 0.027 |

