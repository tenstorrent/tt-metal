// SPDX-FileCopyrightText: © 2023 Tenstorrent USA, Inc.
//
// SPDX-License-Identifier: Apache-2.0

#include "rtoptions.hpp"
#include "llrt/hal.hpp"  // Hal — needed for ParseAllFeatureEnv, ParseFeatureEnv, ParseFeatureRiscvMask

#include <algorithm>
#include <bit>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <limits>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_set>
#include <enchantum/enchantum.hpp>
#include <tt_stl/assert.hpp>
#include <tt-logger/tt-logger.hpp>
#include <umd/device/types/core_coordinates.hpp>
#include <experimental/fabric/control_plane.hpp>
#include <tt-metalium/kernel_types.hpp>
#include <system_mesh.hpp>

// NOLINTBEGIN(bugprone-branch-clone)

using std::vector;

namespace tt::llrt {

const char* RunTimeDebugFeatureNames[RunTimeDebugFeatureCount] = {
    "DPRINT",
    "READ_DEBUG_DELAY",
    "WRITE_DEBUG_DELAY",
    "ATOMIC_DEBUG_DELAY",
    "ENABLE_L1_DATA_CACHE",
};

const char* RunTimeDebugClassNames[RunTimeDebugClassCount] = {"N/A", "worker", "dispatch", "all"};

// ============================================================================
// ENVIRONMENT VARIABLE IDs
// ============================================================================
// Full definition of EnvVarID enum (forward-declared in rtoptions.hpp)
enum class EnvVarID {
    // ========================================
    // PATH CONFIGURATION
    // ========================================

    TT_METAL_CACHE,                           // Cache directory for compiled kernels
    TT_METAL_KERNEL_PATH,                     // Path to kernel source files
    TT_METAL_LOGS_PATH,                       // Path for generated logs and debug output
    TT_METAL_SIMULATOR,                       // Path to simulator executable
    TT_METAL_MOCK_CLUSTER_DESC_PATH,          // Mock cluster descriptor path
    TT_METAL_EMULE_MODE,                      // Enable emulated mode (SWEmuleChip with real memory I/O)
    TT_METAL_VISIBLE_DEVICES,                 // Comma-separated list of visible device IDs
    ARCH_NAME,                                // Architecture name (simulation mode)
    QUASAR_ARCH_VARIANT,                      // Quasar IP variant (LLK arch/<variant> directory)
    TT_MESH_GRAPH_DESC_PATH,                  // Custom fabric mesh graph descriptor
    TT_METAL_FACTORY_SYSTEM_DESCRIPTOR_PATH,  // Factory System Descriptor (FSD) path
    TT_METAL_CORE_GRID_OVERRIDE_TODEPRECATE,  // Core grid override

    // ========================================
    // KERNEL EXECUTION CONTROL
    // ========================================
    TT_METAL_CHECKPOINT,            // Enable debug checkpoints
    TT_METAL_NULL_KERNELS,          // Skip kernel execution (testing)
    TT_METAL_KERNELS_EARLY_RETURN,  // Kernels return early

    // ========================================
    // MEMORY INITIALIZATION
    // ========================================
    TT_METAL_CLEAR_L1,    // Clear L1 memory on device init
    TT_METAL_CLEAR_DRAM,  // Clear DRAM on device init

    // ========================================
    // HOST MEMORY
    // ========================================
    TT_METAL_PINNED_MEMORY_CACHE_LIMIT_BYTES,  // Maximum cached pinned host memory

    // ========================================
    // DEBUG & TESTING
    // ========================================
    TT_METAL_WATCHER_TEST_MODE,         // Enable watcher test mode
    TT_METAL_KERNEL_MAP,                // Enable kernel build mapping
    TT_METAL_DISPATCH_DATA_COLLECTION,  // Enable dispatch debug data collection
    TT_METAL_GTEST_ETH_DISPATCH,        // Use Ethernet cores for dispatch in tests
    TT_METAL_TENSIX_DISPATCH_CORES,     // Quasar: force interim Tensix dispatch cores from core descriptor YAML
    TT_METAL_SKIP_LOADING_FW,           // Skip firmware loading
    TT_METAL_DISABLE_XIP_DUMP,          // Disable XIP dump

    // ========================================
    // HARDWARE CONFIGURATION
    // ========================================
    TT_METAL_ENABLE_HW_CACHE_INVALIDATION,              // Enable HW cache invalidation
    TT_METAL_DISABLE_RELAXED_MEM_ORDERING,              // Disable relaxed memory ordering
    TT_METAL_ENABLE_GATHERING,                          // Enable instruction gathering
    TT_METAL_FABRIC_BW_TELEMETRY,                       // Enable fabric bandwidth telemetry
    TT_METAL_FABRIC_TELEMETRY,                          // Enable fabric telemetry
    TT_FABRIC_PROFILE_RX_CH_FWD,                        // Enable fabric RX channel forwarding profiling
    TT_METAL_ENABLE_CHANNEL_TRIMMING_CAPTURE,           // Enable channel trimming resource usage capture
    TT_METAL_FABRIC_TRIMMING_PROFILE,                   // Path to channel trimming profile YAML for import
    TT_METAL_FABRIC_TRIMMING_OVERRIDE,                  // Path to channel trimming global override YAML
    TT_METAL_ENABLE_FABRIC_VC2,                         // Enable fabric VC2 (neighbour exchange)
    TT_METAL_ENABLE_FABRIC_MESH_PASS_THROUGH,           // Enable experimental VC1 inter-mesh pass-through
    TT_METAL_FORCE_REINIT,                              // Force context reinitialization
    TT_METAL_DISABLE_FABRIC_TWO_ERISC,                  // Disable fabric 2-ERISC mode
    TT_METAL_LOG_KERNELS_COMPILE_COMMANDS,              // Log kernel compilation commands
    TT_METAL_SLOW_DISPATCH_MODE,                        // Use slow dispatch mode
    TT_METAL_SKIP_ETH_CORES_WITH_RETRAIN,               // Skip Ethernet cores during retrain
    TT_METAL_VALIDATE_PROGRAM_BINARIES,                 // Validate kernel binary integrity
    TT_METAL_DISABLE_DMA_OPS,                           // Disable DMA operations
    RELIABILITY_MODE,                                   // Fabric reliability mode (strict/relaxed)
    TT_METAL_DISABLE_MULTI_AERISC,                      // Disable multi-erisc mode (inverted logic, enabled by default)
    TT_METAL_USE_MGD_2_0,                               // Use mesh graph descriptor 2.0
    TT_METAL_FORCE_JIT_COMPILE,                         // Force JIT compilation
    TT_METAL_DISABLE_SFPLOADMACRO,                      // Disable use of SFPLOADMACRO instructions
    TT_METAL_DRAM_BACKED_CQ,                            // Store command queues in device DRAM
    TT_METAL_SIMULATOR_DIRECT_TENSOR_WRITES,            // Simulator tensor preload bypasses FD CQ copies
    TT_METAL_QUASAR_NOC_API_VERSION,                    // Quasar NOC API version
    TT_METAL_ENABLE_BLACKHOLE_DRAM_PROGRAMMABLE_CORES,  // Override Blackhole DRAM programmable cores
    TT_METAL_MEASURE_DFB_INIT_TIME,  // Temporary DFB init rdcycle instrumentation (deprecate once device profiler
                                     // covers this).
    TT_METAL_TDP_LIMIT_WATTS,        // Firmware throttler TDP limit [W] (Blackhole)

    // ========================================
    // PROFILING & PERFORMANCE
    // ========================================
    TT_METAL_DEVICE_PROFILER,                      // Enable device profiling
    TT_METAL_STREAMING_PROFILER,                   // Enable the streaming device profiler (excludes the DRAM one)
    TT_METAL_STREAMING_PROFILER_TRACY,             // Enable Tracy output for the streaming profiler
    TT_METAL_STREAMING_PROFILER_SYNC_EVENTS,       // Enable sync events profiling
    TT_METAL_STREAMING_PROFILER_INLINE_ENABLED,    // Enable zone markers inlining
    TT_METAL_STREAMING_PROFILER_DRAM_MB,           // Streaming profiler per-relay GDDR spool ring, MiB
    TT_METAL_STREAMING_PROFILER_FIFO_MB,           // Streaming profiler host FIFO per D2H socket, MiB
    TT_METAL_STREAMING_PROFILER_OPS_CSV,           // Streaming profiler ops CSV path
    TT_METAL_STREAMING_PROFILER_ZONE_CSV,          // Streaming profiler zone CSV path
    TT_METAL_DEVICE_PROFILER_DISPATCH,             // Enable dispatch core profiling
    TT_METAL_PROFILER_SYNC,                        // Enable synchronous profiling
    TT_METAL_DEVICE_PROFILER_NOC_EVENTS,           // Enable NoC events profiling
    TT_METAL_DEVICE_PROFILER_NOC_EVENTS_RPT_PATH,  // NoC events report path
    TT_METAL_PROFILE_PERF_COUNTERS,                // Enable Performance Counter profiling
    TT_METAL_MEM_PROFILER,                         // Enable memory/buffer profiling
    TT_METAL_TRACE_PROFILER,                       // Enable trace profiling
    TT_METAL_PROFILER_TRACE_TRACKING,              // Enable trace tracking
    TT_METAL_PROFILER_MID_RUN_DUMP,                // Force mid-run profiler dumps
    TT_METAL_PROFILER_CPP_POST_PROCESS,            // Enable C++ post-processing for profiler
    TT_METAL_PROFILER_SUM,                         // Enable sum profiling
    TT_METAL_PROFILER_ACCUMULATE,                  // Accumulate multiple kernels in L1 before DRAM push
    TT_METAL_PROFILER_PROGRAM_SUPPORT_COUNT,       // Maximum number of programs supported by the profiler
    TT_METAL_TRACY_MID_RUN_PUSH,                   // Force Tracy mid-run pushes
    TT_METAL_PROFILER_DISABLE_DUMP_TO_FILES,       // Disable dumping collected device data to files
    TT_METAL_PROFILER_DISABLE_PUSH_TO_TRACY,       // Disable pushing collected device data to Tracy GUI
    TT_METAL_GTEST_NUM_HW_CQS,                     // Number of HW command queues in tests
    TT_METAL_ARC_DEBUG_BUFFER_SIZE,                // ARC processor debug buffer size
    TT_METAL_OPERATION_TIMEOUT_SECONDS,            // Operation timeout duration
    TT_METAL_DISPATCH_TIMEOUT_COMMAND_TO_EXECUTE,  // Terminal command to execute on dispatch timeout.
    TT_METAL_NOC_DEBUG_DUMP,                       // Enable experimental NOC debug dump to detect missing barriers
    TT_METAL_NOC_DEBUG_POLL_INTERVAL_MS,           // NOC debug dump: background poll period (ms)
    TT_METAL_NOC_DEBUG_FULL_READ_INTERVAL_MS,      // NOC debug dump: period between self-triggered full reads (ms)
    TT_METAL_NOC_DEBUG_WATERMARK_MARGIN_MS,        // NOC debug dump: mid-run watermark margin (ms)
    TT_METAL_DISPATCH_PROGRESS_UPDATE_MS,          // Dispatch kernel progress update period in milliseconds
    TT_METAL_DISPATCH_TELEMETRY_DISABLE,           // Dispatch telemetry

    // ========================================
    // WATCHER SYSTEM
    // ========================================
    TT_METAL_WATCHER,                                         // Enable watcher system
    TT_METAL_WATCHER_DUMP_ALL,                                // Dump all watcher data
    TT_METAL_WATCHER_APPEND,                                  // Append mode for watcher output
    TT_METAL_WATCHER_NOINLINE,                                // Disable watcher function inlining
    TT_METAL_WATCHER_PHYS_COORDS,                             // Use physical coordinates in watcher
    TT_METAL_WATCHER_TEXT_START,                              // Include text start info in watcher
    TT_METAL_WATCHER_SKIP_LOGGING,                            // Disable watcher logging
    TT_METAL_WATCHER_DISABLE_ASSERT,                          // Disable watcher assert feature
    TT_METAL_WATCHER_DISABLE_PAUSE,                           // Disable watcher pause feature
    TT_METAL_WATCHER_DISABLE_RING_BUFFER,                     // Disable watcher ring buffer
    TT_METAL_WATCHER_DISABLE_STACK_USAGE,                     // Disable watcher stack usage tracking
    TT_METAL_WATCHER_DISABLE_SANITIZE_NOC,                    // Disable watcher NoC sanitization
    TT_METAL_WATCHER_DISABLE_SANITIZE_READ_ONLY_L1,           // Disable read-only L1 sanitization
    TT_METAL_WATCHER_DISABLE_SANITIZE_WRITE_ONLY_L1,          // Disable write-only L1 sanitization
    TT_METAL_WATCHER_DISABLE_WAYPOINT,                        // Disable watcher waypoint feature
    TT_METAL_WATCHER_DISABLE_DISPATCH,                        // Disable watcher dispatch feature
    TT_METAL_WATCHER_DISABLE_ETH,                             // Disable watcher on ethernet cores
    TT_METAL_WATCHER_DISABLE_CB_SANITIZE,                     // Disable watcher circular buffer sanitization
    TT_METAL_WATCHER_ENABLE_NOC_SANITIZE_LINKED_TRANSACTION,  // Enable NoC linked transaction sanitization

    // ========================================
    // INSPECTOR
    // ========================================
    TT_METAL_INSPECTOR,                                // Enable/disable inspector
    TT_METAL_INSPECTOR_INITIALIZATION_IS_IMPORTANT,    // Track initialization closely
    TT_METAL_INSPECTOR_WARN_ON_WRITE_EXCEPTIONS,       // Warn on write exceptions
    TT_METAL_RISCV_DEBUG_INFO,                         // Enable RISC-V debug info
    TT_METAL_JIT_ANALYTICS,                            // Enable JIT analytics
    TT_METAL_INSPECTOR_RPC_SERVER_ADDRESS,             // Inspector RPC server address (host:port)
    TT_METAL_INSPECTOR_RPC,                            // Enable/disable inspector RPC server
    TT_METAL_INSPECTOR_SERIALIZE_ON_DISPATCH_TIMEOUT,  // Serialize inspector data on dispatch timeout
    TT_METAL_INSPECTOR_CAPTURE_TENSOR_SPECS,           // Capture tensor specs on op dispatch (default: off)
    TT_METAL_INSPECTOR_LOG_RUNTIME_ENTRIES,            // Log runtime entries to YAML (expensive, off by default)
    TT_METAL_INSPECTOR_LOG_MESH_BUFFERS,               // Log mesh buffer lifecycle to YAML (expensive, off by default)
    TT_METAL_INSPECTOR_LOG_MESH_SOCKETS,               // Log mesh socket lifecycle to YAML (off by default)

    // ========================================
    // DEBUG PRINTING (DPRINT)
    // ========================================
    TT_METAL_DPRINT_CORES,                          // Worker cores for debug printing
    TT_METAL_DPRINT_ETH_CORES,                      // Ethernet cores for debug printing
    TT_METAL_DPRINT_DRAM_CORES,                     // DRAM cores for debug printing
    TT_METAL_DPRINT_DISPATCH_CORES,                 // Quasar dispatch-engine cores for debug printing
    TT_METAL_DPRINT_CHIPS,                          // Chip IDs for debug printing
    TT_METAL_DPRINT_NODES,                          // Fabric node IDs for debug printing
    TT_METAL_DPRINT_MESH_COORDS,                    // Global system mesh (row,col) coordinates for debug printing
    TT_METAL_DPRINT_RISCVS,                         // RISC-V processors for debug printing
    TT_METAL_DPRINT_FILE,                           // Debug print output file
    TT_METAL_DPRINT_ONE_FILE_PER_RISC,              // Separate file per RISC-V processor
    TT_METAL_DPRINT_PREPEND_DEVICE_CORE_RISC,       // Prepend device/core/RISC info
    TT_METAL_DEVICE_PRINT_DISPATCH_STALL_US,        // dispatch_s DevicePrintDispatch stall-detection period (us)
    TT_METAL_DEVICE_PRINT_DISPATCH_FULL_US,         // dispatch_s DevicePrintDispatch full-dispatch period (us)
    TT_METAL_DEVICE_PRINT_DISPATCH_L1_CACHE_BYTES,  // dispatch_s DevicePrintDispatch L1 cache size override (bytes)

    // ========================================
    // LIGHTWEIGHT KERNEL DEBUGGING
    // ========================================
    TT_METAL_LIGHTWEIGHT_KERNEL_ASSERTS,  // Enable lightweight kernel asserts

    // ========================================
    // LLK ASSERTIONS
    // ========================================
    TT_METAL_LLK_ASSERTS,  // Enable LLK assertions

    // ========================================
    // LLK SANITIZER
    // For detailed description look at tt-llk/sanitizer/settings.h
    // ========================================
    TT_METAL_LLK_SANITIZER,  // Enable LLK sanitizer (master switch)
    TT_METAL_LLK_SANITIZER_PEDANTIC,
    TT_METAL_LLK_SANITIZER_WARN,
    TT_METAL_LLK_SANITIZER_ERROR,
    TT_METAL_LLK_SANITIZER_INFO,
    TT_METAL_LLK_SANITIZER_FAULT,
    TT_METAL_LLK_SANITIZER_INTERNAL,

    // ========================================
    // DEVICE MANAGER
    // ========================================
    TT_METAL_NUMA_BASED_AFFINITY,

    // ========================================
    // FABRIC CONFIGURATION
    // ========================================
    TT_METAL_FABRIC_ROUTER_SYNC_TIMEOUT_MS,  // Timeout for fabric router sync in milliseconds
    TT_METAL_FABRIC_OPT_LEVEL,               // Override fabric kernel compiler optimization level
    TT_TOPOLOGY_SOLVER_ENGINE,               // sat|dfs: topology mapping backend (fabric)

    // ========================================
    // JIT BUILD CONFIGURATION
    // ========================================
    TT_METAL_DISABLE_PRECOMPILED_FW,  // Disable use of pre-compiled firmware
    TT_METAL_FW_SRC_BRISC,            // BRISC firmware feature variant to JIT-build
    TT_METAL_FW_HEADER_BRISC,         // Header supplied by the selected BRISC firmware variant
    TT_METAL_BACKEND_DUMP_RUN_CMD,    // Dump JIT build commands to stdout

    // ========================================
    // ALLOCATOR CONFIGURATION
    // ========================================
    TT_METAL_ALLOCATOR_MODE_HYBRID,           // Enable hybrid lockstep + per-core L1 allocator mode
    TT_METAL_TRACE_ALLOC_TRACKING,            // Enable per-trace unsafe allocation accounting
    TT_METAL_TRACE_ALLOC_TRACEBACKS,          // Capture diagnostics for unsafe trace allocations
    TT_METAL_TRACE_ALLOC_SKIP_PROGRAM_CACHE,  // Exclude program-cache buffers from trace accounting

    // ========================================
    // SHM TRACKING
    // ========================================
    TT_METAL_SHM_TRACKING_DISABLED,  // Disable shared memory tracking for tt-smi
    TT_METAL_SHM_VERBOSE,            // Enable verbose logging for SHM tracking
};

// Environment variable name for TT-Metal root directory
constexpr auto TT_METAL_RUNTIME_ROOT_ENV_VAR = "TT_METAL_RUNTIME_ROOT";

namespace {
// Helper function to normalize directory paths using std::filesystem
std::string normalize_path(const char* path, const std::string& subdir = "") {
    std::filesystem::path p(path);
    if (!subdir.empty()) {
        p /= subdir;
    }
    return p.lexically_normal().string();
}

// Helper function to check if environment variable value is "1" (enabled)
bool is_env_enabled(const char* value) { return value && value[0] == '1'; }

std::string trim_copy(const std::string& input) {
    auto first = std::find_if_not(input.begin(), input.end(), [](unsigned char ch) { return std::isspace(ch); });
    if (first == input.end()) {
        return "";
    }
    auto last =
        std::find_if_not(input.rbegin(), input.rend(), [](unsigned char ch) { return std::isspace(ch); }).base();
    return std::string(first, last);
}

std::string to_lower_copy(std::string value) {
    std::transform(value.begin(), value.end(), value.begin(), [](unsigned char ch) { return std::tolower(ch); });
    return value;
}

std::string to_upper_copy(std::string value) {
    std::transform(value.begin(), value.end(), value.begin(), [](unsigned char ch) { return std::toupper(ch); });
    return value;
}

template <typename IntType>
IntType parse_int_token(const std::string& token, const std::string& context) {
    try {
        long long parsed = std::stoll(token, nullptr, 0);
        return static_cast<IntType>(parsed);
    } catch (const std::invalid_argument&) {
        TT_THROW("Invalid token '{}' while parsing {}", token, context);
    } catch (const std::out_of_range&) {
        TT_THROW("Out-of-range token '{}' while parsing {}", token, context);
    }
}

bool equals_all(const std::string& token) { return to_lower_copy(trim_copy(token)) == "all"; }

}  // namespace

RunTimeOptions::RunTimeOptions() : system_kernel_dir("/usr/share/tenstorrent/kernels/") {
    // TTNN may need these process-wide options while its Python module is being initialized, before a MetalContext
    // (and therefore a RunTimeOptions instance) exists. It reads the same lazy snapshot through a native binding.
    // Touch it here as well to guarantee that it is initialized no later than RunTimeOptions construction.
    (void)get_trace_allocation_options();

// Default assume package install path
#ifdef TT_METAL_INSTALL_ROOT
    if (std::filesystem::is_directory(std::filesystem::path(TT_METAL_INSTALL_ROOT))) {
        this->root_dir = std::filesystem::path(TT_METAL_INSTALL_ROOT).string();
    }
    log_debug(tt::LogMetal, "initial root_dir: {}", this->root_dir);
#endif

    // ENV Can Override
    const char* root_dir_str = std::getenv(TT_METAL_RUNTIME_ROOT_ENV_VAR);
    if (root_dir_str != nullptr) {
        this->root_dir = std::string(root_dir_str);
        log_debug(tt::LogMetal, "ENV override root_dir: {}", this->root_dir);
    } else if (!g_root_dir.empty()) {
        this->root_dir = g_root_dir;
        log_debug(tt::LogMetal, "API override root_dir: {}", this->root_dir);
    } else if (this->root_dir.empty()) {
        // If the current working directory contains a "tt_metal/" directory,
        // treat the current working directory as the repository root.
        std::filesystem::path current_working_directory = std::filesystem::current_path();
        std::filesystem::path tt_metal_subdirectory = current_working_directory / "tt_metal";
        if (std::filesystem::is_directory(tt_metal_subdirectory)) {
            this->root_dir = current_working_directory.string();
            log_debug(tt::LogMetal, "current working directory fallback root_dir: {}", this->root_dir);
        }
    }

    if (this->root_dir.empty()) {
        log_critical(
            tt::LogMetal,
            "Failed to determine TT-Metal root directory. "
            "Root directory must be set via one of the following methods:\n"
            "1. Automatically determined when using a package install\n"
            "2. Set TT_METAL_RUNTIME_ROOT environment variable to the path containing tt_metal/\n"
            "3. Call RunTimeOptions::set_root_dir() API before creating RunTimeOptions\n"
            "4. Run from the root of the repository\n"
            "Current working directory: {}",
            std::filesystem::current_path().string());
    }

    TT_FATAL(!this->root_dir.empty(), "Root Directory is not set.");

    {
        std::filesystem::path p(root_dir);
        p /= "";  // ensures trailing slash, never duplicates
        this->root_dir = p.string();
    }

    InitializeFromEnvVars();

    // Mock devices mirror real silicon of the same architecture: leave the 2-erisc default (and any
    // TT_METAL_DISABLE_MULTI_AERISC override) intact so that HAL construction and kernel compilation match
    // what a real device would produce. Architecture gating still happens downstream (only Blackhole's HAL
    // acts on the flag). The simulator and emule backends cannot model dual-erisc, so force it off for them.
    if (this->runtime_target_device_ == tt::TargetDevice::Simulator ||
        this->runtime_target_device_ == tt::TargetDevice::Emule) {
        log_info(tt::LogMetal, "Disabling multi-erisc mode with simulator/emule target device");
        this->enable_2_erisc_mode = false;
    }

    TT_FATAL(
        !(get_feature_enabled(RunTimeDebugFeatureDprint) && get_profiler_enabled()),
        "Cannot enable both debug printing and profiling");
    // The DRAM (TT_METAL_DEVICE_PROFILER) and streaming (TT_METAL_STREAMING_PROFILER) device profilers are
    // mutually exclusive modes: their device producers overlay the same L1 profiler region with different
    // layouts, and their hosts would both drive it. Refuse here, at MetalContext construction, before any
    // device is opened or any kernel is compiled.
    TT_FATAL(
        !(get_profiler_enabled() && get_streaming_profiler_enabled()),
        "TT_METAL_DEVICE_PROFILER and TT_METAL_STREAMING_PROFILER are mutually exclusive: set exactly one of "
        "them (DRAM profiler vs streaming profiler).");
    TT_FATAL(
        !(get_feature_enabled(RunTimeDebugFeatureDprint) && get_streaming_profiler_enabled()),
        "Cannot enable both debug printing and the streaming profiler");
}

const RunTimeOptions::TraceAllocationOptions& RunTimeOptions::get_trace_allocation_options() {
    // Unlike ordinary RunTimeOptions fields, these options may be queried by TTNN before MetalContext creates a
    // RunTimeOptions instance. Keep their parsing owned by RunTimeOptions, but cache all related values in one
    // process-wide snapshot so TTNN and Metal cannot observe different settings.
    static const TraceAllocationOptions options = [] {
        const bool tracking_enabled = is_env_enabled(std::getenv("TT_METAL_TRACE_ALLOC_TRACKING"));
        return TraceAllocationOptions{
            .tracking_enabled = tracking_enabled,
            .diagnostics_enabled = tracking_enabled && is_env_enabled(std::getenv("TT_METAL_TRACE_ALLOC_TRACEBACKS")),
            .skip_program_cache =
                tracking_enabled && is_env_enabled(std::getenv("TT_METAL_TRACE_ALLOC_SKIP_PROGRAM_CACHE")),
        };
    }();
    return options;
}

bool RunTimeOptions::get_trace_allocation_tracking_enabled() { return get_trace_allocation_options().tracking_enabled; }

bool RunTimeOptions::get_trace_allocation_diagnostics_enabled() {
    return get_trace_allocation_options().diagnostics_enabled;
}

bool RunTimeOptions::get_trace_allocation_skip_program_cache_enabled() {
    return get_trace_allocation_options().skip_program_cache;
}

void RunTimeOptions::set_root_dir(const std::string& root_dir) {
    std::call_once(g_root_once, [&] { g_root_dir = root_dir; });
}

const std::string& RunTimeOptions::get_root_dir() const { return root_dir; }

const std::string& RunTimeOptions::get_cache_dir() const {
    if (!this->is_cache_dir_specified()) {
        TT_THROW("Env var {} is not set.", "TT_METAL_CACHE");
    }
    return this->cache_dir_;
}

const std::string& RunTimeOptions::get_logs_dir() const { return logs_dir_; }

const std::string& RunTimeOptions::get_kernel_dir() const {
    if (!this->is_kernel_dir_specified()) {
        TT_THROW("Env var {} is not set.", "TT_METAL_KERNEL_PATH");
    }

    return this->kernel_dir;
}

const std::string& RunTimeOptions::get_core_grid_override_todeprecate() const {
    if (!this->is_core_grid_override_todeprecate()) {
        TT_THROW("Env var {} is not set.", enchantum::to_string(EnvVarID::TT_METAL_CORE_GRID_OVERRIDE_TODEPRECATE));
    }

    return this->core_grid_override_todeprecate;
}

const std::string& RunTimeOptions::get_system_kernel_dir() const { return this->system_kernel_dir; }

// ============================================================================
// ENVIRONMENT VARIABLE HANDLER
// ============================================================================
// Central handler that processes environment variables based on their ID
// Uses switch statement for efficient dispatch
//
// IMPORTANT: Most cases assume 'value' is non-null (enforced by InitializeFromEnvVars loop guard).
// Only TT_METAL_RISCV_DEBUG_INFO explicitly handle nullptr
// for default value initialization.

void RunTimeOptions::HandleEnvVar(EnvVarID id, const char* value) {
    switch (id) {
        // ========================================
        // PATH CONFIGURATION
        // ========================================

        // TT_METAL_CACHE
        // Directory for caching compiled kernels and other build artifacts.
        // Default: Defaults to system temp directory if not set
        // Usage: export TT_METAL_CACHE=/path/to/cache
        case EnvVarID::TT_METAL_CACHE:
            this->is_cache_dir_env_var_set = true;
            this->cache_dir_ = normalize_path(value, "tt-metal-cache");
            break;

        // TT_METAL_KERNEL_PATH
        // Path to kernel source files.
        // Default: resolved relative to TT_METAL_RUNTIME_ROOT if not set
        // Usage: export TT_METAL_KERNEL_PATH=/path/to/kernels
        case EnvVarID::TT_METAL_KERNEL_PATH:
            this->is_kernel_dir_env_var_set = true;
            this->kernel_dir = normalize_path(value) + "/";
            break;

        // TT_METAL_LOGS_PATH
        // Directory for generated logs and debug output (dprint, watcher, profiler, etc.)
        // Default: Current working directory if not set
        // Usage: export TT_METAL_LOGS_PATH=/path/to/logs
        case EnvVarID::TT_METAL_LOGS_PATH: this->logs_dir_ = normalize_path(value) + "/"; break;

        // TT_METAL_SIMULATOR
        // Path to simulator executable. When set, overrides mock cluster mode if both are set.
        // Default: Hardware mode (no simulator)
        // Usage: export TT_METAL_SIMULATOR=/path/to/simulator
        case EnvVarID::TT_METAL_SIMULATOR:
            this->simulator_path = std::string(value);
            // Simulator takes precedence over Mock (will be set even if Mock was set first)
            this->runtime_target_device_ = tt::TargetDevice::Simulator;
            break;

        // TT_METAL_MOCK_CLUSTER_DESC_PATH
        // Path to mock cluster descriptor for testing without hardware.
        // Note: If both MOCK and SIMULATOR are set, SIMULATOR takes precedence
        // Default: Hardware mode (no mock cluster)
        // Usage: export TT_METAL_MOCK_CLUSTER_DESC_PATH=/path/to/mock_cluster_desc.yaml
        case EnvVarID::TT_METAL_MOCK_CLUSTER_DESC_PATH:
            this->mock_cluster_desc_path = std::string(value);
            // Only set Mock target if Simulator hasn't been set already
            if (this->simulator_path.empty()) {
                this->runtime_target_device_ = tt::TargetDevice::Mock;
            }
            break;

        // TT_METAL_EMULE_MODE
        // Enable emulated mode: creates SWEmuleChip (with real memory-backed I/O)
        // instead of MockChip.  Requires TT_METAL_MOCK_CLUSTER_DESC_PATH to be set.
        // Automatically forces slow dispatch mode.
        // Default: Disabled
        // Usage: export TT_METAL_EMULE_MODE=1
        case EnvVarID::TT_METAL_EMULE_MODE:
            this->runtime_target_device_ = tt::TargetDevice::Emule;
            // Emulated mode requires slow dispatch (no HWCommandQueue)
            this->using_slow_dispatch = true;
            this->fast_dispatch = false;
            break;

        // TT_METAL_VISIBLE_DEVICES
        // Comma-separated list of device IDs to make visible to the runtime.
        // Default: All devices visible
        // Usage: export TT_METAL_VISIBLE_DEVICES=0,1,2
        case EnvVarID::TT_METAL_VISIBLE_DEVICES: this->visible_devices = std::string(value); break;

        // ARCH_NAME
        // Sets the architecture name (only necessary during simulation).
        // Default: Hardware-detected architecture
        // Usage: export ARCH_NAME=wormhole_b0
        case EnvVarID::ARCH_NAME: this->arch_name = std::string(value); break;

        // QUASAR_ARCH_VARIANT
        // Build the Quasar LLKs for an IP variant. The name is a directory under
        // tt_metal/tt-llk/tt_llk_quasar/arch/ whose headers shadow the base Quasar ones.
        // Default: unset (base Quasar part)
        // Usage: export QUASAR_ARCH_VARIANT=quasar_4row
        case EnvVarID::QUASAR_ARCH_VARIANT: {
            const std::string variant(value);
            if (variant.empty()) {
                break;
            }
            const bool plain_name = std::all_of(variant.begin(), variant.end(), [](unsigned char c) {
                return std::islower(c) || std::isdigit(c) || c == '_';
            });
            TT_FATAL(plain_name, "QUASAR_ARCH_VARIANT '{}' must be a plain lowercase name (a-z, 0-9, _)", variant);
            const auto dir = std::filesystem::path(get_root_dir()) / "tt_metal/tt-llk/tt_llk_quasar/arch" / variant;
            TT_FATAL(
                std::filesystem::is_directory(dir),
                "QUASAR_ARCH_VARIANT '{}' has no directory {}",
                variant,
                dir.string());
            this->quasar_arch_variant = variant;
            break;
        }

        // TT_MESH_GRAPH_DESC_PATH
        // Custom fabric mesh graph descriptor path.
        // Default: Default fabric mesh configuration
        // Usage: export TT_MESH_GRAPH_DESC_PATH=/path/to/mesh_desc.yaml
        case EnvVarID::TT_MESH_GRAPH_DESC_PATH:
            this->is_custom_fabric_mesh_graph_desc_path_set = true;
            this->custom_fabric_mesh_graph_desc_path = std::string(value);
            break;

        // TT_METAL_FACTORY_SYSTEM_DESCRIPTOR_PATH
        // Path to a Factory System Descriptor (FSD) textproto describing the as-built/expected topology.
        // When set, tooling may map against it instead of live-discovering the PSD, and it lets
        // Fabric 2.0 statically reroute traffic around broken links.
        // Default: unset (fall back to live PSD discovery)
        // Usage: export TT_METAL_FACTORY_SYSTEM_DESCRIPTOR_PATH=/path/to/fsd.textproto
        // See https://github.com/tenstorrent/tt-metal/issues/52859 for the design and rollout.
        case EnvVarID::TT_METAL_FACTORY_SYSTEM_DESCRIPTOR_PATH:
            this->factory_system_descriptor_path = std::string(value);
            break;

        // TT_METAL_CORE_GRID_OVERRIDE_TODEPRECATE
        // Override core grid configuration (this is meant to be deprecated).
        // Default: Hardware-detected core grid
        // Usage: export TT_METAL_CORE_GRID_OVERRIDE_TODEPRECATE=custom_grid
        case EnvVarID::TT_METAL_CORE_GRID_OVERRIDE_TODEPRECATE:
            this->is_core_grid_override_todeprecate_env_var_set = true;
            this->core_grid_override_todeprecate = std::string(value);
            break;

        // ========================================
        // KERNEL EXECUTION CONTROL
        // ========================================

        // TT_METAL_NULL_KERNELS
        // Skip actual kernel execution, useful for testing dispatch logic without running kernels.
        // Default: false (kernels execute normally)
        // Usage: export TT_METAL_NULL_KERNELS=1
        case EnvVarID::TT_METAL_NULL_KERNELS: this->null_kernels = true; break;

        // TT_METAL_CHECKPOINT
        // Enable debug checkpoints for fine-grain debugging of large ops.
        // Default: false
        // Usage: export TT_METAL_CHECKPOINT=1
        case EnvVarID::TT_METAL_CHECKPOINT: this->checkpoint_enabled = true; break;

        // TT_METAL_KERNELS_EARLY_RETURN
        // Kernels return early, skipping execution but maintaining same size as normal.
        // Default: false (kernels execute fully)
        // Usage: export TT_METAL_KERNELS_EARLY_RETURN=1
        case EnvVarID::TT_METAL_KERNELS_EARLY_RETURN: this->kernels_early_return = true; break;

        // ========================================
        // MEMORY INITIALIZATION
        // ========================================

        // TT_METAL_CLEAR_L1
        // Clear L1 memory on device initialization.
        // Default: 0 (don't clear)
        // Usage: export TT_METAL_CLEAR_L1=1
        case EnvVarID::TT_METAL_CLEAR_L1: this->clear_l1 = is_env_enabled(value); break;

        // TT_METAL_CLEAR_DRAM
        // Clear DRAM memory on device initialization.
        // Default: 0 (don't clear)
        // Usage: export TT_METAL_CLEAR_DRAM=1
        case EnvVarID::TT_METAL_CLEAR_DRAM: this->clear_dram = is_env_enabled(value); break;

        // ========================================
        // HOST MEMORY
        // ========================================

        // TT_METAL_PINNED_MEMORY_CACHE_LIMIT_BYTES
        // Maximum host memory bytes held by the pinned memory cache.
        // Default: 4GB
        // Usage: export TT_METAL_PINNED_MEMORY_CACHE_LIMIT_BYTES=4294967296
        case EnvVarID::TT_METAL_PINNED_MEMORY_CACHE_LIMIT_BYTES: {
            std::string limit_value = trim_copy(value);
            if (limit_value.empty() || limit_value.front() == '-') {
                TT_THROW("TT_METAL_PINNED_MEMORY_CACHE_LIMIT_BYTES must be a non-negative byte count: {}", value);
            }

            try {
                size_t parse_pos = 0;
                unsigned long long parsed_limit = std::stoull(limit_value, &parse_pos, 0);
                if (parse_pos != limit_value.size()) {
                    TT_THROW("TT_METAL_PINNED_MEMORY_CACHE_LIMIT_BYTES must be a byte count: {}", value);
                }
                if (parsed_limit > std::numeric_limits<size_t>::max()) {
                    TT_THROW("TT_METAL_PINNED_MEMORY_CACHE_LIMIT_BYTES value out of range: {}", value);
                }
                this->pinned_memory_cache_limit_bytes = static_cast<size_t>(parsed_limit);
            } catch (const std::invalid_argument&) {
                TT_THROW("Invalid TT_METAL_PINNED_MEMORY_CACHE_LIMIT_BYTES: {}", value);
            } catch (const std::out_of_range&) {
                TT_THROW("TT_METAL_PINNED_MEMORY_CACHE_LIMIT_BYTES value out of range: {}", value);
            }
            break;
        }

        // ========================================
        // DEBUG & TESTING
        // ========================================

        // TT_METAL_WATCHER_TEST_MODE
        // Enable test mode for watcher functionality.
        // Default: false (normal mode)
        // Usage: export TT_METAL_WATCHER_TEST_MODE=1
        case EnvVarID::TT_METAL_WATCHER_TEST_MODE: this->test_mode_enabled = true; break;

        // TT_METAL_KERNEL_MAP
        // Enable kernel build mapping for debugging.
        // Default: false (mapping disabled)
        // Usage: export TT_METAL_KERNEL_MAP=1
        case EnvVarID::TT_METAL_KERNEL_MAP: this->build_map_enabled = true; break;

        // TT_METAL_DISPATCH_DATA_COLLECTION
        // Enable collection of dispatch debugging data.
        // Default: false (collection disabled)
        // Usage: export TT_METAL_DISPATCH_DATA_COLLECTION=1
        case EnvVarID::TT_METAL_DISPATCH_DATA_COLLECTION: this->enable_dispatch_data_collection = true; break;

        // TT_METAL_GTEST_ETH_DISPATCH
        // Use Ethernet cores for dispatch in tests.
        // Default: Worker cores (default dispatch type)
        // Usage: export TT_METAL_GTEST_ETH_DISPATCH=1
        case EnvVarID::TT_METAL_GTEST_ETH_DISPATCH:
            this->dispatch_core_type_override = tt_metal::DispatchCoreType::ETH;
            break;

        // TT_METAL_TENSIX_DISPATCH_CORES
        // Quasar: use interim Tensix dispatch cores from core descriptor YAML instead of soc dispatch-engine cores.
        // Default: false (use soc dispatch-engine cores when present)
        // Usage: export TT_METAL_TENSIX_DISPATCH_CORES=1
        case EnvVarID::TT_METAL_TENSIX_DISPATCH_CORES:
            this->use_quasar_tensix_dispatch_cores = is_env_enabled(value);
            log_info(
                tt::LogDevice,
                "TT_METAL_TENSIX_DISPATCH_CORES=1: using interim Tensix dispatch cores from core descriptor YAML");
            break;

        // TT_METAL_SKIP_LOADING_FW
        // Skip loading firmware during device initialization.
        // Default: false (load firmware)
        // Usage: export TT_METAL_SKIP_LOADING_FW=1
        case EnvVarID::TT_METAL_SKIP_LOADING_FW: this->skip_loading_fw = true; break;

        // ========================================
        // HARDWARE CONFIGURATION
        // ========================================

        // TT_METAL_ENABLE_HW_CACHE_INVALIDATION
        // Enable hardware to automatically invalidate Blackhole's data cache.
        // Default: false (cache invalidation disabled)
        // Usage: export TT_METAL_ENABLE_HW_CACHE_INVALIDATION=1
        case EnvVarID::TT_METAL_ENABLE_HW_CACHE_INVALIDATION: this->enable_hw_cache_invalidation = true; break;

        // TT_METAL_DISABLE_RELAXED_MEM_ORDERING
        // Disable relaxed memory ordering optimizations on Blackhole.
        // Default: false (relaxed ordering enabled)
        // Usage: export TT_METAL_DISABLE_RELAXED_MEM_ORDERING=1
        case EnvVarID::TT_METAL_DISABLE_RELAXED_MEM_ORDERING: this->disable_relaxed_memory_ordering = true; break;

        // TT_METAL_ENABLE_GATHERING
        // Enable data gathering on Blackhole.
        // Default: false (gathering disabled)
        // Usage: export TT_METAL_ENABLE_GATHERING=1
        case EnvVarID::TT_METAL_ENABLE_GATHERING: this->enable_gathering = true; break;

        // TT_METAL_FABRIC_BW_TELEMETRY
        // Enable fabric bandwidth telemetry data collection.
        // Default: false (telemetry disabled)
        // Usage: export TT_METAL_FABRIC_BW_TELEMETRY=1
        case EnvVarID::TT_METAL_FABRIC_BW_TELEMETRY: this->enable_fabric_bw_telemetry = true; break;

        // TT_METAL_FABRIC_TELEMETRY
        // Enable fabric telemetry data collection (supports structured spec).
        // Default: false (telemetry disabled)
        // Usage: export TT_METAL_FABRIC_TELEMETRY=1 (enable all stats on all chip/eth/erisc) or
        //        export TT_METAL_FABRIC_TELEMETRY="chips=all;eth=0,2,7;erisc=all;stats=ROUTER_STATE|BANDWIDTH"
        case EnvVarID::TT_METAL_FABRIC_TELEMETRY: this->ParseFabricTelemetryEnv(value); break;

        // TT_FABRIC_PROFILE_RX_CH_FWD
        // Enables fabric RX channel forwarding profiling.
        // Default: false
        // Usage: export TT_FABRIC_PROFILE_RX_CH_FWD=1
        case EnvVarID::TT_FABRIC_PROFILE_RX_CH_FWD: this->fabric_profiling_settings.enable_rx_ch_fwd = true; break;

        // TT_METAL_ENABLE_CHANNEL_TRIMMING_CAPTURE
        // Enables channel trimming resource usage capture on fabric routers.
        // Default: false
        // Usage: export TT_METAL_ENABLE_CHANNEL_TRIMMING_CAPTURE=1
        case EnvVarID::TT_METAL_ENABLE_CHANNEL_TRIMMING_CAPTURE: this->enable_channel_trimming_capture = true; break;

        // TT_METAL_FABRIC_TRIMMING_PROFILE
        // Path to a previously captured channel trimming YAML file. When set, fabric router
        // construction uses the captured profile to disable unused sender/receiver channels.
        // Default: empty (no profile import)
        // Usage: export TT_METAL_FABRIC_TRIMMING_PROFILE=/path/to/channel_trimming_capture.yaml
        case EnvVarID::TT_METAL_FABRIC_TRIMMING_PROFILE: this->fabric_trimming_profile_path = std::string(value); break;

        // TT_METAL_FABRIC_TRIMMING_OVERRIDE
        // Path to a global override YAML file for channel trimming. When set, override entries
        // replace capture-driven decisions for specified VCs (force-enable/disable channels).
        // Can be used with or without TT_METAL_FABRIC_TRIMMING_PROFILE.
        // Default: empty (no override)
        // Usage: export TT_METAL_FABRIC_TRIMMING_OVERRIDE=/path/to/override.yaml
        case EnvVarID::TT_METAL_FABRIC_TRIMMING_OVERRIDE:
            this->fabric_trimming_override_path = std::string(value);
            break;

        // TT_METAL_ENABLE_FABRIC_VC2
        // Enables the third virtual channel (VC2) for single-hop neighbour exchange traffic.
        // Only effective when intermesh VC is also enabled (2D + multi-mesh + Blackhole + no UDM/mux).
        // Default: false
        // Usage: export TT_METAL_ENABLE_FABRIC_VC2=1
        case EnvVarID::TT_METAL_ENABLE_FABRIC_VC2: this->enable_fabric_vc2 = true; break;

        // TT_METAL_ENABLE_FABRIC_MESH_PASS_THROUGH
        // EXPERIMENTAL: Enables VC1 inter-mesh pass-through routing (e.g. A->B->C), where inter-mesh
        // (VC1) traffic is forwarded across intermediate meshes instead of sinking at the first mesh
        // boundary. Selects IntermeshVCConfig::full_mesh_with_pass_through() when intermesh VC is active.
        // WARNING: This reuses VC1 for both in-mesh delivery and cross-mesh pass-through and is NOT
        // guaranteed deadlock-free; a fully deadlock-free implementation requires a dedicated VC.
        // Default: false
        // Usage: export TT_METAL_ENABLE_FABRIC_MESH_PASS_THROUGH=1
        case EnvVarID::TT_METAL_ENABLE_FABRIC_MESH_PASS_THROUGH: this->enable_fabric_mesh_pass_through = true; break;

        // RELIABILITY_MODE
        // Sets the fabric reliability mode (STRICT, RELAXED, or DYNAMIC).
        // Default: nullopt (uses system default)
        // Usage: export RELIABILITY_MODE=STRICT (or strict/0), RELAXED (or relaxed/1), DYNAMIC (or dynamic/2)
        case EnvVarID::RELIABILITY_MODE: {
            std::string mode_str(value);
            // Convert to lowercase for case-insensitive comparison
            std::transform(
                mode_str.begin(), mode_str.end(), mode_str.begin(), [](unsigned char c) { return std::tolower(c); });
            if (mode_str == "strict" || mode_str == "0") {
                this->reliability_mode = tt::tt_fabric::FabricReliabilityMode::STRICT_SYSTEM_HEALTH_SETUP_MODE;
            } else if (mode_str == "relaxed" || mode_str == "1") {
                this->reliability_mode = tt::tt_fabric::FabricReliabilityMode::RELAXED_SYSTEM_HEALTH_SETUP_MODE;
            } else if (mode_str == "dynamic" || mode_str == "2") {
                this->reliability_mode = tt::tt_fabric::FabricReliabilityMode::DYNAMIC_RECONFIGURATION_SETUP_MODE;
            }
            break;
        }

        // TT_METAL_DISABLE_FABRIC_TWO_ERISC
        // Presence-based override to force-disable fabric 2-ERISC mode, even if defaults would enable
        // Default: false (2-ERISC mode enabled)
        // Usage: export TT_METAL_DISABLE_FABRIC_TWO_ERISC=1
        case EnvVarID::TT_METAL_DISABLE_FABRIC_TWO_ERISC:
            log_info(tt::LogMetal, "Disabling two-erisc fabric mode with TT_METAL_DISABLE_FABRIC_TWO_ERISC");
            this->disable_fabric_2_erisc_mode = true;
            break;

        // TT_METAL_DISABLE_MULTI_AERISC
        // Disable multi-ERISC mode (2-ERISC mode is enabled by default on Blackhole).
        // Use this to fallback to single ERISC mode.
        // Default: enabled (2-ERISC mode)
        // Usage: export TT_METAL_DISABLE_MULTI_AERISC=1
        case EnvVarID::TT_METAL_DISABLE_MULTI_AERISC:
            log_info(tt::LogMetal, "Disabling multi-erisc mode with TT_METAL_DISABLE_MULTI_AERISC");
            this->enable_2_erisc_mode = false;
            break;

        // TT_METAL_USE_MGD_2_0
        // Enables use of Mesh Graph Descriptor 2.0 format for fabric configuration.
        // Default: false (uses MGD 1.0)
        // Usage: export TT_METAL_USE_MGD_2_0=1
        case EnvVarID::TT_METAL_USE_MGD_2_0:
            this->use_mesh_graph_descriptor_2_0 = (std::strncmp(value, "0", 1) != 0);
            break;

        // TT_METAL_FORCE_JIT_COMPILE
        // Force JIT compilation even if dependencies are up-to-date.
        // This overrides the dependency tracking optimization.
        // Default: false (uses dependency tracking)
        // Usage: export TT_METAL_FORCE_JIT_COMPILE=1
        case EnvVarID::TT_METAL_FORCE_JIT_COMPILE: this->force_jit_compile = true; break;

        // TT_METAL_FORCE_REINIT
        // Force context reinitialization on each run.
        // Default: false (normal initialization)
        // Usage: export TT_METAL_FORCE_REINIT=1
        case EnvVarID::TT_METAL_FORCE_REINIT: this->force_context_reinit = true; break;

        // TT_METAL_LOG_KERNELS_COMPILE_COMMANDS
        // Log kernel compilation commands for debugging.
        // Default: false (no logging)
        // Usage: export TT_METAL_LOG_KERNELS_COMPILE_COMMANDS=1
        case EnvVarID::TT_METAL_LOG_KERNELS_COMPILE_COMMANDS: this->log_kernels_compilation_commands = true; break;

        // TT_METAL_SLOW_DISPATCH_MODE
        // Use slow dispatch mode for debugging.
        // Default: false (fast dispatch mode)
        // Usage: export TT_METAL_SLOW_DISPATCH_MODE=1
        case EnvVarID::TT_METAL_SLOW_DISPATCH_MODE:
            this->using_slow_dispatch = true;
            this->fast_dispatch = false;
            break;

        // TT_METAL_SKIP_ETH_CORES_WITH_RETRAIN
        // Skip Ethernet cores during retraining process.
        // Default: true (skip retraining)
        // Usage: export TT_METAL_SKIP_ETH_CORES_WITH_RETRAIN=1
        case EnvVarID::TT_METAL_SKIP_ETH_CORES_WITH_RETRAIN:
            this->skip_eth_cores_with_retrain = is_env_enabled(value);
            break;

        // TT_METAL_VALIDATE_PROGRAM_BINARIES
        // Validate kernel binary integrity before execution.
        // Default: 0 (no validation)
        // Usage: export TT_METAL_VALIDATE_PROGRAM_BINARIES=1
        case EnvVarID::TT_METAL_VALIDATE_PROGRAM_BINARIES:
            this->set_validate_kernel_binaries(is_env_enabled(value));
            break;

        // TT_METAL_DISABLE_DMA_OPS
        // Disable DMA operations for debugging.
        // Default: 0 (DMA enabled)
        // Usage: export TT_METAL_DISABLE_DMA_OPS=1
        case EnvVarID::TT_METAL_DISABLE_DMA_OPS: this->disable_dma_ops = is_env_enabled(value); break;

        // TT_METAL_DISABLE_SFPLOADMACRO
        // Disable use of SFPLOADMACRO instructions.
        // Default: 0 (use SFPLOADMACRO instructions)
        // Usage: export TT_METAL_DISABLE_SFPLOADMACRO=1
        case EnvVarID::TT_METAL_DISABLE_SFPLOADMACRO: this->disable_sfploadmacro = is_env_enabled(value); break;

        // TT_METAL_DRAM_BACKED_CQ
        // Store command queues in device DRAM.
        // Default: false (use hugepages)
        // Usage: export TT_METAL_DRAM_BACKED_CQ=1
        case EnvVarID::TT_METAL_DRAM_BACKED_CQ:
            this->dram_backed_cq_env_var_set = true;
            this->dram_backed_cq = is_env_enabled(value);
            break;

        // TT_METAL_SIMULATOR_DIRECT_TENSOR_WRITES
        // Use synchronous direct buffer writes for simulator tensor preloads instead of FD CQ copies.
        // Default: false
        // Usage: export TT_METAL_SIMULATOR_DIRECT_TENSOR_WRITES=1
        case EnvVarID::TT_METAL_SIMULATOR_DIRECT_TENSOR_WRITES:
            this->simulator_direct_tensor_writes = is_env_enabled(value);
            break;

        // TT_METAL_QUASAR_NOC_API_VERSION
        // Set the NOC API version for Quasar.
        // Default: 2 (use NOC API v2)
        // Usage: export TT_METAL_QUASAR_NOC_API_VERSION=1
        case EnvVarID::TT_METAL_QUASAR_NOC_API_VERSION:
            this->quasar_noc_api_version = std::stoi(value);
            TT_FATAL(
                this->quasar_noc_api_version == 1 || this->quasar_noc_api_version == 2,
                "Invalid NOC API version: {}",
                this->quasar_noc_api_version);
            break;

        // TT_METAL_ENABLE_BLACKHOLE_DRAM_PROGRAMMABLE_CORES
        // Controls Blackhole DRAM programmable cores in the HAL:
        //   =1 → force enable, =0 → force disable, unset → auto-detect (firmware + topology)
        // Usage: export TT_METAL_ENABLE_BLACKHOLE_DRAM_PROGRAMMABLE_CORES=0
        case EnvVarID::TT_METAL_ENABLE_BLACKHOLE_DRAM_PROGRAMMABLE_CORES:
            this->blackhole_dram_programmable_cores_override = is_env_enabled(value);
            break;

        // TT_METAL_MEASURE_DFB_INIT_TIME
        // Enables rdcycle-based DFB init timing slots in device firmware (Quasar only).
        // Deprecate once the device profiler subsumes this instrumentation.
        // Default: false (rdcycle timing disabled; device uses no-op counters)
        // Usage: export TT_METAL_MEASURE_DFB_INIT_TIME=1
        case EnvVarID::TT_METAL_MEASURE_DFB_INIT_TIME:
            this->measure_dfb_init_time_enabled = is_env_enabled(value);
            break;

        // TT_METAL_TDP_LIMIT_WATTS
        // TDP limit [W] to hand the firmware throttler when the cluster opens, or 0 to restore the
        // board default. It stays in effect until the chip is reset or another writer replaces it,
        // outliving this process. Needs Blackhole with firmware 19.11.0+; anywhere else the limit
        // is left alone with a warning. An empty value is treated as unset.
        // Default: unset (whatever limit is already in effect stays)
        // Usage: export TT_METAL_TDP_LIMIT_WATTS=300
        case EnvVarID::TT_METAL_TDP_LIMIT_WATTS: {
            std::string limit_value = trim_copy(value);
            if (limit_value.empty()) {
                this->tdp_limit_watts = std::nullopt;
                break;
            }
            try {
                size_t parse_pos = 0;
                unsigned long long parsed_limit = std::stoull(limit_value, &parse_pos, 0);
                if (parse_pos != limit_value.size() || parsed_limit > std::numeric_limits<uint32_t>::max()) {
                    TT_THROW("TT_METAL_TDP_LIMIT_WATTS must be a watt count: {}", value);
                }
                this->tdp_limit_watts = static_cast<uint32_t>(parsed_limit);
            } catch (const std::invalid_argument&) {
                TT_THROW("TT_METAL_TDP_LIMIT_WATTS must be a watt count: {}", value);
            } catch (const std::out_of_range&) {
                TT_THROW("TT_METAL_TDP_LIMIT_WATTS value out of range: {}", value);
            }
            break;
        }

        // ========================================
        // PROFILING & PERFORMANCE
        // ========================================

        // TT_METAL_DEVICE_PROFILER
        // Enables device profiling (requires TRACY_ENABLE compilation flag).
        // Default: false (profiling disabled)
        // Usage: export TT_METAL_DEVICE_PROFILER=1
        case EnvVarID::TT_METAL_DEVICE_PROFILER:
#if !defined(TRACY_ENABLE)
            TT_FATAL(false, "TT_METAL_DEVICE_PROFILER requires a Tracy-enabled build of tt-metal.");
#else
            if (is_env_enabled(value)) {
                this->profiler_enabled = true;
            }
#endif
            break;

        // TT_METAL_STREAMING_PROFILER
        // Boots the streaming profiler at MeshDevice bring-up. Records go to registered callbacks
        // (RegisterCallback and the TT_METAL_STREAMING_PROFILER_*_CSV writers); add
        // TT_METAL_STREAMING_PROFILER_TRACY=1 for the Tracy sink. Needs a Tracy-enabled build and
        // TT_METAL_DEVICE_PROFILER off.

        // Default: false
        // Usage: export TT_METAL_STREAMING_PROFILER=1
        case EnvVarID::TT_METAL_STREAMING_PROFILER:
#if !defined(TRACY_ENABLE)
            TT_FATAL(false, "TT_METAL_STREAMING_PROFILER requires a Tracy-enabled build of tt-metal.");
#else
            if (is_env_enabled(value)) {
                this->streaming_profiler_enabled = true;
            }
#endif
            break;

        // TT_METAL_STREAMING_PROFILER_SYNC_EVENTS
        // Enables profiling for synchronization events (cb reserve/wait/push/pop, semaphore set/wait).
        // Requires TT_METAL_STREAMING_PROFILER to be enabled as well.
        // Default: false
        // Usage: export TT_METAL_STREAMING_PROFILER_SYNC_EVENTS=1
        case EnvVarID::TT_METAL_STREAMING_PROFILER_SYNC_EVENTS:
            this->streaming_profiler_sync_events_enabled = is_env_enabled(value);
            break;

        // TT_METAL_STREAMING_PROFILER_INLINE_ENABLED
        // This is enabled by default. Disabling inlining of kernel zone-marker emit path to
        // reduce kernel size overhead from profiler instrumentation. This is useful for
        // kernels with many zones that would otherwise exceed the kernel-config ring and fail to launch at all.
        // Only works on the streaming profiler.
        // Default: true
        // Usage: export TT_METAL_STREAMING_PROFILER_INLINE_ENABLED=1
        case EnvVarID::TT_METAL_STREAMING_PROFILER_INLINE_ENABLED:
            this->streaming_profiler_inline_enabled = is_env_enabled(value);
            break;

        // TT_METAL_STREAMING_PROFILER_TRACY
        // Attaches the Tracy sink to the streaming profiler. Off by default.
        // Default: false
        // Usage: export TT_METAL_STREAMING_PROFILER_TRACY=1
        case EnvVarID::TT_METAL_STREAMING_PROFILER_TRACY:
            this->streaming_profiler_tracy_enabled = is_env_enabled(value);
            break;

        // TT_METAL_STREAMING_PROFILER_DRAM_MB
        // Per-relay device DRAM buffer, in MiB. Raise it to absorb more host-side backpressure on the device;
        // 0 sends profiling data straight to the host. Capped at STREAMING_PROFILER_SPOOL_MB_MAX.
        // Default: STREAMING_PROFILER_SPOOL_MB_DEFAULT
        // Usage: export TT_METAL_STREAMING_PROFILER_DRAM_MB=256
        case EnvVarID::TT_METAL_STREAMING_PROFILER_DRAM_MB:
            this->streaming_profiler_spool_mb =
                std::min<unsigned long>(std::stoul(value), STREAMING_PROFILER_SPOOL_MB_MAX);
            break;

        // TT_METAL_STREAMING_PROFILER_FIFO_MB
        // Host FIFO per D2H socket, in MiB. Raise it to let a slow callback fall further behind before it loses
        // profiling data; it costs this much pinned host memory per relay. A power of two, at most
        // STREAMING_PROFILER_FIFO_MB_MAX.
        // Default: STREAMING_PROFILER_FIFO_MB_DEFAULT
        // Usage: export TT_METAL_STREAMING_PROFILER_FIFO_MB=1024
        case EnvVarID::TT_METAL_STREAMING_PROFILER_FIFO_MB: {
            const unsigned long mb = std::clamp<unsigned long>(std::stoul(value), 1, STREAMING_PROFILER_FIFO_MB_MAX);
            TT_FATAL(std::has_single_bit(mb), "TT_METAL_STREAMING_PROFILER_FIFO_MB='{}' is not a power of two", value);
            this->streaming_profiler_fifo_mb = mb;
            break;
        }

        // TT_METAL_STREAMING_PROFILER_OPS_CSV
        // Path for the per-op CSV consumer; empty leaves it unregistered.
        // Default: "" (off)
        // Usage: export TT_METAL_STREAMING_PROFILER_OPS_CSV=/tmp/ops.csv
        case EnvVarID::TT_METAL_STREAMING_PROFILER_OPS_CSV:
            this->streaming_profiler_ops_csv_path = std::string(value);
            break;

        // TT_METAL_STREAMING_PROFILER_ZONE_CSV
        // Path for the per-zone CSV consumer; empty leaves it unregistered.
        // Default: "" (off)
        // Usage: export TT_METAL_STREAMING_PROFILER_ZONE_CSV=/tmp/zones.csv
        case EnvVarID::TT_METAL_STREAMING_PROFILER_ZONE_CSV:
            this->streaming_profiler_zone_csv_path = std::string(value);
            break;

        // TT_METAL_DEVICE_PROFILER_DISPATCH
        // Enables profiling of dispatch cores. Requires TT_METAL_DEVICE_PROFILER=1 to be effective.
        // Default: 0 (dispatch profiling disabled)
        // Usage: export TT_METAL_DEVICE_PROFILER_DISPATCH=1
        case EnvVarID::TT_METAL_DEVICE_PROFILER_DISPATCH: {
            // Only enable dispatch profiling if device profiler is also enabled
            if (this->profiler_enabled && is_env_enabled(value)) {
                this->profile_dispatch_cores = true;
            }
            break;
        }

        // TT_METAL_PROFILER_SYNC
        // Enables synchronous profiling mode for more accurate timing.
        // Default: false (asynchronous profiling)
        // Usage: export TT_METAL_PROFILER_SYNC=1
        case EnvVarID::TT_METAL_PROFILER_SYNC: {
            // Only enable sync profiling if device profiler is also enabled
            if (this->profiler_enabled && is_env_enabled(value)) {
                this->profiler_sync_enabled = true;
            }
            break;
        }

        // TT_METAL_DEVICE_PROFILER_NOC_EVENTS
        // Enables NoC (Network-on-Chip) events profiling.
        // Default: false (NoC events not profiled)
        // Usage: export TT_METAL_DEVICE_PROFILER_NOC_EVENTS=1
        case EnvVarID::TT_METAL_DEVICE_PROFILER_NOC_EVENTS:
            if (is_env_enabled(value)) {
                this->profiler_enabled = true;
                this->profiler_noc_events_enabled = true;
            }
            break;

        // TT_METAL_DEVICE_PROFILER_NOC_EVENTS_RPT_PATH
        // Sets the report path for NoC events profiling output files.
        // Default: Default report location
        // Usage: export TT_METAL_DEVICE_PROFILER_NOC_EVENTS_RPT_PATH=/path/to/reports
        case EnvVarID::TT_METAL_DEVICE_PROFILER_NOC_EVENTS_RPT_PATH:
            this->profiler_noc_events_report_path = std::string(value);
            break;

        // TT_METAL_MEM_PROFILER
        // Enables memory/buffer usage profiling for tracking memory allocation patterns.
        // Default: false (memory profiling disabled)
        // Usage: export TT_METAL_MEM_PROFILER=1
        case EnvVarID::TT_METAL_MEM_PROFILER:
            if (is_env_enabled(value)) {
                this->profiler_buffer_usage_enabled = true;
            }
            break;

        // TT_METAL_PROFILE_PERF_COUNTERS
        // Bitfield selecting perf counter groups. Only one L1 bank bit may be set per run.
        // Default: 0 (disabled)
        // Usage: export TT_METAL_PROFILE_PERF_COUNTERS=47
        case EnvVarID::TT_METAL_PROFILE_PERF_COUNTERS:
            sscanf(value, "%u", &this->profiler_perf_counter_mode);
            if (this->profiler_perf_counter_mode != 0) {
                // PROFILE_PERF_COUNTERS_L1_0 to L1_5: the six L1 mux groups, which share one set of counters.
                constexpr uint32_t L1_GROUP_BITS = (1 << 3) | (1 << 4) | (1 << 6) | (1 << 7) | (1 << 8) | (1 << 9);
                uint32_t l1_selected = this->profiler_perf_counter_mode & L1_GROUP_BITS;
                if (l1_selected && (l1_selected & (l1_selected - 1))) {
                    TT_THROW(
                        "Multiple L1 perf counter banks cannot be enabled simultaneously. "
                        "They share the same hardware mux. Use the CLI (python -m tracy "
                        "--profiler-capture-perf-counters) for automatic multi-pass execution, "
                        "or specify at most one L1 bank via the env var.");
                }
                this->profiler_enabled = true;
            }
            break;

        // TT_METAL_TRACE_PROFILER
        // Enables trace profiler for detailed execution tracing.
        // Default: false (trace profiling disabled)
        // Usage: export TT_METAL_TRACE_PROFILER=1
        case EnvVarID::TT_METAL_TRACE_PROFILER: {
            // Only enable trace profiling if device profiler is also enabled
            if (this->profiler_enabled && is_env_enabled(value)) {
                this->profiler_trace_profiler = true;
            }
            break;
        }

        // TT_METAL_PROFILER_TRACE_TRACKING
        // Enables trace tracking for detailed execution tracing.
        // Default: false (trace tracking disabled)
        // Usage: export TT_METAL_PROFILER_TRACE_TRACKING=1
        case EnvVarID::TT_METAL_PROFILER_TRACE_TRACKING: {
            // Only enable trace tracking if device profiler is also enabled
            if (this->profiler_enabled && is_env_enabled(value)) {
                this->profiler_trace_tracking = true;
            }
            break;
        }

        // TT_METAL_PROFILER_MID_RUN_DUMP
        // Forces Tracy profiler dumps during execution for real-time profiling.
        // Default: false (no mid-run dumps)
        // Usage: export TT_METAL_PROFILER_MID_RUN_DUMP=1
        case EnvVarID::TT_METAL_PROFILER_MID_RUN_DUMP: {
            this->profiler_mid_run_dump = is_env_enabled(value);
            break;
        }

        // TT_METAL_PROFILER_CPP_POST_PROCESS
        // Enable C++ post-processing for profiler output. Requires TT_METAL_DEVICE_PROFILER=1 to be effective.
        // Default: false
        // Usage: export TT_METAL_PROFILER_CPP_POST_PROCESS=1
        case EnvVarID::TT_METAL_PROFILER_CPP_POST_PROCESS: {
            // Only enable C++ post-processing if device profiler is also enabled
            if (this->profiler_enabled && is_env_enabled(value)) {
                this->profiler_cpp_post_process = true;
            }
            break;
        }

        // TT_METAL_PROFILER_SUM
        // Enables sum profiling.
        // Default: false (sum profiling disabled)
        // Usage: export TT_METAL_PROFILER_SUM=1
        case EnvVarID::TT_METAL_PROFILER_SUM: {
            if (this->profiler_enabled && is_env_enabled(value)) {
                this->profiler_sum = true;
            }
            break;
        }

        // TT_METAL_PROFILER_ACCUMULATE
        // Accumulate kernel invocations in per-RISC L1 (main zones use the growing index), flush to DRAM when nearly
        // full, read residual via DRAM_AND_L1. Default: false Usage: export TT_METAL_PROFILER_ACCUMULATE=1
        case EnvVarID::TT_METAL_PROFILER_ACCUMULATE: {
            if (this->profiler_enabled && is_env_enabled(value)) {
                this->profiler_accumulate = true;
            }
            break;
        }

        // TT_METAL_NOC_DEBUG_POLL_INTERVAL_MS
        // How often the NOC debug dump background thread polls the device for stalled cores. Lower values unblock
        // stalled cores sooner at the cost of more NoC/PCIe traffic.
        // Default: 500
        // Usage: export TT_METAL_NOC_DEBUG_POLL_INTERVAL_MS=250
        case EnvVarID::TT_METAL_NOC_DEBUG_POLL_INTERVAL_MS: {
            if (value) {
                this->noc_debug_poll_interval = std::chrono::milliseconds(std::stoi(value));
            }
            break;
        }

        // TT_METAL_NOC_DEBUG_FULL_READ_INTERVAL_MS
        // How often the NOC debug dump thread self-triggers a full read, then processes, reports and discharges. This
        // bounds host memory and surfaces issues during a long run. Rounded up to a whole number of poll intervals.
        // Set to 0 to disable the self-triggered full read (events are then only processed on a user read or at
        // device close).
        // Default: 4000
        // Usage: export TT_METAL_NOC_DEBUG_FULL_READ_INTERVAL_MS=10000
        case EnvVarID::TT_METAL_NOC_DEBUG_FULL_READ_INTERVAL_MS: {
            if (value) {
                this->noc_debug_full_read_interval = std::chrono::milliseconds(std::stoi(value));
            }
            break;
        }

        // TT_METAL_NOC_DEBUG_WATERMARK_MARGIN_MS
        // Bounded-lateness margin used when processing NOC debug events mid-run: events newer than
        // (latest seen - margin) are held back so a momentarily-stalled core cannot have a cross-core violation
        // judged before its earlier event arrives. MUST exceed TT_METAL_NOC_DEBUG_POLL_INTERVAL_MS, which bounds the
        // worst-case record-to-host latency; this is validated at debug-dump thread start.
        // Default: 3000
        // Usage: export TT_METAL_NOC_DEBUG_WATERMARK_MARGIN_MS=5000
        case EnvVarID::TT_METAL_NOC_DEBUG_WATERMARK_MARGIN_MS: {
            if (value) {
                this->noc_debug_watermark_margin = std::chrono::milliseconds(std::stoi(value));
            }
            break;
        }

        // TT_METAL_PROFILER_PROGRAM_SUPPORT_COUNT
        // Specifies the maximum number of programs supported by the profiler.
        // Default: nullopt (uses profiler default)
        // Usage: export TT_METAL_PROFILER_PROGRAM_SUPPORT_COUNT=500
        case EnvVarID::TT_METAL_PROFILER_PROGRAM_SUPPORT_COUNT: {
            if (value) {
                this->profiler_program_support_count = std::stoi(value);
            }
            break;
        }

        // TT_METAL_TRACY_MID_RUN_PUSH
        // Forces Tracy profiler pushes during execution for real-time profiling.
        // Default: false (no mid-run pushes)
        // Usage: export TT_METAL_TRACY_MID_RUN_PUSH=1
        case EnvVarID::TT_METAL_TRACY_MID_RUN_PUSH: this->tracy_mid_run_push = true; break;

        // TT_METAL_PROFILER_DISABLE_DUMP_TO_FILES
        // Disables dumping collected device data to files.
        // Default: false (dump to files)
        // Usage: export TT_METAL_PROFILER_DISABLE_DUMP_TO_FILES=1
        case EnvVarID::TT_METAL_PROFILER_DISABLE_DUMP_TO_FILES: {
            if (is_env_enabled(value)) {
                this->profiler_disable_dump_to_files = true;
            }
            break;
        }

        // TT_METAL_PROFILER_DISABLE_PUSH_TO_TRACY
        // Disables pushing collected device data to Tracy GUI.
        // Default: false (push to Tracy GUI)
        // Usage: export TT_METAL_PROFILER_DISABLE_PUSH_TO_TRACY=1
        case EnvVarID::TT_METAL_PROFILER_DISABLE_PUSH_TO_TRACY: {
            // Only disable pushing to Tracy GUI if device profiler is also enabled
            if (this->profiler_enabled && is_env_enabled(value)) {
                this->profiler_disable_push_to_tracy = true;
            }
            break;
        }

        // TT_METAL_NOC_DEBUG_DUMP
        // Enable experimental NOC debug dump mode. In this mode,
        // the profiler infrastructure will be used to continuously dump NOC debug packets to a file. Default: false
        // (debug dump mode disabled) Usage: export TT_METAL_NOC_DEBUG_DUMP=1
        case EnvVarID::TT_METAL_NOC_DEBUG_DUMP: {
#if !defined(TRACY_ENABLE)
            if (is_env_enabled(value)) {
                log_warning(
                    tt::LogMetal,
                    "TT_METAL_NOC_DEBUG_DUMP=1 requires a Tracy-enabled build (build with ENABLE_TRACY=ON). "
                    "Ignoring; NOC debug events will not be collected.");
            }
#else
            if (is_env_enabled(value)) {
                this->set_experimental_noc_debug_dump_enabled(true);
            }
#endif
            break;
        }

        // TT_METAL_GTEST_NUM_HW_CQS
        // Number of hardware command queues to use in tests.
        // Default: 1
        // Usage: export TT_METAL_GTEST_NUM_HW_CQS=4
        case EnvVarID::TT_METAL_GTEST_NUM_HW_CQS: try { this->set_num_hw_cqs(std::stoi(value));
            } catch (const std::invalid_argument& ia) {
                TT_THROW("Invalid TT_METAL_GTEST_NUM_HW_CQS: {}", value);
            } catch (const std::out_of_range&) {
                TT_THROW("TT_METAL_GTEST_NUM_HW_CQS value out of range: {}", value);
            }
            break;

        // TT_METAL_ARC_DEBUG_BUFFER_SIZE
        // Buffer size in DRAM for storing ARC processor debug samples.
        // Default: 0 (disabled)
        // Usage: export TT_METAL_ARC_DEBUG_BUFFER_SIZE=1024
        case EnvVarID::TT_METAL_ARC_DEBUG_BUFFER_SIZE: sscanf(value, "%u", &this->arc_debug_buffer_size); break;

        // TT_METAL_OPERATION_TIMEOUT_SECONDS
        // Timeout duration for device operations in seconds.
        // Default: 0.0 (no timeout)
        // Usage: export TT_METAL_OPERATION_TIMEOUT_SECONDS=30.0
        case EnvVarID::TT_METAL_OPERATION_TIMEOUT_SECONDS: {
            float timeout_duration = std::stof(value);
            this->timeout_duration_for_operations = std::chrono::duration<float>(timeout_duration);
            break;
        }

        // TT_METAL_DISPATCH_TIMEOUT_COMMAND_TO_EXECUTE
        // Terminal command to execute on dispatch timeout.
        // Default: "" (no command)
        // Usage: export TT_METAL_DISPATCH_TIMEOUT_COMMAND_TO_EXECUTE=./tools/tt-triage.py
        case EnvVarID::TT_METAL_DISPATCH_TIMEOUT_COMMAND_TO_EXECUTE:
            this->dispatch_timeout_command_to_execute = std::string(value);
            break;

        // TT_METAL_DISPATCH_PROGRESS_UPDATE_MS
        // Dispatch kernel progress update period in milliseconds.
        // Default: 100ms
        // Usage: export TT_METAL_DISPATCH_PROGRESS_UPDATE_MS=200
        case EnvVarID::TT_METAL_DISPATCH_PROGRESS_UPDATE_MS:
            this->dispatch_progress_update_ms = std::stoul(value);
            break;

        // TT_METAL_DISPATCH_TELEMETRY_DISABLE
        // Disable dispatch telemetry.
        // Default: false (dispatch telemetry enabled)
        // Usage: export TT_METAL_DISPATCH_TELEMETRY_DISABLE=1
        case EnvVarID::TT_METAL_DISPATCH_TELEMETRY_DISABLE:
            this->dispatch_telemetry_disabled = is_env_enabled(value);
            break;

        // ========================================
        // WATCHER SYSTEM
        // ========================================

        // TT_METAL_WATCHER
        // Enables the watcher system for debugging. When set, enables watcher on all features.
        // Default: disabled
        // Usage: export TT_METAL_WATCHER=1
        case EnvVarID::TT_METAL_WATCHER: {
            int sleep_val = 0;
            sscanf(value, "%d", &sleep_val);
            if (strstr(value, "ms") == nullptr) {
                sleep_val *= 1000;
            }
            this->watcher_settings.enabled = true;
            this->watcher_settings.interval_ms = sleep_val;
            break;
        }

        // TT_METAL_WATCHER_DUMP_ALL
        // Enables dumping all watcher data, including potentially unsafe state information.
        // Default: false (safe data only)
        // Usage: export TT_METAL_WATCHER_DUMP_ALL=1
        case EnvVarID::TT_METAL_WATCHER_DUMP_ALL: this->watcher_settings.dump_all = true; break;

        // TT_METAL_WATCHER_APPEND
        // Enables append mode for watcher output files instead of overwriting.
        // Default: false (overwrite mode)
        // Usage: export TT_METAL_WATCHER_APPEND=1
        case EnvVarID::TT_METAL_WATCHER_APPEND: this->watcher_settings.append = true; break;

        // TT_METAL_WATCHER_NOINLINE
        // Disables inlining for watcher functions to reduce binary size.
        // Default: false (inlining enabled)
        // Usage: export TT_METAL_WATCHER_NOINLINE=1
        case EnvVarID::TT_METAL_WATCHER_NOINLINE: this->watcher_settings.noinline = true; break;

        // TT_METAL_WATCHER_PHYS_COORDS
        // Uses physical coordinates in watcher output instead of logical coordinates.
        // Default: false (logical coordinates)
        // Usage: export TT_METAL_WATCHER_PHYS_COORDS=1
        case EnvVarID::TT_METAL_WATCHER_PHYS_COORDS: this->watcher_settings.phys_coords = true; break;

        // TT_METAL_WATCHER_TEXT_START
        // Includes text start information in watcher output for debugging.
        // Default: false (no text start info)
        // Usage: export TT_METAL_WATCHER_TEXT_START=1
        case EnvVarID::TT_METAL_WATCHER_TEXT_START: this->watcher_settings.text_start = true; break;

        // TT_METAL_WATCHER_SKIP_LOGGING
        // Disables watcher logging to reduce overhead.
        // Default: false (logging enabled)
        // Usage: export TT_METAL_WATCHER_SKIP_LOGGING=1
        case EnvVarID::TT_METAL_WATCHER_SKIP_LOGGING: this->watcher_settings.skip_logging = true; break;

        // TT_METAL_WATCHER_DISABLE_ASSERT
        // Disables watcher assert feature when set to any value.
        // Default: enabled
        // Usage: export TT_METAL_WATCHER_DISABLE_ASSERT=1
        case EnvVarID::TT_METAL_WATCHER_DISABLE_ASSERT:
            this->watcher_disabled_features.insert(this->watcher_assert_str);
            break;

        // TT_METAL_WATCHER_DISABLE_PAUSE
        // Disables watcher pause feature when set to any value.
        // Default: enabled
        // Usage: export TT_METAL_WATCHER_DISABLE_PAUSE=1
        case EnvVarID::TT_METAL_WATCHER_DISABLE_PAUSE:
            this->watcher_disabled_features.insert(this->watcher_pause_str);
            break;

        // TT_METAL_WATCHER_DISABLE_RING_BUFFER
        // Disables watcher ring buffer feature when set to any value.
        // Default: enabled
        // Usage: export TT_METAL_WATCHER_DISABLE_RING_BUFFER=1
        case EnvVarID::TT_METAL_WATCHER_DISABLE_RING_BUFFER:
            this->watcher_disabled_features.insert(this->watcher_ring_buffer_str);
            break;

        // TT_METAL_WATCHER_DISABLE_STACK_USAGE
        // Disables watcher stack usage tracking when set to any value.
        // Default: enabled
        // Usage: export TT_METAL_WATCHER_DISABLE_STACK_USAGE=1
        case EnvVarID::TT_METAL_WATCHER_DISABLE_STACK_USAGE:
            this->watcher_disabled_features.insert(this->watcher_stack_usage_str);
            break;

        // TT_METAL_WATCHER_DISABLE_SANITIZE_NOC
        // Disables watcher NoC sanitization when set to any value.
        // Default: enabled
        // Usage: export TT_METAL_WATCHER_DISABLE_SANITIZE_NOC=1
        case EnvVarID::TT_METAL_WATCHER_DISABLE_SANITIZE_NOC:
            this->watcher_disabled_features.insert(this->watcher_noc_sanitize_str);
            break;

        // TT_METAL_WATCHER_DISABLE_SANITIZE_READ_ONLY_L1
        // Disables watcher read-only L1 sanitization when set to any value.
        // Default: enabled
        // Usage: export TT_METAL_WATCHER_DISABLE_SANITIZE_READ_ONLY_L1=1
        case EnvVarID::TT_METAL_WATCHER_DISABLE_SANITIZE_READ_ONLY_L1:
            this->watcher_disabled_features.insert(this->watcher_sanitize_read_only_l1_str);
            break;

        // TT_METAL_WATCHER_DISABLE_SANITIZE_WRITE_ONLY_L1
        // Disables watcher write-only L1 sanitization when set to any value.
        // Default: enabled
        // Usage: export TT_METAL_WATCHER_DISABLE_SANITIZE_WRITE_ONLY_L1=1
        case EnvVarID::TT_METAL_WATCHER_DISABLE_SANITIZE_WRITE_ONLY_L1:
            this->watcher_disabled_features.insert(this->watcher_sanitize_write_only_l1_str);
            break;

        // TT_METAL_WATCHER_DISABLE_WAYPOINT
        // Disables watcher waypoint feature when set to any value.
        // Default: enabled
        // Usage: export TT_METAL_WATCHER_DISABLE_WAYPOINT=1
        case EnvVarID::TT_METAL_WATCHER_DISABLE_WAYPOINT:
            this->watcher_disabled_features.insert(this->watcher_waypoint_str);
            break;

        // TT_METAL_WATCHER_DISABLE_DISPATCH
        // Disables watcher dispatch feature when set to any value.
        // Default: enabled
        // Usage: export TT_METAL_WATCHER_DISABLE_DISPATCH=1
        case EnvVarID::TT_METAL_WATCHER_DISABLE_DISPATCH:
            this->watcher_disabled_features.insert(this->watcher_dispatch_str);
            break;

        // TT_METAL_WATCHER_DISABLE_ETH
        // Disables watcher on ethernet cores when set to any value.
        // Default: enabled
        // Usage: export TT_METAL_WATCHER_DISABLE_ETH=1
        case EnvVarID::TT_METAL_WATCHER_DISABLE_ETH:
            this->watcher_disabled_features.insert(this->watcher_eth_str);
            break;

        // TT_METAL_WATCHER_DISABLE_CB_SANITIZE
        // Disables watcher circular buffer out-of-bounds sanitization when set to any value.
        // Default: enabled
        // Usage: export TT_METAL_WATCHER_DISABLE_CB_SANITIZE=1
        case EnvVarID::TT_METAL_WATCHER_DISABLE_CB_SANITIZE:
            this->watcher_disabled_features.insert(this->watcher_cb_sanitize_str);
            break;

        // TT_METAL_WATCHER_ENABLE_NOC_SANITIZE_LINKED_TRANSACTION
        // Enables NoC sanitization for linked transactions to catch more subtle errors.
        // Default: false (linked transaction sanitization disabled)
        // Usage: export TT_METAL_WATCHER_ENABLE_NOC_SANITIZE_LINKED_TRANSACTION=1
        case EnvVarID::TT_METAL_WATCHER_ENABLE_NOC_SANITIZE_LINKED_TRANSACTION:
            this->watcher_settings.noc_sanitize_linked_transaction = true;
            break;

        // ========================================
        // INSPECTOR
        // ========================================

        // TT_METAL_INSPECTOR
        // Enables or disables the inspector system. Set to '0' to disable, any other value enables it.
        // Default: true (enabled)
        // Usage: export TT_METAL_INSPECTOR=1
        case EnvVarID::TT_METAL_INSPECTOR:
            this->inspector_settings.enabled = true;
            if (strcmp(value, "0") == 0) {
                this->inspector_settings.enabled = false;
            }
            break;

        // TT_METAL_INSPECTOR_INITIALIZATION_IS_IMPORTANT
        // Controls whether initialization is considered important for inspector. Set to '0' to disable.
        // Default: false (not important)
        // Usage: export TT_METAL_INSPECTOR_INITIALIZATION_IS_IMPORTANT=1
        case EnvVarID::TT_METAL_INSPECTOR_INITIALIZATION_IS_IMPORTANT:
            this->inspector_settings.initialization_is_important = true;
            if (strcmp(value, "0") == 0) {
                this->inspector_settings.initialization_is_important = false;
            }
            break;

        // TT_METAL_INSPECTOR_WARN_ON_WRITE_EXCEPTIONS
        // Controls whether to warn on write exceptions in inspector. Set to '0' to disable warnings.
        // Default: true (warnings enabled)
        // Usage: export TT_METAL_INSPECTOR_WARN_ON_WRITE_EXCEPTIONS=0
        case EnvVarID::TT_METAL_INSPECTOR_WARN_ON_WRITE_EXCEPTIONS:
            this->inspector_settings.warn_on_write_exceptions = true;
            if (strcmp(value, "0") == 0) {
                this->inspector_settings.warn_on_write_exceptions = false;
            }
            break;

        // TT_METAL_RISCV_DEBUG_INFO
        // Enable RISC-V debug info. Defaults to inspector setting, override with 0/1.
        // Default: Inherits from inspector setting
        // Usage: export TT_METAL_RISCV_DEBUG_INFO=1  # or =0 to disable
        case EnvVarID::TT_METAL_RISCV_DEBUG_INFO: {
            bool enable_riscv_debug_info = this->get_inspector_enabled();  // Default from inspector
            if (value) {
                enable_riscv_debug_info = true;  // Default to true if set
                if (strcmp(value, "0") == 0) {
                    enable_riscv_debug_info = false;  // Only "0" = false
                }
            }
            this->set_riscv_debug_info_enabled(enable_riscv_debug_info);
            break;
        }

        // TT_METAL_JIT_ANALYTICS_
        // Enable JIT compiler state information. Disable state by default; override with 1.
        // Default: '0', or disable
        // Usage: export TT_METAL_JIT_ANALYTICS=1  # in disable state by default
        case EnvVarID::TT_METAL_JIT_ANALYTICS: {
            jit_analytics_enabled = false;
            if (value) {
                if (strcmp(value, "1") == 0) {
                    jit_analytics_enabled = true;
                }
            }
            this->set_jit_analytics_enabled(jit_analytics_enabled);
            break;
        }

        // TT_METAL_INSPECTOR_RPC_SERVER_ADDRESS
        // Sets the RPC server address for the inspector. Format: "host:port" or just "host" (uses default port).
        // Default: localhost:50051
        // Usage: export TT_METAL_INSPECTOR_RPC_SERVER_ADDRESS=127.0.0.1:8080
        case EnvVarID::TT_METAL_INSPECTOR_RPC_SERVER_ADDRESS: {
            // Parse address into host and port
            std::string addr(value);
            size_t colon_pos = addr.find(':');
            if (colon_pos != std::string::npos) {
                this->inspector_settings.rpc_server_host = addr.substr(0, colon_pos);
                try {
                    this->inspector_settings.rpc_server_port = std::stoi(addr.substr(colon_pos + 1));
                } catch (const std::invalid_argument&) {
                    TT_THROW("Invalid port in TT_METAL_INSPECTOR_RPC_SERVER_ADDRESS: {}", value);
                } catch (const std::out_of_range&) {
                    TT_THROW("Port out of range in TT_METAL_INSPECTOR_RPC_SERVER_ADDRESS: {}", value);
                }
            } else {
                this->inspector_settings.rpc_server_host = addr;
            }
            break;
        }

        // TT_METAL_INSPECTOR_RPC
        // Enables or disables the inspector RPC server. Set to '0' to disable, any other value enables it.
        // Default: true (enabled)
        // Usage: export TT_METAL_INSPECTOR_RPC=1
        case EnvVarID::TT_METAL_INSPECTOR_RPC:
            this->inspector_settings.rpc_server_enabled = true;
            if (std::strncmp(value, "0", 1) == 0) {
                this->inspector_settings.rpc_server_enabled = false;
            }
            break;

        // TT_METAL_INSPECTOR_SERIALIZE_ON_DISPATCH_TIMEOUT
        // Enables serialization of inspector state on dispatch timeout. Set to '0' to disable.
        // Default: true (enabled)
        // Usage: export TT_METAL_INSPECTOR_SERIALIZE_ON_DISPATCH_TIMEOUT=1
        case EnvVarID::TT_METAL_INSPECTOR_SERIALIZE_ON_DISPATCH_TIMEOUT:
            this->inspector_settings.serialize_on_dispatch_timeout = true;
            if (std::strncmp(value, "0", 1) == 0) {
                this->inspector_settings.serialize_on_dispatch_timeout = false;
            }
            break;

        // TT_METAL_INSPECTOR_CAPTURE_TENSOR_SPECS
        // Controls whether tensor specs are captured on every op dispatch.
        // Default: true (enabled). Set to 0 to disable.
        // Usage: export TT_METAL_INSPECTOR_CAPTURE_TENSOR_SPECS=1
        case EnvVarID::TT_METAL_INSPECTOR_CAPTURE_TENSOR_SPECS:
            this->inspector_settings.capture_tensor_specs = true;
            if (std::strncmp(value, "0", 1) == 0) {
                this->inspector_settings.capture_tensor_specs = false;
            }
            break;

        // TT_METAL_INSPECTOR_LOG_RUNTIME_ENTRIES
        // Enables logging of runtime entries (operation name, parameters, runtime ID) to YAML.
        // WARNING: This is expensive and will cause significant log file growth.
        // Default: false (disabled)
        // Usage: export TT_METAL_INSPECTOR_LOG_RUNTIME_ENTRIES=1
        case EnvVarID::TT_METAL_INSPECTOR_LOG_RUNTIME_ENTRIES:
            this->inspector_settings.log_runtime_entries = false;
            if (strcmp(value, "1") == 0) {
                this->inspector_settings.log_runtime_entries = true;
            }
            break;

        // TT_METAL_INSPECTOR_LOG_MESH_BUFFERS
        // Enables logging of every MeshBuffer construction and destruction to YAML.
        // WARNING: This is expensive. Buffers churn orders of magnitude faster than programs, so the log
        // grows very quickly and each event costs a flushed write.
        // Default: false (disabled)
        // Usage: export TT_METAL_INSPECTOR_LOG_MESH_BUFFERS=1
        case EnvVarID::TT_METAL_INSPECTOR_LOG_MESH_BUFFERS:
            this->inspector_settings.log_mesh_buffers = false;
            if (strcmp(value, "1") == 0) {
                this->inspector_settings.log_mesh_buffers = true;
            }
            break;

        // TT_METAL_INSPECTOR_LOG_MESH_SOCKETS
        // Enables logging of every MeshSocket creation and destruction to YAML.
        // Default: false (disabled)
        // Usage: export TT_METAL_INSPECTOR_LOG_MESH_SOCKETS=1
        case EnvVarID::TT_METAL_INSPECTOR_LOG_MESH_SOCKETS:
            this->inspector_settings.log_mesh_sockets = false;
            if (strcmp(value, "1") == 0) {
                this->inspector_settings.log_mesh_sockets = true;
            }
            break;

        // ========================================
        // DEBUG PRINTING (DPRINT)
        // ========================================
        // Note: Most DPRINT variables are handled by ParseFeatureEnv() in constructor
        // These cases exist for documentation and potential future direct handling

        // TT_METAL_DPRINT_CORES
        // Specifies worker cores for debug printing. Supports 'all', ranges '(1,1)-(2,2)', or lists '(1,1),(2,2)'.
        // Default: disabled (no debug printing)
        // Usage: export TT_METAL_DPRINT_CORES=all
        case EnvVarID::TT_METAL_DPRINT_CORES:
            // Handled by ParseFeatureEnv() - this is for documentation
            break;

        // TT_METAL_DPRINT_ETH_CORES
        // Specifies Ethernet cores for debug printing. Same syntax as DPRINT_CORES.
        // Default: disabled (no debug printing on ETH cores)
        // Usage: export TT_METAL_DPRINT_ETH_CORES=(0,0),(1,0)
        case EnvVarID::TT_METAL_DPRINT_ETH_CORES:
            // Handled by ParseFeatureEnv() - this is for documentation
            break;

        // TT_METAL_DPRINT_DRAM_CORES
        // Specifies DRAM programmable cores (Blackhole DRISC) for debug printing. Same syntax as DPRINT_CORES.
        // Default: disabled (no debug printing on DRAM cores)
        // Usage: export TT_METAL_DPRINT_DRAM_CORES=all
        case EnvVarID::TT_METAL_DPRINT_DRAM_CORES:
            // Handled by ParseFeatureEnv() - this is for documentation
            break;

        // TT_METAL_DPRINT_DISPATCH_CORES
        // Specifies Quasar dispatch-engine cores (CoreType::DISPATCH, synthetic logical coords (index,0)) for
        // debug printing. Same syntax as DPRINT_CORES (e.g. 'all', 'dispatch', '(0,0)').
        // Default: disabled (no debug printing on dispatch-engine cores)
        // Usage: export TT_METAL_DPRINT_DISPATCH_CORES=all
        case EnvVarID::TT_METAL_DPRINT_DISPATCH_CORES:
            // Handled by ParseFeatureEnv() - this is for documentation
            break;

        // TT_METAL_DPRINT_CHIPS
        // Specifies chip IDs for debug printing. Supports 'all' or comma-separated list of chip IDs.
        // Mutually exclusive with TT_METAL_DPRINT_NODES and TT_METAL_DPRINT_MESH_COORDS.
        // Default: all chips
        // Usage: export TT_METAL_DPRINT_CHIPS=0,1,2
        case EnvVarID::TT_METAL_DPRINT_CHIPS:
            // Handled by ParseFeatureEnv() - this is for documentation
            break;

        // TT_METAL_DPRINT_NODES
        // Specifies fabric node IDs for debug printing. Supports 'all' or comma-separated list of node IDs.
        // Mutually exclusive with TT_METAL_DPRINT_MESH_COORDS and TT_METAL_DPRINT_CHIPS.
        // Default: all nodes
        // Usage: export TT_METAL_DPRINT_NODES="(M0,D0),(M0,D1)"
        case EnvVarID::TT_METAL_DPRINT_NODES:
            // Handled by ParseFeatureEnv() - this is for documentation
            break;

        // TT_METAL_DPRINT_MESH_COORDS
        // Specifies devices by (row,col) in the global system mesh.
        // Mutually exclusive with TT_METAL_DPRINT_CHIPS and TT_METAL_DPRINT_NODES.
        // Default: all chips
        // Usage: export TT_METAL_DPRINT_MESH_COORDS="(0,0),(1,3)"
        case EnvVarID::TT_METAL_DPRINT_MESH_COORDS:
            // Handled by ParseFeatureEnv() - this is for documentation
            break;

        // TT_METAL_DPRINT_RISCVS
        // Specifies RISC-V processors for debug printing. Complex processor selection syntax.
        // Default: all RISC-V processors
        // Usage: export TT_METAL_DPRINT_RISCVS=BR+NCRISC+TRISC0
        case EnvVarID::TT_METAL_DPRINT_RISCVS:
            // Handled by ParseFeatureEnv() - this is for documentation
            break;

        // TT_METAL_DPRINT_FILE
        // Output file path for debug printing. If not specified, prints to stdout.
        // Default: stdout
        // Usage: export TT_METAL_DPRINT_FILE=/tmp/debug_output.log
        case EnvVarID::TT_METAL_DPRINT_FILE:
            // Handled by ParseFeatureEnv() - this is for documentation
            break;

        // TT_METAL_DPRINT_ONE_FILE_PER_RISC
        // Creates separate output files for each RISC-V processor when set.
        // Default: false (single output file)
        // Usage: export TT_METAL_DPRINT_ONE_FILE_PER_RISC=1
        case EnvVarID::TT_METAL_DPRINT_ONE_FILE_PER_RISC:
            // Handled by ParseFeatureEnv() - this is for documentation
            break;

        // TT_METAL_DPRINT_PREPEND_DEVICE_CORE_RISC
        // Prepends device/core/RISC information to each debug print line. Set to '0' to disable.
        // Default: true (prepend enabled)
        // Usage: export TT_METAL_DPRINT_PREPEND_DEVICE_CORE_RISC=0
        case EnvVarID::TT_METAL_DPRINT_PREPEND_DEVICE_CORE_RISC:
            // Handled by ParseFeatureEnv() - this is for documentation
            break;

        // TT_METAL_LIGHTWEIGHT_KERNEL_ASSERTS
        // Enables lightweight kernel assertions. If watcher asserts are enabled, they take precedence.
        // Default: false (disabled)
        // Usage: export TT_METAL_LIGHTWEIGHT_KERNEL_ASSERTS=1
        case EnvVarID::TT_METAL_LIGHTWEIGHT_KERNEL_ASSERTS: this->lightweight_kernel_asserts = true; break;

        // TT_METAL_LLK_ASSERTS
        // Enables LLK assertions. If watcher asserts are enabled, they take precedence.
        // Default: false (disabled)
        // Usage: export TT_METAL_LLK_ASSERTS=1
        case EnvVarID::TT_METAL_LLK_ASSERTS: this->enable_llk_asserts = true; break;

        // ========================================
        // LLK SANITIZER
        // ========================================
        // TT_METAL_LLK_SANITIZER
        // Enables the LLK sanitizer (master switch).
        // Default: false (disabled)
        // Usage: export TT_METAL_LLK_SANITIZER=1
        case EnvVarID::TT_METAL_LLK_SANITIZER: {
            this->sanitizer_settings.enabled = is_env_enabled(value);
            break;
        }

        // TT_METAL_LLK_SANITIZER_PEDANTIC
        // Usage: export TT_METAL_LLK_SANITIZER_PEDANTIC=1
        case EnvVarID::TT_METAL_LLK_SANITIZER_PEDANTIC:
            this->sanitizer_settings.pedantic = is_env_enabled(value);
            break;

        // TT_METAL_LLK_SANITIZER_WARN
        // Usage: export TT_METAL_LLK_SANITIZER_WARN=1
        case EnvVarID::TT_METAL_LLK_SANITIZER_WARN: this->sanitizer_settings.warn = is_env_enabled(value); break;

        // TT_METAL_LLK_SANITIZER_ERROR
        // Usage: export TT_METAL_LLK_SANITIZER_ERROR=1
        case EnvVarID::TT_METAL_LLK_SANITIZER_ERROR: this->sanitizer_settings.error = is_env_enabled(value); break;

        // TT_METAL_LLK_SANITIZER_INFO
        // Usage: export TT_METAL_LLK_SANITIZER_INFO=1
        case EnvVarID::TT_METAL_LLK_SANITIZER_INFO: this->sanitizer_settings.info = is_env_enabled(value); break;

        // TT_METAL_LLK_SANITIZER_FAULT
        // Usage: export TT_METAL_LLK_SANITIZER_FAULT=1
        case EnvVarID::TT_METAL_LLK_SANITIZER_FAULT: this->sanitizer_settings.fault = is_env_enabled(value); break;

        // TT_METAL_LLK_SANITIZER_INTERNAL
        // Enables LLK developer internal mode.
        // Usage: export TT_METAL_LLK_SANITIZER_INTERNAL=1
        case EnvVarID::TT_METAL_LLK_SANITIZER_INTERNAL:
            this->sanitizer_settings.internal = is_env_enabled(value);
            break;

        // ========================================
        // DEVICE MANAGER
        // ========================================
        // TT_METAL_NUMA_BASED_AFFINITY
        // Specifies thread binding in DeviceManager
        // Default: disabled
        // Usage: export TT_METAL_NUMA_BASED_AFFINITY=1
        case EnvVarID::TT_METAL_NUMA_BASED_AFFINITY: {
            this->numa_based_affinity = is_env_enabled(value);
            break;
        }

        // ========================================
        // FABRIC CONFIGURATION
        // ========================================
        // TT_METAL_FABRIC_ROUTER_SYNC_TIMEOUT_MS
        // Timeout in milliseconds for fabric router sync
        // Default: 5000ms
        // Usage: export TT_METAL_FABRIC_ROUTER_SYNC_TIMEOUT_MS=8000
        case EnvVarID::TT_METAL_FABRIC_ROUTER_SYNC_TIMEOUT_MS:
            try {
                int parsed_value = std::stoi(value);
                if (parsed_value < 0) {
                    TT_THROW("TT_METAL_FABRIC_ROUTER_SYNC_TIMEOUT_MS must be non-negative: {}", value);
                }
                this->fabric_router_sync_timeout_ms = static_cast<uint32_t>(parsed_value);
            } catch (const std::invalid_argument& ia) {
                TT_THROW("Invalid TT_METAL_FABRIC_ROUTER_SYNC_TIMEOUT_MS: {}", value);
            } catch (const std::out_of_range&) {
                TT_THROW("TT_METAL_FABRIC_ROUTER_SYNC_TIMEOUT_MS value out of range: {}", value);
            }
            break;

        // TT_METAL_FABRIC_OPT_LEVEL
        // Override the compiler optimization level for fabric router kernels.
        // When set, this overrides the automatic VC1-based selection.
        // Default: not set (automatic: O3 when VC1 inactive, Os when VC1 active)
        // Usage: export TT_METAL_FABRIC_OPT_LEVEL=O3  (or O0, O1, O2, Os, Oz, Ofast)
        case EnvVarID::TT_METAL_FABRIC_OPT_LEVEL: {
            auto opt = enchantum::cast<tt::tt_metal::KernelBuildOptLevel>(std::string_view(value));
            if (opt.has_value()) {
                this->fabric_kernel_opt_level = opt;
                log_info(tt::LogMetal, "Fabric kernel optimization level override: -{}", value);
            } else {
                TT_THROW(
                    "Invalid TT_METAL_FABRIC_OPT_LEVEL value: '{}'. Valid values: O0, O1, O2, O3, Os, Oz, Ofast",
                    value);
            }
            break;
        }

        // TT_TOPOLOGY_SOLVER_ENGINE
        // If set to sat/1/true/yes, topology mapping uses the SAT backend when solver_engine is Auto (same rule as
        // tt::tt_fabric::topology_mapping_use_sat_engine). Value is snapshotted here at Metal init.
        // Usage: export TT_TOPOLOGY_SOLVER_ENGINE=sat
        case EnvVarID::TT_TOPOLOGY_SOLVER_ENGINE: {
            const std::string lowered = to_lower_copy(trim_copy(std::string(value)));
            this->topology_mapping_use_sat_engine_ =
                lowered == "sat" || lowered == "1" || lowered == "true" || lowered == "yes";
            break;
        }

        // TT_METAL_DISABLE_XIP_DUMP
        // Disable XIP dump
        // Default: false
        // Usage: export TT_METAL_DISABLE_XIP_DUMP=1
        case EnvVarID::TT_METAL_DISABLE_XIP_DUMP: {
            this->disable_xip_dump = is_env_enabled(value);
            break;
        }

        // TT_METAL_BACKEND_DUMP_RUN_CMD
        // Dump JIT build commands to stdout for debugging kernel compilation.
        // Default: false
        // Usage: export TT_METAL_BACKEND_DUMP_RUN_CMD=1
        case EnvVarID::TT_METAL_BACKEND_DUMP_RUN_CMD: this->dump_build_commands = is_env_enabled(value); break;

        // TT_METAL_DISABLE_PRECOMPILED_FW
        // Disable use of pre-compiled firmware and force JIT compilation instead.
        // Default: false
        // Usage: export TT_METAL_DISABLE_PRECOMPILED_FW=1
        case EnvVarID::TT_METAL_DISABLE_PRECOMPILED_FW: this->set_disable_precompiled_fw(is_env_enabled(value)); break;

        // TT_METAL_FW_SRC_BRISC
        // Select a BRISC firmware extension.
        // A non-empty value also disables the precompiled firmware.
        // Default: unset
        // Usage: export TT_METAL_FW_SRC_BRISC=blaze
        case EnvVarID::TT_METAL_FW_SRC_BRISC: {
            if (value != nullptr && *value != '\0') {
                const std::string variant = to_lower_copy(trim_copy(value));
                TT_FATAL(
                    variant == "blaze", "Unsupported TT_METAL_FW_SRC_BRISC value '{}'; supported values: blaze", value);
                this->brisc_firmware_variant = BriscFirmwareVariant::Blaze;
                this->set_disable_precompiled_fw(true);
            }
            break;
        }

        // TT_METAL_FW_HEADER_BRISC
        // Absolute or working-directory-relative header supplied by the selected BRISC firmware variant.
        // Default: unset
        // Usage: export TT_METAL_FW_HEADER_BRISC=/path/to/blaze/firmware/runtime_reload.h
        case EnvVarID::TT_METAL_FW_HEADER_BRISC: {
            const std::string header = trim_copy(value);
            if (!header.empty()) {
                const auto path = std::filesystem::absolute(header).lexically_normal();
                TT_FATAL(
                    std::filesystem::is_regular_file(path),
                    "TT_METAL_FW_HEADER_BRISC '{}' is not a file",
                    path.string());
                TT_FATAL(path.filename() == "runtime_reload.h", "TT_METAL_FW_HEADER_BRISC must name runtime_reload.h");
                this->brisc_firmware_header = path.string();
            }
            break;
        }

        // TT_METAL_DEVICE_PRINT_DISPATCH_STALL_US
        // Period in microseconds between dispatch_s DEVICE_PRINT stall-detection passes.
        // Default: 50
        case EnvVarID::TT_METAL_DEVICE_PRINT_DISPATCH_STALL_US:
            this->device_print_dispatch_stall_us = std::stoul(value);
            break;

        // TT_METAL_DEVICE_PRINT_DISPATCH_FULL_US
        // Period in microseconds between dispatch_s DEVICE_PRINT full-dispatch passes.
        // Default: 100000 (100 ms)
        case EnvVarID::TT_METAL_DEVICE_PRINT_DISPATCH_FULL_US:
            this->device_print_dispatch_full_us = std::stoul(value);
            break;

        // TT_METAL_DEVICE_PRINT_DISPATCH_L1_CACHE_BYTES
        // Override the dispatch_s DEVICE_PRINT dispatch L1 cache buffer size (bytes).
        // 0 (default) means use the per-arch HAL default. Set this if dispatch_s logs
        // that aggregation self-disabled because the cache was too small.
        case EnvVarID::TT_METAL_DEVICE_PRINT_DISPATCH_L1_CACHE_BYTES:
            this->device_print_dispatch_l1_cache_bytes = std::stoul(value);
            break;

        // TT_METAL_ALLOCATOR_MODE_HYBRID
        // Enable hybrid lockstep + per-core L1 allocator mode.
        // Default: false (lockstep-only allocation)
        // Usage: export TT_METAL_ALLOCATOR_MODE_HYBRID=1
        case EnvVarID::TT_METAL_ALLOCATOR_MODE_HYBRID: this->allocator_mode_hybrid = is_env_enabled(value); break;

        // These process-wide settings are parsed together by get_trace_allocation_options(). That snapshot may be
        // initialized before this instance exists and is explicitly touched at the start of the constructor.
        case EnvVarID::TT_METAL_TRACE_ALLOC_TRACKING:
        case EnvVarID::TT_METAL_TRACE_ALLOC_TRACEBACKS:
        case EnvVarID::TT_METAL_TRACE_ALLOC_SKIP_PROGRAM_CACHE: break;

        // TT_METAL_SHM_TRACKING_DISABLED
        // Disable shared memory tracking for tt-smi.
        // Default: 0 (SHM tracking enabled)
        // Usage: export TT_METAL_SHM_TRACKING_DISABLED=1
        case EnvVarID::TT_METAL_SHM_TRACKING_DISABLED: this->shm_tracking_disabled = is_env_enabled(value); break;

        // TT_METAL_SHM_VERBOSE
        // Enable verbose logging for SHM tracking.
        // Default: 0 (disabled)
        // Usage: export TT_METAL_SHM_VERBOSE=1
        case EnvVarID::TT_METAL_SHM_VERBOSE: this->shm_verbose = is_env_enabled(value); break;
    }
}

void RunTimeOptions::InitializeFromEnvVars() {
    // Use enchantum to automatically iterate over all EnvVarID enum values
    for (const auto [id, name] : enchantum::entries_generator<EnvVarID>) {
        const char* value = std::getenv(std::string(name).c_str());

        // Only process if the environment variable is set
        if (value) {
            HandleEnvVar(id, value);
        }
    }

    if (this->brisc_firmware_variant == BriscFirmwareVariant::Blaze) {
        TT_FATAL(!this->brisc_firmware_header.empty(), "TT_METAL_FW_SRC_BRISC=blaze requires TT_METAL_FW_HEADER_BRISC");
    } else {
        TT_FATAL(this->brisc_firmware_header.empty(), "TT_METAL_FW_HEADER_BRISC requires TT_METAL_FW_SRC_BRISC=blaze");
    }

    // Validate emulated mode configuration
    if (this->runtime_target_device_ == tt::TargetDevice::Emule && this->mock_cluster_desc_path.empty()) {
        TT_THROW("TT_METAL_EMULE_MODE=1 requires TT_METAL_MOCK_CLUSTER_DESC_PATH to be set");
    }

    // Set inspector log path
    this->inspector_settings.log_path = std::filesystem::path(this->get_logs_dir()) / "generated/inspector";

    // TT_METAL_RISCV_DEBUG_INFO: Inherit from inspector if not explicitly set
    if (std::getenv("TT_METAL_RISCV_DEBUG_INFO") == nullptr) {
        HandleEnvVar(EnvVarID::TT_METAL_RISCV_DEBUG_INFO, nullptr);
    }

    // TT_METAL_JIT_ANALYTICS: Inherit from inspector if not explicitly set
    if (std::getenv("TT_METAL_JIT_ANALYTICS") == nullptr) {
        HandleEnvVar(EnvVarID::TT_METAL_JIT_ANALYTICS, nullptr);
    }
    ParseWatcherEnv();
}

void RunTimeOptions::ParseWatcherEnv() {
    // Auto unpause is for testing only, no env var.
    watcher_settings.auto_unpause = false;

    // Any watcher features to disabled based on env var.
    std::set all_features = {
        watcher_waypoint_str,
        watcher_noc_sanitize_str,
        watcher_assert_str,
        watcher_pause_str,
        watcher_ring_buffer_str,
        watcher_stack_usage_str,
        watcher_dispatch_str,
        watcher_eth_str,
        watcher_eth_link_status_str,
        watcher_cb_sanitize_str};
    for (const std::string& feature : all_features) {
        std::string env_var("TT_METAL_WATCHER_DISABLE_");
        env_var += feature;
        if (getenv(env_var.c_str()) != nullptr) {
            watcher_disabled_features.insert(feature);
        }
    }

    const char* watcher_debug_delay_str = getenv("TT_METAL_WATCHER_DEBUG_DELAY");
    if (watcher_debug_delay_str != nullptr) {
        sscanf(watcher_debug_delay_str, "%u", &watcher_debug_delay);
        // Assert watcher is also enabled (TT_METAL_WATCHER=1)
        TT_ASSERT(watcher_settings.enabled, "TT_METAL_WATCHER_DEBUG_DELAY requires TT_METAL_WATCHER");
        // Assert TT_METAL_WATCHER_DISABLE_NOC_SANITIZE is either not set or set to 0
        TT_ASSERT(
            !watcher_disabled_features.contains(watcher_noc_sanitize_str),
            "TT_METAL_WATCHER_DEBUG_DELAY requires TT_METAL_WATCHER_DISABLE_NOC_SANITIZE=0");
    }
    if (watcher_settings.noc_sanitize_linked_transaction) {
        TT_ASSERT(
            !watcher_disabled_features.contains(watcher_noc_sanitize_str),
            "TT_METAL_WATCHER_ENABLE_NOC_SANITIZE_LINKED_TRANSACTION requires TT_METAL_WATCHER_DISABLE_NOC_SANITIZE=0");
    }
}

void RunTimeOptions::ParseFabricTelemetryEnv(const char* value) {
    auto disable_telemetry = [&]() {
        set_enable_fabric_telemetry(false);
        fabric_telemetry_settings = FabricTelemetrySettings{};
    };

    if (value == nullptr) {
        disable_telemetry();
        return;
    }

    std::string spec = trim_copy(value);
    if (spec.empty() || spec == "0") {
        disable_telemetry();
        return;
    }

    FabricTelemetrySettings parsed_settings{};
    parsed_settings.enabled = true;
    set_enable_fabric_telemetry(true);

    if (spec == "1") {
        fabric_telemetry_settings = parsed_settings;
        return;
    }

    auto handle_required_entries = [&](bool condition, const char* key) {
        if (!condition) {
            TT_THROW("TT_METAL_FABRIC_TELEMETRY {}= requires at least one entry", key);
        }
    };

    auto parse_uint32_selection =
        [&](const std::string& raw_value, FabricTelemetrySelection<uint32_t>& selection, const char* key) {
            if (raw_value.empty() || equals_all(raw_value)) {
                selection.set_monitor_all(true);
                return;
            }
            selection.set_monitor_all(false);
            selection.ids.clear();
            std::stringstream value_stream(raw_value);
            std::string token;
            bool parsed_any = false;
            while (std::getline(value_stream, token, ',')) {
                token = trim_copy(token);
                if (token.empty()) {
                    continue;
                }
                int parsed_value = parse_int_token<int>(token, key);
                if (parsed_value < 0) {
                    TT_THROW("TT_METAL_FABRIC_TELEMETRY {}= requires non-negative IDs", key);
                }
                parsed_any = true;
                selection.ids.insert(static_cast<uint32_t>(parsed_value));
            }
            handle_required_entries(parsed_any, key);
        };

    std::stringstream section_stream(spec);
    std::string section;
    while (std::getline(section_stream, section, ';')) {
        section = trim_copy(section);
        if (section.empty()) {
            continue;
        }

        auto eq_pos = section.find('=');
        if (eq_pos == std::string::npos) {
            TT_THROW("Invalid TT_METAL_FABRIC_TELEMETRY segment '{}'. Expected key=value.", section);
        }

        std::string key = trim_copy(section.substr(0, eq_pos));
        std::string raw_value = trim_copy(section.substr(eq_pos + 1));
        std::string key_lower = to_lower_copy(key);

        if (key_lower == "chips") {
            parse_uint32_selection(raw_value, parsed_settings.chips, key_lower.c_str());
        } else if (key_lower == "eth") {
            parse_uint32_selection(raw_value, parsed_settings.channels, key_lower.c_str());
        } else if (key_lower == "erisc") {
            parse_uint32_selection(raw_value, parsed_settings.eriscs, key_lower.c_str());
        } else if (key_lower == "stats") {
            if (raw_value.empty() || equals_all(raw_value)) {
                parsed_settings.stats_mask = FabricTelemetrySettings::kAllStatsMask;
                continue;
            }
            parsed_settings.stats_mask = 0;
            std::replace(raw_value.begin(), raw_value.end(), '|', ',');
            std::stringstream stats_stream(raw_value);
            std::string stats_token;
            while (std::getline(stats_stream, stats_token, ',')) {
                stats_token = trim_copy(stats_token);
                if (stats_token.empty()) {
                    continue;
                }
                std::string upper = to_upper_copy(stats_token);
                if (upper == "ROUTER_STATE") {
                    parsed_settings.stats_mask |= static_cast<uint8_t>(DynamicStatistics::ROUTER_STATE);
                } else if (upper == "BANDWIDTH") {
                    parsed_settings.stats_mask |= static_cast<uint8_t>(DynamicStatistics::BANDWIDTH);
                } else if (upper == "HEARTBEAT_TX") {
                    parsed_settings.stats_mask |= static_cast<uint8_t>(DynamicStatistics::HEARTBEAT_TX);
                } else if (upper == "HEARTBEAT_RX") {
                    parsed_settings.stats_mask |= static_cast<uint8_t>(DynamicStatistics::HEARTBEAT_RX);
                } else {
                    parsed_settings.stats_mask |= static_cast<uint8_t>(parse_int_token<int>(stats_token, "stats"));
                }
            }
        } else {
            TT_THROW("Unknown TT_METAL_FABRIC_TELEMETRY key '{}'", key);
        }
    }

    fabric_telemetry_settings = parsed_settings;
}

void RunTimeOptions::ParseAllFeatureEnv(const tt_metal::Hal& hal) {
    for (int i = 0; i < RunTimeDebugFeatureCount; i++) {
        ParseFeatureEnv((RunTimeDebugFeatures)i, hal);
    }
}

void RunTimeOptions::ParseFeatureEnv(RunTimeDebugFeatures feature, const tt_metal::Hal& hal) {
    std::string feature_env_prefix("TT_METAL_");
    feature_env_prefix += RunTimeDebugFeatureNames[feature];

    ParseFeatureCoreRange(feature, feature_env_prefix + "_CORES", CoreType::WORKER);
    ParseFeatureCoreRange(feature, feature_env_prefix + "_ETH_CORES", CoreType::ETH);
    ParseFeatureCoreRange(feature, feature_env_prefix + "_DRAM_CORES", CoreType::DRAM);
    // Quasar dispatch-engine cores (CoreType::DISPATCH) use synthetic logical coords (index, 0). Same
    // syntax as the worker/eth/dram core lists (e.g. "all", "dispatch", "(0,0)").
    ParseFeatureCoreRange(feature, feature_env_prefix + "_DISPATCH_CORES", CoreType::DISPATCH);
    bool chips_specified = ParseFeatureChipIds(feature, feature_env_prefix + "_CHIPS");
    bool nodes_specified = ParseFeatureNodeIds(feature, feature_env_prefix + "_NODES");
    bool mesh_coords_specified = ParseFeatureMeshCoords(feature, feature_env_prefix + "_MESH_COORDS");
    int num_chip_filters_specified =
        static_cast<int>(chips_specified) + static_cast<int>(nodes_specified) + static_cast<int>(mesh_coords_specified);
    if (num_chip_filters_specified > 1) {
        TT_THROW(
            "TT_METAL_{0}_CHIPS, TT_METAL_{0}_NODES, and TT_METAL_{0}_MESH_COORDS are mutually exclusive; "
            "specify at most one.",
            RunTimeDebugFeatureNames[feature]);
    } else if (num_chip_filters_specified == 0) {
        // All chips are enabled if none of the chip filter env vars are set
        feature_targets[feature].all_chips = true;
    }
    ParseFeatureRiscvMask(feature, feature_env_prefix + "_RISCVS", hal);
    ParseFeatureFileName(feature, feature_env_prefix + "_FILE");
    ParseFeatureOneFilePerRisc(feature, feature_env_prefix + "_ONE_FILE_PER_RISC");
    ParseFeaturePrependDeviceCoreRisc(feature, feature_env_prefix + "_PREPEND_DEVICE_CORE_RISC");

    // Set feature enabled if the user asked for any feature cores, chips, or nodes
    feature_targets[feature].enabled = false;
    for (auto& core_type_and_all_flag : feature_targets[feature].all_cores) {
        if (core_type_and_all_flag.second != RunTimeDebugClassNoneSpecified) {
            feature_targets[feature].enabled = true;
        }
    }
    for (auto& core_type_and_cores : feature_targets[feature].cores) {
        if (!core_type_and_cores.second.empty()) {
            feature_targets[feature].enabled = true;
        }
    }

    const char* print_noc_xfers = std::getenv("TT_METAL_RECORD_NOC_TRANSFER_DATA");
    if (print_noc_xfers != nullptr) {
        record_noc_transfer_data = true;
    }
};

void RunTimeOptions::ParseFeatureCoreRange(
    RunTimeDebugFeatures feature, const std::string& env_var, CoreType core_type) {
    char* str = std::getenv(env_var.c_str());
    std::vector<tt::tt_metal::CoreCoord> cores;

    // Check if "all" is specified, rather than a range of cores.
    feature_targets[feature].all_cores[core_type] = RunTimeDebugClassNoneSpecified;
    if (str != nullptr) {
        for (int idx = 0; idx < RunTimeDebugClassCount; idx++) {
            if (strcmp(str, RunTimeDebugClassNames[idx]) == 0) {
                feature_targets[feature].all_cores[core_type] = idx;
                return;
            }
        }
    }
    if (str != nullptr) {
        if (isdigit(str[0])) {
            // Assume this is a single core
            uint32_t x, y;
            if (sscanf(str, "%d,%d", &x, &y) != 2) {
                TT_THROW("Invalid {}", env_var);
            }
            cores.push_back({x, y});
        } else if (str[0] == '(') {
            if (strchr(str, '-')) {
                // Assume this is a range
                tt::tt_metal::CoreCoord start, end;
                if (sscanf(str, "(%zu,%zu)", &start.x, &start.y) != 2) {
                    TT_THROW("Invalid {}", env_var);
                }
                str = strchr(str, '-');
                if (sscanf(str, "-(%zu,%zu)", &end.x, &end.y) != 2) {
                    TT_THROW("Invalid {}", env_var);
                }
                for (uint32_t x = start.x; x <= end.x; x++) {
                    for (uint32_t y = start.y; y <= end.y; y++) {
                        cores.push_back({x, y});
                    }
                }
            } else {
                // Assume this is a list of coordinates (maybe just one)
                while (str != nullptr) {
                    uint32_t x, y;
                    if (sscanf(str, "(%d,%d)", &x, &y) != 2) {
                        TT_THROW("Invalid {}", env_var);
                    }
                    cores.push_back({x, y});
                    str = strchr(str, ',');
                    str = strchr(str + 1, ',');
                    if (str != nullptr) {
                        str++;
                    }
                }
            }
        } else {
            TT_THROW("Invalid {}", env_var);
        }
    }

    // Set the core range
    feature_targets[feature].cores[core_type] = std::move(cores);
}

bool RunTimeOptions::ParseFeatureChipIds(RunTimeDebugFeatures feature, const std::string& env_var) {
    std::vector<int> chips;
    char* env_var_str = std::getenv(env_var.c_str());
    bool specified = env_var_str != nullptr;

    // If the environment variable is not empty, parse it.
    while (env_var_str != nullptr) {
        // Can also have "all"
        if (strcmp(env_var_str, "all") == 0) {
            feature_targets[feature].all_chips = true;
            break;
        }
        uint32_t chip;
        if (sscanf(env_var_str, "%d", &chip) != 1) {
            TT_THROW("Invalid {}", env_var_str);
        }
        chips.push_back(chip);
        env_var_str = strchr(env_var_str, ',');
        if (env_var_str != nullptr) {
            env_var_str++;
        }
    }

    feature_targets[feature].chip_ids = std::move(chips);

    return specified;
}

bool RunTimeOptions::ParseFeatureNodeIds(RunTimeDebugFeatures feature, const std::string& env_var) {
    char* env_var_str = std::getenv(env_var.c_str());
    bool specified = env_var_str != nullptr;
    while (env_var_str != nullptr && *env_var_str != '\0') {
        while (*env_var_str == ' ' || *env_var_str == '"') {
            env_var_str++;
        }
        if (*env_var_str == '\0') {
            break;
        }
        // Can also have "all"
        if (strcmp(env_var_str, "all") == 0) {
            feature_targets[feature].all_chips = true;
            break;
        }
        uint32_t mesh_id, chip_id;
        // Parse format: (M<n>, D<n>) with optional spaces, e.g. (M0, D1)
        if (sscanf(env_var_str, "(M%u , D%u)", &mesh_id, &chip_id) != 2 &&
            sscanf(env_var_str, "(M%u, D%u)", &mesh_id, &chip_id) != 2 &&
            sscanf(env_var_str, "(M%u,D%u)", &mesh_id, &chip_id) != 2) {
            TT_THROW(
                "Invalid format for {}: '{}'. Expected format: (Mn,Dn) or 'all'. Example: (M0,D0),(M0,D1)",
                env_var,
                env_var_str);
        }

        feature_targets[feature].node_ids.push_back(tt_fabric::FabricNodeId(tt_fabric::MeshId{mesh_id}, chip_id));
        env_var_str = strchr(env_var_str, ')');
        if (env_var_str != nullptr) {
            env_var_str++;  // Skip ')'
            while (*env_var_str == ',') {
                env_var_str++;
            }
            if (*env_var_str == '\0') {
                break;
            }
        }
    }
    return specified;
}

bool RunTimeOptions::ParseFeatureMeshCoords(RunTimeDebugFeatures feature, const std::string& env_var) {
    char* env_var_str = std::getenv(env_var.c_str());
    bool specified = env_var_str != nullptr;
    // Clear stale state so repeated parses (e.g. on MetalContext re-init) are deterministic.
    feature_targets[feature].mesh_coords.clear();
    while (env_var_str != nullptr && *env_var_str != '\0') {
        // Skip leading whitespace and quotes
        while (*env_var_str == ' ' || *env_var_str == '"') {
            env_var_str++;
        }
        if (*env_var_str == '\0') {
            break;
        }
        // "all" maps to the same all_chips flag used by the other filters
        if (strcmp(env_var_str, "all") == 0) {
            feature_targets[feature].all_chips = true;
            break;
        }
        uint32_t row, col;
        if (sscanf(env_var_str, "(%u,%u)", &row, &col) != 2 && sscanf(env_var_str, "(%u, %u)", &row, &col) != 2 &&
            sscanf(env_var_str, "(%u , %u)", &row, &col) != 2) {
            TT_THROW(
                "Invalid format for {}: '{}'. Expected (row,col) tuples or 'all'. "
                "Example: (0,0),(1,3)",
                env_var,
                env_var_str);
        }
        auto coord = std::make_pair(row, col);
        auto& coords = feature_targets[feature].mesh_coords;
        if (std::find(coords.begin(), coords.end(), coord) != coords.end()) {
            log_warning(
                tt::LogMetal,
                "{}: coordinate ({},{}) specified more than once, ignoring duplicate.",
                env_var,
                row,
                col);
        } else {
            coords.emplace_back(coord);
        }
        env_var_str = strchr(env_var_str, ')');
        if (env_var_str != nullptr) {
            env_var_str++;  // Skip ')'
            while (*env_var_str == ',') {
                env_var_str++;
            }
        }
    }
    if (specified && !feature_targets[feature].all_chips && feature_targets[feature].mesh_coords.empty()) {
        TT_THROW(
            "{} is set but contains no valid coordinates. "
            "Expected (row,col) tuples or 'all'. Example: (0,0),(1,3)",
            env_var);
    }
    return specified;
}

void RunTimeOptions::ParseFeatureRiscvMask(
    RunTimeDebugFeatures feature, const std::string& env_var, const tt_metal::Hal& hal) {
    const char* env_var_str = std::getenv(env_var.c_str());

    if (env_var_str != nullptr) {
        feature_targets[feature].processors = hal.parse_processor_set_spec(env_var_str);
    } else {
        auto& processors = feature_targets[feature].processors;
        uint32_t num_core_types = hal.get_programmable_core_type_count();
        for (uint32_t core_type_index = 0; core_type_index < num_core_types; ++core_type_index) {
            auto core_type = hal.get_programmable_core_type(core_type_index);
            uint32_t num_processors = hal.get_num_risc_processors(core_type);
            for (uint32_t processor_index = 0; processor_index < num_processors; ++processor_index) {
                processors.add(core_type, processor_index);
            }
        }
    }
}

void RunTimeOptions::ParseFeatureFileName(RunTimeDebugFeatures feature, const std::string& env_var) {
    char* env_var_str = std::getenv(env_var.c_str());
    feature_targets[feature].file_name = (env_var_str != nullptr) ? std::string(env_var_str) : "";
}

void RunTimeOptions::ParseFeatureOneFilePerRisc(RunTimeDebugFeatures feature, const std::string& env_var) {
    char* env_var_str = std::getenv(env_var.c_str());
    feature_targets[feature].one_file_per_risc = (env_var_str != nullptr);
}

void RunTimeOptions::ParseFeaturePrependDeviceCoreRisc(RunTimeDebugFeatures feature, const std::string& env_var) {
    char* env_var_str = std::getenv(env_var.c_str());
    feature_targets[feature].prepend_device_core_risc =
        (env_var_str != nullptr) ? (strcmp(env_var_str, "1") == 0) : true;
}

std::string RunTimeOptions::get_watcher_hash() const {
    // These values will cause kernels / firmware to be recompiled if they change
    // Only the ones which have #define on the device side need to be listed here
    std::string hash_str;
    hash_str += std::to_string(watcher_feature_disabled(watcher_waypoint_str));
    hash_str += std::to_string(watcher_feature_disabled(watcher_noc_sanitize_str));
    hash_str += std::to_string(watcher_feature_disabled(watcher_assert_str));
    hash_str += std::to_string(watcher_feature_disabled(watcher_pause_str));
    hash_str += std::to_string(watcher_feature_disabled(watcher_ring_buffer_str));
    hash_str += std::to_string(watcher_feature_disabled(watcher_stack_usage_str));
    hash_str += std::to_string(watcher_feature_disabled(watcher_dispatch_str));
    hash_str += std::to_string(watcher_feature_disabled(watcher_eth_str));
    hash_str += std::to_string(watcher_feature_disabled(watcher_cb_sanitize_str));
    hash_str += std::to_string(get_watcher_noc_sanitize_linked_transaction());
    hash_str += std::to_string(get_watcher_enabled());
    hash_str += std::to_string(get_lightweight_kernel_asserts());
    hash_str += std::to_string(get_llk_asserts());
    return hash_str;
}

std::string RunTimeOptions::get_sanitizer_hash() const {
    auto optional_hash = [](const std::optional<bool>& optional) {
        return optional.has_value() ? std::to_string(*optional) : "nullopt";
    };

    const auto& san = get_sanitizer_settings();
    std::string hash_str;
    hash_str += std::to_string(san.enabled);
    hash_str += optional_hash(san.pedantic);
    hash_str += optional_hash(san.warn);
    hash_str += optional_hash(san.error);
    hash_str += optional_hash(san.info);
    hash_str += optional_hash(san.fault);
    hash_str += optional_hash(san.internal);
    return hash_str;
}

void RunTimeOptions::set_experimental_noc_debug_dump_enabled(bool enabled) {
    if (enabled) {
        profiler_enabled = true;
        profiler_noc_events_enabled = true;
        experimental_noc_debug_dump_enabled = true;
    } else {
        profiler_enabled = false;
        profiler_noc_events_enabled = false;
        experimental_noc_debug_dump_enabled = false;
    }
}

void RunTimeOptions::resolve_fabric_node_ids_to_chip_ids(const tt::tt_fabric::ControlPlane& control_plane) {
    for (auto& target : feature_targets) {
        if (!target.node_ids.empty()) {
            // Clear the chip IDs because the chip ID from fabric node IDs come from the MGD which can change
            // during runtime
            // We only allowed specifying chip ID xor node ID so clearing the chip IDs is safe
            target.chip_ids.clear();
            std::unordered_set<int> seen_chip_ids;
            for (const auto& node_id : target.node_ids) {
                ChipId chip_id = control_plane.get_physical_chip_id_from_fabric_node_id(node_id);
                int chip_id_int = static_cast<int>(chip_id);
                if (seen_chip_ids.insert(chip_id_int).second) {
                    target.chip_ids.push_back(chip_id_int);
                    fmt::print("Resolved fabric node ID {} to chip ID {}\n", node_id, chip_id_int);
                }
            }
        }
    }
}

void RunTimeOptions::resolve_mesh_coords_to_chip_ids(const tt::tt_metal::distributed::SystemMesh& system_mesh) {
    for (auto& target : feature_targets) {
        if (target.mesh_coords.empty()) {
            continue;
        }

        // Explicit coord list overrides the "all chips" mode.
        target.all_chips = false;

        const tt::tt_metal::distributed::MeshShape& mesh_shape = system_mesh.shape();
        const tt::tt_metal::distributed::SystemMesh::MappedDevices mapped =
            system_mesh.get_mapped_devices(std::nullopt);

        target.chip_ids.clear();
        std::unordered_set<int> seen_chip_ids;

        for (const auto& [row, col] : target.mesh_coords) {
            // Bounds check — done here because we didn't have the shape at parse time.
            TT_FATAL(
                row < mesh_shape[0] && col < mesh_shape[1],
                "TT_METAL_DPRINT_MESH_COORDS ({},{}) is out of bounds for system mesh shape {}x{}",
                row,
                col,
                mesh_shape[0],
                mesh_shape[1]);

            tt::tt_metal::distributed::MeshCoordinate coord(row, col);
            size_t linear_index = coord.to_linear_index(mapped.mesh_shape);
            const auto& maybe_device_id = mapped.device_ids[linear_index];

            if (!maybe_device_id.is_local()) {
                log_warning(
                    tt::LogMetal,
                    "DPRINT_MESH_COORDS ({},{}) corresponds to a device on a remote host; "
                    "skipping for this process.",
                    row,
                    col);
                continue;
            }

            int chip_id = *maybe_device_id;
            if (seen_chip_ids.insert(chip_id).second) {
                target.chip_ids.push_back(chip_id);
                log_info(tt::LogMetal, "Resolved DPRINT_MESH_COORDS ({},{}) to chip ID {}", row, col, chip_id);
            }
        }
    }
}

}  // namespace tt::llrt

// NOLINTEND(bugprone-branch-clone)
