// SPDX-FileCopyrightText: © 2023 Tenstorrent USA, Inc.
//
// SPDX-License-Identifier: Apache-2.0

#include "build.hpp"

#include "build_cache_telemetry.hpp"
#include "jit_build_cache.hpp"
#include "jit_device_config.hpp"

#include <fcntl.h>
#include <sys/file.h>
#include <unistd.h>

#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <exception>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
#include <mutex>
#include <string>
#include <string_view>
#include <unordered_map>
#include <vector>

#include "hostdev/profiler_zone_id.h"

#include <enchantum/enchantum.hpp>
#include <fmt/base.h>
#include <fmt/format.h>
#include <fmt/ranges.h>
#include <taskflow/core/async.hpp>

#include <tt_stl/assert.hpp>
#include "common/executor.hpp"
#include "common/stable_hash.hpp"
#include "env_lib.hpp"
#include "hal_types.hpp"
#include "llrt/hal.hpp"
#include "hostdev/profiler_common.h"
#include "llrt/rtoptions.hpp"
#include "jit_build/kernel_args.hpp"
#include "jit_build/depend.hpp"
#include "jit_build_settings.hpp"
#include "jit_build_utils.hpp"
#include "pch.hpp"
#include <tt-logger/tt-logger.hpp>
#include "profiler_paths.hpp"
#include "tt_metal/llrt/tt_elffile.hpp"
#include <umd/device/types/arch.hpp>
#include "tt_metal/tools/profiler/tracy_debug_zones.hpp"

namespace fs = std::filesystem;

using namespace std;

namespace tt::tt_metal {

namespace {

// Hands out the tu_id half of a structural zone id (hostdev/profiler_zone_id.h) as -DTT_PROFILER_TU_ID.
// Ids must be unique across TUs and stable across runs (a cached ELF keeps the id in its .tt_zone_meta),
// hence a file. The key is source identity plus build target: one source compiled for BRISC vs NCRISC can
// number its zones differently. Compile-time args are left out to keep the registry bounded; two
// define-variants of one source then share a tu_id, which the host reports as a collision rather than
// mis-naming. Append-only "<source_id>\t<tu_id>" lines, lowest free id; flock() covers parallel builds
// sharing a cache root, the mutex covers the JIT's own thread pool.
uint32_t get_or_assign_profiler_tu_id(const std::string& registry_path, const std::string& source_id) {
    static std::mutex mtx;
    std::lock_guard<std::mutex> lk(mtx);

    struct RegistryLock {
        int fd;
        explicit RegistryLock(const std::string& path) : fd(::open(path.c_str(), O_RDWR | O_CREAT, 0644)) {
            TT_FATAL(fd >= 0, "Failed to open profiler zone tu-id registry '{}': {}", path, std::strerror(errno));
            if (::flock(fd, LOCK_EX) != 0) {
                int err = errno;
                ::close(fd);
                TT_THROW("Failed to lock profiler zone tu-id registry '{}': {}", path, std::strerror(err));
            }
        }
        ~RegistryLock() {
            ::flock(fd, LOCK_UN);
            ::close(fd);
        }
    } registry_lock(registry_path);

    std::vector<bool> taken(TT_ZONE_TU_COUNT, false);
    {
        std::ifstream in(registry_path);
        std::string line;
        while (std::getline(in, line)) {
            auto tab = line.rfind('\t');
            if (tab == std::string::npos) {
                continue;
            }
            uint32_t entry_id = 0;
            try {
                entry_id = static_cast<uint32_t>(std::stoul(line.substr(tab + 1)));
            } catch (const std::exception&) {
                continue;
            }
            if (entry_id >= TT_ZONE_TU_COUNT) {
                continue;  // assigned when the tu split was wider
            }
            if (line.compare(0, tab, source_id) == 0) {
                return entry_id;
            }
            taken[entry_id] = true;
        }
    }

    taken[TT_ZONE_RESERVED_TU] = true;
    uint32_t id = 0;
    while (id < TT_ZONE_TU_COUNT && taken[id]) {
        ++id;
    }
    TT_FATAL(
        id < TT_ZONE_TU_COUNT,
        "Profiler zone tu-id space ({} ids) is exhausted. Delete '{}' to compact it; ids are re-derived from "
        "each build's ELFs, so nothing is lost by resetting it.",
        TT_ZONE_TU_COUNT,
        registry_path);

    std::ofstream out(registry_path, std::ios::app);
    out << source_id << '\t' << id << '\n';
    out.flush();
    TT_FATAL(out.good(), "Failed to persist profiler zone tu-id registry entry to '{}'", registry_path);
    return id;
}

void report_result(const string& target_name, string_view op, const string& cmd, const string& log_file, bool result) {
    if (!result) {
        log_error(tt::LogBuildKernels, "{} {} failure -- cmd: {}", target_name, op, cmd);
    }

    std::ifstream file{log_file};
    if (file.is_open()) {
        std::string log_contents{std::istreambuf_iterator<char>(file), std::istreambuf_iterator<char>()};
        if (!result) {
            TT_THROW("{} build failed. Log: {}", target_name, log_contents);
        }
        if (!log_contents.empty()) {
            // Don't mix warnings from parallel compilations.
            static std::mutex mutex;
            std::lock_guard lock(mutex);
            std::cerr << "Building " << target_name << ", " << op << " step:\n" << cmd << "\n" << log_contents;
        }
    } else if (!result) {
        TT_THROW("Failed to open {} failure log file {}", op, log_file);
    }
}

void hard_link_or_copy(const std::filesystem::path& target, const std::filesystem::path& link) {
    std::error_code ec;
    std::filesystem::create_hard_link(target, link, ec);
    if (!ec) {
        return;
    }
    // Fall back to copying, but use the non-throwing overload so a failure is
    // reported with both paths and both error codes instead of escaping as a bare
    // std::filesystem_error.
    //
    // Note we deliberately do NOT treat an already-existing `link` as reusable, even
    // when it is already equivalent to `target`. Temp object names are per-process
    // (see FileRenamer::generate_temp_path) and the caller removes them once linking
    // finishes, so adopting another process's temp file would let that process delete
    // it while our LTO link still has it open.
    const std::error_code link_ec = ec;
    ec.clear();
    std::filesystem::copy_file(target, link, fs::copy_options::overwrite_existing, ec);
    if (ec) {
        TT_THROW(
            "Failed to hard link or copy {} to {}: copy failed with '{}' (hard link failed with '{}')",
            target.string(),
            link.string(),
            ec.message(),
            link_ec.message());
    }
}

}  // namespace

std::string get_default_root_path() {
    const std::string emptyString;
    const std::string home_path = parse_env<std::string>("HOME", emptyString);
    if (!home_path.empty() && std::filesystem::exists(home_path)) {
        return home_path + "/.cache/tt-metal-cache/";
    }
    return "/tmp/tt-metal-cache/";
}

std::string get_cache_root(const llrt::RunTimeOptions& rtoptions) {
    return rtoptions.is_cache_dir_specified() ? rtoptions.get_cache_dir() : get_default_root_path();
}

JitBuildEnv::JitBuildEnv() = default;

void JitBuildEnv::init(
    uint64_t build_key,
    const JitDeviceConfig& config,
    const tt::llrt::RunTimeOptions& rtoptions,
    const std::map<std::string, std::string>& device_kernel_defines) {
    this->rtoptions_ = &rtoptions;
    // Paths
    this->root_ = rtoptions.get_root_dir();
    this->out_root_ = get_cache_root(rtoptions);

    this->arch_ = config.arch;
    this->max_dfbs_ = config.max_dfbs;

    // Tools
    const static bool use_ccache = std::getenv("TT_METAL_CCACHE_KERNEL_SUPPORT") != nullptr;
    if (use_ccache) {
        // ccache requires sloppiness settings for both PCH creation and consumption
        this->gpp_ = "ccache sloppiness=pch_defines,time_macros ";
    } else {
        this->gpp_ = "";
    }

    // Use local sfpi for development
    // Use system sfpi for production to avoid packaging it
    // Ordered by precedence
    const std::array<std::string, 2> sfpi_roots = {this->root_ + "runtime/sfpi", "/opt/tenstorrent/sfpi"};

    bool sfpi_found = false;
    for (unsigned i = 0; i < 2; ++i) {
        auto gxx = sfpi_roots[i] + "/compiler/bin/riscv-tt-elf-g++";
        if (std::filesystem::exists(gxx)) {
            this->gpp_ += gxx + " ";
            this->gpp_include_dir_ = sfpi_roots[i] + "/include";
            log_debug(tt::LogBuildKernels, "Using {} sfpi at {}", i ? "system" : "local", sfpi_roots[i]);
            sfpi_found = true;
            break;
        }
    }
    if (!sfpi_found) {
        TT_THROW("sfpi not found at {} or {}", sfpi_roots[0], sfpi_roots[1]);
    }

    // Flags
    string common_flags =
        // Use C++17, plus some specific C++20 features we've enabled
        "-std=c++17 -ftt-nttp -ftt-constinit -ftt-consteval "
        // Ban dynamic initializations, via a check we've added
        "-ftt-no-dyninit "
        // Rely on Link Time Optimization (removes globally unreachable code).
        // Partitioning and job count are pinned rather than left to -flto=auto: the JIT
        // scheduler already builds ~30 kernels at once, and with no make jobserver to
        // consult 'auto' resolves to the host CPU count, letting each of those links fan
        // out on top of it. A single partition is what kernels this size already produce,
        // so pinning holds current behavior instead of leaving it to a size threshold.
        "-flto=1 -flto-partition=one "
        // Fast math allows non-IEEE compliant optimizations ...
        "-ffast-math "
        // ... but we require these IEEE behaviors
        "-fno-finite-math-only -fsigned-zeros -fno-associative-math "
        // No exceptions or rtti emission, and no using cxa-atexit for cleanups
        "-fno-exceptions -fno-rtti -fno-use-cxa-atexit ";

    if (rtoptions.get_jit_analytics_enabled()) {
        common_flags += "-fdump-rtl-all -fdump-tree-original ";
    }

    if (rtoptions.get_riscv_debug_info_enabled()) {
        common_flags += "-g ";
    }

    this->cflags_ = common_flags;
    this->cflags_ +=
        "-MMD "
        // Extra warnings and make them fatal
        "-Wall -Werror "
        // But don't die for these warnings
        "-Wno-error=deprecated-declarations "
        "-Wno-error=multistatement-macros -Wno-error=parentheses "
        "-Wno-error=unused-but-set-variable "
        // And don't detect these issues
        "-Wno-unused-variable -Wno-unused-function "
        // Firmware and kernels access mailboxes and MMIO through pointers
        // formed from small literal addresses (e.g. MEM_MAILBOX_BASE is 16
        // on Wormhole). On these bare-metal cores the bottom of the address
        // space is ordinary L1 memory, but GCC assumes no object can live in
        // the first page and -Warray-bounds diagnoses such accesses as
        // "source object is likely at address zero", which -Werror makes
        // fatal. (With -flto the literal address is not visible during
        // per-TU compilation, so today this only fires if LTO is disabled;
        // see issue #54692.) min-pagesize=0 tells GCC that constant
        // addresses from zero up are valid objects, disabling exactly that
        // heuristic while keeping -Warray-bounds active for genuine
        // out-of-bounds accesses. It is a diagnostics-only parameter with no
        // effect on generated code.
        "--param=min-pagesize=0 ";

    // Defines
    this->defines_ = "";
    for (const auto& device_kernel_define : device_kernel_defines) {
        this->defines_ += "-D" + device_kernel_define.first + "=" + device_kernel_define.second + " ";
    }
    this->defines_ += "-DTENSIX_FIRMWARE -DLOCAL_MEM_EN=0 ";

    if (rtoptions.get_profiler_enabled()) {
        uint32_t profiler_options = 1;
        if (rtoptions.get_profiler_do_dispatch_cores()) {
            profiler_options |= PROFILER_OPT_DO_DISPATCH_CORES;
        }
        if (rtoptions.get_profiler_trace_only()) {
            profiler_options |= PROFILER_OPT_DO_TRACE_ONLY;
        }
        if (rtoptions.get_profiler_sum()) {
            profiler_options |= PROFILER_OPT_DO_SUM;
        }
        if (rtoptions.get_profiler_accumulate()) {
            profiler_options |= PROFILER_OPT_DO_ACCUMULATE;
        }
        this->defines_ += "-DPROFILE_KERNEL=" + std::to_string(profiler_options) + " ";

        this->defines_ += "-DPROFILER_FULL_HOST_BUFFER_SIZE_PER_RISC=" +
                          std::to_string(config.profiler_dram_bank_size_per_risc_bytes) + " ";
    }
    if (rtoptions.get_streaming_profiler_enabled()) {
        // Streaming profiler. Mutually exclusive with get_profiler_enabled() (rtoptions
        // TT_FATALs on both), so this branch never stacks on the one above. PROFILE_KERNEL=1 keeps every
        // DeviceZoneScopedN / DeviceTimestampedData site compiled; PROFILE_STREAMING makes
        // tools/profiler/kernel_profiler.hpp select the SPSC producer (kernel_profiler_streaming.hpp) instead of
        // the DRAM one. No DRAM options (dispatch cores, trace-only, sum, accumulate) apply here.
        TT_FATAL(
            this->arch_ != tt::ARCH::QUASAR,
            "TT_METAL_STREAMING_PROFILER is not supported on Quasar: the streaming profiler needs a DRISC "
            "drainer, which Quasar does not have. Use TT_METAL_DEVICE_PROFILER instead.");
        this->defines_ += "-DPROFILE_KERNEL=1 -DPROFILE_STREAMING=1 ";
        if (rtoptions.get_streaming_profiler_sync_events_enabled()) {
            // Enable synchronization-event instrumentation (tools/profiler/synchronization_event_profiler.hpp)
            // Note: only enabled with streaming profiler.
            this->defines_ += "-DPROFILE_SYNC_EVENTS=1 ";
        }
        if (rtoptions.get_streaming_profiler_inline_enabled()) {
            this->defines_ += "-DPROFILE_INLINE_ENABLED=1 ";
        }
    }
    if (rtoptions.get_profiler_noc_events_enabled()) {
        // force profiler on if noc events are being profiled
        if (!rtoptions.get_profiler_enabled()) {
            this->defines_ += "-DPROFILE_KERNEL=1 ";
        }
        this->defines_ += "-DPROFILE_NOC_EVENTS=1 ";
    }
    if (rtoptions.get_experimental_noc_debug_dump_enabled()) {
        this->defines_ += "-DDEVICE_DEBUG_DUMP=1 ";
    }
    if (rtoptions.get_profiler_perf_counter_mode() != 0) {
        // force profiler on if perf counters are being captured
        TT_ASSERT(rtoptions.get_profiler_enabled());
        this->defines_ += "-DPROFILE_PERF_COUNTERS=" + std::to_string(rtoptions.get_profiler_perf_counter_mode()) + " ";
    }

    if (rtoptions.get_watcher_enabled()) {
        this->defines_ += "-DWATCHER_ENABLED ";
    }
    if (rtoptions.get_watcher_noinline()) {
        this->defines_ += "-DWATCHER_NOINLINE ";
    }
    if (rtoptions.get_watcher_noc_sanitize_linked_transaction()) {
        this->defines_ += "-DWATCHER_ENABLE_NOC_SANITIZE_LINKED_TRANSACTION ";
    }
    for (const auto& feature : rtoptions.get_watcher_disabled_features()) {
        this->defines_ += "-DWATCHER_DISABLE_" + feature + " ";
    }

    if (rtoptions.get_feature_enabled(tt::llrt::RunTimeDebugFeatureDprint)) {
        this->defines_ += "-DDEBUG_PRINT_ENABLED ";
    }

    if (rtoptions.get_checkpoint_enabled()) {
        this->defines_ += "-DDEBUG_CHECKPOINT_ENABLED ";
    }

    if (rtoptions.get_record_noc_transfers()) {
        this->defines_ += "-DNOC_LOGGING_ENABLED ";
    }

    if (rtoptions.get_kernels_nullified()) {
        this->defines_ += "-DDEBUG_NULL_KERNELS ";
    }

    if (rtoptions.get_kernels_early_return()) {
        this->defines_ += "-DDEBUG_EARLY_RETURN_KERNELS ";
    }

    if (rtoptions.get_measure_dfb_init_time_enabled()) {
        this->defines_ += "-DDFB_INIT_TIMING_ENABLED ";
    }

    if (rtoptions.get_watcher_debug_delay()) {
        this->defines_ += "-DWATCHER_DEBUG_DELAY=" + to_string(rtoptions.get_watcher_debug_delay()) + " ";
    }

    if (rtoptions.get_hw_cache_invalidation_enabled()) {
        this->defines_ += "-DENABLE_HW_CACHE_INVALIDATION ";
    }

    if (rtoptions.get_relaxed_memory_ordering_disabled()) {
        this->defines_ += "-DDISABLE_RELAXED_MEMORY_ORDERING ";
    }

    if (rtoptions.get_gathering_enabled()) {
        this->defines_ += "-DENABLE_GATHERING ";
    }

    if (config.routing_fw_enabled) {
        this->defines_ += "-DROUTING_FW_ENABLED ";
    }

    if (rtoptions.get_lightweight_kernel_asserts()) {
        this->defines_ += "-DLIGHTWEIGHT_KERNEL_ASSERTS ";
    }

    if (rtoptions.get_llk_asserts()) {
        this->defines_ += "-DENABLE_LLK_ASSERT ";
    }

    if (!rtoptions.get_watcher_enabled() && !rtoptions.get_lightweight_kernel_asserts() &&
        rtoptions.get_llk_asserts()) {
        this->defines_ += "-DENABLE_LLK_ASSERT_ONLY ";
    }

    const auto& san = rtoptions.get_sanitizer_settings();

    // sanitizer and checkpoint can't both be enabled because they overlap.
    TT_ASSERT(!san.enabled || !rtoptions.get_checkpoint_enabled());

    if (san.enabled) {
        this->defines_ += "-DLLK_SAN_ENABLE ";

        auto add_sanitizer_toggle = [&](const std::optional<bool>& opt, std::string_view name) {
            if (opt.has_value()) {
                this->defines_ += "-DLLK_SAN_SETTING_" + std::string(name) + "=" + std::to_string(*opt) + " ";
            }
        };

        add_sanitizer_toggle(san.pedantic, "PEDANTIC");
        add_sanitizer_toggle(san.warn, "WARN");
        add_sanitizer_toggle(san.error, "ERROR");
        add_sanitizer_toggle(san.info, "INFO");
        add_sanitizer_toggle(san.fault, "FAULT");
        add_sanitizer_toggle(san.internal, "INTERNAL");
    }

    if (rtoptions.get_disable_sfploadmacro()) {
        this->defines_ += "-DDISABLE_SFPLOADMACRO ";
    }

    // Includes
    // TODO(pgk) this list is insane
    std::vector<std::string> includeDirs = {
        ".",
        "..",
        root_,
        root_ + "ttnn",
        root_ + "ttnn/cpp",
        root_ + "tt_metal",
        root_ + "tt_metal/hw/inc",
        root_ + "tt_metal/tt-llk/common",
        root_ + "tt_metal/tt-llk/tools/include",
        root_ + "tt_metal/hostdevcommon/api",
        root_ + "tt_metal/api/"};

    std::ostringstream oss;
    for (const auto& includeDir : includeDirs) {
        oss << "-I" << includeDir << " ";
    }
    this->includes_ = oss.str();

    this->lflags_ = common_flags;
    this->lflags_ += "-Wl,-z,max-page-size=16 -Wl,-z,common-page-size=16 -nostartfiles ";

    // Need to capture more info in build key to prevent stale binaries from being reused.
    tt::StableHasher hasher;
    hasher.update(build_key);
    hasher.update(enchantum::to_underlying(this->arch_));
    hasher.update(cflags_);
    hasher.update(lflags_);
    hasher.update(defines_);

    if (get_rtoptions().get_build_map_enabled()) {
        // Do not hash compiler version when generating compiler logs
        // so that we may compare them between different compilers
        // without undue difficulty.
    } else {
        hasher.update(tt::jit_build::utils::compiler_version(gpp_));
    }

    build_key_ = hasher.digest();

    this->out_firmware_root_ = fmt::format("{}{}/firmware/", this->out_root_, build_key_);
    this->out_kernel_root_ = fmt::format("{}{}/kernels/", this->out_root_, build_key_);
    this->firmware_binary_root_ = this->out_firmware_root_;
}

JitBuildState::JitBuildState(const JitBuildEnv& env, const JitBuiltStateConfig& build_config, const Hal& hal) :
    env_(env),
    is_fw_(build_config.is_fw),
    process_defines_at_compile_(true),
    out_path_(build_config.is_fw ? env_.out_firmware_root_ : env_.out_kernel_root_),
    cflags_(env.cflags_),
    defines_(env.defines_),
    includes_(env.includes_),
    lflags_(env.lflags_),
    default_compile_opt_level_("Os"),
    default_linker_opt_level_("Os") {
    // Anything that is arch-specific should be added to HalJitBuildQueryInterface instead of here.
    if (build_config.core_type == HalProgrammableCoreType::TENSIX &&
        build_config.processor_class == HalProcessorClassType::COMPUTE) {
        this->default_compile_opt_level_ = "O3";
        this->default_linker_opt_level_ = "O3";
        this->includes_ += "-I" + env_.gpp_include_dir_ + " ";
        this->process_defines_at_compile_ = false;
    } else if (build_config.core_type == HalProgrammableCoreType::ACTIVE_ETH && build_config.is_cooperative) {
        // Only cooperative active ethernet needs "-L <root>/tt_metal/hw/toolchain",
        // because its linker script depends on some files in that directory.
        // Maybe we should move the dependencies to runtime/hw/toolchain/<arch>/?
        fmt::format_to(std::back_inserter(this->lflags_), "-L{}/tt_metal/hw/toolchain/ ", env_.root_);
    }

    HalJitBuildQueryInterface::Params params{
        build_config.is_fw,
        build_config.core_type,
        build_config.processor_class,
        static_cast<uint32_t>(build_config.processor_id),
        env_.get_rtoptions()};
    const auto& jit_build_query = hal.get_jit_build_query();

    this->target_name_ = jit_build_query.target_name(params);
    this->is_compute_pack_ = build_config.core_type == HalProgrammableCoreType::TENSIX &&
                             build_config.processor_class == HalProcessorClassType::COMPUTE &&
                             build_config.processor_id == 2;
    // Per-kernel opt-in flags (applied in export_target_recipe); empty when unsupported.
    this->rvv_cflags_ = jit_build_query.rvv_compile_flags(params);
    // Includes
    {
        auto it = std::back_inserter(this->includes_);
        for (const auto& include : jit_build_query.includes(params)) {
            fmt::format_to(it, "-I{}{} ", env_.root_, include);
        }
    }
    if (build_config.is_fw && build_config.core_type == HalProgrammableCoreType::TENSIX &&
        build_config.processor_class == HalProcessorClassType::DM && build_config.processor_id == 0 &&
        env_.get_rtoptions().get_brisc_firmware_variant() == llrt::BriscFirmwareVariant::Blaze) {
        fmt::format_to(
            std::back_inserter(this->includes_),
            "-I{} ",
            std::filesystem::path(env_.get_rtoptions().get_brisc_firmware_header()).parent_path().string());
    }
    // Defines
    {
        auto it = std::back_inserter(this->defines_);
        for (const auto& define : jit_build_query.defines(params)) {
            fmt::format_to(it, "-D{} ", define);
        }
        fmt::format_to(it, "-DDISPATCH_MESSAGE_ADDR={} ", build_config.dispatch_message_addr);
        if (build_config.fds_signalling) {
            fmt::format_to(it, "-DFDS_SIGNALLING=1 ");
        }
    }
    if (this->is_fw_) {
        this->defines_ += "-DFW_BUILD ";
    } else {
        this->defines_ += "-DKERNEL_BUILD ";
    }
    // Flags
    {
        auto common_flags = jit_build_query.common_flags(params);
        this->cflags_ += common_flags;
        this->lflags_ += common_flags;
    }

    this->linker_script_ = env_.root_ + jit_build_query.linker_script(params);

    // Source files
    {
        auto srcs = jit_build_query.srcs(params);
        this->srcs_.insert(this->srcs_.end(), std::move_iterator(srcs.begin()), std::move_iterator(srcs.end()));
    }
    this->firmware_is_kernel_object_ = jit_build_query.firmware_is_kernel_object(params);

    // Create the objs from the srcs
    for (const string& src : srcs_) {
        fs::path obj_path = fs::path(src).filename().replace_extension(".o");
        this->objs_.push_back(obj_path.string());
        this->temp_objs_.push_back(jit_build::utils::FileRenamer::generate_temp_path(obj_path));
    }

    // Prepend root path to srcs, but not to outputs (objs) due to device dependency.
    // An absolute source path is complete already; that is how an out-of-tree firmware source is
    // named.
    for (string& src : this->srcs_) {
        if (src.empty() || src.front() != '/') {
            src = env_.root_ + src;
        }
    }

    // Append hw build objects compiled offline
    {
        auto it = std::back_inserter(this->extra_link_objs_);
        for (const auto& obj : jit_build_query.link_objs(params)) {
            fmt::format_to(it, "{}{} ", env_.root_, obj);
        }
    }

    // Linker flags
    this->lflags_ += jit_build_query.linker_flags(params);
    this->lflags_ += fmt::format("-T{} ", this->linker_script_);
    if (!this->is_fw_) {
        this->lflags_ += "-Wl,--emit-relocs ";
    }

    // Precompute the weakened firmware path
    {
        auto target_name = jit_build_query.weakened_firmware_target_name(params);
        std::string_view suffix = this->firmware_is_kernel_object_ ? "object.o" : "weakened.elf";
        this->weakened_firmware_name_ =
            fmt::format("{}{}/{}_{}", this->env_.firmware_binary_root_, target_name, target_name, suffix);
    }

    // Note the preceding slash which defies convention as this gets appended to
    // the kernel name used as a path which doesn't have a slash
    this->target_full_path_ = "/" + this->target_name_ + "/" + this->target_name_ + ".elf";

    // Compute a hash of all effective compilation/linking parameters.
    // This captures HAL-populated flags (defines, includes, common_flags, linker_flags, etc.)
    // that are not part of the env-level build_key_.  When any of these change between runs
    // (e.g. after a code change that modifies HAL output), the hash changes and cached
    // objects are invalidated, preventing stale binaries from being reused.
    {
        tt::StableHasher hasher;
        hasher.update(env_.gpp_);
        hasher.update(cflags_);
        hasher.update(defines_);
        hasher.update(includes_);
        hasher.update(lflags_);
        hasher.update(linker_script_);
        hasher.update(extra_link_objs_);
        for (const auto& src : srcs_) {
            hasher.update(src);
        }
        hasher.update(default_compile_opt_level_);
        hasher.update(default_linker_opt_level_);
        // Not part of default recipes, but a change to the HAL's RVV flag string must still
        // invalidate cached opted-in kernels.
        hasher.update(rvv_cflags_);
        build_state_hash_ = hasher.digest();
    }
}

static constexpr std::string_view BUILD_STATE_HASH_FILE = ".build_state";

bool JitBuildState::build_state_matches(const string& out_dir) const {
    std::ifstream file(out_dir + string(BUILD_STATE_HASH_FILE));
    if (!file.is_open()) {
        return false;
    }
    uint64_t stored_hash{};
    file >> stored_hash;
    if (file.fail() || stored_hash != build_state_hash_) {
        log_debug(
            tt::LogBuildKernels,
            "Build state hash mismatch in {}: stored={}, current={}",
            out_dir,
            stored_hash,
            build_state_hash_);
        return false;
    }
    return true;
}

void JitBuildState::write_build_state_hash(const string& out_dir) const {
    jit_build::utils::FileRenamer tmp(out_dir + string(BUILD_STATE_HASH_FILE));
    std::ofstream file(tmp.path());
    file << build_state_hash_;
}

bool JitBuildState::warmed_elf_reusable(std::string_view kernel_name) const {
    // TT_METAL_FORCE_JIT_COMPILE bypasses all reuse; both the local fast path and the remote gate
    // (remote_kernel_cached) consult this predicate, so both recompile when it is set.
    if (env_.get_rtoptions().get_force_jit_compile()) {
        return false;
    }
    // Derive the ELF path from the canonical accessor (the same path the preprocess-and-ship client
    // writes the ELF + sidecar to), so local and remote reuse agree on both location and validity.
    const fs::path elf_path = get_target_out_path(std::string(kernel_name));
    // The sidecar is a sibling of the ELF (<elf>.fulldephash); build_state_matches() appends
    // BUILD_STATE_HASH_FILE to out_dir, so keep the trailing separator.
    const std::string full_dephash = elf_path.string() + std::string(jit_build::FULL_DEPHASH_SUFFIX);
    const std::string out_dir = elf_path.parent_path().string() + "/";
    return fs::exists(elf_path) && fs::exists(full_dephash) && build_state_matches(out_dir) &&
           jit_build::dependencies_up_to_date_file(full_dephash);
}

void JitBuildState::write_reuse_cache(std::string_view kernel_name) const {
    // Write the reuse cache (source-complete FULL_DEPHASH_SUFFIX sidecar + ".build_state") that lets a
    // later run reuse this ELF with no intermediate object. Called only after a successful compile, so
    // the cache never validates against a missing or stale ELF. The dependencies come from the .d files
    // the preprocess-and-ship -E step left in the target dir (which is hash-qualified, so it holds only
    // this build's sources) plus the link inputs, which only this build state knows.
    const fs::path elf_path = get_target_out_path(std::string(kernel_name));
    const std::string out_dir = elf_path.parent_path().string() + "/";

    std::vector<std::string> deps;
    for (const auto& entry : fs::directory_iterator(elf_path.parent_path())) {
        if (entry.path().extension() != ".d") {
            continue;
        }
        std::ifstream d_file(entry.path());
        if (!d_file.is_open()) {
            continue;
        }
        for (auto& [key, dep_list] : jit_build::parse_dependency_file(d_file)) {
            deps.insert(deps.end(), std::make_move_iterator(dep_list.begin()), std::make_move_iterator(dep_list.end()));
        }
    }
    // Link inputs also gate reuse: a changed linker script, firmware, or offline-compiled link object
    // must invalidate the ELF even when no source changed. weakened_firmware_name_ is the real on-disk
    // path (the recipe carries only the bare filename, which the server resolves from its own cache).
    if (!linker_script_.empty()) {
        deps.push_back(linker_script_);
    }
    if (!weakened_firmware_name_.empty()) {
        deps.push_back(weakened_firmware_name_);
    }
    // extra_link_objs_ are offline-built objects linked into the ELF (e.g. Quasar CRT / substitutes);
    // hash their contents so rebuilding one at the same path invalidates the warmed ELF. Stored as a
    // space-separated list of real on-disk paths.
    for (auto& obj : jit_build::utils::tokenize_flags(extra_link_objs_)) {
        deps.push_back(std::move(obj));
    }
    if (deps.empty()) {
        return;
    }
    std::sort(deps.begin(), deps.end());
    deps.erase(std::unique(deps.begin(), deps.end()), deps.end());

    const std::string elf = elf_path.string();
    const std::string full_dephash = elf + std::string(jit_build::FULL_DEPHASH_SUFFIX);
    jit_build::ParsedDependencies deps_map{{elf, std::move(deps)}};
    std::ofstream hash_file(full_dephash);
    jit_build::write_dependency_hashes(deps_map, out_dir, elf, hash_file);
    hash_file.close();
    if (hash_file.fail()) {
        // A genuinely unreadable dependency drops the sidecar, correctly forcing a later recompile.
        fs::remove(full_dephash);
        return;
    }
    write_build_state_hash(out_dir);
}

void JitBuildState::compile_one(const string& out_dir, const JitBuildSettings* settings, size_t src_index) const {
    TTZoneScopedD(JIT);

    // Use the shared recipe and argv builder to pass defines verbatim without shell escaping.
    const tt::jit_build::TargetRecipe recipe = export_target_recipe(settings);

    std::string cflags = recipe.cflags;
    if (env_.get_rtoptions().get_build_map_enabled()) {
        cflags += " -save-temps=obj -fdump-tree-all -fdump-rtl-all";
    }

    // Add the machine-local PCH here so exported recipes remain portable.
    // Exclude build-map dump flags from the PCH profile.
    const std::string pch = tt::jit_build::ensure_pch(
        env_.gpp_,
        recipe.compiler_opt_level,
        recipe.cflags,
        recipe.pch_umbrella,
        fs::path(env_.out_root_) / "pch");

    // Preserve the recipe's defines for watcher logging.
    std::vector<std::string> defines = recipe.defines;
    if (!pch.empty()) {
        // Load the PCH before any other force-included header emits C++ tokens.
        defines.insert(defines.begin(), {"-include", pch});
        // Warn if GCC rejects the PCH, while allowing textual fallback.
        cflags += " -Winvalid-pch -Wno-error=invalid-pch";
    }

    // Per-TU half of the structural device zone id (STREAMING profiler only; the DRAM profiler's 16-bit
    // hash ids need no registry). Kept out of `defines_`/`build_key_` on purpose: a tu_id is a property of
    // the SOURCE, not of the build recipe, so folding it into the cache key would split the cache for no
    // reason. It is stable for a given source identity, so a cached object never disagrees with a freshly
    // compiled one.
    if (env_.get_rtoptions().get_streaming_profiler_enabled()) {
        // Firmware has no JitBuildSettings; its source identity is the source path itself plus the target,
        // which is stable across build configs (out_dir is not -- it carries the build key, and keying on it
        // would mint a fresh tu_id per config for the same source).
        const std::string source_id = (settings != nullptr)
                                          ? settings->get_profiler_zone_src_id() + '\x1f' + this->target_name_
                                          : "fw\x1f" + this->srcs_[src_index] + '\x1f' + this->target_name_;
        const uint32_t tu_id =
            get_or_assign_profiler_tu_id(env_.get_out_root_path() + ".profiler_zone_tu_ids", source_id);
        defines.push_back(fmt::format("-DTT_PROFILER_TU_ID={}", tu_id));
    }

    const std::string obj_path = out_dir + this->objs_[src_index];
    const std::string obj_temp_path = out_dir + this->temp_objs_[src_index];
    const std::string temp_d_path = fs::path(obj_temp_path).replace_extension("d").string();

    std::vector<std::string> args = tt::jit_build::utils::build_gpp_argv(
        env_.gpp_,
        recipe.compiler_opt_level,
        cflags,
        recipe.includes,
        defines,
        this->srcs_[src_index],
        tt::jit_build::utils::GppAction::Compile,
        obj_temp_path,
        temp_d_path);

    if (env_.get_rtoptions().get_log_kernels_compilation_commands()) {
        log_info(tt::LogBuildKernels, "    g++ compile cmd: {}", fmt::join(args, " "));
    }

    if (env_.get_rtoptions().get_watcher_enabled() && settings) {
        log_kernel_defines_and_args(
            out_dir, settings->get_full_kernel_name(), fmt::format("{}", fmt::join(defines, " ")));
    }

    // log file and dephash file can be renamed after compilation, but the .o file
    // needs to be renamed after link step to avoid LTO reading inconsistent object files.
    jit_build::utils::FileRenamer log_file(obj_path + ".log");
    fs::remove(log_file.path());
    bool result = tt::jit_build::utils::exec_command(args, out_dir, log_file.path());
    report_result(this->target_name_, "compile", fmt::format("{}", fmt::join(args, " ")), log_file.path(), result);
    jit_build::write_dependency_hashes(out_dir, obj_temp_path, obj_temp_path + ".dephash", recipe.pch_umbrella);
    fs::remove(temp_d_path);  // .d file not needed after hash is written
}

bool JitBuildState::need_compile(const string& out_dir, const string& obj) const {
    return env_.get_rtoptions().get_force_jit_compile() || !fs::exists(out_dir + obj) ||
           !jit_build::dependencies_up_to_date(out_dir, obj);
}

std::bitset<JitBuildState::kMaxBuildBitset> JitBuildState::compile(
    const string& out_dir, const JitBuildSettings* settings, bool state_changed) const {
    TTZoneScopedD(JIT);
    TT_FATAL(
        this->srcs_.size() <= kMaxBuildBitset,
        "Number of source files ({}) exceeds kMaxBuildBitset ({})",
        this->srcs_.size(),
        kMaxBuildBitset);

    std::bitset<kMaxBuildBitset> compiled;
    std::vector<std::shared_future<void>> events;
    for (size_t i = 0; i < this->srcs_.size(); ++i) {
        if (state_changed || need_compile(out_dir, this->objs_[i])) {
            compiled.set(i);
            launch_build_step([this, &out_dir, settings, i] { this->compile_one(out_dir, settings, i); }, events);
        } else {
            log_debug(tt::LogBuildKernels, "JIT build cache hit: {}{}", out_dir, this->objs_[i]);
            BuildCacheTelemetry::inst().record_cache_hit();
        }
    }

    sync_build_steps(events);

    BuildCacheTelemetry::inst().record_compile(
        static_cast<uint32_t>(this->srcs_.size()), static_cast<uint32_t>(compiled.count()));

    if (env_.get_rtoptions().get_watcher_enabled()) {
        dump_kernel_defines_and_args(env_.get_out_kernel_root_path());
    }
    return compiled;
}

bool JitBuildState::need_link(const string& out_dir) const {
    std::string elf_path = out_dir + this->target_name_ + ".elf";
    return !fs::exists(elf_path) || !jit_build::dependencies_up_to_date(out_dir, elf_path);
}

void JitBuildState::link(const string& out_dir, const JitBuildSettings* settings, const string& link_objs) const {
    string cmd{"cd " + out_dir + " && " + env_.gpp_};
    string lflags = this->lflags_;
    if (env_.get_rtoptions().get_build_map_enabled()) {
        lflags += "-Wl,-Map=" + out_dir + this->target_name_ + ".map ";
        lflags += "-save-temps=obj -fdump-tree-all -fdump-rtl-all ";
    }

    // Append user args
    cmd += fmt::format("-{} ", settings ? settings->get_linker_opt_level() : this->default_linker_opt_level_);

    // Elf file has dependencies other than object files:
    // 1. Linker script
    // 2. Weakened firmware elf (for kernels)
    std::vector<std::string> link_deps = {this->linker_script_};
    if (!this->is_fw_) {
        link_deps.push_back(this->weakened_firmware_name_);
        if (!this->firmware_is_kernel_object_) {
            cmd += "-Wl,--just-symbols=";
        }
        cmd += this->weakened_firmware_name_ + " ";
    }

    // Append common args provided by the build state
    cmd += lflags;
    cmd += this->extra_link_objs_;
    cmd += link_objs;
    std::string elf_name = out_dir + this->target_name_ + ".elf";
    jit_build::utils::FileRenamer elf_file(elf_name);
    cmd += "-o " + elf_file.path();
    if (env_.get_rtoptions().get_log_kernels_compilation_commands()) {
        log_info(tt::LogBuildKernels, "    g++ link cmd: {}", cmd);
    }
    jit_build::utils::FileRenamer log_file(elf_name + ".log");
    fs::remove(log_file.path());
    bool result =
        tt::jit_build::utils::run_command(cmd, log_file.path(), env_.get_rtoptions().get_dump_build_commands());
    report_result(this->target_name_, "link", cmd, log_file.path(), result);
    jit_build::utils::FileRenamer dephash_file(elf_name + ".dephash");
    std::ofstream hash_file(dephash_file.path());
    jit_build::write_dependency_hashes({{elf_name, std::move(link_deps)}}, out_dir, elf_name, hash_file);
    hash_file.close();
    if (hash_file.fail()) {
        // Don't leave incomplete hash file
        std::filesystem::remove(dephash_file.path());
    }
}

// Given this elf (A) and a later elf (B):
// weakens symbols in A so that it can be used as a "library" for B. B imports A's weakened symbols, B's symbols of the
// same name don't result in duplicate symbols but B can reference A's symbols. Force the fw_export symbols to remain
// strong so to propagate link addresses
void JitBuildState::weaken(const string& out_dir) const {
    TTZoneScopedD(JIT);

    std::string pathname_in = out_dir + target_name_ + ".elf";
    jit_build::utils::FileRenamer out_file(this->weakened_firmware_name_);

    // The output directory may differ from out_dir when firmware_binary_root_
    // points to a pre-compiled directory that lacks this target's subdirectory.
    fs::create_directories(fs::path(out_file.path()).parent_path());

    ll_api::ElfFile elf;
    elf.ReadImage(pathname_in);
    static const std::string_view strong_names[] = {"__fw_export_*", "__global_pointer$"};
    elf.WeakenDataSymbols(strong_names);
    if (this->firmware_is_kernel_object_) {
        elf.ObjectifyExecutable();
    }
    elf.WriteImage(out_file.path());
}

void JitBuildState::extract_zone_src_locations(const std::string& out_dir) const {
    TTZoneScopedD(JIT);
    static std::atomic<bool> new_log = true;
    // Mutex to serialize concurrent writes to the shared zone src locations log file.
    // Multiple kernels are compiled in parallel; without serialization their grep outputs
    // interleave in the file, producing corrupted lines that fail to parse.
    static std::mutex zone_log_mutex;
    if (env_.get_rtoptions().get_profiler_enabled()) {
        std::lock_guard<std::mutex> lk(zone_log_mutex);
        if (new_log.exchange(false) && std::filesystem::exists(tt::tt_metal::NEW_PROFILER_ZONE_SRC_LOCATIONS_LOG)) {
            std::remove(tt::tt_metal::NEW_PROFILER_ZONE_SRC_LOCATIONS_LOG.c_str());
        }

        if (!std::filesystem::exists(tt::tt_metal::NEW_PROFILER_ZONE_SRC_LOCATIONS_LOG)) {
            tt::jit_build::utils::create_file(tt::tt_metal::NEW_PROFILER_ZONE_SRC_LOCATIONS_LOG);
        }

        auto cmd = fmt::format("grep KERNEL_PROFILER {}*.o.log", out_dir);
        tt::jit_build::utils::run_command(
            cmd, tt::tt_metal::NEW_PROFILER_ZONE_SRC_LOCATIONS_LOG, env_.get_rtoptions().get_dump_build_commands());
    }
}

void JitBuildState::build(const JitBuildSettings* settings, std::span<const JitBuildState* const> link_targets) const {
    TTZoneScopedD(JIT);
    // Widens the process-wide JIT build window to cover this call, on every exit path -- including
    // the warmed-ELF early return below, which is build activity even though it compiles nothing.
    ScopedBuildWindow build_window;
    const auto t0_build = build_window.start();
    auto kernel_name = settings ? std::string_view{settings->get_full_kernel_name()} : "";
    std::string out_dir = fmt::format("{}{}{}/", this->out_path_, kernel_name, this->target_name_);

    // If no link targets are provided, use the current build state as the only link target
    const JitBuildState* self = this;
    if (link_targets.empty()) {
        link_targets = std::span<const JitBuildState* const>(&self, 1);
    }
    const size_t num_objs = this->objs_.size();

    fs::create_directories(out_dir);

    // Check build state once: if build parameters (flags, defines, includes from HAL, etc.)
    // have changed, force full recompilation and relinking.
    bool state_changed = !build_state_matches(out_dir);

    // Preprocess-and-ship reuse: a warmed cache (produced by an AOT preprocess-and-ship pass) ships
    // only each ELF plus a source-complete FULL_DEPHASH_SUFFIX sidecar and a ".build_state". When
    // every target has a matching recipe and a valid sidecar, reuse the ELFs directly -- no object is
    // needed. Ordinary local builds never write the sidecar, so this stays inert for them.
    // Firmware never uses the warmed-ELF reuse path; force-recompile is handled inside
    // warmed_elf_reusable, which both reuse paths call.
    if (!this->is_fw_) {
        const bool all_reusable = std::all_of(link_targets.begin(), link_targets.end(), [&](const auto* target) {
            return target->warmed_elf_reusable(kernel_name);
        });
        if (all_reusable) {
            BuildCacheTelemetry::inst().record_compile(static_cast<uint32_t>(num_objs), 0);
            extract_zone_src_locations(out_dir);
            return;
        }
    }

    static auto& tok_compile = BuildCacheTelemetry::inst().get_or_register_metric("JitBuildState::compile");
    auto compiled = record_elapsed(tok_compile, [&] { return compile(out_dir, settings, state_changed); });

    string link_objs;
    // Populate link_objs once only when anything needs to be linked
    auto populate_link_objs = [&] {
        if (!link_objs.empty()) {
            return;
        }
        uint32_t reused_objs = 0;
        for (size_t i = 0; i < num_objs; ++i) {
            auto temp_obj = out_dir + this->temp_objs_[i];
            if (!compiled.test(i)) {
                // If reusing up-to-date .o files, we should give them temporary names for linking because:
                // 1. There is no guarantee that another process will not rename its compiled object to this .o during
                //    our linking.
                // 2. JIT compiler is not deterministic. Different .o files can be produced from the same source.
                // 3. LTO linker opens the object file multiple times. Atomic rename doesn't prevent the linker from
                //    getting confused.
                hard_link_or_copy(out_dir + this->objs_[i], temp_obj);
                ++reused_objs;
            }
            link_objs += temp_obj;
            link_objs += " ";
        }
        if (reused_objs != 0) {
            BuildCacheTelemetry::inst().record_merge(reused_objs);
        }
    };

    for (const auto* target : link_targets) {
        string target_out_dir = fmt::format("{}{}{}/", target->out_path_, kernel_name, target->target_name_);
        fs::create_directories(target_out_dir);
        if (state_changed || compiled.any() || target->need_link(target_out_dir)) {
            populate_link_objs();
            // target_name_ alone does not distinguish firmware from kernels, and firmware images are
            // much larger/slower to link than a typical kernel -- sharing a key would let firmware set
            // max and drag mean up, so the numbers would no longer describe kernels.
            const std::string_view target_kind = target->is_fw_ ? "fw" : "kernel";
            // Only link() is per-target work (compile() and populate_link_objs() are shared across
            // targets), and only this branch links at all -- cache hits would record ~0 ms noise.
            record_elapsed(
                per_target_telemetry_token(fmt::format("{}_link_time", target_kind), target->target_name_, "ms"),
                [&] { target->link(target_out_dir, settings, link_objs); });
            if (target->is_fw_) {
                target->weaken(target_out_dir);
            }

            // Inside the link branch so count is "binaries produced", not "times build() was called":
            // on a warm cache every target would otherwise re-stat and re-record the same ELF.
            // This is the on-disk ELF, which is neither stripped nor loaded as-is: it carries debug
            // info when riscv_debug_info_enabled is set and relocations from -Wl,--emit-relocs, so it
            // tracks build settings more than the device footprint and will not match
            // program_config_size.kernel_text.
            std::error_code elf_size_ec;
            const auto elf_size = fs::file_size(target_out_dir + target->target_name_ + ".elf", elf_size_ec);
            if (!elf_size_ec) {
                per_target_telemetry_token(fmt::format("{}_elf_size", target_kind), target->target_name_, "B")
                    .record(static_cast<double>(elf_size));
            }

            // Record the build state used for linking so that future runs can detect
            // when link-affecting flags (lflags, linker script, etc.) change.
            target->write_build_state_hash(target_out_dir);
        }
    }

    if (!link_objs.empty()) {
        // Rename the temporary .o and .dephash files after linking is done.
        fs::path src_path = out_dir;
        fs::path dst_path = out_dir;
        for (size_t i = 0; i < num_objs; ++i) {
            src_path.replace_filename(this->temp_objs_[i]);
            dst_path.replace_filename(this->objs_[i]);
            if (compiled.test(i)) {
                fs::rename(src_path, dst_path);
                src_path += ".dephash";
                dst_path += ".dephash";
                fs::rename(src_path, dst_path);
            } else {
                fs::remove(src_path);
            }
        }
    }

    // `extract_zone_src_locations` must be called every time, because it writes to a global file
    // that gets cleared in each run.
    extract_zone_src_locations(out_dir);

    auto elapsed_ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0_build).count();
    static auto& tok_build = BuildCacheTelemetry::inst().get_or_register_metric("JitBuildState::build");
    tok_build.record(elapsed_ms);

    // Per-kernel compile time makes a slow/stuck compile visible instead of silent, but a workload
    // can compile 10k+ kernels, so it is off by default (TT_METAL_LOG_KERNEL_COMPILE=1 opts in;
    // models/tt_dit sets it for every DiT run). Read once, lazily, so an importer that sets the env
    // before the first compile is honored; only when something actually compiled (cache hits are noise).
    if (compiled.any() && !kernel_name.empty()) {
        static const bool log_compile = tt::parse_env<bool>("TT_METAL_LOG_KERNEL_COMPILE", false);
        if (log_compile) {
            log_info(tt::LogBuildKernels, "compiled {} in {:.0f} ms", kernel_name, elapsed_ms);
        }
    }
}

tt::jit_build::TargetRecipe JitBuildState::export_target_recipe(const JitBuildSettings* settings) const {
    tt::jit_build::TargetRecipe target;
    target.target_name = target_name_;
    target.cflags = cflags_;
    target.pch_umbrella = (fs::path(env_.root_) / jit_build::PCH_UMBRELLA).string();
    // Per-kernel RVV opt-in: only the pack (TRISC2) compile of a kernel that set
    // ComputeConfig::enable_trisc2_rvv gets the vector flags. Compile-only: lflags_ is
    // untouched, so the link stays stock (the -fno-lto object simply opts out of LTO).
    if (settings != nullptr && this->is_compute_pack_ && settings->get_trisc2_rvv_enabled()) {
        TT_FATAL(
            !this->rvv_cflags_.empty(),
            "Kernel {} sets enable_trisc2_rvv, but this architecture does not support RVV code "
            "generation on the pack processor",
            settings->get_full_kernel_name());
        target.cflags += this->rvv_cflags_;
    }
    target.lflags = lflags_;
    target.linker_script = linker_script_;
    target.extra_link_objs = extra_link_objs_;
    target.firmware_is_kernel_object = firmware_is_kernel_object_;
    target.weakened_firmware_name = fs::path(weakened_firmware_name_).filename().string();

    for (const auto& src : srcs_) {
        target.srcs.push_back(src);
    }
    for (const auto& obj : objs_) {
        target.objs.push_back(obj);
    }

    // Optimization levels: use kernel-specified levels if available, else defaults.
    if (settings) {
        target.compiler_opt_level = std::string(settings->get_compiler_opt_level());
        target.linker_opt_level = std::string(settings->get_linker_opt_level());
    } else {
        target.compiler_opt_level = default_compile_opt_level_;
        target.linker_opt_level = default_linker_opt_level_;
    }

    // Build defines: start with build-state base, then enrich with kernel-specific defines.
    std::vector<std::string> defines = tt::jit_build::utils::tokenize_flags(defines_);
    if (settings && process_defines_at_compile_) {
        settings->process_defines([&defines](const std::string& define, const std::string& value) {
            defines.push_back(fmt::format("-D{}={}", define, value));
        });
    }
    if (settings) {
        // FULL_KERNEL_NAME: consumed by the LLK sanitizer (CTSTR(FULL_KERNEL_NAME)). Emitted
        // shell-free as one verbatim argv element with literal quotes (the unified/remote-JIT
        // path does no shell expansion).
        defines.push_back(fmt::format(R"(-DFULL_KERNEL_NAME="{}")", settings->get_full_kernel_name()));
        settings->process_compile_time_args([&defines](const std::vector<uint32_t>& values) {
            if (!values.empty()) {
                defines.push_back(fmt::format("-DKERNEL_COMPILE_TIME_ARGS={}", fmt::join(values, ",")));
            }
        });
        // KERNEL_COMPILE_TIME_ARG_MAP arrives as a force-included header (written by genfiles,
        // see write_named_ct_arg_map_header) rather than a -D define, because one define is one
        // argv element and the map alone can exceed the per-element MAX_ARG_STRLEN. Two argv
        // elements, and the bare filename resolves via the "-I.." every compile carries -- so this
        // recipe stays valid verbatim on the remote compile server, where a client-side absolute
        // path would not resolve. See NAMED_CT_ARG_MAP_HEADER.
        settings->process_named_compile_time_args(
            [&defines](const std::unordered_map<std::string, uint32_t>& named_args) {
                if (!named_args.empty()) {
                    defines.emplace_back("-include");
                    defines.emplace_back(tt::jit_build::utils::NAMED_CT_ARG_MAP_HEADER);
                }
            });
    }
    target.defines = std::move(defines);

    // Build includes: start with build-state base, then add kernel-specific paths.
    std::string includes = includes_;
    if (settings) {
        settings->process_include_paths([&includes](const std::string& path) { includes += "-I" + path + " "; });
    }
    target.includes = std::move(includes);

    return target;
}

void jit_build(const JitBuildState& build, const JitBuildSettings* settings) {
    TTZoneScopedD(JIT);
    static auto& tok = BuildCacheTelemetry::inst().get_or_register_metric("jit_build");
    record_elapsed(tok, [&] { build.build(settings); });
}

void jit_build_for_processors(std::span<const JitBuildState* const> targets, const JitBuildSettings* settings) {
    TT_ASSERT(!targets.empty());
    const JitBuildState& primary = *targets[0];
    static auto& tok = BuildCacheTelemetry::inst().get_or_register_metric("jit_build_for_processors");
    record_elapsed(tok, [&] { primary.build(settings, targets); });
}

void jit_build_subset(JitBuildStateSubset build_subset, const JitBuildSettings* settings) {
    std::vector<std::shared_future<void>> events;
    for (const auto& build : build_subset) {
        // Capture the necessary objects by reference
        launch_build_step([&build, settings] { build.build(settings); }, events);
    }

    sync_build_steps(events);
}

void launch_build_step(const std::function<void()>& build_func, std::vector<std::shared_future<void>>& events) {
    events.emplace_back(detail::async(build_func));
}

void sync_build_steps(std::vector<std::shared_future<void>>& events) {
    // Join EVERY build step before returning, even when one throws.
    //
    // A build_func runs asynchronously and captures locals BY REFERENCE — e.g.
    // jit_build_subset's `[&build, settings]` over the by-value `build_subset`, and
    // JitBuildState::compile's `[this, &out_dir, ...]`. Those locals are destroyed as soon as
    // the enclosing scope unwinds. If we let the first exception propagate straight out of this
    // loop, the remaining in-flight tasks keep running against references that are about to be
    // freed (shared_future's destructor does not wait) — a use-after-scope. So we wait on all
    // futures first, stash the first exception, and rethrow it only once nothing is still running.
    std::exception_ptr first_error;
    for (auto& event : events) {
        try {
            event.get();
        } catch (...) {
            if (!first_error) {
                first_error = std::current_exception();
            }
        }
    }
    if (first_error) {
        std::rethrow_exception(first_error);
    }
}

void jit_build_once(size_t hash, const std::function<void()>& build_fn) {
    if (!JitBuildCache::inst().build_once(hash, build_fn)) {
        BuildCacheTelemetry::inst().record_jit_once_dedup();
    }
}

void jit_build_cache_clear() {
    JitBuildCache::inst().clear();
    jit_build::clear_file_hash_cache();
}

}  // namespace tt::tt_metal
