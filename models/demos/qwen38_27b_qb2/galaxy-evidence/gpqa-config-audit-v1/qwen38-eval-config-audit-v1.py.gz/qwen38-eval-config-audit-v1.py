"""Read-only audit of pinned artifacts, installed GPQA harness, and saved outputs."""
import json
import subprocess
from pathlib import Path

REMOTE = r'''
import collections, datetime, hashlib, importlib.metadata as metadata, inspect, json, pathlib, re, sys, urllib.request
art=pathlib.Path('/home/ttuser/qwen38-artifacts-20261007')
taskroot=pathlib.Path('/home/ttuser/kimi-prefill.Ubx2wY/runtime/qwen38-27b-20261006')
source=art/'accuracy-decoder-source-v1'
sys.path.insert(0,str(source))
from models.demos.qwen38_27b_qb2.tests.benchmark import load_gpqa, MODEL_REVISION, HARNESS_REVISION
from lm_eval.tasks.r1_evals import utils
from lm_eval.tasks.gpqa.zeroshot import utils as docutils
from lm_eval.filters.extraction import BoxedChoiceFilter
from lm_eval.tasks import TaskManager
weights=art/'checkpoint-pinned-1d4bf0f2'
report={'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'model_revision':MODEL_REVISION,'harness_revision_expected':HARNESS_REVISION,'mutates_original_run':False}
dist=metadata.distribution('lm_eval')
report['harness_installed']={'version':dist.version,'source':json.loads(dist.read_text('direct_url.json'))}
files=[pathlib.Path(TaskManager().task_index['r1_gpqa_diamond']['yaml_path']),pathlib.Path(utils.__file__),pathlib.Path(docutils.__file__),pathlib.Path(inspect.getfile(BoxedChoiceFilter))]
report['harness_files']={str(p.relative_to(p.parents[2])) if 'r1_evals' in str(p) else str(p):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in files}
report['harness_prompt_template']=files[0].read_text().split('doc_to_text: ',1)[1].split('\n',1)[0]
report['harness_generation_defaults_not_used_by_client']={'do_sample':False,'max_gen_toks':32768,'temperature':0.6,'top_k':40,'top_p':0.95}
report['client_effective_generation']={'temperature':1.0,'top_k':20,'top_p':0.95,'seed':42,'max_tokens':65536,'chat_template_kwargs':{'enable_thinking':True}}
report['upstream_artifact_checks']={}
for name in ['config.json','generation_config.json','tokenizer_config.json','chat_template.jinja','tokenizer.json','model.safetensors.index.json']:
 p=weights/name
 entry={'exists':p.exists()}
 if p.exists():
  data=p.read_bytes(); entry.update(bytes=len(data),local_sha256=hashlib.sha256(data).hexdigest())
  url='https://huggingface.co/Qwen/Qwen3.8-27B/resolve/'+MODEL_REVISION+'/'+name
  try:
   with urllib.request.urlopen(url,timeout=25) as response: other=response.read(32*1024*1024+1)
   if len(other)>32*1024*1024:raise ValueError('Unexpected artifact size')
   entry.update(upstream_url=url,upstream_sha256=hashlib.sha256(other).hexdigest(),exact_match=other==data)
  except Exception as exc:entry['verification_error']=type(exc).__name__+': '+str(exc)
 report['upstream_artifact_checks'][name]=entry
csv=taskroot/'gpqa-data/gpqa_diamond.csv'
if not csv.exists():
 candidates=list((taskroot/'gpqa-data').rglob('gpqa_diamond.csv'))
 if len(candidates)!=1:raise ValueError('Expected one pinned cached CSV')
 csv=candidates[0]
task,cases=load_gpqa(198,csv)
report['input_hash']=hashlib.sha256(json.dumps([{'id':c['id'],'prompt':c['prompt'],'answer':c['doc']['answer']} for c in cases],sort_keys=True).encode()).hexdigest()
report['question_count']=len(cases)
report['choice_answer_consistency']={
 'gold_matches_correct_answer':sum(c['doc']['choice'+str('ABCD'.index(c['doc']['answer'].strip('()'))+1)].strip()==c['doc']['Correct Answer'].strip() for c in cases),
 'distinct_choices':sum(len({c['doc']['choice'+str(i)].strip() for i in range(1,5)})==4 for c in cases)}
base=art/'accuracy-decoder-v1/native-control/evaluation/gpqa'
rows=[json.loads(s) for s in (base/'gpqa-responses.jsonl').read_text().splitlines() if s.strip()]
counts=collections.Counter(); details=[]
for row in rows:
 raw=json.loads((base/'private-responses'/f"{row['id']:03d}.json").read_text())
 doc=cases[row['id']]['doc']; final=raw['text']; thought=raw['reasoning']
 score=task.process_results(doc,[final])['exact_match']
 combined=task.process_results(doc,['<think>\n'+thought+'\n</think>\n'+final])['exact_match']
 boxed=re.findall(r'\\boxed\s*\{\s*(?:\\(?:text|mathrm|mathbf)\s*\{\s*)?[\(\[]?([ABCD])[\)\]]?\s*\}', final)
 counts['completed']+=1;counts['rescored_correct']+=int(score);counts['combined_rescored_correct']+=int(combined)
 counts['receipt_score_disagreements']+=int(score!=row['correct'])
 counts['raw_hash_disagreements']+=int(hashlib.sha256(final.encode()).hexdigest()!=row['final_answer_sha256'] or hashlib.sha256(thought.encode()).hexdigest()!=row['reasoning_sha256'])
 counts['clear_boxed_answer']+=bool(boxed)
 if boxed:
  strict=int(boxed[-1]==doc['answer'].strip('()'))
  counts['boxed_correct']+=strict;counts['boxed_score_disagreements']+=int(strict!=score)
 counts['empty_final']+=not bool(final.strip())
 counts['final_contains_think_tag']+=('<think>' in final or '</think>' in final)
 counts['finish_'+raw['finish_reason']]+=1
 if not row['correct']:
  details.append({'id':row['id'],'finish_reason':raw['finish_reason'],'completion_tokens':raw['usage']['completion_tokens'],'empty_final':not bool(final.strip()),'clear_boxed_answer':bool(boxed),'combined_score':int(combined)})
report['saved_response_audit']=dict(counts)
report['incorrect_response_metadata']=details
report['progress']=json.loads((base/'gpqa-progress.json').read_text())
report['protocol']=json.loads((base/'protocol.json').read_text())
report['doc_processing_source']=inspect.getsource(docutils.process_docs)
print(json.dumps(report))
'''

compile(REMOTE, "remote_eval_config_audit.py", "exec")
ssh = ["ssh", "-o", "BatchMode=yes", "-o", "ConnectTimeout=10", "-o", "IdentityAgent=none", "-o", "IdentitiesOnly=yes", "-i", "/Users/anatarajan/.ssh/id_ed25519", "ttuser@10.228.203.98", "/home/ttuser/kimi-prefill.Ubx2wY/runtime/qwen38-27b-20261006/eval_env/bin/python", "-"]
result=subprocess.run(ssh,input=REMOTE,text=True,capture_output=True,timeout=240)
if result.returncode:
    print(result.stdout[-2000:]); print(result.stderr[-4000:]);raise SystemExit(result.returncode)
data=json.loads(result.stdout)
dest=Path('/private/tmp/qwen38-eval-config-audit-v1.json')
with dest.open('x') as f:json.dump(data,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in data.items() if k not in ('protocol','doc_processing_source','harness_files','incorrect_response_metadata')},indent=2))
print('Saved',dest)
