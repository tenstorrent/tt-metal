"""Complete the read-only audit using normalized labels and actual token IDs."""
import ast
import json
import subprocess
from pathlib import Path

source=Path('/private/tmp/qwen38-eval-config-audit-v1.py').read_text()
tree=ast.parse(source)
remote=next(ast.literal_eval(node.value) for node in tree.body if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='REMOTE' for t in node.targets))
remote=remote.replace("'tokenizer.json','model.safetensors.index.json'", "'tokenizer.json','vocab.json','merges.txt','model.safetensors.index.json'")
remote=remote.replace("json.dumps([{'id':c['id'],'prompt':c['prompt'],'answer':c['doc']['answer']} for c in cases],sort_keys=True)", "''.join(json.dumps(c,sort_keys=True)+'\\n' for c in cases)")
remote=remote.replace("c['doc']['Correct Answer'].strip()", "docutils.preprocess(c['doc']['Correct Answer']).strip()")
remote=remote.replace("report['doc_processing_source']=inspect.getsource(docutils.process_docs)", """
report['input_hash_matches_run']=report['input_hash']==report['protocol']['input_sha256']
receipts={r['id']:r for r in rows}
duplicates=[]
for c in cases:
 choices=[c['doc']['choice'+str(i)] for i in range(1,5)]
 gold=docutils.preprocess(c['doc']['Correct Answer'])
 aliases=[i for i,choice in enumerate(choices) if choice==gold]
 if len(set(choices))<4:
  item={'id':c['id'],'duplicate_correct_choice_count':len(aliases),'completed':c['id'] in receipts}
  if c['id'] in receipts:
   final=json.loads((base/'private-responses'/f"{c['id']:03d}.json").read_text())['text']
   candidate=utils.choice_answer_clean(utils._BOXED_CHOICE.apply([[final]],[dict(c['doc'],choices=choices)])[0][0])
   item.update(scored_correct=receipts[c['id']]['correct'],equivalent_correct_choice_selected=(candidate in 'ABCD' and len(candidate)==1 and 'ABCD'.index(candidate) in aliases))
  duplicates.append(item)
report['duplicate_choice_diagnostics']=duplicates
report['doc_processing_source']=inspect.getsource(docutils.process_docs)
report['preprocess_source']=inspect.getsource(docutils.preprocess)
""")

TOKENIZER_PROBE=r'''
import hashlib,json,pathlib,urllib.request,importlib.metadata as m
from transformers import AutoTokenizer,GenerationConfig
from vllm import SamplingParams
p=pathlib.Path('/home/ttuser/qwen38-artifacts-20261007/checkpoint-pinned-1d4bf0f2')
t=AutoTokenizer.from_pretrained(str(p),local_files_only=True)
messages=[{'role':'user','content':'Reply with the word cedar.'}]
kwargs=dict(tokenize=True,return_dict=False,add_generation_prompt=True,enable_thinking=True)
actual=t.apply_chat_template(messages,**kwargs)
explicit=t.apply_chat_template(messages,reasoning_effort='xhigh',preserve_thinking=True,**kwargs)
if not isinstance(actual,list) or not all(type(x)==int for x in actual):raise ValueError('Expected token ID list')
rendered=t.apply_chat_template(messages,tokenize=False,add_generation_prompt=True,enable_thinking=True)
s=SamplingParams();g=GenerationConfig.from_pretrained(str(p),local_files_only=True)
report={'versions':{x:m.version(x) for x in ('transformers','vllm','tokenizers')},'tokenizer_class':type(t).__name__,'effective_chat_template_sha256':hashlib.sha256(t.chat_template.encode()).hexdigest(),'default_equals_explicit_xhigh':actual==explicit,'synthetic_rendered_prompt':rendered,'synthetic_token_count':len(actual),'sampling_defaults':{k:getattr(s,k) for k in ('min_p','presence_penalty','frequency_penalty','repetition_penalty','ignore_eos','stop_token_ids','skip_special_tokens')},'generation_config':{k:getattr(g,k) for k in ('bos_token_id','eos_token_id','pad_token_id','temperature','top_k','top_p','max_length','max_new_tokens')}}
try:
 req=urllib.request.Request('http://127.0.0.1:8078/tokenize',data=json.dumps({'model':'Qwen/Qwen3.8-27B','messages':messages,'add_generation_prompt':True,'chat_template_kwargs':{'enable_thinking':True}}).encode(),headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(req,timeout=10) as response:api=json.load(response)
 report['endpoint_tokenization']={'count':api.get('count'),'exact_local_token_id_match':api.get('tokens')==actual,'max_model_len':api.get('max_model_len')}
except Exception as e:report['endpoint_tokenization_error']=type(e).__name__+': '+str(e)
print('AUDIT_JSON:'+json.dumps(report))
'''
remote=remote.replace("print(json.dumps(report))", """
import subprocess
result=subprocess.run([str(taskroot/'serving_env/bin/python'),'-'],input=TOKENIZER_PROBE,text=True,capture_output=True,check=True,timeout=45)
report['tokenizer_probe']=json.loads(next(line.removeprefix('AUDIT_JSON:') for line in result.stdout.splitlines() if line.startswith('AUDIT_JSON:')))
report['audit_corrections']='Version 1 compared normalized choices to unnormalized answer text. An initial tokenization probe compared a BatchEncoding mapping instead of its token IDs. This version applies the harness normalization and requests return_dict=False.'
print(json.dumps(report))
""".replace('TOKENIZER_PROBE',repr(TOKENIZER_PROBE)))
compile(remote,'remote_config_audit_v2.py','exec')
command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','IdentityAgent=none','-o','IdentitiesOnly=yes','-i','/Users/anatarajan/.ssh/id_ed25519','ttuser@10.228.203.98','/home/ttuser/kimi-prefill.Ubx2wY/runtime/qwen38-27b-20261006/eval_env/bin/python','-']
result=subprocess.run(command,input=remote,text=True,capture_output=True,timeout=300)
if result.returncode:
 print(result.stdout[-2000:]);print(result.stderr[-4000:]);raise SystemExit(result.returncode)
data=json.loads(result.stdout)
dest=Path('/private/tmp/qwen38-eval-config-audit-v2.json')
with dest.open('x') as f:json.dump(data,f,indent=2);f.write('\n')
for key in ('choice_answer_consistency','input_hash_matches_run','duplicate_choice_diagnostics','saved_response_audit','tokenizer_probe','progress'):
 print(key,json.dumps(data[key],indent=2))
print('upstream artifact matches',{k:v.get('exact_match',v.get('verification_error')) for k,v in data['upstream_artifact_checks'].items()})
print('Saved',dest)
