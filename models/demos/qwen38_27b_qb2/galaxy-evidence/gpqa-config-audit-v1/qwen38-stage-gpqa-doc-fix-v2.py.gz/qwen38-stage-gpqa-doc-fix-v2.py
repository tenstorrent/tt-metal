"""Stage isolated CPU tests and prepare corrected prompts; never run inference."""
import ast
import base64
import gzip
import json
import subprocess
from pathlib import Path

repo=Path('/private/tmp/tt-metal-qwen38-long-context')
model=Path('models/demos/qwen38_27b_qb2')
names=['tests/benchmark.py','tests/gpqa_documents.py','tests/test_benchmark.py','tests/unit/test_gpqa_documents.py','tests/report.py']
files={str(model/name):base64.b64encode((repo/model/name).read_bytes()).decode() for name in names}
files['models/perf/benchmarking_utils.py']=base64.b64encode((repo/'models/perf/benchmarking_utils.py').read_bytes()).decode()
text=(repo/'conftest.py').read_text()
fixture=next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name=='expect_error')
files['conftest.py']=base64.b64encode(('import contextlib\nimport pytest\nfrom loguru import logger\n@pytest.fixture\n'+ast.get_source_segment(text,fixture)+'\n').encode()).decode()

PREPARE=r'''
import collections,hashlib,importlib.util,json,pathlib,re,sys
art=pathlib.Path('/home/ttuser/qwen38-artifacts-20261007')
taskroot=pathlib.Path('/home/ttuser/kimi-prefill.Ubx2wY/runtime/qwen38-27b-20261006')
from models.demos.qwen38_27b_qb2.tests import benchmark as fixed
from lm_eval.tasks.gpqa.zeroshot.utils import preprocess
legacy_path=art/'accuracy-decoder-source-v1/models/demos/qwen38_27b_qb2/tests/benchmark.py'
spec=importlib.util.spec_from_file_location('legacy_benchmark',legacy_path)
legacy=importlib.util.module_from_spec(spec);spec.loader.exec_module(legacy)
csv=taskroot/'gpqa-data/gpqa_diamond.csv'
if not csv.exists():csv=next(csv.parent.rglob('gpqa_diamond.csv'))
_,old=legacy.load_gpqa(198,csv)
_,new=fixed.load_gpqa(198,csv)
def input_hash(cases):return hashlib.sha256(''.join(json.dumps(c,sort_keys=True)+'\n' for c in cases).encode()).hexdigest()
original_protocol=json.loads((art/'accuracy-decoder-v1/native-control/evaluation/gpqa/protocol.json').read_text())
if input_hash(old)!=original_protocol['input_sha256']:raise ValueError('Legacy inputs do not reproduce scored input hash')
runs={}
for name,root in [('decoder8','accuracy-decoder-v1'),('head8','accuracy-head-v1'),('native4','overnight-v2')]:
 p=art/root/'native-control/evaluation/gpqa/gpqa-responses.jsonl'
 runs[name]={r['id']:r for r in [json.loads(line) for line in p.read_text().splitlines()]}
changes=[];affected=[]
for before,after in zip(old,new):
 doc=after['doc']; gold='ABCD'.index(doc['answer'][1])+1
 if doc[f'choice{gold}']!=doc['Correct Answer'].strip():raise ValueError('Fixed label points to different answer')
 if after['prompt']!=before['prompt']:changes.append(after['id'])
 original=[doc[k].strip() for k in ['Incorrect Answer 1','Incorrect Answer 2','Incorrect Answer 3','Correct Answer']]
 displayed=[doc[f'choice{i}'] for i in range(1,5)]
 if sorted(original)!=sorted(displayed):raise ValueError('Fixed choices still alter dataset text')
 if before['doc']['answer']!=after['doc']['answer']:raise ValueError('Fix changed choice permutation or label')
 changed=[s for s in original if re.search(r'\[.*?\]',s)]
 if changed:
  processed=[preprocess(s) for s in original]
  affected.append({'id':after['id'],'affected_choices':len(changed),'raw_distinct_choices':len(set(original)), 'processed_distinct_choices':len(set(processed)),'corrected_distinct_choices':len(set(displayed)),'correct_by_run':{name:rows.get(after['id'],{}).get('correct') for name,rows in runs.items()}})
report={'scope':'CPU-only preparation and regression; no model execution or rescoring','selected_count':198,'fixed_choice_processing':fixed.CHOICE_PROCESSING,'legacy_input_sha256':input_hash(old),'fixed_input_sha256':input_hash(new),'legacy_matches_running_input_hash':True,'all_fixed_choices_preserve_raw_answer_text':True,'all_choice_permutations_and_labels_unchanged':True,'changed_prompt_ids':changes,'changed_prompt_count':len(changes),'bracket_affected_questions':len(affected),'bracket_affected_choices':sum(r['affected_choices'] for r in affected),'affected_question_metadata':affected,'synthetic_reproducer':{s:preprocess(s) for s in ['Vector [1, 2]','Vector [2, 3]','The concentration is [H+] = 0.1 M']}}
print(json.dumps(report))
'''
REMOTE=r'''
import base64,hashlib,json,os,pathlib,subprocess
root=pathlib.Path('/home/ttuser/qwen38-artifacts-20261007/gpqa-doc-fix-cpu-v2');root.mkdir()
source=root/'source'
files=FILES
for name,blob in files.items():
 path=source/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(base64.b64decode(blob))
for name in ['models','models/perf','models/demos','models/demos/qwen38_27b_qb2','models/demos/qwen38_27b_qb2/tests','models/demos/qwen38_27b_qb2/tests/unit']:(source/name/'__init__.py').touch()
(root/'pytest.ini').write_text('[pytest]\n')
task=pathlib.Path('/home/ttuser/kimi-prefill.Ubx2wY/runtime/qwen38-27b-20261006')
env=dict(os.environ,PYTHONPATH=str(source),PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',OMP_NUM_THREADS='1')
cmd=[str(task/'python_env/bin/python'),'-m','pytest','-c',str(root/'pytest.ini'),'--confcutdir='+str(source),str(source/'models/demos/qwen38_27b_qb2/tests/test_benchmark.py'),str(source/'models/demos/qwen38_27b_qb2/tests/unit/test_gpqa_documents.py'),'-q','--junitxml='+str(root/'unit.xml')]
result=subprocess.run(cmd,cwd=source,env=env,text=True,capture_output=True,timeout=120)
(root/'unit.log').write_text(result.stdout+result.stderr)
if result.returncode:print(result.stdout+result.stderr);raise SystemExit(result.returncode)
result=subprocess.run([str(task/'eval_env/bin/python'),'-'],input=PREPARE,cwd=source,env=env,text=True,capture_output=True,timeout=90)
(root/'prepare.log').write_text(result.stderr)
if result.returncode:print(result.stdout+result.stderr);raise SystemExit(result.returncode)
report=json.loads(result.stdout);(root/'preparation.json').write_text(json.dumps(report,indent=2)+'\n')
manifest={'source_sha256':{name:hashlib.sha256((source/name).read_bytes()).hexdigest() for name in files},'test_command':cmd,'hardware_used':False,'original_job_modified':False}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
outputs={name:base64.b64encode((root/name).read_bytes()).decode() for name in ['unit.log','unit.xml','preparation.json','prepare.log','manifest.json']}
outputs['attempt-01-unit.log']=base64.b64encode((root.parent/'gpqa-doc-fix-cpu-v1/unit.log').read_bytes()).decode()
print(json.dumps(outputs))
'''.replace('FILES',repr(files)).replace('PREPARE',repr(PREPARE))
compile(REMOTE,'remote_gpqa_fix_cpu_v1.py','exec')
cmd=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','IdentityAgent=none','-o','IdentitiesOnly=yes','-i','/Users/anatarajan/.ssh/id_ed25519','ttuser@10.228.203.98','python3','-']
result=subprocess.run(cmd,input=REMOTE,text=True,capture_output=True,timeout=250)
if result.returncode:print(result.stdout+result.stderr);raise SystemExit(result.returncode)
outputs=json.loads(result.stdout)
dest=repo/model/'galaxy-evidence/gpqa-config-audit-v1';dest.mkdir(exist_ok=True)
for name,blob in outputs.items():
 data=base64.b64decode(blob)
 if name.endswith(('.log','.xml')):name+='.gz';data=gzip.compress(data,mtime=0)
 with (dest/name).open('xb') as f:f.write(data)
print(base64.b64decode(outputs['unit.log']).decode())
print(base64.b64decode(outputs['preparation.json']).decode())
