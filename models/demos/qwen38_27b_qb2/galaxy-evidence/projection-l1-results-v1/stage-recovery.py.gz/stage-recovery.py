import base64
import json
import subprocess
from pathlib import Path

repo = Path('/private/tmp/tt-metal-qwen38-long-context')
prefix = 'models/demos/qwen38_27b_qb2/'
names = [prefix + n for n in ('tests/projection_sweep.py', 'tests/unit/test_projection_sweep.py')]
payload = {n: base64.b64encode((repo/n).read_bytes()).decode() for n in names}
remote = r'''
import base64,hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
art=Path('/home/ttuser/qwen38-artifacts-20261007')
task=Path('/home/ttuser/kimi-prefill.Ubx2wY/runtime/qwen38-27b-20261006')
sys.path.insert(0,str(art/'export-recovery-source-v2'))
from models.demos.qwen38_27b_qb2.demo.watch_profile_export import properties,empty_cgroup
from models.demos.qwen38_27b_qb2.tests.profile_export_recovery import require_unstarted_failure,replacement_command,terminal
source=art/'projection-sweep-source-v3';control=art/'projection-sweep-control-v7';output=art/'projection-sweep-v7'
rows=[
('projection-sweep-v6-export-recovery1','projection-sweep-control-v6-export-recovery1','fc6fca6ac9e147198d52782c998e4ddb','projection-sweep-v7','projection-sweep-control-v7'),
('prefill-attention-v3-export-recovery1','prefill-attention-control-v3-export-recovery1','d1d81a7ed3604d8aadb27acc4d9ef785','prefill-attention-v4','prefill-attention-control-v4'),
('compact-long-horizon-v3-export-recovery1','compact-long-horizon-control-v3-export-recovery1','1517236f9515446d80c90ac85b68949c','compact-long-horizon-v4','compact-long-horizon-control-v4'),
('gdn-resident-hardware-v1-export-recovery1','gdn-resident-hardware-control-v1-export-recovery1','6c0f0f9d756f4e3a91760437f7d866ec','gdn-resident-hardware-v2','gdn-resident-hardware-control-v2'),
('gdn-compact-gates-v1-export-recovery1','gdn-compact-gates-control-v1-export-recovery1','0b2f9ba4d0c240198f1a9795378a0984','gdn-compact-gates-v2','gdn-compact-gates-control-v2')]
def unit(stem):return 'qwen38-'+stem+'-20261010.service'
audit=[]
for i,(old,oldcontrol,inv,new,newcontrol) in enumerate(rows):
 p=properties(unit(old));q=json.loads((art/old/'queue.json').read_text())
 assert terminal(p,inv),(old,p)
 empty_cgroup(p)
 assert not (art/new).exists() and not (art/newcontrol).exists()
 assert properties(unit(new))['LoadState']=='not-found'
 if i==0:
  receipt=json.loads((art/old/'projections.json').read_text())
  assert p['Result']=='exit-code' and receipt['state']=='failed' and receipt['cleanup_completed'] is True
  assert receipt['active_batch']==16 and receipt['active_role']=='down' and receipt['active_config']==dict(readers=2,cores=8,block=34)
  assert 'static dataflow buffer region ends at 1504000' in receipt['detail']
  assert len(receipt['cases'])==15 and len(receipt['comparisons'])==9
 else:require_unstarted_failure(p,q,inv)
 cmd=json.loads((art/oldcontrol/'launch.json').read_text())['command']
 manifest=Path(cmd[cmd.index('--manifest')+1]);oldsource=Path(cmd[cmd.index('--source')+1])
 for n,h in json.loads(manifest.read_text()).items():assert hashlib.sha256((oldsource/n).read_bytes()).hexdigest()==h,n
 audit.append(dict(unit=unit(old),properties=p,queue=q,manifest_sha256=hashlib.sha256(manifest.read_bytes()).hexdigest()))
assert not source.exists() and shutil.disk_usage(art).free>20*1024**3
shutil.copytree(art/'projection-sweep-source-v2',source,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache','.benchmarks','generated'))
control.mkdir()
for n,data in PAYLOAD.items():(source/n).write_bytes(base64.b64decode(data))
(control/'recovery-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
python=str(task/'python_env/bin/python');model=source/prefix
env=dict(os.environ,TT_METAL_HOME=str(task/'metal'),LD_LIBRARY_PATH=f'{task}/metal-install/lib:{task}/metal-build/lib',PYTHONPATH=f'{source}:{task}/metal:{task}/metal/tools',ARCH_NAME='blackhole',OMP_NUM_THREADS='4',TT_METAL_INSPECTOR_RPC='0')
with (control/'preflight.log').open('w') as log:
 subprocess.run([python,'-m','pytest',str(model/'tests/unit'),'-c',str(source/'pytest.ini'),f'--rootdir={source}','-o','addopts=','-q',f'--junitxml={control}/unit.xml'],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
files=[source/n for n in ('conftest.py','pytest.ini','scripts/run_safe_pytest.sh')]
files.extend(p for p in model.rglob('*') if p.is_file() and p.suffix in ('.py','.cpp','.h','.hpp','.json'))
manifest={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(control/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
# Recheck the unchanged model/config against the previous frozen source.
for n,h in json.loads((art/'projection-sweep-control-v6/source-manifest.json').read_text()).items():
 if n.startswith((prefix+'tt/',prefix+'config/')): assert manifest[n]==h,n
parent='qwen38-compact-export-fallback-v2-20261010.service';parentinv='e37b2f244e924e2f9b03f58af90d47ba';parentreceipt=str(art/'export-recovery-v2/queue.json')
q=json.loads(Path(parentreceipt).read_text());assert q['state']=='completed' and q['cleanup_completed'] is True
launched=[]
for i,(old,oldcontrol,inv,new,newcontrol) in enumerate(rows):
 p=properties(unit(old));assert terminal(p,inv);empty_cgroup(p)
 nc=art/newcontrol
 if i:nc.mkdir()
 oldlaunch=art/oldcontrol/'launch.json'
 cmd=replacement_command(json.loads(oldlaunch.read_text())['command'],old_unit=unit(old),new_unit=unit(new),old_output=str(art/old),new_output=str(art/new),old_log=str(art/oldcontrol/'run.log'),new_log=str(nc/'run.log'),after_unit=parent,after_invocation=parentinv,after_receipt=parentreceipt)
 if i==0:
  for k,v in (('--source',str(source)),('--manifest',str(control/'source-manifest.json'))):cmd[cmd.index(k)+1]=v
  cmd=[f'--working-directory={source}' if s.startswith('--working-directory=') else f'--setenv=PYTHONPATH={source}' if s.startswith('--setenv=PYTHONPATH=') else s for s in cmd]
 data=dict(command=cmd,previous_launch=str(oldlaunch),created_at=time.time(),frozen_source_unchanged=i!=0,model_source_unchanged=True,reason='Preserve failed L1 block-34 attempt; defer both block-34 down candidates and resume unstarted followers',physical_cases=62 if i==0 else None)
 (nc/'launch.json').write_text(json.dumps(data,indent=2)+'\n')
 subprocess.run(cmd,check=True,timeout=30)
 active=properties(unit(new));assert active['ActiveState']=='active' and active['MainPID']!='0'
 (nc/'launch-unit.json').write_text(json.dumps(active,indent=2)+'\n')
 launched.append(dict(unit=unit(new),properties=active,output=str(art/new)))
 print(json.dumps(launched[-1]),flush=True)
 parent,parentinv,parentreceipt=unit(new),active['InvocationID'],str(art/new/'queue.json')
(control/'launched.json').write_text(json.dumps(launched,indent=2)+'\n')
print((control/'preflight.log').read_text()[-1200:])
'''
subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','IdentityAgent=none','-o','IdentitiesOnly=yes','-i','/Users/anatarajan/.ssh/id_ed25519','ttuser@10.228.203.98','python3 -'],input='PAYLOAD='+repr(payload)+'\nprefix='+repr(prefix)+'\n'+remote,text=True,check=True,timeout=750)
