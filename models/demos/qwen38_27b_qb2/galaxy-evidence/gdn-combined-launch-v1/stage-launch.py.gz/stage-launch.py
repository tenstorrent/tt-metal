import base64,subprocess
from pathlib import Path
repo=Path('/private/tmp/tt-metal-qwen38-long-context');prefix='models/demos/qwen38_27b_qb2/'
files=[p for folder in ('tt','demo','tests','config') for p in (repo/prefix/folder).rglob('*') if p.is_file() and p.suffix in ('.py','.cpp','.h','.hpp','.json','.sh')]
payload={str(p.relative_to(repo)):base64.b64encode(p.read_bytes()).decode() for p in files}
remote=r'''
import base64,hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
art=Path('/home/ttuser/qwen38-artifacts-20261007');task=Path('/home/ttuser/kimi-prefill.Ubx2wY/runtime/qwen38-27b-20261006')
source=art/'gdn-combined-source-v1';control=art/'gdn-combined-control-v1';output=art/'gdn-combined-v1';follow=art/'gdn-combined-followup-control-v1';followout=art/'gdn-combined-followup-v1'
assert not any(p.exists() for p in (source,control,output,follow,followout))
assert shutil.disk_usage(art).free>20*1024**3
sys.path.insert(0,str(art/'export-recovery-source-v2'))
from models.demos.qwen38_27b_qb2.demo.watch_profile_export import properties,empty_cgroup
parent='qwen38-gdn-compact-gates-v3-20261010.service';pin='9d7889e59af942ef8e45967635e28d95'
p=properties(parent);assert p['MainPID']=='0' and p['ActiveState'] in ('inactive','failed') and p['Result']=='success';empty_cgroup(p)
prior=json.loads((art/'gdn-compact-gates-v3/queue.json').read_text());assert prior['state']=='completed' and prior['cleanup_completed'] is True
shutil.copytree(art/'operator-profile-source-v1',source,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache','.benchmarks','generated','.git','galaxy-evidence','experiments'))
control.mkdir();follow.mkdir()
for name,encoded in PAYLOAD.items():
 p=source/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(base64.b64decode(encoded))
python=str(task/'python_env/bin/python');model=source/prefix
env=dict(os.environ,TT_METAL_HOME=str(task/'metal'),LD_LIBRARY_PATH=f'{task}/metal-install/lib:{task}/metal-build/lib',PYTHONPATH=f'{source}:{task}/metal:{task}/metal/tools',ARCH_NAME='blackhole',OMP_NUM_THREADS='4',TT_METAL_INSPECTOR_RPC='0')
with (control/'preflight.log').open('w') as log:
 subprocess.run([python,'-m','pytest',str(model/'tests/unit'),'-c',str(source/'pytest.ini'),f'--rootdir={source}','-o','addopts=','-q',f'--junitxml={control}/unit.xml'],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
 subprocess.run([python,'-m','pytest',str(model/'tests/test_compact_gdn_long_horizon.py'),str(model/'tests/test_galaxy_perf_sweep.py'),'--collect-only','-q','-c',str(source/'pytest.ini'),f'--rootdir={source}','-o','addopts='],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
print((control/'preflight.log').read_text()[-2000:],flush=True)
files=[source/n for n in ('conftest.py','pytest.ini','scripts/run_safe_pytest.sh')]
files.extend(p for p in model.rglob('*') if p.is_file() and p.suffix in ('.py','.cpp','.h','.hpp','.json','.sh'))
manifest={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
mp=control/'source-manifest.json';mp.write_text(json.dumps(manifest,indent=2)+'\n')
base=['systemd-run','--user','--property=RuntimeMaxSec=24h','--property=TimeoutStopSec=210','--property=KillMode=control-group','--property=MemoryMax=256G','--property=CPUQuota=1600%',f'--working-directory={source}',f'--setenv=PYTHONPATH={source}','--setenv=PYTHONUNBUFFERED=1']
unit='qwen38-gdn-combined-v1-20261010.service'
cmd=base+[f'--unit={unit.removesuffix(".service")}',f'--property=StandardOutput=append:{control}/run.log',f'--property=StandardError=append:{control}/run.log',python,'-m',prefix.replace('/','.')+'demo.run_compact_gdn','--task',str(task),'--source',str(source),'--weights',str(art/'checkpoint-pinned-1d4bf0f2'),'--output',str(output),'--manifest',str(mp),'--combined','--after-unit',parent,'--after-invocation',pin,'--after-receipt',str(art/'gdn-compact-gates-v3/queue.json')]
meta=dict(command=cmd,created_at=time.time(),source_parent='09f5c9437d5',source_manifest_sha256=hashlib.sha256(mp.read_bytes()).hexdigest(),hardware_plan=['4096 changing-input steps B16/B32: qualified compact versus resident+gates','B16/32K and 16K full-model before/candidate/after, three repeats plus warmup'],estimated_model_saving_ms=0.94,estimated_model_tsu_32k=20.42,estimate_not_guaranteed=True,expected_hardware_minutes=[35,60],precision_change=False,survives_disconnect=True,resumes_after_reboot=False,promoted_to_serving=False)
(control/'launch.json').write_text(json.dumps(meta,indent=2)+'\n')
subprocess.run(cmd,check=True,timeout=30);p=properties(unit);assert p['ActiveState']=='active' and p['MainPID']!='0'
(control/'launch-unit.json').write_text(json.dumps(p,indent=2)+'\n');print(json.dumps(dict(unit=unit,properties=p)),flush=True)
fu='qwen38-gdn-combined-followup-v1-20261010.service'
cmd=base+[f'--unit={fu.removesuffix(".service")}',f'--property=StandardOutput=append:{follow}/run.log',f'--property=StandardError=append:{follow}/run.log',python,'-m',prefix.replace('/','.')+'demo.run_compact_followup','--task',str(task),'--source',str(source),'--weights',str(art/'checkpoint-pinned-1d4bf0f2'),'--output',str(followout),'--profile-output',str(art/'gdn-combined-unused-profile-v1'),'--manifest',str(mp),'--compact-manifest',str(mp),'--compact-results',str(output),'--after-unit',unit,'--after-invocation',p['InvocationID'],'--combined','--skip-profile']
meta=dict(command=cmd,created_at=time.time(),source_manifest_sha256=hashlib.sha256(mp.read_bytes()).hexdigest(),hardware_plan=['Only after clean source-matched >=1% B16/32K gain: 8-replica G0/API and full 198-question GPQA'],expected_hardware_minutes=[70,100],estimate_not_guaranteed=True,survives_disconnect=True,resumes_after_reboot=False,promoted_to_serving=False)
(follow/'launch.json').write_text(json.dumps(meta,indent=2)+'\n')
subprocess.run(cmd,check=True,timeout=30);p=properties(fu);assert p['ActiveState']=='active' and p['MainPID']!='0'
(follow/'launch-unit.json').write_text(json.dumps(p,indent=2)+'\n');print(json.dumps(dict(unit=fu,properties=p)),flush=True)
'''
subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','IdentityAgent=none','-o','IdentitiesOnly=yes','-i','/Users/anatarajan/.ssh/id_ed25519','ttuser@10.228.203.98','python3 -'],input='PAYLOAD='+repr(payload)+'\nprefix='+repr(prefix)+'\n'+remote,text=True,check=True,timeout=900)
