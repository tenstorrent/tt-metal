import base64
import subprocess
from pathlib import Path

repo=Path('/private/tmp/tt-metal-qwen38-long-context')
names=['models/demos/qwen38_27b_qb2/'+n for n in ('tt/decoder.py','tt/decoder_tp.py','tt/gdn_step/workspace.py','tests/unit/test_gdn_decode_integration.py')]
payload={n:base64.b64encode((repo/n).read_bytes()).decode() for n in names}
remote=r'''
import base64,hashlib,json,os,shutil,subprocess,time
from pathlib import Path
art=Path('/home/ttuser/qwen38-artifacts-20261007')
task=Path('/home/ttuser/kimi-prefill.Ubx2wY/runtime/qwen38-27b-20261006')
def props(unit):
 raw=subprocess.check_output(['systemctl','--user','show',unit,'-p','MainPID','-p','ActiveState','-p','LoadState','-p','Result','-p','InvocationID'],text=True,timeout=20)
 return dict(line.split('=',1) for line in raw.splitlines() if '=' in line)
audit={}
for stem,inv in [('compact-gdn-v2','43f1990817724573a9b130ed61f3ff0e'),('compact-followup-v2','1a140fb3cc4e4aea92234ad4d38de9d6'),('projection-sweep-v4','dd0ad89df8004f78aa4270a047e35f91'),('prefill-attention-v1','9df6962d09c44beabf1037326bb33f2e')]:
 p=props('qwen38-'+stem+'-20261010.service');audit[stem]=p
 assert p['MainPID']=='0' and p['ActiveState']=='failed' and p['InvocationID']==inv
 if stem!='compact-gdn-v2':assert json.loads((art/stem/'queue.json').read_text())['hardware_started'] is False
failed=json.loads((art/'compact-gdn-v2/compact/sweep.json').read_text())
assert failed['state']=='failed' and failed['cleanup_completed'] is True
assert 'clash with L1 buffers' in failed['error']['message']
assert json.loads((art/'b16-priority-v2/queue.json').read_text())['cleanup_completed'] is True
assert shutil.disk_usage(art).free>20*1024**3 and shutil.disk_usage('/dev/shm').free>64*1024**3
source,control,output=[art/n for n in ('compact-gdn-source-v3','compact-gdn-control-v3','compact-gdn-v3')]
assert not any(p.exists() for p in (source,control,output))
shutil.copytree(art/'prefill-attention-source-v1',source,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache','.benchmarks','generated'))
control.mkdir()
for n,b in PAYLOAD.items():(source/n).write_bytes(base64.b64decode(b))
(control/'recovery-audit.json').write_text(json.dumps(dict(units=audit,failed_hardware_cleanup=True,error=failed['error']['message'].split('backtrace:')[0]),indent=2)+'\n')
model=source/'models/demos/qwen38_27b_qb2';python=str(task/'python_env/bin/python')
env=dict(os.environ,TT_METAL_HOME=str(task/'metal'),LD_LIBRARY_PATH=f'{task}/metal-install/lib:{task}/metal-build/lib',PYTHONPATH=f'{source}:{task}/metal:{task}/metal/tools',ARCH_NAME='blackhole',OMP_NUM_THREADS='1',TT_METAL_INSPECTOR_RPC='0')
for key in ('TT_METAL_SIMULATOR','TT_METAL_DISABLE_SFPLOADMACRO','TT_METAL_SLOW_DISPATCH_MODE','QWEN_PREFILL_BATCHED_ATTENTION'):env.pop(key,None)
with (control/'preflight.log').open('w') as log:
 subprocess.run([python,'-m','pytest',str(model/'tests/unit'),'-c',str(source/'pytest.ini'),f'--rootdir={source}','-o','addopts=','-q',f'--junitxml={control}/unit.xml'],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
 subprocess.run([python,'-m','pytest',str(model/'tests/test_gdn_epilogue_layer.py'),str(model/'tests/test_full_trace_profile.py'),'--collect-only','-q','-c',str(source/'pytest.ini'),f'--rootdir={source}','-o','addopts='],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
print((control/'preflight.log').read_text()[-1400:],flush=True)
files=[source/n for n in ('conftest.py','pytest.ini','scripts/run_safe_pytest.sh')]
files.extend(p for p in model.rglob('*') if p.suffix in ('.py','.cpp','.h','.hpp','.json'))
manifest={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(control/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
launch=json.loads((art/'compact-gdn-control-v2/launch.json').read_text())
command=[s.replace('compact-gdn-source-v2','compact-gdn-source-v3').replace('compact-gdn-control-v2','compact-gdn-control-v3').replace('compact-gdn-v2','compact-gdn-v3') for s in launch['command']]
launch.update(command=command,created_at=time.time(),source_parent='cf181d0f1cd',changed_files=list(PAYLOAD),reason='Share only compact transient L1 operands across serialized CQ0 layers; all state remains private',native_install_changed=False,prefill_batched_attention_enabled=False,expected_full_model_tsu=20,expected_gain_is_estimate=True,source_manifest_sha256=hashlib.sha256((control/'source-manifest.json').read_bytes()).hexdigest())
(control/'launch.json').write_text(json.dumps(launch,indent=2)+'\n')
subprocess.run(command,check=True,timeout=30)
active=props('qwen38-compact-gdn-v3-20261010.service');assert active['ActiveState']=='active' and active['MainPID']!='0'
(control/'launch-unit.json').write_text(json.dumps(active,indent=2)+'\n');print('compact',active,flush=True)
follow=art/'compact-followup-control-v3';follow.mkdir()
previous=json.loads((art/'compact-followup-control-v2/launch.json').read_text())
cmd=[s.replace('qwen38-compact-followup-v2-20261010','qwen38-compact-followup-v3-20261010').replace('compact-followup-control-v2/run.log','compact-followup-control-v3/run.log') for s in previous['command']]
for name,value in [('--source',str(source)),('--output',str(art/'compact-followup-v3')),('--profile-output','/dev/shm/qwen38-compact-profile-v2-20261010'),('--manifest',str(control/'source-manifest.json')),('--compact-manifest',str(control/'source-manifest.json')),('--compact-results',str(output)),('--after-unit','qwen38-compact-gdn-v3-20261010.service'),('--after-invocation',active['InvocationID'])]:cmd[cmd.index(name)+1]=value
cmd=[f'--working-directory={source}' if s.startswith('--working-directory=') else f'--setenv=PYTHONPATH={source}' if s.startswith('--setenv=PYTHONPATH=') else s for s in cmd]
previous.update(command=cmd,created_at=time.time(),source_parent='cf181d0f1cd',reason='Qualify and profile recovered shared-pool compact source')
(follow/'launch.json').write_text(json.dumps(previous,indent=2)+'\n');subprocess.run(cmd,check=True,timeout=30)
fstate=props('qwen38-compact-followup-v3-20261010.service');assert fstate['ActiveState']=='active' and fstate['MainPID']!='0'
(follow/'launch-unit.json').write_text(json.dumps(fstate,indent=2)+'\n');print('followup',fstate,flush=True)
def follower(old,new,parent,invocation):
 c=art/(new+'-control')
 # Preserve established path ordering, e.g. projection-sweep-control-v5.
 c=art/(new.rsplit('-v',1)[0]+'-control-v'+new.rsplit('-v',1)[1]);c.mkdir()
 oldc=art/(old.rsplit('-v',1)[0]+'-control-v'+old.rsplit('-v',1)[1])
 prior=json.loads((oldc/'launch.json').read_text())
 cmd=[s.replace('--unit=qwen38-'+old+'-20261010','--unit=qwen38-'+new+'-20261010').replace(str(oldc/'run.log'),str(c/'run.log')) for s in prior['command']]
 for name,value in [('--output',str(art/new)),('--after-unit','qwen38-'+parent+'-20261010.service'),('--after-invocation',invocation),('--after-receipt',str(art/parent/'queue.json'))]:cmd[cmd.index(name)+1]=value
 prior.update(command=cmd,created_at=time.time(),reason='Recover unused follower after clean compact L1 failure',frozen_source_unchanged=True)
 (c/'launch.json').write_text(json.dumps(prior,indent=2)+'\n');subprocess.run(cmd,check=True,timeout=30)
 state=props('qwen38-'+new+'-20261010.service');assert state['ActiveState']=='active' and state['MainPID']!='0'
 (c/'launch-unit.json').write_text(json.dumps(state,indent=2)+'\n');print(new,state,flush=True);return state
pstate=follower('projection-sweep-v4','projection-sweep-v5','compact-followup-v3',fstate['InvocationID'])
follower('prefill-attention-v1','prefill-attention-v2','projection-sweep-v5',pstate['InvocationID'])
'''
subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','IdentityAgent=none','-o','IdentitiesOnly=yes','-i','/Users/anatarajan/.ssh/id_ed25519','ttuser@10.228.203.98','python3 -'],input='PAYLOAD='+repr(payload)+'\n'+remote,text=True,check=True,timeout=900)
