# SPDX-FileCopyrightText: © 2026 Tenstorrent USA, Inc.
# SPDX-License-Identifier: Apache-2.0
"""Ensure the experiment fails closed if the shared reader changes."""

import pytest

from models.demos.qwen38_27b_qb2.tests.gdn_resident_padding import INITIALIZATION, reader_variant
from models.demos.qwen38_27b_qb2.tt.gdn_step.op import kernel_source


@pytest.mark.parametrize("mode", ["zero", "skip", "poison"])
@pytest.mark.parametrize("source", ["", INITIALIZATION * 2])
def test_changed_reader_is_rejected(mode, source, expect_error):
    with expect_error(ValueError, "anchor changed or is ambiguous"):
        reader_variant(source, mode)


def test_only_initialization_changes():
    source = kernel_source("reader.cpp")
    assert reader_variant(source, "zero") == source
    before, after = source.split(INITIALIZATION)
    for mode in ("skip", "poison"):
        variant = reader_variant(source, mode)
        assert variant.startswith(before) and variant.endswith(after)
    assert "vr[i] =" not in reader_variant(source, "skip")
    assert "vr[i] = 0x7fc12345" in reader_variant(source, "poison")


@pytest.mark.parametrize("mode", [None, "", "garbage"])
def test_unknown_mode_rejected(mode, expect_error):
    with expect_error(ValueError, "Padding mode must"):
        reader_variant(kernel_source("reader.cpp"), mode)
