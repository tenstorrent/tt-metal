# SPDX-FileCopyrightText: © 2026 Tenstorrent USA, Inc.
# SPDX-License-Identifier: Apache-2.0
"""Isolated reader experiment; leave the production reader and its ABI unchanged."""

INITIALIZATION = """        // V's unused rows must be zero for the SFPU residual. Q/K column
        // broadcasts and scalar broadcasts never consume the other lanes.
        for (uint32_t i = 0; i < value_columns * 1024; ++i) {
            vr[i] = 0;
        }
"""


def reader_variant(source, mode):
    """Only resident, pre-normalized, one-column callers may use these sources.

    The resident SFPU row broadcast consumes delta row zero only. Poison the
    other rows to test that assumption; skip their stores only after that test.
    Source text is part of generic_op's program cache key.
    """
    if mode not in ("zero", "skip", "poison"):
        raise ValueError("Padding mode must be zero, skip, or poison")
    if source.count(INITIALIZATION) != 1:
        raise ValueError("Reader initialization anchor changed or is ambiguous")
    if mode == "zero":
        return source
    replacement = "        // Experimental resident path: only V row zero is consumed.\n"
    if mode == "poison":
        replacement += """        for (uint32_t i = 0; i < value_columns * 1024; ++i) {
            vr[i] = 0x7fc12345;  // Quiet NaN; live row is overwritten below.
        }
"""
    return source.replace(INITIALIZATION, replacement)
