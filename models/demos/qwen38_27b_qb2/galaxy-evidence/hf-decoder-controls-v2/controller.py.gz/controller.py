import hashlib
import json
from pathlib import Path
import subprocess
import time
import xml.etree.ElementTree as ET

from models.demos.qwen38_27b_qb2.demo.run_bounded_layer_profile import run_capture
from models.demos.qwen38_27b_qb2.demo.run_chunked_prefill_followup import predecessor_ready
from models.demos.qwen38_27b_qb2.demo.run_long_context_capacity import environment, save

art=Path('/home/ttuser/qwen38-artifacts-20261007')
task=Path('/home/ttuser/kimi-prefill.Ubx2wY/runtime/qwen38-27b-20261006')
source=art/'hf-controls-source-v2';control=art/'hf-controls-control-v2';root=art/'hf-controls-v2'
root.mkdir();model=source/'models/demos/qwen38_27b_qb2'
status=root/'queue.json'
state=dict(state='preflight',started_at=time.time(),runs=[],survives_disconnect=True,resumes_after_reboot=False,is_gpqa_score=False,is_performance_measurement=False)
save(status,state)
try:
    unit='qwen38-hf-layer-v2-20261009.service'
    props=dict(line.split('=',1) for line in subprocess.check_output(['systemctl','--user','show',unit,'-p','MainPID','-p','ActiveState','-p','InvocationID','-p','LoadState','-p','Result'],text=True,timeout=15).splitlines() if '=' in line)
    receipt=json.loads((art/'hf-layer-v2/queue.json').read_text())
    if not predecessor_ready(props,receipt,'60840a4a755740689518e67aa1afc4e8'):
        raise ValueError('Baseline diagnostic is not terminal')
    manifest=json.loads((control/'source-manifest.json').read_text())
    for path,digest in manifest.items():
        if hashlib.sha256((source/path).read_bytes()).hexdigest()!=digest:
            raise ValueError('Frozen source changed: '+path)
    env=environment(task,source,art/'checkpoint-pinned-1d4bf0f2')
    for key in ['TT_METAL_SIMULATOR','TT_METAL_KERNEL_PATH','TT_METAL_DISABLE_SFPLOADMACRO','TT_VISIBLE_DEVICES']:
        env.pop(key,None)
    env.update(QWEN_HF_LAYER_REFERENCE='1',QWEN_HF_WEIGHTS=str(art/'checkpoint-pinned-1d4bf0f2'),QWEN_HF_QUALIFICATION=str(art/'accuracy-head-v1/native-g0/receipts/full-model.json'),QWEN_HF_PRECISION=str(model/'config/precision_accurate_decode_bfp8_head.json'),QWEN_HF_REFERENCE=str(art/'hf-head-reference-v2'),QWEN_PRECISION_CONFIG=str(model/'config/precision_accurate_decode_bfp8_head.json'),QWEN_DECODE_BUCKETS='1')
    for name,policy in [('bfp4-hifi2','precision_accurate_decode_hifi2.json'),('bfp8-hifi2','precision_accurate_decode_bfp8_all.json')]:
        dest=root/name;dest.mkdir()
        env.update(QWEN_HF_OUTPUT=str(dest/'comparison'),QWEN_HF_CONTROL_PRECISION=str(model/'config'/policy))
        command=['/bin/bash',str(source/'scripts/run_safe_pytest.sh'),str(model/'tests/test_hf_layer_reference.py'),f'--rootdir={source}','-c',str(source/'pytest.ini'),'-vv','-s','--timeout=2400',f'--junitxml={dest}/hardware.xml']
        row=dict(name=name,state='running',started_at=time.time(),command=command,precision_file=policy)
        state['runs'].append(row);state['state']='running';save(status,state)
        run_capture(command,cwd=source,env=env,root=dest,timeout=3000)
        report=json.loads((dest/'comparison/progress.json').read_text())
        suites=ET.parse(dest/'hardware.xml').getroot().findall('.//testsuite')
        if report.get('state')!='completed' or report.get('cleanup_completed') is not True or len(report.get('steps',[]))!=8 or report.get('diagnostic_control') is not True or report.get('serving_qualified') is not False or sum(int(s.get('tests',0)) for s in suites)!=1 or any(int(s.get(k,0)) for s in suites for k in ['failures','errors','skipped']):
            raise ValueError('Precision diagnostic did not complete cleanly')
        row.update(state='completed',finished_at=time.time(),cleanup_completed=True,precision=report['precision'],logit_metrics=[s['full_model_logits'] for s in report['steps']]);save(status,state)
    state.update(state='completed',finished_at=time.time(),cleanup_completed=True)
except BaseException as error:
    state.update(state='failed',error=type(error).__name__,detail=str(error)[:2000],finished_at=time.time())
    if state['runs'] and state['runs'][-1]['state']=='running':state['runs'][-1]['state']='failed'
    raise
finally:
    save(status,state)
