import base64
import json
import subprocess
from pathlib import Path

repo = Path('/private/tmp/tt-metal-qwen38-long-context')
name = 'models/demos/qwen38_27b_qb2/tests/test_gdn_epilogue_layer.py'
payload = {name: base64.b64encode((repo / name).read_bytes()).decode()}
remote = r'''
import base64, hashlib, json, os, shutil, subprocess, time
from pathlib import Path
art=Path('/home/ttuser/qwen38-artifacts-20261007')
task=Path('/home/ttuser/kimi-prefill.Ubx2wY/runtime/qwen38-27b-20261006')
source,control,output=[art/n for n in ('compact-gdn-source-v2','compact-gdn-control-v2','compact-gdn-v2')]
assert not any(p.exists() for p in (source,control,output))
assert shutil.disk_usage(art).free>15*1024**3
old=json.loads((art/'compact-gdn-v1/queue.json').read_text())
layer=json.loads((art/'compact-gdn-v1/layer/layer.json').read_text())
assert old['state']=='failed' and layer['cleanup_completed'] is True
assert 'Changing-input compact GDN diverged' in layer['error']['message']
def props(unit):
 raw=subprocess.check_output(['systemctl','--user','show',unit,'-p','MainPID','-p','ActiveState','-p','SubState','-p','InvocationID','-p','Result','-p','LoadState'],text=True)
 return dict(line.split('=',1) for line in raw.splitlines() if '=' in line)
assert props('qwen38-compact-gdn-v1-20261010.service')['MainPID']=='0'
assert props('qwen38-projection-sweep-v2-20261010.service')['MainPID']=='0'
assert json.loads((art/'b16-priority-v2/queue.json').read_text())['cleanup_completed'] is True
shutil.copytree(art/'compact-gdn-source-v1',source,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache','.benchmarks','generated'))
control.mkdir()
for name,value in PAYLOAD.items():
 (source/name).write_bytes(base64.b64decode(value))
model=source/'models/demos/qwen38_27b_qb2'
python=str(task/'python_env/bin/python')
env=dict(os.environ,TT_METAL_HOME=str(task/'metal'),LD_LIBRARY_PATH=f'{task}/metal-install/lib:{task}/metal-build/lib',
 PYTHONPATH=f'{source}:{task}/metal:{task}/metal/tools',ARCH_NAME='blackhole',OMP_NUM_THREADS='1',TT_METAL_INSPECTOR_RPC='0')
for key in ('TT_METAL_SIMULATOR','TT_METAL_DISABLE_SFPLOADMACRO','TT_METAL_SLOW_DISPATCH_MODE','QWEN_GDN_EPILOGUE_LAYER'):
 env.pop(key,None)
with (control/'preflight.log').open('w') as log:
 subprocess.run([python,'-m','pytest',str(model/'tests/unit'),'-c',str(source/'pytest.ini'),f'--rootdir={source}',
 '-o','addopts=','-q',f'--junitxml={control}/unit.xml'],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
 subprocess.run([python,'-m','pytest',str(model/'tests/test_gdn_epilogue_layer.py'),'--collect-only','-q',
 '-c',str(source/'pytest.ini'),f'--rootdir={source}','-o','addopts='],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
print((control/'preflight.log').read_text()[-1500:],flush=True)
files=[source/n for n in ('conftest.py','pytest.ini','scripts/run_safe_pytest.sh')]
files.extend(p for p in model.rglob('*') if p.suffix in ('.py','.cpp','.h','.hpp','.json'))
manifest={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(control/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
launch=json.loads((art/'compact-gdn-control-v1/launch.json').read_text())
command=[s.replace('compact-gdn-source-v1','compact-gdn-source-v2').replace('compact-gdn-control-v1','compact-gdn-control-v2').replace('compact-gdn-v1','compact-gdn-v2') for s in launch['command']]
launch.update(command=command,created_at=time.time(),source_parent='f6be84a4c00',
 changed_files=list(PAYLOAD),reason='Preallocate and warm both independent test sessions before either trace captures scratch; retain exact checks',
 kernel_code_changed=False,root_cause_proven=False,
 source_manifest_sha256=hashlib.sha256((control/'source-manifest.json').read_bytes()).hexdigest())
(control/'launch.json').write_text(json.dumps(launch,indent=2)+'\n')
subprocess.run(command,check=True)
current=props('qwen38-compact-gdn-v2-20261010.service')
(control/'launch-unit.json').write_text(json.dumps(current,indent=2)+'\n')
print('compact',current,flush=True)
assert current['MainPID']!='0' and current['ActiveState']=='active'
newcontrol=art/'projection-sweep-control-v3'
assert not newcontrol.exists() and not (art/'projection-sweep-v3').exists()
newcontrol.mkdir()
projection=json.loads((art/'projection-sweep-control-v2/launch.json').read_text())['command']
projection=[s.replace('--unit=qwen38-projection-sweep-v2-20261010','--unit=qwen38-projection-sweep-v3-20261010').replace('projection-sweep-control-v2/run.log','projection-sweep-control-v3/run.log') for s in projection]
for name,value in [('--output',str(art/'projection-sweep-v3')),('--after-unit','qwen38-compact-gdn-v2-20261010.service'),('--after-invocation',current['InvocationID']),('--after-receipt',str(output/'queue.json'))]:
 projection[projection.index(name)+1]=value
(newcontrol/'launch.json').write_text(json.dumps(dict(command=projection,created_at=time.time(),frozen_source_unchanged=True,reason='Follow bounded compact harness recovery'),indent=2)+'\n')
subprocess.run(projection,check=True)
state=props('qwen38-projection-sweep-v3-20261010.service')
(newcontrol/'launch-unit.json').write_text(json.dumps(state,indent=2)+'\n')
print('projection',state,flush=True)
'''
subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','IdentityAgent=none','-o','IdentitiesOnly=yes',
 '-i','/Users/anatarajan/.ssh/id_ed25519','ttuser@10.228.203.98','python3 -'],
 input='PAYLOAD='+repr(payload)+'\n'+remote,text=True,check=True,timeout=900)
