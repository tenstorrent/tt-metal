// SPDX-FileCopyrightText: © 2025 Tenstorrent USA, Inc.
//
// SPDX-License-Identifier: Apache-2.0

#include "ttnn/operations/transformer/sdpa/device/sdpa_device_operation.hpp"
#include "ttnn/operations/transformer/sdpa/device/sdpa_interleaved_cb_ids.hpp"
#include "ttnn/operations/transformer/sdpa/device/sdpa_subblock_utils.hpp"
#include "ttnn/operations/transformer/sdpa/device/kernels/sliding_window_geometry.hpp"
#include <tt-metalium/buffer.hpp>
#include <tt-metalium/constants.hpp>
#include <tt-logger/tt-logger.hpp>
#include <tt-metalium/host_api.hpp>
#include <tt-metalium/program_descriptors.hpp>
#include "ttnn/operations/math.hpp"
#include <tt-metalium/tensor_accessor_args.hpp>
#include <hostdevcommon/common_values.hpp>
#include <bit>
#include <map>
#include <optional>
#include <string>
#include <cmath>

using namespace tt::constants;
using namespace tt::tt_metal;

namespace ttnn::prim {

// Chain management structures for KV store-and-forward optimization
struct CoreHeadWork {
    uint32_t batch = 0;
    uint32_t head = 0;
    uint32_t q_chunk_count = 0;
};

struct CoreWork {
    CoreCoord logical_core;
    CoreCoord physical_core;
    uint32_t global_q_start = 0;
    uint32_t global_q_count = 0;
    std::vector<CoreHeadWork> head_work;
};

struct HeadSegmentRef {
    uint32_t core_idx = 0;
    uint32_t head_work_index = 0;
};

struct CoreChainInfo {
    bool participates = false;
    bool is_injector = false;
    bool is_sink = false;
    uint32_t batch = 0;
    uint32_t head = 0;
    uint32_t q_chunk_count = 0;
    CoreCoord prev_physical = CoreCoord{0, 0};
    CoreCoord next_physical = CoreCoord{0, 0};
    uint32_t next_core_q_chunks = 0;
    uint32_t mcast_num_dests = 0;    // num_dests for mcast API (includes self if injector inside rect)
    uint32_t mcast_sender_wait = 0;  // number of actual receivers that signal back (always chain_size - 1)
};

namespace {

// Select the mask data format: user-provided mask dtype, or Float16_b for streaming (avoids Bfp4_b precision loss),
// or Bfp4_b for legacy path.
tt::DataFormat select_mask_dataformat(const std::optional<Tensor>& attn_mask, bool use_streaming_compute) {
    if (attn_mask.has_value()) {
        return tt::tt_metal::datatype_to_dataformat_converter(attn_mask.value().dtype());
    }
    return use_streaming_compute ? tt::DataFormat::Float16_b : tt::DataFormat::Bfp4_b;
}

// Streaming compute (v2) handles every SDPA variant; only fp32 dest-accumulate falls back to the
// legacy compute kernel.
bool can_use_streaming_compute(bool fp32_dest_acc_en) { return !fp32_dest_acc_en; }

uint32_t lightweight_mask_tile_count(bool is_causal, bool has_sliding_window, bool has_k_partial_mask) {
    uint32_t tiles = 1;  // neginf
    if (has_sliding_window) {
        tiles += kSlidingWindowEdgeTiles;
    } else if (is_causal) {
        tiles++;  // causal diagonal
    }
    if (has_k_partial_mask) {
        tiles++;  // partial K tile
    }
    return tiles;
}

// Compute the largest granularity that evenly divides both DHt and vDHt (up to dst_size).
uint32_t compute_dht_granularity(uint32_t DHt, uint32_t vDHt, uint32_t dst_size) {
    uint32_t g = std::min({DHt, vDHt, dst_size});
    while (g > 1 && (DHt % g != 0 || vDHt % g != 0)) {
        g--;
    }
    return g;
}

// Resolve exp_approx_mode from program config, defaulting to true.
bool get_exp_approx_mode(const std::optional<ttnn::operations::transformer::SDPAProgramConfig>& program_config) {
    if (program_config.has_value() && program_config->exp_approx_mode.has_value()) {
        return program_config->exp_approx_mode.value();
    }
    return true;
}

// Effective (num_kv_heads_k, num_kv_heads_v, block_size) for an HMA-shared paged buffer.
// Apply PagedCacheGeometryOverride only when !use_mla: MLA never passes overrides (validated
// upstream), and applying num_kv_heads to V under MLA would skip the elems/block check.
struct EffectiveKvGeometry {
    uint32_t nkh = 0;
    uint32_t nvh = 0;
    uint32_t block_size = 0;
};

EffectiveKvGeometry resolve_effective_kv_geometry(
    const ttnn::operations::transformer::PagedCacheGeometryOverride& geo,
    bool use_mla,
    uint32_t k_num_heads,
    uint32_t v_num_heads,
    uint32_t k_block_size) {
    if (use_mla || !geo.active()) {
        return {k_num_heads, v_num_heads, k_block_size};
    }
    return {geo.num_kv_heads, geo.num_kv_heads, geo.block_size};
}

// Chunked prefill parameters collected from page table layout.
struct ChunkedParams {
    uint32_t chunked_q_chunk_offset = 0;
    uint32_t block_size = 0;
    uint32_t block_size_t = 0;
    uint32_t max_blocks_per_seq = 0;
    uint32_t page_table_stick_size = 0;
};

// Compute chunked prefill parameters from the page table tensor.
ChunkedParams compute_chunked_params(
    bool is_chunked,
    bool is_chunked_legacy,
    bool flexible_chunked,
    const std::optional<int64_t>& chunk_start_idx,
    const std::optional<Tensor>& page_table,
    uint32_t k_seq_dim,
    std::size_t q_chunk_size) {
    ChunkedParams p;
    if (!is_chunked) {
        return p;
    }
    if (is_chunked_legacy) {
        p.chunked_q_chunk_offset = chunk_start_idx.value() / q_chunk_size;
    }
    const auto& page_table_tensor = page_table.value();
    p.block_size = k_seq_dim;
    p.block_size_t = p.block_size / TILE_HEIGHT;
    if (flexible_chunked) {
        p.max_blocks_per_seq = page_table_tensor.padded_shape()[1];
        p.page_table_stick_size = p.max_blocks_per_seq * sizeof(int32_t);
        TT_FATAL(p.page_table_stick_size % 32 == 0, "page table stick size must be a multiple of 32");
    } else {
        p.max_blocks_per_seq = page_table_tensor.padded_shape()[1];
        p.page_table_stick_size = page_table_tensor.buffer()->aligned_page_size();
        TT_FATAL(
            p.page_table_stick_size % 32 == 0,
            "page table page size in bytes must be a multiple of 32 due to address alignment");
    }
    return p;
}

tt::DataFormat fp32_dest_intermediate_dataformat(bool fp32_dest_acc_en) {
    return fp32_dest_acc_en ? tt::DataFormat::Float32 : tt::DataFormat::Float16_b;
}

uint32_t attention_sink_tile_count(bool use_attention_sink, bool use_streaming_compute, uint32_t q_chunk_tiles) {
    if (!use_attention_sink) {
        return 0;
    }
    return use_streaming_compute ? 1 : q_chunk_tiles;
}

// TensorAccessorArgs placeholder rule for optional tensors: nullptr when absent, so the accessor
// chain stays intact and kernels compile against it but never read it.
tt::tt_metal::Buffer* buffer_or_null(const std::optional<Tensor>& t) {
    return t.has_value() ? t.value().buffer() : nullptr;
}

// Windowed (block-diagonal) CB allocation and runtime values, split out of create_descriptor (which
// sits at clang-tidy's cognitive-complexity limit). The allocators are create_descriptor's CB lambdas.
struct WindowedSetup {
    tt::tt_metal::Buffer* cu_window_buffer = nullptr;
    tt::tt_metal::Buffer* q_offset_buffer = nullptr;
    uint32_t cu_window_seqlens_eles = 0;
    // Global row index of Q row 0. Non-zero only when Q is a sequence-parallel shard of a longer
    // sequence: Q and the output are addressed locally, while cu_window_seqlens and K/V stay global,
    // so the writer's mask generator needs the shard's origin to find the right windows.
    uint32_t q_token_offset = 0;
};

template <typename AllocateTileCb, typename AllocateCb>
WindowedSetup setup_windowed_cbs(
    const SDPAParams& attrs,
    const SDPAInputs& tensors,
    sdpa_cb::CBIds& cb_ids,
    const AllocateTileCb& allocate_tile_cb,
    const AllocateCb& allocate_cb) {
    WindowedSetup w;
    // When NOT windowed, fall back to a valid CB id (q_in): the writer's windowed block is gated by
    // `if constexpr`, but in a non-template function the discarded branch is still compiled, so
    // get_tile_size/get_dataformat on this id must be well-formed (an inactive id would
    // constexpr-fault on unpack_tile_size[-1]).
    cb_ids.cu_window_seqlens = cb_ids.q_in;
    cb_ids.windowed_q_offset = cb_ids.q_in;
    cb_ids.windowed_cu_reader = cb_ids.q_in;
    cb_ids.windowed_k_range = cb_ids.q_in;
    if (!attrs.is_windowed) {
        return w;
    }
    // 1-tile CB holding cu_window_seqlens, loaded once by the writer.
    const auto& cu = tensors.cu_window_seqlens.value();
    tt::DataFormat cu_df = tt::tt_metal::datatype_to_dataformat_converter(cu.dtype());
    cb_ids.cu_window_seqlens = allocate_tile_cb(1, tt::tile_size(cu_df), cu_df);
    // K-range narrowing: the reader gets its OWN cu_window copy (sharing the writer's CB would put
    // two producers on one CB), and a small reader->compute ctrl CB carrying each Q chunk's
    // {k_lo, k_hi} (double-buffered so the reader can run a Q chunk ahead; sparse_sdpa precedent).
    cb_ids.windowed_cu_reader = allocate_tile_cb(1, tt::tile_size(cu_df), cu_df);
    constexpr uint32_t k_range_page_size = 16;
    cb_ids.windowed_k_range = allocate_cb(k_range_page_size, 2, tt::DataFormat::Int32);
    w.cu_window_buffer = cu.buffer();
    w.cu_window_seqlens_eles = cu.logical_shape()[-1];
    w.q_token_offset = attrs.windowed_q_token_offset;
    if (tensors.windowed_q_token_offset_tensor.has_value()) {
        // Per-device form: the writer reads the value at runtime, so the scalar baked into the
        // program is unused. Kept identical across devices, which is the point -- one program.
        // The offset gets its own 1-tile CB: every other CB has a producer/consumer contract with
        // another kernel that a writer-side reserve/push would break (borrowing the reader-produced
        // chunk_start_idx_writer CB deadlocked).
        const auto& off = tensors.windowed_q_token_offset_tensor.value();
        tt::DataFormat off_df = tt::tt_metal::datatype_to_dataformat_converter(off.dtype());
        cb_ids.windowed_q_offset = allocate_tile_cb(1, tt::tile_size(off_df), off_df);
        w.q_offset_buffer = off.buffer();
    }
    return w;
}

}  // namespace

ProgramDescriptor SDPAOperation::SDPAProgramFactory::create_descriptor(
    const operation_attributes_t& operation_attributes,
    const tensor_args_t& tensor_args,
    tensor_return_value_t& tensor_return_value) {
    // Windowed (block-diagonal) attention reuses the regular reader/writer/compute kernels. The mask is
    // synthesized on-device in the writer from cu_window_seqlens (reader streams Q/K/V only) and consumed
    // by the compute via the provided-mask path. Like regular SDPA it honors the streaming-vs-standard
    // selection: streaming kernel when fp32_dest_acc_en is false (Blackhole default), standard otherwise.
    const bool is_windowed = operation_attributes.is_windowed;
    const auto& input_tensor_q = tensor_args.q;
    const auto& input_tensor_k = tensor_args.k;
    const auto& input_tensor_v = tensor_args.v.value_or(tensor_args.k);
    const auto& output_tensor = tensor_return_value;
    const auto& attn_mask = tensor_args.attn_mask;
    const auto& page_table = tensor_args.page_table;
    const auto& attention_sink = tensor_args.attention_sink;
    auto scale = operation_attributes.scale;
    if (not scale.has_value()) {
        scale = 1.0f / std::sqrt(static_cast<float>(input_tensor_q.padded_shape()[-1]));
    }
    const bool is_causal = operation_attributes.is_causal;
    const auto& chunk_start_idx = operation_attributes.chunk_start_idx;
    const auto& compute_kernel_config = operation_attributes.compute_kernel_config;
    const auto& program_config = operation_attributes.program_config;
    const bool use_mla = operation_attributes.use_mla;
    const bool mla_kv_overlap = use_mla && !tensor_args.v.has_value();
    const uint32_t head_dim_v = operation_attributes.head_dim_v.value_or(input_tensor_q.logical_shape()[3]);
    const auto& sliding_window_size = operation_attributes.sliding_window_size;

    std::size_t q_chunk_size =
        operation_attributes.program_config ? operation_attributes.program_config->q_chunk_size : 32;
    std::size_t k_chunk_size =
        operation_attributes.program_config ? operation_attributes.program_config->k_chunk_size : 32;

    /*
    Q: B x NQH x S x DH
    K: B x NKH x DH x S
    V: B x NKH x S x DH
    attn_mask: B x NQH x S x S  or  B x 1 x S x S
    */

    const auto& q_shape = input_tensor_q.logical_shape();
    const auto& k_shape = input_tensor_k.logical_shape();
    const auto& v_shape = input_tensor_v.logical_shape();
    const uint32_t B = q_shape[0], NQH = q_shape[1], Sq = q_shape[2], DH = q_shape[3];
    // Geometry overrides for an HMA-shared paged buffer (see PagedCacheGeometryOverride): when
    // the paged K/V cache was allocated for a different layer's view, the reader must address it
    // with this call's num_kv_heads / block_size (Q already drives head_dim via DHt) rather than
    // the cache's declared shape. Unset ⇒ the cache's own num_kv_heads / block_size. The reader
    // computes physical tile ids manually from these as compile-time args
    // (dataflow_common.hpp virtual_seq_tile_id_to_physical_tile_id).
    const auto kv_geo = resolve_effective_kv_geometry(
        operation_attributes.paged_cache_geometry, use_mla, k_shape[1], v_shape[1], k_shape[2]);
    const uint32_t NKH = kv_geo.nkh;
    const uint32_t NVH = kv_geo.nvh;
    const uint32_t effective_kv_block_size = kv_geo.block_size;

    // In flash mla prefill, we have to support the case where NKH != NVH
    // We are calling op with the following shapes:
    // q - [B, NHQ, Sq, DH_qk]
    // k - [B, 1, Sk, DH_qk]
    // v - [B, NVH, Sk, DH_v]
    // k head is in latent space, and is reused across all q heads

    // Paged cache parameters when in chunked mode
    const bool flexible_chunked = operation_attributes.chunk_start_idx_tensor.has_value();
    const bool is_chunked_legacy = chunk_start_idx.has_value() && !flexible_chunked;
    const bool is_chunked = is_chunked_legacy || flexible_chunked;
    // For flexible chunked: max prefix length = page_table num_pages * block_size (from K/V layout).
    uint32_t max_prefix_tokens_flexible = 0;
    if (is_chunked && flexible_chunked) {
        const uint32_t block_size_for_sk = effective_kv_block_size;
        const uint32_t max_blocks = page_table.value().padded_shape()[1];
        max_prefix_tokens_flexible = max_blocks * block_size_for_sk;
    }
    // In chunked mode: legacy uses chunk_start_idx + Sq; flexible uses Sq + max prefix from page table.
    const uint32_t Sk = is_chunked
                            ? (flexible_chunked ? (Sq + max_prefix_tokens_flexible) : (chunk_start_idx.value() + Sq))
                            : k_shape[2];

    /*
    Note about tensor shapes:
    SDPA inputs may be padded on the sequence length dimension. In addition,
    q_chunk_size and k_chunk_size don't have to divide the valid sequence length.
    Internally, the kernels pad tensors up to nearest multiple of the larger chunk size
    and handle masking pad tokens when appropriate.
    */

    // Calculate padded sequence length
    const uint32_t padded_Sq = std::ceil(static_cast<float>(Sq) / q_chunk_size) * q_chunk_size;
    const uint32_t padded_Sk = std::ceil(static_cast<float>(Sk) / k_chunk_size) * k_chunk_size;

    const uint32_t Sqt = padded_Sq / TILE_HEIGHT;
    const uint32_t Skt = padded_Sk / TILE_HEIGHT;
    const uint32_t DHt = DH / TILE_WIDTH;
    const uint32_t vDHt = use_mla ? head_dim_v / TILE_WIDTH : DHt;

    const uint32_t valid_Sqt = std::ceil(static_cast<float>(Sq) / TILE_HEIGHT);
    const uint32_t valid_Skt = std::ceil(static_cast<float>(Sk) / TILE_HEIGHT);
    /*
    For non-causal case with Q/K padding:
    - If user provides a mask: reader reads unpadded mask and fills padded K positions with -inf
    - If no mask provided: writer generates a mask with 0 for valid K and -inf for padded K
    In causal case, the causal mask naturally handles masking of padded K tokens.
    */
    const bool use_padded_mask = (!is_causal) && ((padded_Sk != Sk) || (padded_Sq != Sq));

    const uint32_t Sq_chunk_t = q_chunk_size / TILE_HEIGHT;
    const uint32_t Sk_chunk_t = k_chunk_size / TILE_HEIGHT;
    const uint32_t q_num_chunks = padded_Sq / q_chunk_size;
    const uint32_t k_num_chunks = padded_Sk / k_chunk_size;
    const bool use_provided_mask = attn_mask.has_value();
    const bool broadcast_provided_mask_batch = use_provided_mask ? (attn_mask.value().logical_shape()[0] == 1) : false;
    const bool broadcast_provided_mask_heads = use_provided_mask ? (attn_mask.value().logical_shape()[1] == 1) : false;
    // Windowed mode synthesizes the mask in the writer; the compute consumes it through the provided-mask
    // path even though there is no attn_mask tensor (and the reader does not read one).
    const bool compute_use_provided_mask = use_provided_mask || is_windowed;
    // Windowed masks are complete dense masks synthesized from cu_window_seqlens. They already cover padding
    // positions outside the final boundary, so the generic generated-padding-mask paths must stay disabled.
    const bool generated_padding_mask = use_padded_mask && !is_windowed;

    // log_debug all of the above
    log_debug(tt::LogOp, "B: {}", B);
    log_debug(tt::LogOp, "NQH: {}", NQH);
    log_debug(tt::LogOp, "NVH: {}", NVH);
    log_debug(tt::LogOp, "Sq: {}", Sq);
    log_debug(tt::LogOp, "Sk: {}", Sk);
    log_debug(tt::LogOp, "padded_Sq: {}", padded_Sq);
    log_debug(tt::LogOp, "padded_Sk: {}", padded_Sk);
    log_debug(tt::LogOp, "valid_Sqt: {}", valid_Sqt);
    log_debug(tt::LogOp, "valid_Skt: {}", valid_Skt);
    log_debug(tt::LogOp, "DH: {}", DH);
    log_debug(tt::LogOp, "Sqt: {}", Sqt);
    log_debug(tt::LogOp, "Skt: {}", Skt);
    log_debug(tt::LogOp, "DHt: {}", DHt);
    log_debug(tt::LogOp, "vDHt: {}", vDHt);
    log_debug(tt::LogOp, "Sq_chunk_t: {}", Sq_chunk_t);
    log_debug(tt::LogOp, "Sk_chunk_t: {}", Sk_chunk_t);
    log_debug(tt::LogOp, "q_chunk_size: {}", q_chunk_size);
    log_debug(tt::LogOp, "k_chunk_size: {}", k_chunk_size);
    log_debug(tt::LogOp, "q_num_chunks: {}", q_num_chunks);
    log_debug(tt::LogOp, "k_num_chunks: {}", k_num_chunks);
    log_debug(tt::LogOp, "NKH: {}", NKH);
    log_debug(tt::LogOp, "sliding_window_size: {}", sliding_window_size.has_value() ? sliding_window_size.value() : 0);

    const auto chunked = compute_chunked_params(
        is_chunked,
        is_chunked_legacy,
        flexible_chunked,
        chunk_start_idx,
        page_table,
        effective_kv_block_size,
        q_chunk_size);
    const uint32_t chunked_q_chunk_offset = chunked.chunked_q_chunk_offset;
    const uint32_t block_size = chunked.block_size;
    const uint32_t block_size_t = chunked.block_size_t;
    [[maybe_unused]] const uint32_t max_blocks_per_seq = chunked.max_blocks_per_seq;
    const uint32_t page_table_stick_size = chunked.page_table_stick_size;
    const tt::DataFormat page_table_df = tt::DataFormat::Int32;
    // Log page table info
    log_debug(tt::LogOp, "is_chunked: {}", is_chunked);
    if (is_chunked) {
        log_debug(tt::LogOp, "block_size: {}", block_size);
        log_debug(tt::LogOp, "block_size_t: {}", block_size_t);
        log_debug(tt::LogOp, "max_blocks_per_seq: {}", max_blocks_per_seq);
        log_debug(tt::LogOp, "page_table_stick_size: {}", page_table_stick_size);
        log_debug(tt::LogOp, "page_table_df: {}", page_table_df);
    }

    MeshDevice* device = input_tensor_q.device();

    auto [math_fidelity, math_approx_mode, fp32_dest_acc_en, packer_l1_acc, dst_full_sync_en] =
        get_compute_kernel_config_args(device->arch(), compute_kernel_config);

    auto* q_buffer = input_tensor_q.buffer();
    auto* k_buffer = input_tensor_k.buffer();
    auto* v_buffer = input_tensor_v.buffer();
    auto* mask_buffer = attn_mask.has_value() ? attn_mask.value().buffer() : nullptr;
    auto* attention_sink_buffer = attention_sink.has_value() ? attention_sink.value().buffer() : nullptr;
    // page_table and chunk_start_idx must be BufferBindings (not raw address writes);
    // otherwise their addresses go stale on descriptor cache hits.
    auto* page_table_buffer = is_chunked ? page_table.value().buffer() : nullptr;
    auto* chunk_start_idx_buffer = flexible_chunked ? tensor_args.chunk_start_idx_tensor.value().buffer() : nullptr;

    auto* out0_buffer = output_tensor.buffer();

    bool use_attention_sink = attention_sink.has_value();

    CoreCoord grid_size = program_config.has_value() ? program_config->compute_with_storage_grid_size
                                                     : device->compute_with_storage_grid_size();
    const bool exp_approx_mode = get_exp_approx_mode(program_config);

    auto core_grid = CoreRangeSet(CoreRange({0, 0}, {grid_size.x - 1, grid_size.y - 1}));
    uint32_t num_cores = grid_size.x * grid_size.y;

    TT_FATAL(
        num_cores <= device->compute_with_storage_grid_size().x * device->compute_with_storage_grid_size().y,
        "Provided grid must not contain more cores than the device. Got {} cores, expected at most {} cores.",
        num_cores,
        device->compute_with_storage_grid_size().x * device->compute_with_storage_grid_size().y);

    TT_FATAL(num_cores > 0, "SDPA requires a non-empty core grid; got num_cores=0.");

    // Global Q scheduling is the single-chip default: distribute the flat B*NQH*q_num_chunks
    // Q-chunk space evenly across cores. Pair-distribute when causal + even q_num_chunks so every
    // core gets balanced light/heavy work after the shared zigzag remap (reader/writer/compute CT 32/20/29).
    const uint32_t total_q_chunks = B * NQH * q_num_chunks;
    const bool global_q_pair_distribute = is_causal && (q_num_chunks % 2 == 0);
    uint32_t global_q_base_chunks_per_core = 0;
    uint32_t global_q_cores_doing_extra = 0;
    uint32_t global_q_extra_chunks_per_core = 0;
    if (global_q_pair_distribute) {
        const uint32_t total_pairs = total_q_chunks / 2;
        global_q_base_chunks_per_core = (total_pairs / num_cores) * 2;
        global_q_cores_doing_extra = total_pairs % num_cores;
        global_q_extra_chunks_per_core = 2;
    } else {
        global_q_base_chunks_per_core = total_q_chunks / num_cores;
        global_q_cores_doing_extra = total_q_chunks % num_cores;
        global_q_extra_chunks_per_core = 1;
    }
    const uint32_t max_global_q_chunks_per_core =
        global_q_base_chunks_per_core + (global_q_cores_doing_extra > 0 ? global_q_extra_chunks_per_core : 0);

    const uint32_t q_buffer_factor = (max_global_q_chunks_per_core > 1) ? 2 : 1;

    // Host code is responsible for determining matmul configuration
    const uint32_t dst_size = fp32_dest_acc_en ? 4 : 8;
    const uint32_t qk_in0_block_w = DHt;

    auto [qk_out_subblock_h, qk_out_subblock_w] =
        detail::determine_largest_subblock_size(Sq_chunk_t, Sk_chunk_t, dst_size);

    const bool use_streaming_compute = can_use_streaming_compute(fp32_dest_acc_en);

    const bool has_sliding_window = sliding_window_size.value_or(0) != 0;
    // A user-provided dense mask on the streaming path takes its own per-chunk apply
    // (apply_provided_mask_streaming) and must win over the structured lightweight palette: forcing
    // lightweight_mask false (via !use_provided_mask below) routes cb_mask_in sizing/dtype to the
    // full Sq×Sk provided-mask branch instead of the 1–4-tile palette.
    const bool lightweight_causal = is_causal && !use_provided_mask && !is_windowed && !has_sliding_window;
    const bool lightweight_streaming_mask = use_streaming_compute && !use_provided_mask && !is_windowed &&
                                            (is_causal || has_sliding_window || generated_padding_mask);
    const bool lightweight_mask = lightweight_causal || lightweight_streaming_mask;
    // Non-causal partial-tile K (Sk % TILE != 0) needs a partial-tile mask in cb_mask_in.
    // Not used for a dense provided mask (the reader neginf-fills padded positions in the mask).
    const uint32_t k_partial_col =
        (use_streaming_compute && generated_padding_mask && !use_provided_mask && (Sk % TILE_HEIGHT != 0))
            ? (Sk % TILE_HEIGHT)
            : 0;
    const bool lw_partial_active = (k_partial_col > 0);
    // These tile capacity counts for CBs need to match the number of tiles expected by the kernel (softmax.cpp)
    uint32_t q_tiles = Sq_chunk_t * DHt * q_buffer_factor;
    uint32_t k_tiles = Sk_chunk_t * DHt * 2;   // double buffer
    uint32_t v_tiles = Sk_chunk_t * vDHt * 2;  // double buffer
    uint32_t mask_tiles = lightweight_mask
                              ? lightweight_mask_tile_count(is_causal, has_sliding_window, lw_partial_active)
                              : Sq_chunk_t * Sk_chunk_t * 2;  // double buffer
    uint32_t qk_tiles = Sq_chunk_t * Sk_chunk_t;
    uint32_t out_im_tiles = Sq_chunk_t * vDHt;
    uint32_t out0_t = Sq_chunk_t * vDHt;  // finalized below once out_out_subblock_h is known
    uint32_t scale_tiles = 1;
    uint32_t statistics_tiles = Sq_chunk_t;  // Single column of values in each iteration
    // Streaming compute broadcasts the per-head scalar directly; legacy compute consumes one
    // expanded first-column tile per Q row.
    uint32_t attention_sink_tiles = attention_sink_tile_count(use_attention_sink, use_streaming_compute, Sq_chunk_t);

    // log all values
    log_debug(tt::LogOp, "q_tiles: {}", q_tiles);
    log_debug(tt::LogOp, "k_tiles: {}", k_tiles);
    log_debug(tt::LogOp, "v_tiles: {}", v_tiles);
    log_debug(tt::LogOp, "mask_tiles: {}", mask_tiles);
    log_debug(tt::LogOp, "qk_tiles: {}", qk_tiles);
    log_debug(tt::LogOp, "scale_tiles: {}", scale_tiles);
    log_debug(tt::LogOp, "statistics_tiles: {}", statistics_tiles);
    log_debug(tt::LogOp, "attention_sink_tiles: {}", attention_sink_tiles);

    const uint32_t qk_in0_num_subblocks = Sq_chunk_t / qk_out_subblock_h;
    const uint32_t qk_in1_num_subblocks = Sk_chunk_t / qk_out_subblock_w;

    // now for out0
    const uint32_t out_in0_block_w = Sk_chunk_t;

    auto [out_out_subblock_h, out_out_subblock_w] =
        detail::determine_largest_subblock_size(Sq_chunk_t, vDHt, dst_size, use_streaming_compute ? 2 : UINT32_MAX);

    const uint32_t out_in0_num_subblocks = Sq_chunk_t / out_out_subblock_h;
    const uint32_t out_in1_num_subblocks = vDHt / out_out_subblock_w;

    // Streaming: shrink cb_out to a 2-slot ping-pong (see sdpa_subblock_utils.hpp).
    if (use_streaming_compute) {
        out0_t = detail::streaming_cb_out_tiles(out_out_subblock_h, out_out_subblock_w, dst_size, Sq_chunk_t, vDHt);
        TT_FATAL(
            Sq_chunk_t % out_out_subblock_h == 0,
            "Streaming cb_out drain requires Sq_chunk_t ({}) divisible by out_out_subblock_h ({})",
            Sq_chunk_t,
            out_out_subblock_h);
    }
    log_debug(tt::LogOp, "out0_t: {}", out0_t);
    log_debug(tt::LogOp, "use_streaming_compute: {}", use_streaming_compute);

    // log all values
    log_debug(tt::LogOp, "dst_size: {}", dst_size);
    log_debug(tt::LogOp, "qk_in0_block_w: {}", qk_in0_block_w);
    log_debug(tt::LogOp, "qk_out_subblock_w: {}", qk_out_subblock_w);
    log_debug(tt::LogOp, "qk_out_subblock_h: {}", qk_out_subblock_h);
    log_debug(tt::LogOp, "qk_in0_num_subblocks: {}", qk_in0_num_subblocks);
    log_debug(tt::LogOp, "qk_in1_num_subblocks: {}", qk_in1_num_subblocks);
    log_debug(tt::LogOp, "out_in0_block_w: {}", out_in0_block_w);
    log_debug(tt::LogOp, "out_out_subblock_w: {}", out_out_subblock_w);
    log_debug(tt::LogOp, "out_out_subblock_h: {}", out_out_subblock_h);
    log_debug(tt::LogOp, "out_in0_num_subblocks: {}", out_in0_num_subblocks);
    log_debug(tt::LogOp, "out_in1_num_subblocks: {}", out_in1_num_subblocks);

    // Determine granularity for statistics computation
    // Each granularity must evenly divide its tile count to avoid dropping tiles
    const uint32_t stats_granularity = detail::find_valid_granularity(Sq_chunk_t, dst_size);
    const uint32_t sub_exp_granularity = detail::find_valid_granularity(Sk_chunk_t, dst_size);
    // DHT_GRANULARITY is used in the kernel with both DHt and vDHt as the cols parameter,
    // so the granularity must evenly divide both to avoid dropping tiles.
    const uint32_t dht_granularity = compute_dht_granularity(DHt, vDHt, dst_size);
    const uint32_t reduce_granularity = detail::find_valid_granularity(Sq_chunk_t, dst_size / 2);

    // Log these
    log_debug(tt::LogOp, "stats_granularity: {}", stats_granularity);
    log_debug(tt::LogOp, "sub_exp_granularity: {}", sub_exp_granularity);
    log_debug(tt::LogOp, "dht_granularity: {}", dht_granularity);
    log_debug(tt::LogOp, "reduce_granularity: {}", reduce_granularity);

    // Reduce ops need to multiply by a scalar. We always want to multiply by 1.0f
    class bfloat16 bfloat_identity_scalar(1.0f);
    uint32_t packed_identity_scalar = pack_two_bfloat16_into_uint32({bfloat_identity_scalar, bfloat_identity_scalar});

    const uint32_t scale_packed = std::bit_cast<uint32_t>(scale.value_or(1.0f));

    const bool use_zigzag_balancing = is_causal;

    std::vector<uint32_t> reader_compile_time_args = {// interleaved accessor args
                                                      B,
                                                      NQH,
                                                      NKH,
                                                      NVH,
                                                      Skt,
                                                      valid_Sqt,
                                                      valid_Skt,
                                                      DHt,
                                                      vDHt,
                                                      Sq_chunk_t,
                                                      q_num_chunks,
                                                      Sk_chunk_t,
                                                      k_num_chunks,
                                                      num_cores,
                                                      static_cast<uint32_t>(is_causal),
                                                      static_cast<uint32_t>(use_provided_mask),
                                                      static_cast<uint32_t>(broadcast_provided_mask_batch),
                                                      static_cast<uint32_t>(broadcast_provided_mask_heads),
                                                      static_cast<uint32_t>(generated_padding_mask),
                                                      static_cast<uint32_t>(is_chunked),
                                                      block_size_t,
                                                      page_table_stick_size,
                                                      static_cast<uint32_t>(use_attention_sink),
                                                      static_cast<uint32_t>(use_mla),
                                                      static_cast<uint32_t>(mla_kv_overlap),
                                                      qk_out_subblock_h,
                                                      sliding_window_size.value_or(0),
                                                      static_cast<uint32_t>(use_streaming_compute)};

    // Placeholder semaphore IDs for KV chain forwarding (will be filled later if enabled)
    // Add these BEFORE TensorAccessorArgs to keep indexing consistent with kernel expectations
    const auto sem_args_offset = reader_compile_time_args.size();
    reader_compile_time_args.push_back(0);  // sender_semaphore_id placeholder
    reader_compile_time_args.push_back(0);  // receiver_semaphore_id placeholder
    reader_compile_time_args.push_back(0);  // valid_semaphore_id placeholder
    reader_compile_time_args.push_back(0);  // mcast_enabled placeholder
    reader_compile_time_args.push_back(static_cast<uint32_t>(use_zigzag_balancing));  // arg 32
    reader_compile_time_args.push_back(static_cast<uint32_t>(is_windowed));           // arg 33: K-range narrowing

    TensorAccessorArgs(input_tensor_q.buffer()).append_to(reader_compile_time_args);
    TensorAccessorArgs(input_tensor_k.buffer()).append_to(reader_compile_time_args);
    TensorAccessorArgs(input_tensor_v.buffer()).append_to(reader_compile_time_args);
    TensorAccessorArgs(attn_mask.has_value() ? attn_mask->buffer() : nullptr).append_to(reader_compile_time_args);
    TensorAccessorArgs(page_table.has_value() ? page_table->buffer() : nullptr).append_to(reader_compile_time_args);
    TensorAccessorArgs(attention_sink.has_value() ? attention_sink->buffer() : nullptr)
        .append_to(reader_compile_time_args);
    TensorAccessorArgs(flexible_chunked ? tensor_args.chunk_start_idx_tensor.value().buffer() : nullptr)
        .append_to(reader_compile_time_args);
    // Windowed K-range narrowing: the reader needs its own view of cu_window_seqlens and the per-device
    // Q-offset tensor to compute each Q chunk's [k_lo, k_hi) — same placeholder rule as the writer's pair.
    TensorAccessorArgs(buffer_or_null(tensor_args.cu_window_seqlens)).append_to(reader_compile_time_args);
    TensorAccessorArgs(buffer_or_null(tensor_args.windowed_q_token_offset_tensor))
        .append_to(reader_compile_time_args);

    // Set up semaphore IDs for KV chain forwarding (non-causal only).
    // In the descriptor pattern, semaphore IDs are explicit sequential integers
    // matching the order they are pushed into desc.semaphores below.
    uint32_t sender_semaphore_id = 0;
    uint32_t receiver_semaphore_id = 0;
    uint32_t valid_semaphore_id = 0;

    if (!is_causal) {
        sender_semaphore_id = 0;
        receiver_semaphore_id = 1;
        valid_semaphore_id = 2;

        // Update the placeholder compile-time args with actual semaphore IDs
        reader_compile_time_args[sem_args_offset + 0] = sender_semaphore_id;
        reader_compile_time_args[sem_args_offset + 1] = receiver_semaphore_id;
        reader_compile_time_args[sem_args_offset + 2] = valid_semaphore_id;

        log_debug(
            tt::LogOp,
            "KV chain forwarding enabled - created semaphores: sender={}, receiver={}, valid={}",
            sender_semaphore_id,
            receiver_semaphore_id,
            valid_semaphore_id);
    }

    std::vector<uint32_t> writer_compile_time_args = {
        // interleaved accessor args
        B,
        NQH,
        valid_Sqt,
        Sk,
        vDHt,
        Sq_chunk_t,
        q_num_chunks,
        Sk_chunk_t,
        k_num_chunks,
        packed_identity_scalar,
        num_cores,
        static_cast<uint32_t>(is_causal),
        static_cast<uint32_t>(use_provided_mask),
        static_cast<uint32_t>(generated_padding_mask),
        static_cast<uint32_t>(is_chunked),
        sliding_window_size.value_or(0),
        static_cast<uint32_t>(lightweight_mask),       // arg 16: lightweight mask
        static_cast<uint32_t>(use_streaming_compute),  // arg 17: row-grouped cb_out drain
        out_out_subblock_h,                            // arg 18: drain group height
        k_partial_col,                                 // arg 19: K partial-tile col (0 = no partial)
        static_cast<uint32_t>(use_zigzag_balancing),   // arg 20
        static_cast<uint32_t>(is_windowed),            // arg 21: windowed block-diagonal mask generation
        static_cast<uint32_t>(operation_attributes.output_concat_heads),  // arg 22: concat-heads output layout
    };

    // out accessor, then the cu_window accessor chained right after it (before the CB-id block) so the
    // accessor offset chain stays intact. nullptr when not windowed (consistent placeholder).
    TensorAccessorArgs(output_tensor.buffer()).append_to(writer_compile_time_args);
    TensorAccessorArgs(buffer_or_null(tensor_args.cu_window_seqlens)).append_to(writer_compile_time_args);
    // Then the per-device Q-offset accessor. Same chain, same placeholder rule: nullptr when the caller
    // passed the offset as a scalar (or is not windowed), in which case the writer never reads it.
    TensorAccessorArgs(buffer_or_null(tensor_args.windowed_q_token_offset_tensor))
        .append_to(writer_compile_time_args);

    std::vector<uint32_t> compute_compile_time_args = {
        // matmul args
        Skt,  // Padded K tile count — used by standard SDPA path for loop bounds
        DHt,
        vDHt,
        Sq_chunk_t,
        q_num_chunks,
        Sk_chunk_t,
        k_num_chunks,
        qk_in0_block_w,
        qk_out_subblock_w,
        qk_out_subblock_h,
        qk_in0_num_subblocks,
        qk_in1_num_subblocks,
        out_in0_block_w,
        out_out_subblock_w,
        out_out_subblock_h,
        out_in0_num_subblocks,
        out_in1_num_subblocks,
        static_cast<uint32_t>(is_causal),
        static_cast<uint32_t>(compute_use_provided_mask),
        static_cast<uint32_t>(generated_padding_mask),
        static_cast<uint32_t>(is_chunked),
        scale_packed,
        sliding_window_size.value_or(0),
        static_cast<std::uint32_t>(use_attention_sink),
        static_cast<std::uint32_t>(use_streaming_compute),  // arg 26
        valid_Skt,                                    // arg 27: unpadded K tile count for streaming padded_k_tiles
        k_partial_col,                                // arg 28: K partial-tile col (0 = no partial)
        static_cast<uint32_t>(use_zigzag_balancing),  // arg 29: unified zigzag remap
        static_cast<uint32_t>(is_windowed),           // arg 30: K-range narrowing (bounds from the ctrl CB)
    };

    std::map<std::string, std::string> defines_map;
    defines_map["STATS_GRANULARITY"] = std::to_string(stats_granularity);
    defines_map["SUB_EXP_GRANULARITY"] = std::to_string(sub_exp_granularity);
    defines_map["DHT_GRANULARITY"] = std::to_string(dht_granularity);
    defines_map["REDUCE_GRANULARITY"] = std::to_string(reduce_granularity);
    defines_map["EXP_APPROX_MODE"] = std::to_string(exp_approx_mode);
    log_debug(tt::LogOp, "use_zigzag_balancing: {}", use_zigzag_balancing);

    KernelDescriptor::Defines defines(defines_map.begin(), defines_map.end());

    // NOTE: Kernel descriptors are appended to the program descriptor after chain construction so that
    // the mcast_enabled compile-time arg can be determined first.

    // ---- Circular buffers ----

    ProgramDescriptor desc;

    tt::DataFormat q_df = tt::tt_metal::datatype_to_dataformat_converter(input_tensor_q.dtype());
    tt::DataFormat k_df = tt::tt_metal::datatype_to_dataformat_converter(input_tensor_k.dtype());
    tt::DataFormat v_df = tt::tt_metal::datatype_to_dataformat_converter(input_tensor_v.dtype());
    // Windowed mask is generated on-device. Float16_b so it works on both the streaming path (which does
    // not decode block-float masks) and the standard path; windowed_mask_gen.hpp fills the right format.
    tt::DataFormat mask_df =
        is_windowed ? tt::DataFormat::Float16_b : select_mask_dataformat(attn_mask, use_streaming_compute);
    tt::DataFormat out_df = tt::tt_metal::datatype_to_dataformat_converter(output_tensor.dtype());
    tt::DataFormat scalar_df =
        (input_tensor_q.dtype() == DataType::FLOAT32) ? tt::DataFormat::Float32 : tt::DataFormat::Float16_b;
    tt::DataFormat im_df =
        tt::DataFormat::Float16_b;  // Keep most intermediates in bf16 to save L1; opt-in fp32 per-CB below.
    tt::DataFormat stats_df = im_df;
    tt::DataFormat qk_im_df = fp32_dest_intermediate_dataformat(fp32_dest_acc_en);
    tt::DataFormat sum_df = fp32_dest_intermediate_dataformat(fp32_dest_acc_en);
    // salad_correct_fused inits mul_bcast_cols with out CB and applies it to sum CB too —
    // both must share the same data format for the unpack config to be correct.
    TT_ASSERT(
        !use_streaming_compute || sum_df == im_df,
        "SDPA fused SALAD correction requires out and sum CBs to share data format");

    uint32_t q_tile_size = tt::tile_size(q_df);
    uint32_t k_tile_size = tt::tile_size(k_df);
    uint32_t v_tile_size = tt::tile_size(v_df);
    uint32_t out_tile_size = tt::tile_size(out_df);
    uint32_t scalar_tile_size = tt::tile_size(scalar_df);
    uint32_t im_tile_size = tt::tile_size(im_df);
    uint32_t stats_tile_size = tt::tile_size(stats_df);
    uint32_t qk_im_tile_size = tt::tile_size(qk_im_df);
    uint32_t sum_tile_size = tt::tile_size(sum_df);

    log_debug(tt::LogOp, "q_data_format: {}", q_df);
    log_debug(tt::LogOp, "k_data_format: {}", k_df);
    log_debug(tt::LogOp, "v_data_format: {}", v_df);
    log_debug(tt::LogOp, "mask_data_format: {}", mask_df);
    log_debug(tt::LogOp, "out_data_format: {}", out_df);
    log_debug(tt::LogOp, "scalar_data_format: {}", scalar_df);
    log_debug(tt::LogOp, "intermediate_data_format: {}", im_df);
    log_debug(tt::LogOp, "statistics_data_format: {}", stats_df);
    log_debug(tt::LogOp, "qk_im_data_format: {}", qk_im_df);
    log_debug(tt::LogOp, "sum_data_format: {}", sum_df);

    sdpa_cb::CBIds cb_ids;
    uint32_t next_cb_index = 0;
    const auto allocate_cb = [&](uint32_t page_size_bytes, uint32_t num_pages, tt::DataFormat data_format) -> uint32_t {
        const uint32_t cb_index = next_cb_index++;
        desc.cbs.push_back(CBDescriptor{
            .total_size = page_size_bytes * num_pages,
            .core_ranges = core_grid,
            .format_descriptors = {{CBFormatDescriptor{
                .buffer_index = static_cast<uint8_t>(cb_index),
                .data_format = data_format,
                .page_size = page_size_bytes,
            }}},
        });
        return cb_index;
    };
    const auto allocate_tile_cb = [&](uint32_t num_tiles, uint32_t tile_size, tt::DataFormat data_format) -> uint32_t {
        return allocate_cb(tile_size, num_tiles, data_format);
    };

    cb_ids.q_in = allocate_tile_cb(q_tiles, q_tile_size, q_df);
    cb_ids.k_in = allocate_tile_cb(k_tiles, k_tile_size, k_df);
    cb_ids.v_in = allocate_tile_cb(v_tiles, v_tile_size, v_df);

    const bool needs_mask_cb =
        use_provided_mask || is_causal || generated_padding_mask || sliding_window_size.value_or(0) > 0 || is_windowed;
    // Only create mask buffer if it's going to be used.
    if (needs_mask_cb) {
        // Lightweight mask: Float16_b, mask_tiles already computed (1 for padding, 2 for causal).
        // Legacy: full Sq×Sk double-buffered matrix in Bfp4_b.
        tt::DataFormat actual_mask_df = lightweight_mask ? tt::DataFormat::Float16_b : mask_df;
        uint32_t actual_mask_tile_size = tt::tile_size(actual_mask_df);
        cb_ids.mask_in = allocate_tile_cb(mask_tiles, actual_mask_tile_size, actual_mask_df);
    }

    // Windowed (block-diagonal) CBs and runtime values; see setup_windowed_cbs above.
    const WindowedSetup windowed =
        setup_windowed_cbs(operation_attributes, tensor_args, cb_ids, allocate_tile_cb, allocate_cb);
    tt::tt_metal::Buffer* const cu_window_buffer = windowed.cu_window_buffer;
    tt::tt_metal::Buffer* const windowed_q_offset_buffer = windowed.q_offset_buffer;
    const uint32_t cu_window_seqlens_eles = windowed.cu_window_seqlens_eles;
    const uint32_t windowed_q_token_offset = windowed.q_token_offset;

    cb_ids.identity_scale_in = allocate_tile_cb(scale_tiles, scalar_tile_size, scalar_df);
    cb_ids.col_identity = allocate_tile_cb(scale_tiles, scalar_tile_size, scalar_df);

    if (is_chunked) {
        cb_ids.page_table = allocate_cb(page_table_stick_size, 1, page_table_df);
    }
    if (flexible_chunked) {
        constexpr uint32_t chunk_start_idx_page_size = 32;
        cb_ids.chunk_start_idx_compute = allocate_cb(chunk_start_idx_page_size, 1, tt::DataFormat::Int32);
        cb_ids.chunk_start_idx_writer = allocate_cb(chunk_start_idx_page_size, 1, tt::DataFormat::Int32);
    }

    if (use_attention_sink) {
        tt::DataFormat sink_df = tt::tt_metal::datatype_to_dataformat_converter(attention_sink.value().dtype());
        uint32_t sink_tile_size = tt::tile_size(sink_df);
        log_debug(tt::LogOp, "attention_sink_tiles: {}", attention_sink_tiles);
        log_debug(tt::LogOp, "sink_tile_size: {}", sink_tile_size);
        log_debug(tt::LogOp, "sink_df: {}", sink_df);
        cb_ids.attention_sink = allocate_tile_cb(attention_sink_tiles, sink_tile_size, sink_df);
    }

    // Streaming compute v2: 1-tile recip scratch CB for normalize_row_streaming.
    // No row buffers needed — cb_push_back_hold_wr_ptr writes directly to cb_qkt_im.
    if (use_streaming_compute) {
        cb_ids.recip_scratch = allocate_tile_cb(1, im_tile_size, im_df);
    }

    cb_ids.qk_im = allocate_tile_cb(qk_tiles, qk_im_tile_size, qk_im_df);
    cb_ids.out_im_A = allocate_tile_cb(out_im_tiles, im_tile_size, im_df);
    cb_ids.out_im_B = allocate_tile_cb(out_im_tiles, im_tile_size, im_df);
    cb_ids.max_A = allocate_tile_cb(statistics_tiles, stats_tile_size, stats_df);
    cb_ids.max_B = allocate_tile_cb(statistics_tiles, stats_tile_size, stats_df);
    cb_ids.sum_A = allocate_tile_cb(statistics_tiles, sum_tile_size, sum_df);
    cb_ids.sum_B = allocate_tile_cb(statistics_tiles, sum_tile_size, sum_df);
    cb_ids.exp_max_diff = allocate_tile_cb(statistics_tiles, stats_tile_size, stats_df);
    cb_ids.out = allocate_tile_cb(out0_t, out_tile_size, out_df);

    const auto reader_cb_compile_time_args = cb_ids.reader_compile_time_args();
    const auto writer_cb_compile_time_args = cb_ids.writer_compile_time_args();
    const auto compute_cb_compile_time_args = cb_ids.compute_compile_time_args();
    reader_compile_time_args.insert(
        reader_compile_time_args.end(), reader_cb_compile_time_args.begin(), reader_cb_compile_time_args.end());
    writer_compile_time_args.insert(
        writer_compile_time_args.end(), writer_cb_compile_time_args.begin(), writer_cb_compile_time_args.end());
    compute_compile_time_args.insert(
        compute_compile_time_args.end(), compute_cb_compile_time_args.begin(), compute_cb_compile_time_args.end());
    TensorAccessorArgs(output_tensor.buffer()).append_to(compute_compile_time_args);

    // Semaphores for KV chain forwarding (non-causal only).
    // IDs match the order they were assigned above: sender=0, receiver=1, valid=2.
    if (!is_causal) {
        desc.semaphores.push_back(SemaphoreDescriptor{
            .id = sender_semaphore_id,
            .core_type = tt::CoreType::WORKER,
            .core_ranges = core_grid,
            .initial_value = INVALID,
        });
        desc.semaphores.push_back(SemaphoreDescriptor{
            .id = receiver_semaphore_id,
            .core_type = tt::CoreType::WORKER,
            .core_ranges = core_grid,
            .initial_value = INVALID,
        });
        desc.semaphores.push_back(SemaphoreDescriptor{
            .id = valid_semaphore_id,
            .core_type = tt::CoreType::WORKER,
            .core_ranges = core_grid,
            .initial_value = VALID,
        });
    }

    uint32_t num_phases = 1;
    uint32_t read_offset = 0;
    uint32_t write_offset = 0;

    // Defense-in-depth: kernels place global_q runtime args past the max phase_2 slot,
    // but the host-side compute/writer arg packing only zeros the phase_2 slots when
    // num_phases==1. Any future change that raises num_phases on this path must rethink
    // the layout — assert early so the failure is loud rather than a slot reinterpretation.
    TT_FATAL(num_phases == 1, "Single-chip SDPA assumes num_phases == 1 under global Q scheduling");

    // Build chain topology for KV forwarding (non-causal only)
    std::vector<CoreWork> core_work(num_cores);
    std::vector<CoreChainInfo> core_chain_info(num_cores);
    const uint32_t total_heads = B * NQH;
    std::vector<std::vector<HeadSegmentRef>> head_segments;
    uint32_t mcast_chains = 0;

    // Windowed is excluded like sliding-window: both narrow the per-Q-chunk K range, and chains
    // lock-step-forward K between cores whose Q chunks now need DIFFERENT K ranges — the semaphore
    // handshake counts diverge and the cores deadlock. Narrowing saves far more K reads than
    // forwarding did.
    if (!is_causal && !is_chunked && !has_sliding_window && !is_windowed) {
        head_segments.resize(total_heads);

        log_debug(tt::LogOp, "=== Building KV chain forwarding topology ===");
        log_debug(tt::LogOp, "Total heads (B * NQH): {}", total_heads);
        log_debug(tt::LogOp, "Q chunks per head: {}", q_num_chunks);
        log_debug(tt::LogOp, "Grid size: {}x{} = {} cores", grid_size.x, grid_size.y, num_cores);

        // First pass: Record work distribution for each core
        for (uint32_t i = 0; i < num_cores; ++i) {
            CoreCoord core = {i % grid_size.x, i / grid_size.x};

            auto& work = core_work[i];
            work.logical_core = core;
            work.physical_core = device->worker_core_from_logical_core(core);

            auto push_head_work = [&](uint32_t nb, uint32_t nh, uint32_t q_count) {
                if (q_count == 0) {
                    return;
                }
                work.head_work.push_back(CoreHeadWork{
                    .batch = nb,
                    .head = nh,
                    .q_chunk_count = q_count,
                });
                const uint32_t head_id = (nb * NQH) + nh;
                if (head_id < head_segments.size()) {
                    head_segments[head_id].push_back(HeadSegmentRef{
                        .core_idx = i, .head_work_index = static_cast<uint32_t>(work.head_work.size() - 1)});
                }
            };

            // Walk the core's [g_start, g_start + g_count) linear range and split into
            // contiguous (nb, nq, q_chunk_range) segments. Non-causal here (chain section is
            // !is_causal), so the zigzag remap is off and the decompose is identity.
            uint32_t g_start = i * global_q_base_chunks_per_core +
                               std::min(i, global_q_cores_doing_extra) * global_q_extra_chunks_per_core;
            uint32_t g_count = global_q_base_chunks_per_core +
                               ((i < global_q_cores_doing_extra) ? global_q_extra_chunks_per_core : 0u);
            if (g_start >= total_q_chunks) {
                g_start = total_q_chunks;
                g_count = 0;
            } else if (g_start + g_count > total_q_chunks) {
                g_count = total_q_chunks - g_start;
            }
            work.global_q_start = g_start;
            work.global_q_count = g_count;

            uint32_t cursor = g_start;
            const uint32_t g_end = g_start + g_count;
            while (cursor < g_end) {
                const uint32_t nb = cursor / (NQH * q_num_chunks);
                const uint32_t nq = (cursor / q_num_chunks) % NQH;
                const uint32_t q_in_head = cursor % q_num_chunks;
                const uint32_t remaining_in_head = q_num_chunks - q_in_head;
                const uint32_t remaining_in_range = g_end - cursor;
                const uint32_t span = std::min(remaining_in_head, remaining_in_range);
                push_head_work(nb, nq, span);
                cursor += span;
            }

            if (!work.head_work.empty()) {
                log_debug(
                    tt::LogOp, "Core {} ({}): handles {} head segments", i, work.physical_core, work.head_work.size());
            }
        }

        // Second pass: Build chains for heads spanning multiple cores
        uint32_t chains_built = 0;
        uint32_t chains_skipped = 0;
        // Track injector physical X columns for DRAM channel spreading
        std::vector<uint32_t> injector_phys_x;
        injector_phys_x.reserve(head_segments.size());

        for (uint32_t head_id = 0; head_id < head_segments.size(); ++head_id) {
            auto& segments = head_segments[head_id];
            if (segments.size() < 2) {
                continue;  // No chain needed for single core
            }

            // Find first non-conflicting single-segment core as chain start.
            // Exclude the last segment: it must remain as a chain tail since the
            // wrap-around build below needs at least one segment after start.
            std::optional<std::size_t> chain_start_idx;
            for (std::size_t idx = 0; idx + 1 < segments.size(); ++idx) {
                const auto& seg = segments[idx];
                const auto& work = core_work[seg.core_idx];
                if (seg.head_work_index >= work.head_work.size()) {
                    continue;
                }
                if (core_chain_info[seg.core_idx].participates) {
                    continue;
                }
                if (work.head_work.size() == 1) {
                    chain_start_idx = idx;
                    break;
                }
            }
            if (!chain_start_idx.has_value()) {
                for (std::size_t idx = 0; idx + 1 < segments.size(); ++idx) {
                    const auto& seg = segments[idx];
                    if (!core_chain_info[seg.core_idx].participates) {
                        chain_start_idx = idx;
                        break;
                    }
                }
            }

            if (!chain_start_idx.has_value()) {
                chains_skipped++;
                continue;
            }

            const std::size_t start = chain_start_idx.value();

            // Build chain in wrap order: start, start+1, ..., N-1, 0, 1, ..., start-1.
            // Break on conflict (core already in a different chain).
            std::vector<std::size_t> chain_order;
            chain_order.reserve(segments.size());
            for (std::size_t step = 0; step < segments.size(); ++step) {
                std::size_t idx = (start + step) % segments.size();
                const auto& seg = segments[idx];
                const uint32_t core_idx = seg.core_idx;
                if (core_idx >= core_work.size() || seg.head_work_index >= core_work[core_idx].head_work.size()) {
                    continue;
                }
                if (core_chain_info[core_idx].participates) {
                    break;
                }
                chain_order.push_back(idx);
            }

            if (chain_order.size() < 2) {
                chains_skipped++;
                continue;
            }

            // Check if all chain cores have the same q_chunk_count.
            // Mixed q_chunk_count chains are safe in unicast mode when sorted in
            // descending q_chunk_count order: the kernel's should_forward condition
            // guards on (q_iter < next_core_q_chunks), so a heavier sender only
            // forwards for the lighter receiver's iteration count, and the receiver
            // receives for all of its own iterations.  Mcast mode requires uniform
            // q_chunk_count (checked separately in the mcast eligibility pass).
            const uint32_t ref_q = core_work[segments[chain_order[0]].core_idx]
                                       .head_work[segments[chain_order[0]].head_work_index]
                                       .q_chunk_count;
            bool uniform_q = true;
            for (std::size_t i = 1; i < chain_order.size(); ++i) {
                const auto& seg = segments[chain_order[i]];
                if (core_work[seg.core_idx].head_work[seg.head_work_index].q_chunk_count != ref_q) {
                    uniform_q = false;
                    break;
                }
            }

            if (uniform_q) {
                // All cores have equal q_chunk_count — safe to pick any injector.
                // Choose the core whose physical X is furthest from existing
                // injectors to spread DRAM reads across channels.
                std::size_t best_pos = 0;
                uint32_t best_dist = 0;
                for (std::size_t pos = 0; pos < chain_order.size(); ++pos) {
                    const uint32_t phys_x = core_work[segments[chain_order[pos]].core_idx].physical_core.x;
                    uint32_t min_dist = UINT32_MAX;
                    for (uint32_t ix : injector_phys_x) {
                        uint32_t d = (phys_x > ix) ? (phys_x - ix) : (ix - phys_x);
                        min_dist = std::min(min_dist, d);
                    }
                    if (min_dist > best_dist) {
                        best_dist = min_dist;
                        best_pos = pos;
                    }
                }
                if (best_pos != 0) {
                    std::swap(chain_order[0], chain_order[best_pos]);
                }
            } else {
                // Mixed q_chunk_counts — sort descending so heavier cores come first.
                // Each sender forwards only for min(own_q_iters, next_core_q_chunks)
                // iterations, so a heavier sender safely serves a lighter receiver.
                // Stable sort preserves physical topology where q_counts are equal.
                std::stable_sort(chain_order.begin(), chain_order.end(), [&](std::size_t a, std::size_t b) {
                    const auto& seg_a = segments[a];
                    const auto& seg_b = segments[b];
                    return core_work[seg_a.core_idx].head_work[seg_a.head_work_index].q_chunk_count >
                           core_work[seg_b.core_idx].head_work[seg_b.head_work_index].q_chunk_count;
                });
            }

            const auto& inj_seg = segments[chain_order[0]];
            injector_phys_x.push_back(core_work[inj_seg.core_idx].physical_core.x);
            uint32_t batch = core_work[inj_seg.core_idx].head_work[inj_seg.head_work_index].batch;
            uint32_t head = head_id % NQH;

            log_debug(
                tt::LogOp,
                "Building chain for head {} (batch={}, head={}): {} cores, uniform_q={}, injector phys_x={}",
                head_id,
                batch,
                head,
                chain_order.size(),
                uniform_q,
                core_work[inj_seg.core_idx].physical_core.x);

            for (std::size_t pos = 0; pos < chain_order.size(); ++pos) {
                const std::size_t idx = chain_order[pos];
                const auto& seg = segments[idx];
                const uint32_t core_idx = seg.core_idx;
                const auto& hw = core_work[core_idx].head_work[seg.head_work_index];
                auto& chain = core_chain_info[core_idx];

                chain.participates = true;
                chain.batch = hw.batch;
                chain.head = hw.head;
                chain.q_chunk_count = hw.q_chunk_count;

                if (pos == 0) {
                    chain.is_injector = true;
                }
                if (pos == chain_order.size() - 1) {
                    chain.is_sink = true;
                }

                // Set prev core coordinates (previous in wrap order)
                if (pos > 0) {
                    const uint32_t prev_core_idx = segments[chain_order[pos - 1]].core_idx;
                    if (prev_core_idx < core_work.size()) {
                        chain.prev_physical = core_work[prev_core_idx].physical_core;
                    }
                }

                // Set next core coordinates and q_chunk count (next in wrap order)
                if (pos + 1 < chain_order.size()) {
                    const std::size_t next_idx = chain_order[pos + 1];
                    const uint32_t next_core_idx = segments[next_idx].core_idx;
                    if (next_core_idx < core_work.size() &&
                        segments[next_idx].head_work_index < core_work[next_core_idx].head_work.size()) {
                        chain.next_physical = core_work[next_core_idx].physical_core;
                        const auto& next_hw = core_work[next_core_idx].head_work[segments[next_idx].head_work_index];
                        chain.next_core_q_chunks = next_hw.q_chunk_count;
                    }
                }

                log_debug(
                    tt::LogOp,
                    "  Core {} in chain: injector={}, sink={}, q_chunks={}, prev={}, next={}",
                    core_idx,
                    chain.is_injector,
                    chain.is_sink,
                    chain.q_chunk_count,
                    chain.prev_physical,
                    chain.next_physical);
            }

            chains_built++;
        }

        log_debug(
            tt::LogOp,
            "Chain construction complete: {} chains built, {} skipped due to conflicts",
            chains_built,
            chains_skipped);

        // Third pass: Check multicast eligibility — all-or-nothing policy.
        // First, check if ALL multi-core chains are eligible. Only if every chain
        // qualifies do we configure mcast (compile-time decision for the kernel).
        struct McastCandidate {
            std::vector<uint32_t> core_indices;
            uint32_t ref_q_chunks;
        };
        std::vector<McastCandidate> candidates;
        candidates.reserve(head_segments.size());
        bool all_eligible = true;
        uint32_t total_multi_core_chains = 0;

        for (uint32_t head_id = 0; head_id < head_segments.size(); ++head_id) {
            auto& segments = head_segments[head_id];
            if (segments.size() < 2) {
                continue;
            }

            // Collect chain core indices that actually participate in this head's chain
            std::vector<uint32_t> chain_core_indices;
            chain_core_indices.reserve(segments.size());
            for (const auto& seg : segments) {
                if (seg.core_idx < core_chain_info.size() && core_chain_info[seg.core_idx].participates &&
                    core_chain_info[seg.core_idx].batch == (head_id / NQH) &&
                    core_chain_info[seg.core_idx].head == (head_id % NQH)) {
                    chain_core_indices.push_back(seg.core_idx);
                }
            }

            if (chain_core_indices.size() < 2) {
                continue;
            }

            total_multi_core_chains++;

            // Check eligibility condition 1: All physical cores share the same Y coordinate
            const uint32_t ref_y = core_work[chain_core_indices[0]].physical_core.y;
            bool same_row = true;
            for (size_t ci = 1; ci < chain_core_indices.size(); ++ci) {
                if (core_work[chain_core_indices[ci]].physical_core.y != ref_y) {
                    same_row = false;
                    break;
                }
            }

            if (!same_row) {
                all_eligible = false;
                log_debug(tt::LogOp, "Head {}: mcast ineligible - cores span multiple rows", head_id);
                break;
            }

            // Eligibility condition 2: no non-chain worker cores inside the mcast rectangle.
            // The mcast rectangle spans [min_x, max_x] on the same row. Any active worker
            // core in that range receives the multicast — if it's not part of the chain,
            // its K/V CB and semaphores get corrupted. This can happen when the q_chunk_count
            // filter creates "gaps" by excluding mid-chain segments with uneven tail work.
            uint32_t min_x = core_work[chain_core_indices[0]].physical_core.x;
            uint32_t max_x = min_x;
            for (const auto& ci : chain_core_indices) {
                uint32_t x = core_work[ci].physical_core.x;
                min_x = std::min(min_x, x);
                max_x = std::max(max_x, x);
            }

            bool has_gap = false;
            for (const auto& seg : segments) {
                if (seg.core_idx >= core_work.size()) {
                    continue;
                }
                const auto& phys = core_work[seg.core_idx].physical_core;
                if (phys.y == ref_y && phys.x >= min_x && phys.x <= max_x) {
                    bool in_chain = false;
                    for (const auto& ci : chain_core_indices) {
                        if (ci == seg.core_idx) {
                            in_chain = true;
                            break;
                        }
                    }
                    if (!in_chain) {
                        has_gap = true;
                        break;
                    }
                }
            }

            if (has_gap) {
                all_eligible = false;
                log_debug(
                    tt::LogOp, "Head {}: mcast ineligible - non-chain worker core inside mcast rectangle", head_id);
                break;
            }

            // Eligibility condition 3: All chain cores must have the same q_chunk_count.
            // Mcast uses a single sender_wait count — receivers that finish their Q loop
            // early won't signal back, causing the injector to deadlock waiting for
            // missing semaphores.  (Unicast chains handle mixed q via descending sort,
            // but mcast requires strict uniformity.)
            const uint32_t ref_q_chunks = core_chain_info[chain_core_indices[0]].q_chunk_count;
            bool uniform_q_mcast = true;
            for (size_t ci = 1; ci < chain_core_indices.size(); ++ci) {
                if (core_chain_info[chain_core_indices[ci]].q_chunk_count != ref_q_chunks) {
                    uniform_q_mcast = false;
                    break;
                }
            }

            if (!uniform_q_mcast) {
                all_eligible = false;
                log_debug(tt::LogOp, "Head {}: mcast ineligible - mixed q_chunk_counts", head_id);
                break;
            }

            // Defensive: crash in all builds if a non-uniform chain slips past the check above.
            for (const auto& ci : chain_core_indices) {
                TT_FATAL(
                    core_chain_info[ci].q_chunk_count == ref_q_chunks,
                    "Mcast chain for head {} has non-uniform q_chunk_count: core {} has {} vs ref {}",
                    head_id,
                    ci,
                    core_chain_info[ci].q_chunk_count,
                    ref_q_chunks);
            }

            candidates.push_back(McastCandidate{std::move(chain_core_indices), ref_q_chunks});
        }

        // Only configure mcast if ALL multi-core chains are eligible (all-or-nothing)
        if (all_eligible && !candidates.empty()) {
            mcast_chains = candidates.size();
            for (const auto& cand : candidates) {
                const uint32_t chain_size = cand.core_indices.size();
                const uint32_t num_receivers = chain_size - 1;

                // Find the injector (may not be at index 0 due to rotation)
                uint32_t injector_idx = cand.core_indices[0];
                for (const auto& ci : cand.core_indices) {
                    if (core_chain_info[ci].is_injector) {
                        injector_idx = ci;
                        break;
                    }
                }

                // Mcast rect covers the full row (min to max physical X across all chain cores).
                // The mcast API excludes the source from destinations automatically.
                uint32_t min_x = core_work[cand.core_indices[0]].physical_core.x;
                uint32_t max_x = min_x;
                for (size_t ci = 1; ci < cand.core_indices.size(); ++ci) {
                    uint32_t x = core_work[cand.core_indices[ci]].physical_core.x;
                    min_x = std::min(min_x, x);
                    max_x = std::max(max_x, x);
                }
                const uint32_t injector_y = core_work[injector_idx].physical_core.y;
                const CoreCoord rect_start = CoreCoord{min_x, injector_y};
                const CoreCoord rect_end = CoreCoord{max_x, injector_y};

                const uint32_t mcast_num_dests = num_receivers;

                // Configure injector
                auto& injector_chain = core_chain_info[injector_idx];
                injector_chain.prev_physical = rect_start;  // mcast rect start
                injector_chain.next_physical = rect_end;    // mcast rect end
                injector_chain.mcast_num_dests = mcast_num_dests;
                injector_chain.mcast_sender_wait = num_receivers;
                injector_chain.next_core_q_chunks = cand.ref_q_chunks;

                // Configure receivers (all non-injector cores)
                for (const auto& ci : cand.core_indices) {
                    if (ci == injector_idx) {
                        continue;
                    }
                    auto& receiver_chain = core_chain_info[ci];
                    receiver_chain.prev_physical = core_work[injector_idx].physical_core;
                    receiver_chain.next_physical = CoreCoord{0, 0};
                    receiver_chain.next_core_q_chunks = 0;
                    receiver_chain.is_sink = true;
                }

                log_debug(
                    tt::LogOp,
                    "Head: mcast enabled - {} receivers, injector core {} (phys_x={}), num_dests={} -> rect ({},{}) to "
                    "({},{})",
                    num_receivers,
                    injector_idx,
                    core_work[injector_idx].physical_core.x,
                    mcast_num_dests,
                    rect_start.x,
                    rect_start.y,
                    rect_end.x,
                    rect_end.y);
            }
        }

        log_debug(
            tt::LogOp,
            "Multicast eligibility: {}/{} chains using mcast (all-or-nothing)",
            mcast_chains,
            total_multi_core_chains);
    }

    // Update mcast_enabled compile-time arg now that chain construction is complete
    reader_compile_time_args[sem_args_offset + 3] = (mcast_chains > 0) ? 1 : 0;

    // ---- Kernels (deferred until after chain construction for mcast_enabled flag) ----

    KernelDescriptor reader_desc;
    reader_desc.kernel_source =
        "ttnn/cpp/ttnn/operations/transformer/sdpa/device/kernels/dataflow/reader_interleaved.cpp";
    reader_desc.source_type = KernelDescriptor::SourceType::FILE_PATH;
    reader_desc.core_ranges = core_grid;
    reader_desc.compile_time_args = reader_compile_time_args;
    reader_desc.defines = defines;
    reader_desc.config = ReaderConfigDescriptor{};

    KernelDescriptor writer_desc;
    writer_desc.kernel_source =
        "ttnn/cpp/ttnn/operations/transformer/sdpa/device/kernels/dataflow/writer_interleaved.cpp";
    writer_desc.source_type = KernelDescriptor::SourceType::FILE_PATH;
    writer_desc.core_ranges = core_grid;
    writer_desc.compile_time_args = writer_compile_time_args;
    writer_desc.defines = defines;
    writer_desc.config = WriterConfigDescriptor{};

    KernelDescriptor compute_desc;
    compute_desc.kernel_source = "ttnn/cpp/ttnn/operations/transformer/sdpa/device/kernels/compute/sdpa.cpp";
    compute_desc.source_type = KernelDescriptor::SourceType::FILE_PATH;
    compute_desc.core_ranges = core_grid;
    compute_desc.compile_time_args = compute_compile_time_args;
    compute_desc.defines = defines;
    compute_desc.config = ComputeConfigDescriptor{
        .math_fidelity = math_fidelity,
        .fp32_dest_acc_en = fp32_dest_acc_en,
        .dst_full_sync_en = dst_full_sync_en,
        .math_approx_mode = math_approx_mode,
    };

    // Set reader rt args
    for (uint32_t i = 0; i < num_cores; ++i) {
        CoreCoord core = {i % grid_size.x, i / grid_size.x};

        // Global Q scheduling per-core range: contiguous slice of the flat (B, NQH, q_num_chunks) space.
        uint32_t global_q_start = i * global_q_base_chunks_per_core +
                                  std::min(i, global_q_cores_doing_extra) * global_q_extra_chunks_per_core;
        uint32_t global_q_count =
            global_q_base_chunks_per_core + ((i < global_q_cores_doing_extra) ? global_q_extra_chunks_per_core : 0u);
        if (global_q_start >= total_q_chunks) {
            global_q_start = total_q_chunks;
            global_q_count = 0;
        } else if (global_q_start + global_q_count > total_q_chunks) {
            global_q_count = total_q_chunks - global_q_start;
        }

        log_debug(
            tt::LogOp,
            "core: {} x={} y={} global_q_start={} global_q_count={}",
            i,
            core.x,
            core.y,
            global_q_start,
            global_q_count);

        // Get chain info for this core
        const auto& chain = core_chain_info[i];

        KernelDescriptor::RTArgList reader_args;
        reader_args.push_back(q_buffer);
        reader_args.push_back(k_buffer);
        reader_args.push_back(v_buffer);
        reader_args.push_back(mask_buffer);
        reader_args.push_back(page_table_buffer);
        reader_args.push_back(attention_sink_buffer);
        reader_args.push_back(chunk_start_idx_buffer);
        reader_args.push_back(num_phases);
        reader_args.push_back(chunked_q_chunk_offset);
        reader_args.push_back(read_offset);  // read_offset

        // Add chain metadata for non-causal case
        if (!is_causal) {
            reader_args.push_back(static_cast<uint32_t>(chain.participates));
            reader_args.push_back(static_cast<uint32_t>(chain.is_injector));
            reader_args.push_back(static_cast<uint32_t>(chain.is_sink));
            reader_args.push_back(chain.batch);
            reader_args.push_back(chain.head);
            reader_args.push_back(static_cast<uint32_t>(chain.prev_physical.x));
            reader_args.push_back(static_cast<uint32_t>(chain.prev_physical.y));
            reader_args.push_back(static_cast<uint32_t>(chain.next_physical.x));
            reader_args.push_back(static_cast<uint32_t>(chain.next_physical.y));
            reader_args.push_back(chain.next_core_q_chunks);
            reader_args.push_back(chain.mcast_num_dests);
            reader_args.push_back(chain.mcast_sender_wait);
        }

        // Global-Q tail (read by kernel after chain block when non-causal, immediately when causal).
        reader_args.push_back(global_q_start);
        reader_args.push_back(global_q_count);

        // Windowed K-range narrowing tail: same four values the writer gets at slots 9-12, so the
        // reader resolves each Q chunk's global row range and windows identically.
        reader_args.push_back(cu_window_buffer);
        reader_args.push_back(cu_window_seqlens_eles);
        reader_args.push_back(windowed_q_token_offset);
        reader_args.push_back(windowed_q_offset_buffer);

        reader_desc.emplace_runtime_args(core, reader_args);

        writer_desc.emplace_runtime_args(
            core,
            {out0_buffer,
             num_phases,                                       // 1
             static_cast<uint32_t>(flexible_chunked ? 1 : 0),  // 2
             chunked_q_chunk_offset,                           // 3: phase_1
             write_offset,                                     // 4
             0u,                                               // 5: phase_2 chunk_start (unused, num_phases==1)
             0u,                                               // 6: phase_2 write_offset (unused, num_phases==1)
             global_q_start,                                   // 7
             global_q_count,                                   // 8
             cu_window_buffer,                                 // 9: windowed mask src (nullptr if unused)
             cu_window_seqlens_eles,                           // 10: window count + 1
             windowed_q_token_offset,                          // 11: global origin of this Q shard (scalar)
             windowed_q_offset_buffer});                       // 12: same, per-device (nullptr => use 11)

        compute_desc.emplace_runtime_args(
            core,
            {num_phases,                                       // 0
             static_cast<uint32_t>(flexible_chunked ? 1 : 0),  // 1
             chunked_q_chunk_offset,                           // 2: phase_1
             0u,                                               // 3: phase_2 chunked offset (unused, num_phases==1)
             global_q_start,                                   // 4
             global_q_count});                                 // 5
    }

    desc.kernels.push_back(std::move(reader_desc));
    desc.kernels.push_back(std::move(writer_desc));
    desc.kernels.push_back(std::move(compute_desc));

    return desc;
}

}  // namespace ttnn::prim
