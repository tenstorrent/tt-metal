import base64
import subprocess
from pathlib import Path

repo = Path('/private/tmp/tt-metal-qwen38-long-context')
prefix = 'models/demos/qwen38_27b_qb2/'
names = [prefix + name for name in (
    'tests/compact_gdn.py', 'tests/test_gdn_epilogue_layer.py',
    'tests/test_compact_gdn_long_horizon.py', 'tests/unit/test_compact_long_horizon.py',
    'demo/run_compact_long_horizon.py',
)]
payload = {name: base64.b64encode((repo / name).read_bytes()).decode() for name in names}
remote = r'''
import base64,hashlib,json,os,shutil,subprocess,time
from pathlib import Path
art=Path('/home/ttuser/qwen38-artifacts-20261007')
task=Path('/home/ttuser/kimi-prefill.Ubx2wY/runtime/qwen38-27b-20261006')
def props(unit):
 raw=subprocess.check_output(['systemctl','--user','show',unit,'-p','MainPID','-p','ActiveState','-p','LoadState','-p','Result','-p','InvocationID'],text=True,timeout=20)
 return dict(line.split('=',1) for line in raw.splitlines() if '=' in line)
predecessor='qwen38-prefill-attention-v2-20261010.service'
prior=props(predecessor)
launch_prior=json.loads((art/'prefill-attention-control-v2/launch-unit.json').read_text())
assert prior['InvocationID']==launch_prior['InvocationID'] and prior['MainPID']!='0' and prior['ActiveState']=='active'
assert shutil.disk_usage(art).free>20*1024**3
source,control,output=[art/name for name in ('compact-long-horizon-source-v1','compact-long-horizon-control-v1','compact-long-horizon-v1')]
assert not any(path.exists() for path in (source,control,output))
shutil.copytree(art/'compact-gdn-source-v3',source,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache','.benchmarks','generated'))
control.mkdir()
for name,data in PAYLOAD.items():(source/name).write_bytes(base64.b64decode(data))
model=source/'models/demos/qwen38_27b_qb2'
original=json.loads((art/'compact-gdn-control-v3/source-manifest.json').read_text())
expected={n:d for n,d in original.items() if n.startswith(('models/demos/qwen38_27b_qb2/tt/','models/demos/qwen38_27b_qb2/config/'))}
actual={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for folder in ('tt','config') for p in (model/folder).rglob('*') if p.is_file() and p.suffix in ('.py','.cpp','.h','.hpp','.json')}
assert actual==expected, 'The model being validated must match the active compact source'
python=str(task/'python_env/bin/python')
env=dict(os.environ,TT_METAL_HOME=str(task/'metal'),LD_LIBRARY_PATH=f'{task}/metal-install/lib:{task}/metal-build/lib',PYTHONPATH=f'{source}:{task}/metal:{task}/metal/tools',ARCH_NAME='blackhole',OMP_NUM_THREADS='1',TT_METAL_INSPECTOR_RPC='0')
for key in ('TT_METAL_SIMULATOR','TT_METAL_DISABLE_SFPLOADMACRO','TT_METAL_SLOW_DISPATCH_MODE','QWEN_PREFILL_BATCHED_ATTENTION'):env.pop(key,None)
with (control/'preflight.log').open('w') as log:
 subprocess.run([python,'-m','pytest',str(model/'tests/unit'),'-c',str(source/'pytest.ini'),f'--rootdir={source}','-o','addopts=','-q',f'--junitxml={control}/unit.xml'],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
 subprocess.run([python,'-m','pytest',str(model/'tests/test_compact_gdn_long_horizon.py'),'--collect-only','-q','-c',str(source/'pytest.ini'),f'--rootdir={source}','-o','addopts='],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
print((control/'preflight.log').read_text()[-1400:],flush=True)
files=[source/n for n in ('conftest.py','pytest.ini','scripts/run_safe_pytest.sh')]
files.extend(p for p in model.rglob('*') if p.suffix in ('.py','.cpp','.h','.hpp','.json'))
manifest={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(control/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
command=['systemd-run','--user','--unit=qwen38-compact-long-horizon-v1-20261010','--property=RuntimeMaxSec=28h','--property=TimeoutStopSec=210','--property=KillMode=control-group','--property=MemoryMax=96G','--property=CPUQuota=800%',f'--property=StandardOutput=append:{control}/run.log',f'--property=StandardError=append:{control}/run.log',f'--working-directory={source}',f'--setenv=PYTHONPATH={source}','--setenv=PYTHONUNBUFFERED=1',python,'-m','models.demos.qwen38_27b_qb2.demo.run_compact_long_horizon','--task',str(task),'--source',str(source),'--weights',str(art/'checkpoint-pinned-1d4bf0f2'),'--output',str(output),'--manifest',str(control/'source-manifest.json'),'--after-unit',predecessor,'--after-invocation',prior['InvocationID'],'--after-receipt',str(art/'prefill-attention-v2/queue.json')]
launch=dict(command=command,source_parent='210b30ef573',created_at=time.time(),changed_files=list(PAYLOAD),model_matches_compact_v3=True,source_manifest_sha256=hashlib.sha256((control/'source-manifest.json').read_bytes()).hexdigest(),expected_physical_minutes=[2,10],hardware_timeout_seconds=1800,reference='Exact qualified-path comparison, not independent dense reference or full-model qualification',native_install_changed=False,active_sources_changed=False,predecessor=prior)
(control/'launch.json').write_text(json.dumps(launch,indent=2)+'\n')
subprocess.run(command,check=True,timeout=30)
state=props('qwen38-compact-long-horizon-v1-20261010.service')
assert state['ActiveState']=='active' and state['MainPID']!='0'
(control/'launch-unit.json').write_text(json.dumps(state,indent=2)+'\n')
print(state,flush=True)
'''
subprocess.run(
    ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', '-o', 'IdentityAgent=none', '-o', 'IdentitiesOnly=yes',
     '-i', '/Users/anatarajan/.ssh/id_ed25519', 'ttuser@10.228.203.98', 'python3 -'],
    input='PAYLOAD='+repr(payload)+'\n'+remote, text=True, check=True, timeout=900,
)
