#define TRISC_MATH
#include "defines_generated.h"
void kernel_main();
#include "/home/ttuser/qwen38-artifacts-20261007/attention-half-tile-sim-v2/accurate_partial/overlay/ttnn/cpp/ttnn/operations/transformer/sdpa_decode/device/kernels/compute/sdpa_flash_decode.cpp"
