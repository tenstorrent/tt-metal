#define TRISC_MATH
#include "kernel_bindings_generated.h"
#include "kernel_args_generated.h"
#include "defines_generated.h"
void kernel_main();
#include "/home/ttuser/kimi-prefill.Ubx2wY/runtime/qwen38-27b-20261006/metal/ttnn/cpp/ttnn/kernel/compute/tilize_metal2.cpp"
