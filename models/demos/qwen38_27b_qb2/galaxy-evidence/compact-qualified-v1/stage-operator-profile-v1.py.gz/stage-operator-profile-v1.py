import base64
import subprocess
from pathlib import Path

repo=Path('/private/tmp/tt-metal-qwen38-long-context');prefix='models/demos/qwen38_27b_qb2/'
names=['demo/analyze_operator_profile.py','demo/watch_operator_profile.py','tests/operator_profile.py','tests/unit/test_operator_profile.py']
payload={prefix+n:base64.b64encode((repo/prefix/n).read_bytes()).decode() for n in names}
remote=r'''
from pathlib import Path
import base64,hashlib,json,os,shutil,subprocess,time
art=Path('/home/ttuser/qwen38-artifacts-20261007');task=Path('/home/ttuser/kimi-prefill.Ubx2wY/runtime/qwen38-27b-20261006')
source=art/'operator-profile-source-v1';control=art/'operator-profile-control-v1';output=art/'operator-profile-v1';validation=art/'operator-profile-validation-v1'
assert not any(p.exists() for p in (source,control,output,validation))
assert shutil.disk_usage(art).free>20*1024**3
def props(unit):
 raw=subprocess.check_output(['systemctl','--user','show',unit,'-p','LoadState','-p','MainPID','-p','ActiveState','-p','InvocationID','-p','Result'],text=True,timeout=20)
 return dict(line.split('=',1) for line in raw.splitlines() if '=' in line)
parent='qwen38-compact-followup-v3-20261010.service';fallback='qwen38-compact-export-fallback-v2-20261010.service'
assert props(parent)['InvocationID']=='28c688b7780445999483523a9cbc75fc'
assert props(fallback)['InvocationID']=='e37b2f244e924e2f9b03f58af90d47ba'
shutil.copytree(art/'export-recovery-source-v2',source,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache','.benchmarks','generated'))
control.mkdir()
for name,encoded in PAYLOAD.items():
 p=source/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(base64.b64decode(encoded))
python=str(task/'python_env/bin/python');model=source/prefix
env=dict(os.environ,TT_METAL_HOME=str(task/'metal'),LD_LIBRARY_PATH=f'{task}/metal-install/lib:{task}/metal-build/lib',PYTHONPATH=f'{source}:{task}/metal:{task}/metal/tools',ARCH_NAME='blackhole',OMP_NUM_THREADS='4',TT_METAL_INSPECTOR_RPC='0')
with (control/'preflight.log').open('w') as log:
 subprocess.run([python,'-m','pytest',str(model/'tests/unit'),'-c',str(source/'pytest.ini'),f'--rootdir={source}','-o','addopts=','-q',f'--junitxml={control}/unit.xml'],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
manifest={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(model.rglob('*.py'))}
(control/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
plan=dict(baseline='/dev/shm/qwen38-compact-profile-v2-20261010/unprofiled',validation=str(validation/'analysis.json'),source_sha256={str(source/name):digest for name,digest in manifest.items()},producers=[dict(unit=parent,invocation='28c688b7780445999483523a9cbc75fc',receipt=str(art/'compact-followup-v3/queue.json'),capture='/dev/shm/qwen38-compact-profile-v2-20261010/profiled'),dict(unit=fallback,invocation='e37b2f244e924e2f9b03f58af90d47ba',receipt=str(art/'export-recovery-v2/queue.json'),capture=str(art/'export-recovery-v2/report'))])
(control/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
base=['systemd-run','--user','--property=RuntimeMaxSec=28h','--property=TimeoutStopSec=90','--property=KillMode=control-group','--property=MemoryMax=16G','--property=CPUQuota=400%',f'--working-directory={source}',f'--setenv=PYTHONPATH={source}:{task}/metal:{task}/metal/tools',f'--setenv=TT_METAL_HOME={task}/metal',f'--setenv=LD_LIBRARY_PATH={task}/metal-install/lib:{task}/metal-build/lib','--setenv=ARCH_NAME=blackhole','--setenv=OMP_NUM_THREADS=4','--setenv=PYTHONUNBUFFERED=1']
validate=base+['--unit=qwen38-operator-profile-validation-v1-20261010',f'--property=StandardOutput=append:{control}/validation.log',f'--property=StandardError=append:{control}/validation.log',python,'-m',prefix.replace('/','.')+'demo.analyze_operator_profile','--capture',str(art/'export-recovery-validation-v2'),'--baseline','/dev/shm/qwen38-p0-priority-v1-20261010/unprofiled','--output',str(validation)]
validate=[v.replace('--property=RuntimeMaxSec=28h','--property=RuntimeMaxSec=20min') for v in validate]
command=base+['--unit=qwen38-operator-profile-v1-20261010',f'--property=StandardOutput=append:{control}/run.log',f'--property=StandardError=append:{control}/run.log',python,'-m',prefix.replace('/','.')+'demo.watch_operator_profile','--plan',str(control/'plan.json'),'--output',str(output)]
(control/'launch.json').write_text(json.dumps(dict(command=command,validation_command=validate,created_at=time.time(),physical_devices_accessed=False),indent=2)+'\n')
subprocess.run(validate,check=True,timeout=30)
subprocess.run(command,check=True,timeout=30)
active={name:props(name) for name in ('qwen38-operator-profile-v1-20261010.service','qwen38-operator-profile-validation-v1-20261010.service')}
(control/'launch-units.json').write_text(json.dumps(active,indent=2)+'\n')
print(json.dumps(active,indent=2));print((control/'preflight.log').read_text()[-1200:])
'''
subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','IdentityAgent=none','-o','IdentitiesOnly=yes','-i','/Users/anatarajan/.ssh/id_ed25519','ttuser@10.228.203.98','python3 -'],input='PAYLOAD='+repr(payload)+'\nprefix='+repr(prefix)+'\n'+remote,text=True,check=True,timeout=750)
