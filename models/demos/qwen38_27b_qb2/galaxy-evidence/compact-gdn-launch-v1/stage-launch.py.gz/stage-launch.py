import base64
import subprocess
from pathlib import Path
repo=Path('/private/tmp/tt-metal-qwen38-long-context')
prefix='models/demos/qwen38_27b_qb2/'
names=[n for n in subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=repo,text=True).splitlines() if n.startswith(prefix) and Path(n).suffix in ('.py','.cpp','.json')]
payload={n:base64.b64encode((repo/n).read_bytes()).decode() for n in names}
assert any(n.endswith('run_compact_gdn.py') for n in names)
remote=r'''
from pathlib import Path
import base64, hashlib, json, os, shutil, subprocess, time
art=Path('/home/ttuser/qwen38-artifacts-20261007')
task=Path('/home/ttuser/kimi-prefill.Ubx2wY/runtime/qwen38-27b-20261006')
source,control,output=[art/n for n in ('compact-gdn-source-v1','compact-gdn-control-v1','compact-gdn-v1')]
assert not any(p.exists() for p in (source,control,output))
assert shutil.disk_usage(art).free>15*1024**3
base=art/'projection-sweep-source-v1'
shutil.copytree(base,source,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache','.benchmarks','generated'))
control.mkdir()
for name,data in PAYLOAD.items():
 p=source/name
 p.parent.mkdir(parents=True,exist_ok=True)
 p.write_bytes(base64.b64decode(data))
model=source/'models/demos/qwen38_27b_qb2'
python=str(task/'python_env/bin/python')
env=dict(os.environ,TT_METAL_HOME=str(task/'metal'),LD_LIBRARY_PATH=f'{task}/metal-install/lib:{task}/metal-build/lib',
 PYTHONPATH=f'{source}:{task}/metal:{task}/metal/tools',ARCH_NAME='blackhole',OMP_NUM_THREADS='1',TT_METAL_INSPECTOR_RPC='0')
for key in ('TT_METAL_SIMULATOR','TT_METAL_DISABLE_SFPLOADMACRO','TT_METAL_SLOW_DISPATCH_MODE','QWEN_COMPACT_EPILOGUE','QWEN_GDN_EPILOGUE_LAYER'):
 env.pop(key,None)
with (control/'preflight.log').open('w') as log:
 subprocess.run([python,'-m','pytest',str(model/'tests/unit'),'-c',str(source/'pytest.ini'),f'--rootdir={source}',
 '-o','addopts=','-q',f'--junitxml={control}/unit.xml'],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
 subprocess.run([python,'-m','pytest',str(model/'tests/test_compact_gdn_epilogue.py'),str(model/'tests/test_gdn_epilogue_layer.py'),
 str(model/'tests/test_galaxy_perf_sweep.py'),'--collect-only','-q','-c',str(source/'pytest.ini'),f'--rootdir={source}',
 '-o','addopts='],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
print((control/'preflight.log').read_text()[-3200:],flush=True)
files=[source/name for name in ('conftest.py','pytest.ini','scripts/run_safe_pytest.sh')]
files.extend(p for p in model.rglob('*') if p.suffix in ('.py','.cpp','.h','.hpp','.json'))
manifest={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(control/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')

def props(unit):
 raw=subprocess.check_output(['systemctl','--user','show',unit,'-p','MainPID','-p','ActiveState','-p','InvocationID','-p','SubState'],text=True)
 return dict(line.split('=',1) for line in raw.splitlines() if '=' in line)
predecessor='qwen38-b16-priority-v2-20261010.service'
invocation='f5b0da5649614052ba7b8ddf37b466d5'
p=props(predecessor)
assert p['InvocationID']==invocation and p['ActiveState']=='active' and p['MainPID']!='0',p
old='qwen38-projection-sweep-v1-20261010.service'
oldprops=props(old)
r=json.loads((art/'projection-sweep-v1/queue.json').read_text())
assert oldprops['InvocationID']=='998fcce35571487c9eac759638d71013' and oldprops['ActiveState']=='active',oldprops
assert r['state']=='waiting' and r['hardware_started'] is False,r
# The predecessor is still running, so this follower cannot acquire hardware.
# Retain its exact source; only its place in the queue changes.
subprocess.run(['systemctl','--user','stop',old],check=True,timeout=60)
assert props(old)['MainPID']=='0'
(control/'projection-reorder.json').write_text(json.dumps(dict(old_unit=old,old_properties=oldprops,
 old_receipt=r,reason='User prioritizes 30 native TSU big swings; compact block precedes minor projection tuning',
 active_hardware_interrupted=False,stopped_at=time.time()),indent=2)+'\n')
unit='qwen38-compact-gdn-v1-20261010'
command=['systemd-run','--user',f'--unit={unit}','--property=RuntimeMaxSec=38h',
 '--property=TimeoutStopSec=210','--property=KillMode=control-group','--property=MemoryMax=192G','--property=CPUQuota=800%',
 f'--property=StandardOutput=append:{control}/run.log',f'--property=StandardError=append:{control}/run.log',
 f'--working-directory={source}',f'--setenv=PYTHONPATH={source}','--setenv=PYTHONUNBUFFERED=1',python,
 '-m','models.demos.qwen38_27b_qb2.demo.run_compact_gdn','--task',str(task),'--source',str(source),
 '--weights',str(art/'checkpoint-pinned-1d4bf0f2'),'--output',str(output),'--manifest',str(control/'source-manifest.json'),
 '--after-unit',predecessor,'--after-invocation',invocation,'--after-receipt',str(art/'b16-priority-v2/queue.json')]
(control/'launch.json').write_text(json.dumps(dict(command=command,source_parent='45c2b85909b',created_at=time.time(),
 physical_stages=['26 compact epilogue cases','real-weight GDN B16/B32/B8/B1 + changing inputs',
 'B16 32K/16K control/compact/control full-model sweeps'],primary_target_tsu=30,speculative_decoding=False,
 estimated_incremental_step_saving_ms=[4,6],expected_gain_is_estimate=True,
 estimated_physical_minutes=[90,180],full_gpqa_qualified=False,
 source_manifest_sha256=hashlib.sha256((control/'source-manifest.json').read_bytes()).hexdigest()),indent=2)+'\n')
subprocess.run(command,check=True)
current=props(unit+'.service')
(control/'launch-unit.json').write_text(json.dumps(current,indent=2)+'\n')
print('compact',current,flush=True)
# Reuse the original frozen projection experiment with a new receipt/output.
projection=json.loads((art/'projection-sweep-control-v1/launch.json').read_text())['command']
oldcontrol=str(art/'projection-sweep-control-v1')
newcontrol=art/'projection-sweep-control-v2'
newcontrol.mkdir()
projection=[s.replace('--unit=qwen38-projection-sweep-v1-20261010','--unit=qwen38-projection-sweep-v2-20261010')
 .replace('append:'+oldcontrol+'/run.log','append:'+str(newcontrol)+'/run.log') for s in projection]
for name,value in [('--output',str(art/'projection-sweep-v2')),('--after-unit',unit+'.service'),
 ('--after-invocation',current['InvocationID']),('--after-receipt',str(output/'queue.json'))]:
 projection[projection.index(name)+1]=value
(newcontrol/'launch.json').write_text(json.dumps(dict(command=projection,created_at=time.time(),
 frozen_source_unchanged=True,reason='Follow compact GDN block'),indent=2)+'\n')
subprocess.run(projection,check=True)
p=props('qwen38-projection-sweep-v2-20261010.service')
(newcontrol/'launch-unit.json').write_text(json.dumps(p,indent=2)+'\n')
print('projection',p,flush=True)
'''
subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','IdentityAgent=none','-o','IdentitiesOnly=yes',
 '-i','/Users/anatarajan/.ssh/id_ed25519','ttuser@10.228.203.98','python3 -'],input='PAYLOAD='+repr(payload)+'\n'+remote,
 text=True,check=True,timeout=900)
