"""Collect immutable compact timing and persistent GPQA queue receipts."""

import base64
import datetime
import gzip
import json
import shlex
import subprocess
import sys
from pathlib import Path

OUTPUT = Path('/private/tmp/tt-metal-qwen38-long-context/models/demos/qwen38_27b_qb2/galaxy-evidence/compact-first-decode-v1')
if sys.argv[1:] == ['--completed-candidate']:
    OUTPUT = OUTPUT / 'completed-candidate'
elif sys.argv[1:]:
    raise ValueError('Unknown capture arguments')
REMOTE = r'''
import base64, datetime, json, subprocess
from pathlib import Path
root = Path('/home/ttuser/qwen38-artifacts-20261007')
files = {
    'before-sweep.json': 'compact-gdn-v3/before/sweep.json',
    'compact-sweep.json': 'compact-gdn-v3/compact/sweep.json',
    'compact-queue.json': 'compact-gdn-v3/queue.json',
    'followup-queue.json': 'compact-followup-v3/queue.json',
    'followup-launch.json': 'compact-followup-control-v3/launch.json',
    'source-manifest.json': 'compact-gdn-control-v3/source-manifest.json',
    'compact-run.log.gz': 'compact-gdn-control-v3/run.log',
}
result = {'captured_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'files': {}}
for name, relative in files.items():
    path = root / relative
    if path.stat().st_size > 4 * 1024 * 1024:
        raise ValueError('Unexpected artifact size: ' + relative)
    result['files'][name] = {'remote_path': str(path), 'base64': base64.b64encode(path.read_bytes()).decode()}
units = ['qwen38-compact-gdn-v3-20261010.service', 'qwen38-compact-followup-v3-20261010.service']
result['units'] = {}
for unit in units:
    raw = subprocess.check_output(['systemctl', '--user', 'show', unit, '-p', 'Id', '-p', 'MainPID', '-p', 'InvocationID', '-p', 'ActiveState', '-p', 'SubState', '-p', 'Result', '-p', 'RuntimeMaxUSec', '-p', 'MemoryMax'], text=True, timeout=20)
    result['units'][unit] = dict(line.split('=', 1) for line in raw.splitlines() if '=' in line)
print(json.dumps(result))
'''
ssh = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', '-o', 'IdentityAgent=none', '-o', 'IdentitiesOnly=yes', '-i', '/Users/anatarajan/.ssh/id_ed25519', 'ttuser@10.228.203.98']
raw = subprocess.check_output(ssh + ['python3 -c ' + shlex.quote(REMOTE)], timeout=60)
result = json.loads(raw)
OUTPUT.mkdir(parents=True, exist_ok=True)
paths = {}
for name, item in result.pop('files').items():
    target = OUTPUT / name
    if target.exists():
        raise FileExistsError(target)
    content = base64.b64decode(item['base64'])
    target.write_bytes(gzip.compress(content, mtime=0) if name.endswith('.gz') else content)
    paths[name] = item['remote_path']
result['remote_paths'] = paths
result['snapshot_note'] = 'Sequential read-only capture; queued qualification is not an accuracy pass.'
(OUTPUT / 'capture.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'output': str(OUTPUT), 'captured_at': result['captured_at'], 'units': result['units']}, indent=2))
