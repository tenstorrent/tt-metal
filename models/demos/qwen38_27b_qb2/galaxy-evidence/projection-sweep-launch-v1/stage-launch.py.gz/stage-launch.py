import base64
import hashlib
import subprocess
from pathlib import Path

repo = Path('/private/tmp/tt-metal-qwen38-long-context')
prefix = 'models/demos/qwen38_27b_qb2/'
names = ['tests/projection_sweep.py', 'tests/test_projection_sweep.py',
         'tests/unit/test_projection_sweep.py', 'demo/run_projection_sweep.py']
payload = {prefix + name: base64.b64encode((repo / prefix / name).read_bytes()).decode() for name in names}
runtime = {prefix + name: hashlib.sha256((repo / prefix / name).read_bytes()).hexdigest()
           for name in ('tt/decoder.py', 'tt/decoder_tp.py', 'tt/precision.py',
                        'tests/test_gdn_epilogue.py', 'tests/test_gdn_layer_integration.py')}
remote = r'''
from pathlib import Path
import base64, hashlib, json, os, shutil, subprocess, time
art=Path('/home/ttuser/qwen38-artifacts-20261007')
task=Path('/home/ttuser/kimi-prefill.Ubx2wY/runtime/qwen38-27b-20261006')
source,control,output=[art/name for name in ('projection-sweep-source-v1','projection-sweep-control-v1','projection-sweep-v1')]
assert not any(p.exists() for p in (source,control,output))
assert shutil.disk_usage(art).free>15*1024**3
predecessor='qwen38-b16-priority-v2-20261010.service'
invocation='f5b0da5649614052ba7b8ddf37b466d5'
props=dict(line.split('=',1) for line in subprocess.check_output(['systemctl','--user','show',predecessor,
  '-p','InvocationID','-p','ActiveState','-p','MainPID'],text=True).splitlines() if '=' in line)
assert props.get('InvocationID')==invocation,props
base=art/'b16-priority-source-v2'
for name,digest in RUNTIME.items():
 assert hashlib.sha256((base/name).read_bytes()).hexdigest()==digest,name
shutil.copytree(base,source,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache','.benchmarks','generated'))
control.mkdir()
for name,encoded in PAYLOAD.items():
 p=source/name
 p.parent.mkdir(parents=True,exist_ok=True)
 p.write_bytes(base64.b64decode(encoded))
model=source/'models/demos/qwen38_27b_qb2'
python=str(task/'python_env/bin/python')
env=dict(os.environ,TT_METAL_HOME=str(task/'metal'),LD_LIBRARY_PATH=f'{task}/metal-install/lib:{task}/metal-build/lib',
         PYTHONPATH=f'{source}:{task}/metal:{task}/metal/tools',ARCH_NAME='blackhole',OMP_NUM_THREADS='1',TT_METAL_INSPECTOR_RPC='0')
for key in ('TT_METAL_SIMULATOR','TT_METAL_DISABLE_SFPLOADMACRO','TT_METAL_SLOW_DISPATCH_MODE','QWEN_PROJECTION_SWEEP'):
 env.pop(key,None)
with (control/'preflight.log').open('w') as log:
 subprocess.run([python,'-m','pytest',str(model/'tests/unit/test_projection_sweep.py'),
  str(model/'tests/unit/test_b16_followup.py'),'-c',str(source/'pytest.ini'),f'--rootdir={source}',
  '-o','addopts=','-q',f'--junitxml={control}/unit.xml'],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
 subprocess.run([python,'-m','pytest',str(model/'tests/test_projection_sweep.py'),'--collect-only','-q',
  '-c',str(source/'pytest.ini'),f'--rootdir={source}','-o','addopts='],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
print((control/'preflight.log').read_text()[-2500:],flush=True)
files=[source/name for name in ('conftest.py','pytest.ini','scripts/run_safe_pytest.sh')]
files.extend(p for p in model.rglob('*') if p.suffix in ('.py','.cpp','.hpp','.h','.json'))
manifest={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(control/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
unit='qwen38-projection-sweep-v1-20261010'
command=['systemd-run','--user',f'--unit={unit}','--property=RuntimeMaxSec=28h',
 '--property=TimeoutStopSec=210','--property=KillMode=control-group','--property=MemoryMax=64G','--property=CPUQuota=800%',
 f'--property=StandardOutput=append:{control}/run.log',f'--property=StandardError=append:{control}/run.log',
 f'--working-directory={source}',f'--setenv=PYTHONPATH={source}','--setenv=PYTHONUNBUFFERED=1',
 python,'-m','models.demos.qwen38_27b_qb2.demo.run_projection_sweep',
 '--task',str(task),'--source',str(source),'--weights',str(art/'checkpoint-pinned-1d4bf0f2'),
 '--output',str(output),'--manifest',str(control/'source-manifest.json'),
 '--after-unit',predecessor,'--after-invocation',invocation,'--after-receipt',str(art/'b16-priority-v2/queue.json')]
(control/'launch.json').write_text(json.dumps(dict(command=command,created_at=time.time(),
 scope='44 B16/B32 TP4 projection cases: output/down BFP8, reader/core/block sweep, all-reduce and layouts included',
 expected_full_step_saving_ms=[1.5,3.5],expected_gain_is_estimate=True,
 physical_runtime_budget_seconds=5400,estimated_physical_minutes=[30,90],
 source_manifest_sha256=hashlib.sha256((control/'source-manifest.json').read_bytes()).hexdigest()),indent=2)+'\n')
subprocess.run(command,check=True)
raw=subprocess.check_output(['systemctl','--user','show',unit+'.service','-p','MainPID','-p','ActiveState','-p','InvocationID'],text=True)
(control/'launch-unit.txt').write_text(raw)
print(raw,flush=True)
'''
subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','IdentityAgent=none','-o','IdentitiesOnly=yes',
 '-i','/Users/anatarajan/.ssh/id_ed25519','ttuser@10.228.203.98','python3 -'],
 input='PAYLOAD='+repr(payload)+'\nRUNTIME='+repr(runtime)+'\n'+remote,text=True,check=True,timeout=450)
