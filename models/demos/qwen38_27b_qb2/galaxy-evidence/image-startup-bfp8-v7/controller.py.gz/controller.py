import fcntl
import hashlib
import os
import shutil
import json
from pathlib import Path
import subprocess
import time

ART = Path("/home/ttuser/qwen38-artifacts-20261007")
ROOT = ART / "image-startup-bfp8-v7"
SOURCE = ART / "image-startup-bfp8-source-v7"
UNIT = "qwen38-precision-perf-v1-20261009.service"
INVOCATION = "122b1077bed2438d9802360ab6277514"
IMAGE = "sha256:79f7b4469a6ec2bcce5204399b37b2aeced8be7f260dd98f7007ad41f8813055"
CONFIG = "sha256:2f70ab2ae93b7edb362340ef3c241f1577a49d6795548c7d62cdde4f4e5b1ecd"
NAME = "qwen38-image-startup-bfp8-v7"
ROOT.mkdir()
state = dict(state="waiting", predecessor_unit=UNIT, predecessor_invocation=INVOCATION,
             hardware_opened=False, survives_disconnect=True, resumes_after_reboot=False,
             image_config_digest=CONFIG, image_manifest_digest=IMAGE, started_at=time.time())

def save():
    state["updated_at"] = time.time()
    p = ROOT / "status.tmp"
    p.write_text(json.dumps(state, indent=2) + "\n")
    p.replace(ROOT / "status.json")

save()
lock = None
try:
    deadline = time.monotonic() + 14 * 3600
    while True:
        if time.monotonic() >= deadline:
            raise TimeoutError("Precision comparison predecessor wait exceeded bound")
        try:
            output = subprocess.check_output(
                ["systemctl", "--user", "show", UNIT, "-p", "InvocationID", "-p", "MainPID",
                 "-p", "ActiveState", "-p", "LoadState", "-p", "Result"], text=True, timeout=15)
        except (subprocess.TimeoutExpired, subprocess.CalledProcessError) as error:
            state["observation_error"] = type(error).__name__
            save()
            time.sleep(30)
            continue
        props = dict(line.split("=", 1) for line in output.splitlines() if "=" in line)
        state["predecessor"] = props
        save()
        if props.get("InvocationID") and props["InvocationID"] != INVOCATION:
            raise ValueError("Precision comparison predecessor invocation was replaced")
        if (props.get("LoadState") in ("loaded", "not-found") and props.get("MainPID") == "0"
                and props.get("ActiveState") in ("inactive", "failed")):
            if props.get("LoadState") == "loaded" and props.get("Result") != "success":
                raise ValueError("Precision comparison predecessor failed")
            receipt = json.loads((ART / "precision-perf-v1/queue.json").read_text())
            if receipt.get("state") != "completed" or receipt.get("cleanup_completed") is not True:
                raise ValueError("Precision comparison predecessor lacks completed clean shutdown")
            break
        time.sleep(30)
    manifest = json.loads((SOURCE / "source-manifest.json").read_text())
    for name, digest in manifest.items():
        if hashlib.sha256((SOURCE / name).read_bytes()).hexdigest() != digest:
            raise ValueError("Frozen startup probe changed")
    state["state"] = "waiting_for_hardware_lock"
    save()
    # No devices are exposed. This lock merely prevents CPU import work from
    # overlapping any of the queued hardware measurements.
    lock = open("/tmp/tt-device.lock", "a")
    if lock:
        while True:
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                if time.monotonic() >= deadline:
                    raise TimeoutError("Device coordination lock wait exceeded bound")
                time.sleep(10)
        # Import only after the active hardware chain releases the global lock.
        # The native image occupied 18.9 GB uncompressed; budget 21 GiB plus
        # both the compressed archive/store and an 8-GiB free-space reserve.
        archive_bytes = 6011314688
        archive_sha = "603a03b83772c8f47f7817d838316657ef6b4a77e972d9f9580559d4db2550dd"
        reserve = 8 * 1024**3
        import_budget = archive_bytes + 21 * 1024**3
        free = shutil.disk_usage(ROOT).free
        required = archive_bytes + import_budget + reserve
        if free <= required:
            raise RuntimeError(f"Image needs {required} free bytes; found {free}")
        state.update(state="downloading", free_before_bytes=free,
                     archive_sha256=archive_sha, expected_archive_bytes=archive_bytes,
                     conservative_required_bytes=required)
        save()
        partial = ROOT / "image.oci.tar.partial"
        archive = ROOT / "image.oci.tar"
        download = subprocess.run(
            ["curl", "--fail", "--silent", "--show-error", "--cacert", str(SOURCE / "cert.pem"),
             "--connect-timeout", "10", "--max-time", "900", "--retry", "2", "--retry-max-time", "900",
             "--max-filesize", str(archive_bytes), "--output", str(partial),
             "https://10.228.203.34:18444/sha256/" + archive_sha],
            text=True, capture_output=True, timeout=1100)
        (ROOT / "download.log").write_text(download.stdout + download.stderr)
        download.check_returncode()
        if partial.stat().st_size != archive_bytes:
            raise ValueError("Downloaded archive size differs from the completed build")
        digest = hashlib.sha256()
        with partial.open("rb") as stream:
            for chunk in iter(lambda: stream.read(16 * 1024**2), b""):
                digest.update(chunk)
            os.fsync(stream.fileno())
        if digest.hexdigest() != archive_sha:
            raise ValueError("Downloaded archive checksum differs from the completed build")
        partial.rename(archive)
        directory_fd = os.open(ROOT, os.O_DIRECTORY)
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
        if shutil.disk_usage(ROOT).free <= import_budget + reserve:
            raise RuntimeError("Insufficient host disk before Docker import")
        state.update(state="loading", downloaded_at=time.time(), archive_bytes=archive.stat().st_size)
        save()
        result = subprocess.run(["docker", "image", "load", "--input", str(archive)],
                                text=True, capture_output=True, timeout=1200)
        (ROOT / "load.log").write_text(result.stdout + result.stderr)
        result.check_returncode()
        state.update(state="verifying_identity", loaded_at=time.time())
        save()
        identity_command = ["/usr/bin/python3", str(SOURCE / "verify_local_oci_image.py"),
                            "--archive", str(ROOT / "image.oci.tar"),
                            "--manifest-digest", IMAGE, "--config-digest", CONFIG,
                            "--output", str(ROOT / "image-identity.json")]
        identity_result = subprocess.run(identity_command, text=True, capture_output=True, timeout=90, check=True)
        (ROOT / "identity.log").write_text(identity_result.stdout + identity_result.stderr)
        common = ["docker", "run", "--rm", "--label", "qwen38.task=image-startup-bfp8-v7",
                  "--network=none", "--read-only", "--memory=4g", "--memory-swap=4g", "--cpus=4",
                  "--pids-limit=256", "--tmpfs", "/tmp:rw,size=512m", "--env", "PYTHONDONTWRITEBYTECODE=1",
                  "--entrypoint", "/home/container_app_user/tt-metal/python_env/bin/python"]
        state["stages"] = []
        for label, suffix, marker in [
            ("runtime-imports", ["/home/container_app_user/qwen38-bundle/verify_image.py"], "QWEN_IMAGE_SOURCE_AND_IMPORTS_PASS"),
            ("entrypoint-help", ["/home/container_app_user/app/src/run_vllm_api_server.py", "--help"], None),
        ]:
            command = common + ["--name", NAME + "-" + label, IMAGE, *suffix]
            row = dict(name=label, state="running", command=command, started_at=time.time())
            state["stages"].append(row)
            state["state"] = "runtime_checks"
            save()
            result = subprocess.run(command, text=True, capture_output=True, timeout=180, check=False)
            (ROOT / (label + ".log")).write_text(result.stdout + result.stderr)
            if result.returncode or (marker and marker not in result.stdout):
                row.update(state="failed", exit_code=result.returncode)
                raise RuntimeError("Container check failed: " + label)
            row.update(state="completed", finished_at=time.time())
            save()
        command = ["docker", "run", "--rm", "--name", NAME,
                   "--label", "qwen38.task=image-startup-bfp8-v7", "--network=none", "--read-only",
                   "--memory=4g", "--memory-swap=4g", "--cpus=4", "--pids-limit=256",
                   "--tmpfs", "/tmp:rw,size=512m",
                   "--tmpfs", "/home/container_app_user/cache_root:rw,uid=1000,gid=1000,size=512m",
                   "--mount", f"type=bind,src={SOURCE / 'probe_qwen38_startup.py'},dst=/startup-probe.py,readonly",
                   "--mount", f"type=bind,src={ART / 'checkpoint-pinned-1d4bf0f2'},dst=/mnt/hf-cache,readonly",
                   "--env", "PYTHONDONTWRITEBYTECODE=1", "--entrypoint",
                   "/home/container_app_user/tt-metal/python_env/bin/python", IMAGE, "/startup-probe.py"]
        state.update(state="probing", command=command)
        save()
        result = subprocess.run(command, text=True, capture_output=True, timeout=180, check=False)
        (ROOT / "stdout.log").write_text(result.stdout)
        (ROOT / "stderr.log").write_text(result.stderr)
        if result.returncode:
            raise RuntimeError(f"Startup probe exited {result.returncode}")
        decoder = json.JSONDecoder()
        report = None
        for index, char in enumerate(result.stdout):
            if char == "{":
                try:
                    candidate, _ = decoder.raw_decode(result.stdout[index:])
                except ValueError:
                    continue
                if isinstance(candidate, dict) and candidate.get("state") == "startup_handoff_passed_unqualified":
                    report = candidate
        if report is None:
            raise ValueError("Startup handoff receipt missing")
        (ROOT / "report.json").write_text(json.dumps(report, indent=2) + "\n")
        state.update(state="completed", passed=True, accuracy_qualified=False,
                     server_started=False, free_after_bytes=shutil.disk_usage(ROOT).free, finished_at=time.time())
except BaseException as error:
    state.update(state="failed", error=type(error).__name__, detail=str(error)[:2000], finished_at=time.time())
    raise
finally:
    try:
        owned = subprocess.check_output(["docker", "ps", "-aq", "--filter", "label=qwen38.task=image-startup-bfp8-v7"], text=True, timeout=30).split()
        if owned:
            subprocess.run(["docker", "rm", "-f", *owned], timeout=60, check=True)
    finally:
        if lock is not None:
            lock.close()
        save()
