import base64
import hashlib
import json
from pathlib import Path
import subprocess

REPO = Path('/private/tmp/tt-inference-server-qwen38-release')
SHA = 'bbb1ca07e7cd0f97af47745a1686545a16089b9c'
SSH = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', '-o', 'IdentityAgent=none',
       '-o', 'IdentitiesOnly=yes', '-i', '/Users/anatarajan/.ssh/id_ed25519']

def remote(host, script):
    compile(script, 'remote.py', 'exec')
    result = subprocess.run(SSH + ['ttuser@' + host, 'python3 -'], input=script,
                            text=True, capture_output=True, timeout=60)
    if result.returncode:
        print(result.stdout)
        print(result.stderr)
        result.check_returncode()
    return result.stdout

server = Path('/private/tmp/qwen38-serve-image-v7.py').read_bytes()
controller = Path('/private/tmp/qwen38-startup-bfp8-controller-v7.py').read_bytes()
for name, source in [('server.py', server), ('controller.py', controller)]:
    compile(source, name, 'exec')

stage_server = r'''
import base64,json,pathlib,subprocess,hashlib
root=pathlib.Path('/home/ttuser/qwen38-release-build-20261009-v7')
state=json.loads((root/'state.json').read_text())
if state.get('state')!='built_unqualified' or state.get('archive_sha256')!='603a03b83772c8f47f7817d838316657ef6b4a77e972d9f9580559d4db2550dd':
 raise ValueError('Completed immutable BFP8 image missing')
if pathlib.Path(state['durable_archive']).stat().st_size!=6011314688:
 raise ValueError('Image size changed')
props=subprocess.check_output(['systemctl','--user','show','qwen38-release-build-v7-20261009.service','-p','MainPID','-p','InvocationID','-p','ActiveState','-p','Result','-p','LoadState'],text=True)
fields=dict(x.split('=',1) for x in props.splitlines() if '=' in x)
if fields.get('InvocationID') and fields['InvocationID']!='ea312e233d9e4dd5995f81ccadd7f564':
 raise ValueError('Image builder invocation was replaced')
if fields.get('MainPID')!='0' or fields.get('ActiveState')!='inactive' or fields.get('LoadState') not in ('loaded','not-found') or fields.get('Result')!='success':
 raise ValueError('Image builder has not completed cleanly')
container=json.loads(subprocess.check_output(['docker','inspect','--format','{{json .State}}','qwen38-release-builder-20261009-v7'],text=True))
if container.get('Running') is not False or container.get('Pid')!=0:
 raise ValueError('Owned image builder is still running')
work=root/'transfer-v7';work.mkdir(mode=0o700)
source=base64.b64decode(SERVER)
(work/'serve.py').write_bytes(source)
subprocess.run(['openssl','req','-x509','-newkey','rsa:2048','-nodes','-days','1',
 '-subj','/CN=10.228.203.34','-addext','subjectAltName=IP:10.228.203.34',
 '-keyout',str(work/'key.pem'),'-out',str(work/'cert.pem')],capture_output=True,check=True,timeout=20)
(work/'key.pem').chmod(0o600)
command=['systemd-run','--user','--unit=qwen38-serve-image-v7-20261009',
 '--property=RuntimeMaxSec=18h','--property=MemoryMax=128M','--property=CPUQuota=200%',
 '--property=UMask=0077',f'--property=StandardOutput=append:{work}/run.log',
 f'--property=StandardError=append:{work}/run.log','/usr/bin/python3',str(work/'serve.py')]
(work/'launch.json').write_text(json.dumps({'command':command,'source_sha256':hashlib.sha256(source).hexdigest()},indent=2)+'\n')
subprocess.run(command,check=True,capture_output=True,text=True)
service=subprocess.check_output(['systemctl','--user','show','qwen38-serve-image-v7-20261009.service','-p','MainPID','-p','InvocationID','-p','ActiveState'],text=True)
print(json.dumps({'cert':base64.b64encode((work/'cert.pem').read_bytes()).decode(),'service':service,'build':state}))
'''
reply = json.loads(remote('10.228.203.34', 'SERVER=' + repr(base64.b64encode(server).decode()) + '\n' + stage_server))
cert = base64.b64decode(reply['cert'])
contents = {'controller.py': controller, 'cert.pem': cert}
for name in ['verify_local_oci_image.py', 'probe_qwen38_startup.py']:
    contents[name] = subprocess.check_output(['git', '-C', str(REPO), 'show', SHA + ':scripts/release/' + name])
    compile(contents[name], name, 'exec')
manifest = {name: hashlib.sha256(data).hexdigest() for name, data in contents.items()}
contents['source-manifest.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
payload = {name: base64.b64encode(data).decode() for name, data in contents.items()}
stage_controller = r'''
import base64,json,pathlib,subprocess,hashlib,shutil
root=pathlib.Path('/home/ttuser/qwen38-artifacts-20261007/image-startup-bfp8-source-v7')
root.mkdir(mode=0o700)
for name,data in PAYLOAD.items():
 (root/name).write_bytes(base64.b64decode(data))
for name,digest in json.loads((root/'source-manifest.json').read_text()).items():
 if hashlib.sha256((root/name).read_bytes()).hexdigest()!=digest:
  raise ValueError('Frozen startup source mismatch: '+name)
result=subprocess.run(['curl','--head','--fail','--silent','--show-error','--cacert',str(root/'cert.pem'),
 '--connect-timeout','10','--max-time','30',
 'https://10.228.203.34:18444/sha256/603a03b83772c8f47f7817d838316657ef6b4a77e972d9f9580559d4db2550dd'],
 text=True,capture_output=True,timeout=40,check=True)
if 'Content-Length: 6011314688' not in result.stdout:
 raise ValueError('Pinned TLS transfer returned an unexpected image length')
(root/'transfer-preflight.txt').write_text(result.stdout)
subprocess.run(['/usr/bin/python3',str(root/'verify_local_oci_image.py'),'--help'],capture_output=True,check=True,timeout=20)
command=['systemd-run','--user','--unit=qwen38-image-startup-bfp8-v7-20261009',
 '--property=RuntimeMaxSec=16h','--property=TimeoutStopSec=90','--property=KillMode=control-group',
 '--property=MemoryMax=5G','--property=CPUQuota=400%','--property=TasksMax=320','--property=UMask=0077',
 f'--property=StandardOutput=append:{root}/run.log',f'--property=StandardError=append:{root}/run.log',
 '--setenv=PYTHONUNBUFFERED=1','--setenv=PYTHONDONTWRITEBYTECODE=1','/usr/bin/python3',str(root/'controller.py')]
(root/'launch.json').write_text(json.dumps({'command':command,'ttis_sha':SHA,'disk_free_at_launch':shutil.disk_usage(root).free},indent=2)+'\n')
subprocess.run(command,check=True,capture_output=True,text=True)
print(subprocess.check_output(['systemctl','--user','show','qwen38-image-startup-bfp8-v7-20261009.service','-p','MainPID','-p','InvocationID','-p','ActiveState'],text=True))
'''
result = remote('10.228.203.98', 'PAYLOAD=' + repr(payload) + '\nSHA=' + repr(SHA) + '\n' + stage_controller)
print(reply['service'])
print(result)
print(json.dumps({'frozen_source': manifest, 'ttis_sha': SHA, 'image_digest': reply['build']['metadata']['containerimage.digest']}))
