# SPDX-FileCopyrightText: © 2026 Tenstorrent AI ULC
# SPDX-License-Identifier: Apache-2.0

"""Full tensor-parallel Qwen3-32B causal LM on the optimized TP=4 stack.

Decoder layers exchange the selected BF16 hidden-width fracture directly.  The
only model-boundary gather is the terminal RMSNorm gather; the LM head remains
vocabulary-sharded for canonical split sampling.
"""

from __future__ import annotations

import json
import math
import os
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from pathlib import Path

import torch
from loguru import logger
from safetensors import safe_open
from transformers import AutoConfig

import ttnn
from models.autoports.qwen_qwen3_32b.tt.functional_decoder import EMITTED_BATCH, HF_MODEL
from models.autoports.qwen_qwen3_32b.tt.multichip_decoder import (
    PAGE_BLOCK_SIZE,
    TARGET_MESH_SHAPE,
    TP_DEGREE,
    MultichipDecoder,
    _paged_prefill_capacity,
    _replicated_tensor,
    _tp_tensor,
)
from models.autoports.qwen_qwen3_32b.tt.optimized_decoder import (
    DecodePositionBuffers,
    _compute_config,
    _core_grid_for_tiles,
    _dram_matmul_program_config,
    _dram_sharded_memory_config,
    _matmul_output_memory_config,
    _width_sharded_memory_config,
)
from models.common.modules.sampling.sampling_1d import Sampling1D


CHECKPOINT_REVISION = "9216db5781bf21249d130ec9da846c4624c16137"
DEFAULT_CHECKPOINT = (
    Path("/home/mvasiljevic/hf-cache/models--Qwen--Qwen3-32B/snapshots") / CHECKPOINT_REVISION
)
DECODER_WEIGHT_SUFFIXES = (
    "input_layernorm.weight",
    "post_attention_layernorm.weight",
    "self_attn.q_proj.weight",
    "self_attn.k_proj.weight",
    "self_attn.v_proj.weight",
    "self_attn.o_proj.weight",
    "self_attn.q_norm.weight",
    "self_attn.k_norm.weight",
    "mlp.gate_proj.weight",
    "mlp.up_proj.weight",
    "mlp.down_proj.weight",
)


def resolve_checkpoint_dir(checkpoint_dir: str | os.PathLike | None = None) -> Path:
    candidate = checkpoint_dir or os.getenv("QWEN3_32B_REAL_WEIGHT_DIR") or DEFAULT_CHECKPOINT
    path = Path(candidate).expanduser().resolve()
    required = (path / "config.json", path / "model.safetensors.index.json")
    if not all(item.is_file() for item in required):
        raise FileNotFoundError(
            f"Qwen3-32B checkpoint is incomplete at {path}; expected config.json and "
            "model.safetensors.index.json. Set QWEN3_32B_REAL_WEIGHT_DIR explicitly."
        )
    return path


class CheckpointReader:
    """Read requested safetensor keys while keeping host memory layer-bounded."""

    def __init__(self, checkpoint_dir: Path):
        self.path = Path(checkpoint_dir)
        index = json.loads((self.path / "model.safetensors.index.json").read_text())
        self.weight_map = index["weight_map"]

    def read(self, keys: Iterable[str]) -> dict[str, torch.Tensor]:
        keys_by_shard: dict[str, list[str]] = {}
        for key in keys:
            try:
                shard = self.weight_map[key]
            except KeyError as error:
                raise KeyError(f"checkpoint does not contain {key!r}") from error
            keys_by_shard.setdefault(shard, []).append(key)
        tensors: dict[str, torch.Tensor] = {}
        for shard, shard_keys in keys_by_shard.items():
            with safe_open(self.path / shard, framework="pt", device="cpu") as handle:
                for key in shard_keys:
                    tensors[key] = handle.get_tensor(key).to(torch.bfloat16)
        return tensors

    def read_layer(self, layer_idx: int) -> dict[str, torch.Tensor]:
        prefix = f"model.layers.{layer_idx}."
        return self.read(prefix + suffix for suffix in DECODER_WEIGHT_SUFFIXES)


@dataclass
class CacheState:
    kv_cache: list[tuple[ttnn.Tensor, ttnn.Tensor]]
    page_table: ttnn.Tensor
    page_table_host: torch.Tensor
    prompt_lens: list[int]
    positions: torch.Tensor
    active_mask: torch.Tensor


def _dtype_from_name(name: str):
    names = {
        "bfp4": ttnn.bfloat4_b,
        "bfloat4_b": ttnn.bfloat4_b,
        "bfp8": ttnn.bfloat8_b,
        "bfloat8_b": ttnn.bfloat8_b,
        "bf16": ttnn.bfloat16,
        "bfloat16": ttnn.bfloat16,
    }
    try:
        return names[name.lower()]
    except KeyError as error:
        raise ValueError(f"unsupported LM-head dtype {name!r}; choose bfp4, bfp8, or bf16") from error


def _canonical_dtype_name(name: str) -> str:
    aliases = {
        "bfp4": "bfp4",
        "bfloat4_b": "bfp4",
        "bfp8": "bfp8",
        "bfloat8_b": "bfp8",
        "bf16": "bf16",
        "bfloat16": "bf16",
    }
    try:
        return aliases[name.lower()]
    except KeyError as error:
        raise ValueError(f"unsupported LM-head dtype {name!r}") from error


def _fidelity_from_name(name: str):
    names = {
        "lofi": ttnn.MathFidelity.LoFi,
        "hifi2": ttnn.MathFidelity.HiFi2,
        "hifi3": ttnn.MathFidelity.HiFi3,
        "hifi4": ttnn.MathFidelity.HiFi4,
    }
    try:
        return names[name.lower()]
    except KeyError as error:
        raise ValueError(f"unsupported LM-head fidelity {name!r}") from error


def _canonical_fidelity_name(name: str) -> str:
    names = {"lofi": "LoFi", "hifi2": "HiFi2", "hifi3": "HiFi3", "hifi4": "HiFi4"}
    try:
        return names[name.lower()]
    except KeyError as error:
        raise ValueError(f"unsupported LM-head fidelity {name!r}") from error


def lm_head_experiment_plan(
    *,
    hidden_size: int,
    padded_local_vocab_size: int,
    target_cores: int,
    in0_block_w: int,
    weight_dtype: str,
    fidelity: str,
    dram_readers: int,
) -> dict:
    """Make the selected LM-head topology and its rejected alternatives explicit."""

    n_tiles = padded_local_vocab_size // 32
    per_core_tiles = math.ceil(n_tiles / target_cores)
    return {
        "shape": [EMITTED_BATCH, hidden_size, padded_local_vocab_size],
        "weight_dtype": weight_dtype,
        "fidelity": fidelity,
        "target_cores": target_cores,
        "in0_block_w": in0_block_w,
        "dram_readers": dram_readers,
        "output_subblock": [1, max(1, math.gcd(per_core_tiles, 4))],
        "selected": "20-core DRAM width-sharded vocab projection",
        "rejected": [
            "80-core projection: higher multicast/static-CB cost in focused benchmark",
            "full-vocabulary gather before sampling: unnecessary host/CCL boundary",
        ],
    }


class Qwen3FullModel:
    """Complete HF causal-LM path on the fixed 1x4 Blackhole mesh."""

    def __init__(
        self,
        *,
        mesh_device,
        config,
        checkpoint_dir: Path,
        layers: list[MultichipDecoder],
        embedding_weight,
        final_norm_weight,
        lm_head_weight,
        lm_head_dtype,
        lm_head_dtype_name: str,
        lm_head_local_vocab: int,
        lm_head_padded_local_vocab: int,
        max_seq_len: int,
        lm_head_target_cores: int,
        lm_head_in0_block_w: int,
        lm_head_fidelity_name: str,
    ):
        self.mesh_device = mesh_device
        self.config = config
        self.checkpoint_dir = checkpoint_dir
        self.layers = layers
        self.embedding_weight = embedding_weight
        self.final_norm_weight = final_norm_weight
        self.lm_head_weight = lm_head_weight
        self.lm_head_dtype = lm_head_dtype
        self.lm_head_dtype_name = lm_head_dtype_name
        self.local_vocab_size = lm_head_local_vocab
        self.padded_local_vocab_size = lm_head_padded_local_vocab
        self.max_seq_len = max_seq_len
        self.lm_head_target_cores = lm_head_target_cores
        self.lm_head_in0_block_w = lm_head_in0_block_w
        self.lm_head_fidelity_name = lm_head_fidelity_name
        self.batch = EMITTED_BATCH
        self.page_block_size = PAGE_BLOCK_SIZE
        self.paged_prefill_capacity = _paged_prefill_capacity(self.max_seq_len, self.page_block_size)
        self.vocab_size = int(config.vocab_size)
        self.hidden_size = int(config.hidden_size)
        self.local_hidden_size = self.hidden_size // TP_DEGREE
        self._build_terminal_configs()
        sampling_kwargs = dict(
            vocab_size=self.vocab_size,
            mesh_device=mesh_device,
            tt_ccl=layers[0].tt_ccl,
            max_batch_size=self.batch,
            pad_to_power_of_2=True,
        )
        self.sampling = Sampling1D(max_top_k=32, allow_force_argmax=False, **sampling_kwargs)
        # Greedy uses Sampling1D's exact on-device argmax path. The alternative
        # tiled candidate path is exact too, but its local TopK dominates the
        # reduced token-out profile; retain it only for non-greedy sampling.
        self.greedy_sampling = Sampling1D(max_top_k=32, allow_force_argmax=True, **sampling_kwargs)

    @classmethod
    def from_checkpoint(
        cls,
        *,
        mesh_device,
        checkpoint_dir: str | os.PathLike | None = None,
        max_seq_len: int = 20672,
        override_num_layers: int | None = None,
        lm_head_dtype: str = "bfp8",
        lm_head_target_cores: int = 20,
        lm_head_in0_block_w: int = 2,
        lm_head_fidelity: str = "hifi2",
    ) -> "Qwen3FullModel":
        checkpoint = resolve_checkpoint_dir(checkpoint_dir)
        config = AutoConfig.from_pretrained(checkpoint, local_files_only=True, trust_remote_code=True)
        config._attn_implementation = "eager"
        mesh_shape = tuple(int(value) for value in mesh_device.shape)
        if mesh_shape != TARGET_MESH_SHAPE or mesh_device.get_num_devices() != TP_DEGREE:
            raise ValueError(
                f"{HF_MODEL} full model requires the complete 1x4 mesh, got {mesh_shape} "
                f"with {mesh_device.get_num_devices()} devices"
            )
        if max_seq_len < 1 or max_seq_len > int(config.max_position_embeddings):
            raise ValueError(f"max_seq_len must be in [1,{config.max_position_embeddings}], got {max_seq_len}")
        layer_count = int(config.num_hidden_layers) if override_num_layers is None else int(override_num_layers)
        if not 1 <= layer_count <= int(config.num_hidden_layers):
            raise ValueError(f"override_num_layers must be in [1,{config.num_hidden_layers}], got {layer_count}")
        if lm_head_target_cores not in (20, 80):
            raise ValueError("lm_head_target_cores must be 20 or 80")

        canonical_dtype = _canonical_dtype_name(lm_head_dtype)
        canonical_fidelity = _canonical_fidelity_name(lm_head_fidelity)
        resolved_lm_dtype = _dtype_from_name(canonical_dtype)
        _fidelity_from_name(canonical_fidelity)
        reader = CheckpointReader(checkpoint)
        layers: list[MultichipDecoder] = []
        shared_rotary = None
        shared_tt_ccl = None
        shared_decode_collective_buffers = None
        for layer_idx in range(layer_count):
            logger.info(f"Loading Qwen3-32B TT decoder layer {layer_idx + 1}/{layer_count}")
            state = reader.read_layer(layer_idx)
            layer = MultichipDecoder.from_state_dict(
                state,
                hf_config=config,
                layer_idx=layer_idx,
                mesh_device=mesh_device,
                max_cache_len=max_seq_len,
                precision_policy="all_bfp4_lofi",
                ccl_payload_dtype=ttnn.bfloat16,
                use_persistent_decode_collectives=True,
                use_packed_mlp=True,
                packed_mlp_split_layout="dram",
                keep_decode_output_sharded=True,
                residual_contract="sharded",
                shared_rotary_tensors=shared_rotary,
                shared_tt_ccl=shared_tt_ccl,
                shared_decode_collective_buffers=shared_decode_collective_buffers,
            )
            if shared_rotary is None:
                shared_rotary = (
                    layer.rotary_cos,
                    layer.rotary_sin,
                    layer.rotary_cos_row_major,
                    layer.rotary_sin_row_major,
                )
                shared_tt_ccl = layer.tt_ccl
                shared_decode_collective_buffers = (
                    layer._decode_ag_persistent_buffers,
                    layer._decode_rs_persistent_buffers,
                    layer._decode_fused_rs_persistent_buffers,
                )
            layers.append(layer)
            del state
        first_layer = layers[0]
        for layer in layers[1:]:
            pools_match = (
                layer._decode_ag_persistent_buffers is first_layer._decode_ag_persistent_buffers
                and layer._decode_rs_persistent_buffers is first_layer._decode_rs_persistent_buffers
                and layer._decode_fused_rs_persistent_buffers is first_layer._decode_fused_rs_persistent_buffers
            )
            if not pools_match:
                raise RuntimeError("all decoder layers must share one persistent CCL double-buffer pool")

        terminal = reader.read(("model.embed_tokens.weight", "model.norm.weight", "lm_head.weight"))
        embedding_host = terminal["model.embed_tokens.weight"]
        embedding_weight = ttnn.from_torch(
            embedding_host.contiguous(),
            dtype=ttnn.bfloat16,
            layout=ttnn.ROW_MAJOR_LAYOUT,
            device=mesh_device,
            memory_config=ttnn.DRAM_MEMORY_CONFIG,
            mesh_mapper=ttnn.ShardTensorToMesh(mesh_device, dim=-1),
        )
        final_norm_weight = _replicated_tensor(
            terminal["model.norm.weight"], mesh_device=mesh_device, dtype=ttnn.bfloat16
        )
        vocab_size = int(config.vocab_size)
        if vocab_size % TP_DEGREE:
            raise ValueError(f"vocab_size={vocab_size} must divide TP={TP_DEGREE}")
        local_vocab = vocab_size // TP_DEGREE
        dram_grid = mesh_device.dram_grid_size()
        dram_banks = int(dram_grid.x) * int(dram_grid.y)
        vocab_alignment = math.lcm(32 * dram_banks, 32 * lm_head_target_cores)
        padded_local_vocab = math.ceil(local_vocab / vocab_alignment) * vocab_alignment
        lm_chunks = terminal["lm_head.weight"].T.chunk(TP_DEGREE, dim=-1)
        padded_chunks = [
            torch.nn.functional.pad(chunk, (0, padded_local_vocab - local_vocab)) for chunk in lm_chunks
        ]
        lm_head_host = torch.cat(padded_chunks, dim=-1)
        lm_head_weight = _tp_tensor(
            lm_head_host,
            shard_dim=-1,
            mesh_device=mesh_device,
            dtype=resolved_lm_dtype,
            memory_config=_dram_sharded_memory_config(mesh_device, int(config.hidden_size), padded_local_vocab),
        )
        return cls(
            mesh_device=mesh_device,
            config=config,
            checkpoint_dir=checkpoint,
            layers=layers,
            embedding_weight=embedding_weight,
            final_norm_weight=final_norm_weight,
            lm_head_weight=lm_head_weight,
            lm_head_dtype=resolved_lm_dtype,
            lm_head_dtype_name=canonical_dtype,
            lm_head_local_vocab=local_vocab,
            lm_head_padded_local_vocab=padded_local_vocab,
            max_seq_len=max_seq_len,
            lm_head_target_cores=lm_head_target_cores,
            lm_head_in0_block_w=lm_head_in0_block_w,
            lm_head_fidelity_name=canonical_fidelity,
        )

    def _build_terminal_configs(self) -> None:
        self.lm_head_grid = _core_grid_for_tiles(
            self.hidden_size // 32,
            self.padded_local_vocab_size // 32,
            target_cores=self.lm_head_target_cores,
            device=self.mesh_device,
        )
        dram_grid = self.mesh_device.dram_grid_size()
        self.lm_head_experiment = lm_head_experiment_plan(
            hidden_size=self.hidden_size,
            padded_local_vocab_size=self.padded_local_vocab_size,
            target_cores=self.lm_head_grid.num_cores,
            in0_block_w=self.lm_head_in0_block_w,
            weight_dtype=self.lm_head_dtype_name,
            fidelity=self.lm_head_fidelity_name,
            dram_readers=int(dram_grid.x) * int(dram_grid.y),
        )
        self.lm_head_compute_config = _compute_config(
            self.mesh_device, _fidelity_from_name(self.lm_head_fidelity_name)
        )
        self.lm_head_decode_program_config = _dram_matmul_program_config(
            self.batch,
            self.hidden_size,
            self.padded_local_vocab_size,
            self.lm_head_grid,
            in0_block_w_limit=self.lm_head_in0_block_w,
        )
        if int(self.lm_head_decode_program_config.in0_block_w) != self.lm_head_in0_block_w:
            raise RuntimeError(
                f"LM-head requested exact in0_block_w={self.lm_head_in0_block_w}, but the program resolved "
                f"{self.lm_head_decode_program_config.in0_block_w}"
            )
        self.lm_head_decode_input_memory_config = _width_sharded_memory_config(
            self.batch, self.hidden_size, self.lm_head_grid
        )
        self.lm_head_decode_output_memory_config = _matmul_output_memory_config(
            self.batch, self.padded_local_vocab_size, self.lm_head_grid, self.mesh_device
        )

    @property
    def num_layers(self) -> int:
        return len(self.layers)

    def policy_summary(self) -> dict:
        return {
            "checkpoint": str(self.checkpoint_dir),
            "revision": CHECKPOINT_REVISION,
            "mesh": list(TARGET_MESH_SHAPE),
            "layers": self.num_layers,
            "max_seq_len": self.max_seq_len,
            "decoder_precision": "all_bfp4_lofi",
            "activation_norm_residual": "BF16",
            "kv_cache": "BFP8_B",
            "ccl": "BF16 Ring; stack-shared TT-CCL semaphores and decode double buffers",
            "inter_layer_residual": "BF16 TP hidden shard, 1280 channels/device; decode L1 width-sharded",
            "embedding": "BF16 hidden-width sharded",
            "prefill": "single active fixed slot; page-64 padding; <=512-token TP4 chunks with absolute RoPE",
            "lm_head": self.lm_head_experiment,
            "sampling": "Sampling1D device argmax for greedy; local top-32 then 128-candidate gather otherwise",
        }

    def allocate_kv_cache(self) -> list[tuple[ttnn.Tensor, ttnn.Tensor]]:
        return [
            layer.allocate_kv_cache(max_cache_len=self.max_seq_len, paged=True)
            for layer in self.layers
        ]

    def allocate_page_table(self) -> tuple[torch.Tensor, ttnn.Tensor]:
        blocks_per_user = math.ceil(self.max_seq_len / self.page_block_size)
        host = torch.arange(self.batch * blocks_per_user, dtype=torch.int32).reshape(
            self.batch, blocks_per_user
        )
        device = _replicated_tensor(
            host,
            mesh_device=self.mesh_device,
            dtype=ttnn.int32,
            layout=ttnn.ROW_MAJOR_LAYOUT,
        )
        return host, device

    def allocate_cache_state(self) -> CacheState:
        page_table_host, page_table = self.allocate_page_table()
        return CacheState(
            kv_cache=self.allocate_kv_cache(),
            page_table=page_table,
            page_table_host=page_table_host,
            prompt_lens=[0] * self.batch,
            positions=torch.full((self.batch,), -1, dtype=torch.int32),
            active_mask=torch.zeros(self.batch, dtype=torch.bool),
        )

    def reset_kv_cache(self, kv_cache) -> None:
        self._validate_kv_cache(kv_cache)
        for key_cache, value_cache in kv_cache:
            ttnn.fill(key_cache, 0, memory_config=key_cache.memory_config(), output_tensor=key_cache)
            ttnn.fill(value_cache, 0, memory_config=value_cache.memory_config(), output_tensor=value_cache)

    def _validate_kv_cache(self, kv_cache) -> None:
        if not isinstance(kv_cache, list) or len(kv_cache) != self.num_layers:
            raise ValueError(f"kv_cache must contain one K/V pair for each of {self.num_layers} layers")
        if any(not isinstance(pair, (tuple, list)) or len(pair) != 2 for pair in kv_cache):
            raise ValueError("each kv_cache entry must be a (key_cache, value_cache) pair")

    def create_token_buffer(self, tokens: Sequence[int] | torch.Tensor | None = None):
        token_buffer = _replicated_tensor(
            torch.zeros((1, 1, 1, self.batch), dtype=torch.int32),
            mesh_device=self.mesh_device,
            dtype=ttnn.uint32,
            layout=ttnn.ROW_MAJOR_LAYOUT,
        )
        if tokens is not None:
            self.update_token_buffer(token_buffer, tokens)
        return token_buffer

    def update_token_buffer(self, token_buffer, tokens: Sequence[int] | torch.Tensor) -> None:
        values = torch.as_tensor(tokens, dtype=torch.int32).flatten()
        if values.numel() > self.batch:
            raise ValueError(f"at most {self.batch} decode tokens are supported")
        host_values = torch.zeros((self.batch,), dtype=torch.int32)
        host_values[: values.numel()] = values
        host = ttnn.from_torch(
            host_values.reshape(1, 1, 1, self.batch),
            dtype=ttnn.uint32,
            layout=ttnn.ROW_MAJOR_LAYOUT,
            mesh_mapper=ttnn.ReplicateTensorToMesh(self.mesh_device),
        )
        ttnn.copy_host_to_device_tensor(host, token_buffer)

    def allocate_position_buffers(self, positions) -> DecodePositionBuffers:
        return self.layers[0].allocate_decode_position_buffers(positions)

    def update_position_buffers(self, buffers: DecodePositionBuffers, positions, *, force: bool = False):
        return self.layers[0].prepare_decode_position_buffers(buffers, positions, force=force)

    def _embed_decode(self, token_buffer):
        hidden = ttnn.embedding(
            token_buffer,
            self.embedding_weight,
            layout=ttnn.TILE_LAYOUT,
            dtype=ttnn.bfloat16,
            memory_config=self.layers[0].local_residual_memory_config,
        )
        return ttnn.reshape(hidden, [1, self.batch, 1, self.local_hidden_size])

    def _embed_prefill(self, prompt_tokens: torch.Tensor):
        prompt_tokens = prompt_tokens.to(torch.int32).flatten()
        seq_len = int(prompt_tokens.numel())
        tt_tokens = _replicated_tensor(
            prompt_tokens.reshape(1, 1, 1, seq_len),
            mesh_device=self.mesh_device,
            dtype=ttnn.uint32,
            layout=ttnn.ROW_MAJOR_LAYOUT,
        )
        hidden = ttnn.embedding(
            tt_tokens,
            self.embedding_weight,
            layout=ttnn.TILE_LAYOUT,
            dtype=ttnn.bfloat16,
            memory_config=ttnn.DRAM_MEMORY_CONFIG,
        )
        ttnn.deallocate(tt_tokens, True)
        return ttnn.reshape(hidden, [1, 1, seq_len, self.local_hidden_size])

    def _temporary_prefill_page_table(self, page_table_host, *, slot: int, prompt_len: int):
        blocks = math.ceil(prompt_len / self.page_block_size)
        row = page_table_host[slot, :blocks].to(torch.int32).reshape(1, blocks)
        return _replicated_tensor(
            row,
            mesh_device=self.mesh_device,
            dtype=ttnn.int32,
            layout=ttnn.ROW_MAJOR_LAYOUT,
        )

    def _temporary_prefill_chunk_page_table(
        self,
        page_table_host,
        *,
        slot: int,
        chunk_start: int,
        chunk_len: int,
    ):
        if chunk_start % self.page_block_size or chunk_len % self.page_block_size:
            raise ValueError(
                f"prefill chunks must be page aligned to {self.page_block_size}: "
                f"start={chunk_start}, length={chunk_len}"
            )
        first_block = chunk_start // self.page_block_size
        num_blocks = chunk_len // self.page_block_size
        row = page_table_host[slot, first_block : first_block + num_blocks].to(torch.int32).reshape(1, -1)
        if int(row.shape[1]) != num_blocks:
            raise ValueError(f"page table does not cover chunk [{chunk_start},{chunk_start + chunk_len})")
        return _replicated_tensor(
            row,
            mesh_device=self.mesh_device,
            dtype=ttnn.int32,
            layout=ttnn.ROW_MAJOR_LAYOUT,
        )

    def validate_host_page_table(self, page_table_host, kv_cache, *, slot_positions) -> None:
        self._validate_kv_cache(kv_cache)
        host = torch.as_tensor(page_table_host, dtype=torch.int32)
        if host.ndim != 2:
            raise ValueError(f"page_table must be rank 2, got {tuple(host.shape)}")
        num_blocks = int(kv_cache[0][0].shape[0])
        for slot, position in slot_positions:
            if slot < 0 or slot >= self.batch or slot >= host.shape[0]:
                raise ValueError(f"page_table has no fixed slot {slot}; shape is {tuple(host.shape)}")
            if position < 0 or position >= self.max_seq_len:
                raise ValueError(f"position must be in [0,{self.max_seq_len}), got {position}")
            required_blocks = position // self.page_block_size + 1
            if host.shape[1] < required_blocks:
                raise ValueError(
                    f"page_table slot {slot} has {host.shape[1]} blocks but position {position} "
                    f"requires {required_blocks}"
                )
            ids = host[slot, :required_blocks]
            if torch.any(ids < 0) or torch.any(ids >= num_blocks):
                raise ValueError(f"page_table slot {slot} contains physical IDs outside [0,{num_blocks})")

    def _terminal_norm(self, hidden_states):
        shape = tuple(hidden_states.shape)
        rows = math.prod(shape[1:-1])
        local = ttnn.reshape(hidden_states, [1, 1, rows, self.local_hidden_size])
        gathered = self.layers[0]._all_gather_hidden(
            local,
            memory_config=ttnn.DRAM_MEMORY_CONFIG,
            use_persistent_decode_buffer=False,
        )
        ttnn.deallocate(hidden_states, True)
        normalized = ttnn.rms_norm(
            gathered,
            epsilon=float(self.config.rms_norm_eps),
            weight=self.final_norm_weight,
            compute_kernel_config=self.layers[0].norm_compute_config,
            memory_config=ttnn.DRAM_MEMORY_CONFIG,
        )
        ttnn.deallocate(gathered, True)
        return normalized

    def _lm_head_chunk(self, normalized):
        rows = int(normalized.shape[-2])
        if not 1 <= rows <= 32:
            raise ValueError(f"LM-head chunk rows must be in [1,32], got {rows}")
        padded_rows = 32 * math.ceil(rows / 32)
        input_memory = _width_sharded_memory_config(padded_rows, self.hidden_size, self.lm_head_grid)
        output_memory = _matmul_output_memory_config(
            padded_rows, self.padded_local_vocab_size, self.lm_head_grid, self.mesh_device
        )
        program = (
            self.lm_head_decode_program_config
            if rows == self.batch
            else _dram_matmul_program_config(
                rows,
                self.hidden_size,
                self.padded_local_vocab_size,
                self.lm_head_grid,
                in0_block_w_limit=self.lm_head_in0_block_w,
            )
        )
        lm_input = ttnn.to_memory_config(normalized, input_memory)
        if lm_input is not normalized:
            ttnn.deallocate(normalized, True)
        padded_logits = ttnn.matmul(
            lm_input,
            self.lm_head_weight,
            dtype=ttnn.bfloat16,
            program_config=program,
            compute_kernel_config=self.lm_head_compute_config,
            memory_config=output_memory,
        )
        logits = ttnn.slice(
            padded_logits,
            [0, 0, 0, 0],
            [1, 1, rows, self.local_vocab_size],
            memory_config=ttnn.DRAM_MEMORY_CONFIG,
        )
        ttnn.deallocate(lm_input, True)
        ttnn.deallocate(padded_logits, True)
        return logits

    def _lm_head_forward(self, normalized):
        rows = int(normalized.shape[-2])
        if rows <= 32:
            return self._lm_head_chunk(normalized)
        chunks = []
        for start in range(0, rows, 32):
            end = min(start + 32, rows)
            chunk = ttnn.slice(
                normalized,
                [0, 0, start, 0],
                [1, 1, end, self.hidden_size],
                memory_config=ttnn.DRAM_MEMORY_CONFIG,
            )
            chunks.append(self._lm_head_chunk(chunk))
        ttnn.deallocate(normalized, True)
        logits = ttnn.concat(chunks, dim=-2, memory_config=ttnn.DRAM_MEMORY_CONFIG)
        for chunk in chunks:
            ttnn.deallocate(chunk, True)
        return logits

    @staticmethod
    def _position_marker(buffers: DecodePositionBuffers):
        return buffers.current_pos

    def _advance_positions_device(self, buffers: DecodePositionBuffers) -> None:
        ttnn.plus_one(buffers.update_indices, skip_negative_entries=True)
        ttnn.plus_one(buffers.rope_index)
        ttnn.embedding(
            buffers.rope_index,
            self.layers[0].rotary_cos_row_major,
            layout=ttnn.TILE_LAYOUT,
            dtype=ttnn.bfloat16,
            memory_config=buffers.cos_embedding_output.memory_config(),
            output_tensor=buffers.cos_embedding_output,
        )
        ttnn.embedding(
            buffers.rope_index,
            self.layers[0].rotary_sin_row_major,
            layout=ttnn.TILE_LAYOUT,
            dtype=ttnn.bfloat16,
            memory_config=buffers.sin_embedding_output.memory_config(),
            output_tensor=buffers.sin_embedding_output,
        )
        buffers.current_pos = tuple(value + 1 if value >= 0 else -1 for value in buffers.current_pos)

    def decode_forward_from_device_inputs(
        self,
        token_buffer,
        *,
        position_buffers: DecodePositionBuffers,
        page_table,
        kv_cache,
        advance_positions: bool,
    ):
        """Device-only token-to-vocabulary-shard body used by trace capture."""

        self._validate_kv_cache(kv_cache)
        hidden = self._embed_decode(token_buffer)
        marker = self._position_marker(position_buffers)
        for layer, (key_cache, value_cache) in zip(self.layers, kv_cache):
            next_hidden = layer.decode_forward(
                hidden,
                key_cache,
                value_cache,
                current_pos=marker,
                position_buffers=position_buffers,
                page_table=page_table,
            )
            ttnn.deallocate(hidden, True)
            hidden = next_hidden
        normalized = self._terminal_norm(hidden)
        logits = self._lm_head_forward(normalized)
        if advance_positions:
            self._advance_positions_device(position_buffers)
        return logits

    def prefill_user(
        self,
        prompt_tokens: torch.Tensor,
        *,
        slot: int,
        page_table_host,
        kv_cache,
        return_all_logits: bool = False,
    ):
        """Prefill one fixed slot with bounded, page-aligned internal chunks."""

        self._validate_kv_cache(kv_cache)
        prompt_tokens = torch.as_tensor(prompt_tokens, dtype=torch.int64).flatten()
        prompt_len = int(prompt_tokens.numel())
        if slot < 0 or slot >= self.batch:
            raise ValueError(f"slot must be in [0,{self.batch}), got {slot}")
        if prompt_len < 1 or prompt_len > self.max_seq_len:
            raise ValueError(f"prompt length must be in [1,{self.max_seq_len}], got {prompt_len}")
        self.validate_host_page_table(page_table_host, kv_cache, slot_positions=((slot, prompt_len - 1),))
        max_prefill_chunk_size = 512
        padded_prompt_len = prompt_len
        if prompt_len > max_prefill_chunk_size:
            padded_prompt_len = self.page_block_size * math.ceil(prompt_len / self.page_block_size)
        if padded_prompt_len > self.paged_prefill_capacity:
            raise ValueError(
                f"page-aligned prompt length {padded_prompt_len} exceeds paged prefill capacity "
                f"{self.paged_prefill_capacity}"
            )
        if padded_prompt_len != prompt_len:
            prompt_tokens = torch.nn.functional.pad(
                prompt_tokens, (0, padded_prompt_len - prompt_len), value=0
            )
        fill_page_table = self._temporary_prefill_page_table(
            page_table_host, slot=slot, prompt_len=padded_prompt_len
        )
        selected_chunks = []
        selected = None
        for chunk_start in range(0, padded_prompt_len, max_prefill_chunk_size):
            chunk_end = min(chunk_start + max_prefill_chunk_size, padded_prompt_len)
            chunk_len = chunk_end - chunk_start
            chunk_page_table = None
            if padded_prompt_len > max_prefill_chunk_size:
                chunk_page_table = self._temporary_prefill_chunk_page_table(
                    page_table_host,
                    slot=slot,
                    chunk_start=chunk_start,
                    chunk_len=chunk_len,
                )
            hidden = self._embed_prefill(prompt_tokens[chunk_start:chunk_end])
            for layer, (key_cache, value_cache) in zip(self.layers, kv_cache):
                next_hidden = layer.prefill_forward(
                    hidden,
                    key_cache,
                    value_cache,
                    page_table=fill_page_table,
                    chunk_page_table=chunk_page_table,
                    chunk_start_idx=chunk_start,
                    prefill_user_id=slot,
                )
                ttnn.deallocate(hidden, True)
                hidden = next_hidden
            logical_chunk_len = max(0, min(chunk_end, prompt_len) - chunk_start)
            if return_all_logits and logical_chunk_len:
                selected_view = ttnn.slice(
                    hidden,
                    [0, 0, 0, 0],
                    [1, 1, logical_chunk_len, self.local_hidden_size],
                )
                selected_chunks.append(
                    ttnn.clone(
                        selected_view,
                        dtype=ttnn.bfloat16,
                        memory_config=ttnn.DRAM_MEMORY_CONFIG,
                    )
                )
                ttnn.deallocate(selected_view, True)
            elif not return_all_logits and chunk_start < prompt_len <= chunk_end:
                last_token_in_chunk = prompt_len - chunk_start - 1
                selected_view = ttnn.slice(
                    hidden,
                    [0, 0, last_token_in_chunk, 0],
                    [1, 1, last_token_in_chunk + 1, self.local_hidden_size],
                )
                selected = ttnn.clone(
                    selected_view,
                    dtype=ttnn.bfloat16,
                    memory_config=ttnn.DRAM_MEMORY_CONFIG,
                )
                ttnn.deallocate(selected_view, True)
            ttnn.deallocate(hidden, True)
            if chunk_page_table is not None:
                ttnn.deallocate(chunk_page_table, True)
        ttnn.deallocate(fill_page_table, True)
        if return_all_logits:
            selected = (
                selected_chunks[0]
                if len(selected_chunks) == 1
                else ttnn.concat(selected_chunks, dim=2, memory_config=ttnn.DRAM_MEMORY_CONFIG)
            )
            if len(selected_chunks) > 1:
                for chunk in selected_chunks:
                    ttnn.deallocate(chunk, True)
        if selected is None:
            raise RuntimeError("prefill did not select any logical output tokens")
        normalized = self._terminal_norm(selected)
        return self._lm_head_forward(normalized)

    def compose_vocab_logits(self, logits) -> torch.Tensor:
        """Explicit host-compatibility/readiness boundary; never used by traced token-out."""

        shards = [ttnn.to_torch(tensor).to(torch.float32) for tensor in ttnn.get_device_tensors(logits)]
        return torch.cat(shards, dim=-1)[..., : self.vocab_size]

    def fallback_audit(self) -> dict:
        return {
            "decoder": "MultichipDecoder selected TP4 path only; no superclass runtime forward",
            "inter_layer": "TP-fractured residual consumed directly; zero layer-boundary collectives",
            "embedding": "device embedding over hidden-sharded BF16 weight",
            "final_norm": "single terminal Ring all-gather then device RMSNorm",
            "lm_head": "device DRAM-sharded vocabulary projection; no full-vocabulary all-gather",
            "sampling": "Sampling1D exact device argmax for greedy; candidate reduction for non-greedy",
            "host_logits": "only compose_vocab_logits compatibility/readiness boundary",
            "cache": "paged device cache supplied explicitly or generator-owned",
            "reset": "in-place cache fill; resident weights and serving buffers are retained",
        }


__all__ = [
    "CHECKPOINT_REVISION",
    "CacheState",
    "CheckpointReader",
    "Qwen3FullModel",
    "lm_head_experiment_plan",
    "resolve_checkpoint_dir",
]
