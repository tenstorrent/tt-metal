# SPDX-FileCopyrightText: © 2026 Tenstorrent AI ULC
# SPDX-License-Identifier: Apache-2.0

"""Full-model public contracts plus opt-in exact-weight hardware smokes."""

from __future__ import annotations

import inspect
import os
import time

import pytest
import torch

import ttnn
from models.autoports.qwen_qwen3_32b.tt.generator import Qwen3Generator, SamplingSettings, build_generator
from models.autoports.qwen_qwen3_32b.tt.model import Qwen3FullModel
from models.autoports.qwen_qwen3_32b.tt.multichip_decoder import (
    MultichipDecoder,
    _paged_prefill_capacity,
    _rotary_table_rows,
)
from models.common.readiness_check.contract import Generator


MODEL_DIR = os.path.dirname(os.path.dirname(__file__))


def test_full_model_readiness_and_no_fallback_source_contracts():
    assert issubclass(Qwen3Generator, Generator)
    assert not Qwen3Generator.__abstractmethods__
    signature = inspect.signature(Qwen3Generator.generate)
    assert "enable_trace" in signature.parameters
    assert "next_input" in signature.parameters
    model_source = inspect.getsource(Qwen3FullModel.decode_forward_from_device_inputs)
    for token in ("to_torch", "argmax", "cpu(", "super()."):
        assert token not in model_source
    generator_source = inspect.getsource(Qwen3Generator.generate)
    assert "_execute_token_out_traces" not in generator_source  # decode_forward owns replay
    capture_source = inspect.getsource(Qwen3Generator._capture_traces)
    assert "advance_positions=True" in capture_source
    prefill_source = inspect.getsource(Qwen3Generator.prefill_forward)
    assert "if kv_cache is None" in prefill_source
    assert "self._ensure_internal_state().kv_cache" in prefill_source
    assert "shared_decode_collective_buffers=shared_decode_collective_buffers" in inspect.getsource(
        Qwen3FullModel.from_checkpoint
    )


def test_generation_context_boundary_contract_without_device():
    generator = object.__new__(Qwen3Generator)
    generator.model = type("Model", (), {"max_seq_len": 128})()
    generator.validate_generation_bounds(128, 1)
    generator.validate_generation_bounds(127, 2)
    generator.validate_generation_bounds(1, 0)
    with pytest.raises(ValueError, match="exceeds context"):
        generator.validate_generation_bounds(128, 2)
    with pytest.raises(ValueError, match="length must be"):
        generator.validate_generation_bounds(0, 1)
    with pytest.raises(ValueError, match="non-negative"):
        generator.validate_generation_bounds(1, -1)


@pytest.mark.parametrize(
    "logical_capacity,expected_paged_capacity",
    [(20671, 20672), (20672, 20672), (513, 576)],
)
def test_nonaligned_paged_prefill_capacity_without_device(
    logical_capacity, expected_paged_capacity
):
    assert _paged_prefill_capacity(logical_capacity, 64) == expected_paged_capacity


@pytest.mark.parametrize(
    "logical_capacity,expected_rows",
    [(20671, 20672), (20672, 20704), (513, 576), (512, 544), (128, 160)],
)
def test_nonaligned_rotary_table_covers_prefill_padding_and_decode_standby(
    logical_capacity, expected_rows
):
    rows = _rotary_table_rows(logical_capacity, 64)
    assert rows == expected_rows
    assert rows % 32 == 0
    assert rows >= _paged_prefill_capacity(logical_capacity, 64)
    assert rows >= logical_capacity + 1


def test_nonaligned_prefill_keeps_logical_and_physical_bounds_separate():
    decoder = object.__new__(MultichipDecoder)
    decoder.max_cache_len = 20671
    decoder.paged_prefill_capacity = 20672
    decoder.page_block_size = 64
    decoder.batch = 32
    assert (
        decoder._validate_prefill_extent(seq_len=192, chunk_start_idx=20480, cache_mode="paged")
        == 20672
    )
    with pytest.raises(ValueError, match="outside cache capacity"):
        decoder._validate_prefill_extent(
            seq_len=192, chunk_start_idx=20480, cache_mode="contiguous"
        )
    decoder._normalize_decode_positions(20670)
    with pytest.raises(ValueError, match=r"\[-1,20671\)"):
        decoder._normalize_decode_positions(20671)


def test_prefill_all_gathers_do_not_consume_persistent_decode_buffers():
    for method in (MultichipDecoder.prefill_forward, MultichipDecoder._prefill_mlp_chunk):
        source = inspect.getsource(method)
        assert "use_persistent_decode_buffer=False" in source


def test_sampler_selection_records_profiled_greedy_and_nongreedy_paths():
    source = inspect.getsource(Qwen3Generator._sample_device)
    assert "greedy_sampling" in source
    assert "decode_forward" in source
    assert "argmax" not in source
    model_source = inspect.getsource(Qwen3FullModel.__init__)
    assert "max_top_k=32" in model_source
    assert "allow_force_argmax=True" in model_source
    assert "local TopK dominates" in model_source


@pytest.mark.skipif(
    os.getenv("QWEN3_32B_RUN_FULL_MODEL_SMOKE") != "1",
    reason="manual exact-weight reduced full-model trace smoke",
)
@pytest.mark.parametrize(
    "device_params",
    [{"fabric_config": ttnn.FabricConfig.FABRIC_1D_RING, "trace_region_size": 200_000_000}],
    indirect=True,
)
@pytest.mark.parametrize("mesh_device", [(1, 4)], indirect=True)
@pytest.mark.timeout(900)
def test_exact_weight_reduced_full_model_trace_and_sampler_contract(mesh_device):
    def mark(phase: str) -> None:
        print(f"FULL_MODEL_SMOKE_PHASE={phase}", flush=True)

    mark("build_generator_begin")
    generator = build_generator(
        MODEL_DIR,
        mesh_device,
        max_seq_len=128,
        override_num_layers=1,
    )
    mark("build_generator_end")
    state = generator._ensure_internal_state()
    mark("cache_state_ready")
    prompt = torch.tensor([[17, 18, 19, 20, 21]], dtype=torch.int64)
    mark("prefill_begin")
    logits = generator.prefill_forward(
        prompt,
        page_table=state.page_table,
        kv_cache=state.kv_cache,
        prompt_lens=[5],
        return_device_logits=True,
        slots=[7],
    )
    ttnn.synchronize_device(mesh_device)
    mark("prefill_end")
    host_prefill_logits = generator.model.compose_vocab_logits(logits).reshape(
        -1, generator.model.vocab_size
    )
    mark("prefill_sampling_begin")
    sampled = generator._sample_prefill_device(logits, settings=SamplingSettings())
    ttnn.synchronize_device(mesh_device)
    mark("prefill_sampling_end")
    ttnn.deallocate(logits, True)
    first = int(generator._read_tokens(sampled, generator.model.batch)[0])
    assert host_prefill_logits[0, first] == torch.max(host_prefill_logits[0])
    print(f"GREEDY_PREFILL_GLOBAL_MAX_TOKEN={first}", flush=True)
    mark("prefill_token_read_end")
    positions = torch.full((32,), -1, dtype=torch.int32)
    positions[7] = 5
    generator._copy_positions(positions)
    generator._copy_tokens(torch.nn.functional.pad(torch.tensor([first]), (7, 24)))
    mark("decode_trace_begin")
    sampled = generator.decode_forward(
        torch.tensor([[first]]),
        torch.tensor([5]),
        page_table=state.page_table,
        kv_cache=state.kv_cache,
        enable_trace=True,
        sampling_settings=SamplingSettings(),
        device_owned_step=True,
        return_device=True,
        slots=[7],
    )
    ttnn.synchronize_device(mesh_device)
    mark("decode_trace_end")
    tokens = generator._read_tokens(sampled, generator.model.batch)
    mark("decode_token_read_end")
    assert 0 <= int(tokens[7]) < generator.model.vocab_size
    host_decode_logits = generator.model.compose_vocab_logits(generator._trace.logits).reshape(
        generator.model.batch, -1
    )
    assert host_decode_logits[7, int(tokens[7])] == torch.max(host_decode_logits[7])
    print(f"GREEDY_DECODE_GLOBAL_MAX_TOKEN={int(tokens[7])}", flush=True)

    # A second replay consumes the first sampled token and advances the same
    # fixed-address position state without any host token/position refresh.
    sampled = generator.decode_forward(
        torch.tensor([[0]]),
        torch.tensor([6]),
        page_table=state.page_table,
        kv_cache=state.kv_cache,
        enable_trace=True,
        sampling_settings=SamplingSettings(),
        device_owned_step=True,
        return_device=True,
        slots=[7],
    )
    ttnn.synchronize_device(mesh_device)
    tokens = generator._read_tokens(sampled, generator.model.batch)
    positions_after = ttnn.to_torch(
        ttnn.get_device_tensors(generator._trace.position_buffers.update_indices)[0]
    ).reshape(-1)
    assert int(positions_after[7]) == 7
    assert generator.trace_counters["model_trace_replays"] == 2
    assert generator.trace_counters["sampling_trace_replays"] == 2
    assert generator.trace_counters["token_input_refreshes"] == 1
    assert generator.trace_counters["position_refreshes"] == 1
    assert generator._trace.sampled_token is generator._trace.token_buffer

    # Both the no-op and changed physical page mappings are explicit. Restore
    # the canonical mapping before teardown so reset behavior remains valid.
    assert not generator.refresh_page_table(state.page_table_host, state.page_table)
    changed_page_table = state.page_table_host.clone()
    changed_page_table[0, 0], changed_page_table[0, 1] = (
        changed_page_table[0, 1].clone(),
        changed_page_table[0, 0].clone(),
    )
    assert generator.refresh_page_table(changed_page_table, state.page_table)
    assert not generator.refresh_page_table(changed_page_table, state.page_table)
    assert generator.refresh_page_table(state.page_table_host, state.page_table)
    print(f"TRACE_EVIDENCE={generator.trace_counters}", flush=True)

    # Serving API smoke: heterogeneous prompt lengths occupy fixed slots and
    # decode leaves every other row inactive. Host logits are requested only
    # through the explicit compatibility mode.
    generator._release_traces()
    mixed_prompt = torch.tensor(
        [[31, 32, 33, 0, 0], [41, 42, 43, 44, 45]],
        dtype=torch.int64,
    )
    mixed_prefill = generator.prefill_forward(
        mixed_prompt,
        page_table=state.page_table,
        kv_cache=state.kv_cache,
        prompt_lens=[3, 5],
        slots=[2, 7],
    )
    assert tuple(mixed_prefill.shape) == (2, 1, generator.model.vocab_size)
    mixed_decode = generator.decode_forward(
        torch.tensor([51, 52]),
        torch.tensor([3, 5]),
        page_table=state.page_table,
        kv_cache=state.kv_cache,
        enable_trace=False,
        host_sampling=True,
        slots=[2, 7],
    )
    assert tuple(mixed_decode.shape) == (2, generator.model.vocab_size)
    print("MIXED_FIXED_SLOT_COMPATIBILITY=pass,slots=2,7,inactive_rows=30", flush=True)
    generator.teardown()


@pytest.mark.skipif(
    os.getenv("QWEN3_32B_RUN_FULL_MODEL_PROFILE") != "1",
    reason="manual exact-weight reduced split-token-out profile",
)
@pytest.mark.parametrize(
    "device_params",
    [{"fabric_config": ttnn.FabricConfig.FABRIC_1D_RING, "trace_region_size": 200_000_000}],
    indirect=True,
)
@pytest.mark.parametrize("mesh_device", [(1, 4)], indirect=True)
@pytest.mark.timeout(900)
def test_exact_weight_reduced_full_model_token_out_profile(mesh_device):
    """Profile only warmed model+selected-greedy replay, with one final sync."""

    from tracy import signpost

    generator = build_generator(
        MODEL_DIR,
        mesh_device,
        max_seq_len=128,
        override_num_layers=1,
    )
    state = generator._ensure_internal_state()
    prompt = torch.tensor([[17, 18, 19, 20, 21]], dtype=torch.int64)
    logits = generator.prefill_forward(
        prompt,
        page_table=state.page_table,
        kv_cache=state.kv_cache,
        prompt_lens=[5],
        return_device_logits=True,
        slots=[0],
    )
    sampled = generator._sample_prefill_device(logits, settings=SamplingSettings())
    ttnn.deallocate(logits, True)
    positions = torch.full((32,), -1, dtype=torch.int32)
    positions[0] = 5
    generator._copy_positions(positions)
    generator._capture_traces(
        kv_cache=state.kv_cache,
        page_table=state.page_table,
        sampling_settings=SamplingSettings(),
    )
    ttnn.synchronize_device(mesh_device)

    # Two replays keep Blackhole's device-profiler buffers below the marker
    # ceiling; the unprofiled full-model run supplies the throughput number.
    replay_count = 2
    signpost("FULL_MODEL_GREEDY_TOKEN_OUT_START")
    started = time.perf_counter()
    for _ in range(replay_count):
        sampled = generator._execute_token_out_traces()
    ttnn.synchronize_device(mesh_device)
    elapsed = time.perf_counter() - started
    signpost("FULL_MODEL_GREEDY_TOKEN_OUT_STOP")
    assert generator._trace.sampled_token is generator._trace.token_buffer
    print(
        "GREEDY_TOKEN_OUT_PROFILE="
        f"replays={replay_count},elapsed_s={elapsed:.6f},t_s_u={replay_count / elapsed:.3f},"
        f"token={int(generator._read_tokens(sampled, 1)[0])},counters={generator.trace_counters}",
        flush=True,
    )
    generator.teardown()
