# SPDX-FileCopyrightText: © 2026 Tenstorrent AI ULC
# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

import torch

from models.common.readiness_check.schema import Reference, ReferenceEntry, load_reference, save_reference


def _entry() -> ReferenceEntry:
    return ReferenceEntry(
        prompt_text="prompt",
        prompt_tokens=torch.tensor([[1, 2]], dtype=torch.int64),
        generated_tokens=torch.tensor([[3]], dtype=torch.int64),
        topk_tokens=torch.tensor([[3, 4]], dtype=torch.int32),
        tf_prompt_len=2,
    )


def test_reference_provenance_round_trips(tmp_path):
    path = tmp_path / "reference.refpt"
    provenance = {
        "revision": "exact-revision",
        "tokenizer_class": "Tokenizer",
        "chat_template_sha256": "template-sha256",
    }

    save_reference(
        Reference(k=2, hf_model_id="model", entries=[_entry()], provenance=provenance),
        path,
    )

    assert load_reference(path).provenance == provenance


def test_legacy_reference_without_provenance_loads(tmp_path):
    path = tmp_path / "legacy.refpt"
    torch.save(
        {
            "format_version": "readiness_v1",
            "k": 2,
            "hf_model_id": "model",
            "token_ids_meta": {},
            "entries": [
                {
                    "prompt_text": "prompt",
                    "prompt_tokens": torch.tensor([[1, 2]], dtype=torch.int64),
                    "generated_tokens": torch.tensor([[3]], dtype=torch.int64),
                    "topk_tokens": torch.tensor([[3, 4]], dtype=torch.int32),
                    "tf_prompt_len": 2,
                }
            ],
        },
        path,
    )

    assert load_reference(path).provenance == {}
