# SPDX-FileCopyrightText: © 2026 Tenstorrent AI ULC
# SPDX-License-Identifier: Apache-2.0

"""Readiness and serving-oriented generator for the Qwen3-32B TT model."""

from __future__ import annotations

import json
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional, Sequence

import torch
from transformers import AutoTokenizer

import ttnn
from models.autoports.qwen_qwen3_32b.tt.model import CacheState, Qwen3FullModel, resolve_checkpoint_dir
from models.common.readiness_check.contract import Generator, NextInputFn


@dataclass(frozen=True)
class SamplingSettings:
    top_k: int | Sequence[int] = 1
    top_p: float | Sequence[float] = 0.0
    temperature: float | Sequence[float] = 1.0
    seed: int | Sequence[int] | None = 0


@dataclass
class TraceState:
    model_trace_id: int | None = None
    sampling_trace_id: int | None = None
    cache_identity: tuple[int, ...] | None = None
    page_table_identity: tuple[int, ...] | None = None
    token_buffer: ttnn.Tensor | None = None
    position_buffers: Any = None
    logits: ttnn.Tensor | None = None
    sampled_token: ttnn.Tensor | None = None
    k: ttnn.Tensor | None = None
    p: ttnn.Tensor | None = None
    temp: ttnn.Tensor | None = None
    seeds: ttnn.Tensor | None = None
    sampling_settings: tuple[Any, ...] | None = None
    greedy: bool | None = None


def _expand_per_slot(value, *, batch: int, cast, default):
    if value is None:
        value = default
    if isinstance(value, (str, bytes)):
        raise TypeError("sampling parameters must be scalars or numeric sequences")
    if isinstance(value, Sequence):
        values = list(value)
        if len(values) > batch:
            raise ValueError(f"sampling parameter has {len(values)} values; maximum is {batch}")
        if not values:
            values = [default]
        values.extend([values[-1]] * (batch - len(values)))
    else:
        values = [value] * batch
    return [cast(item) for item in values]


class Qwen3Generator(Generator):
    """Explicit-cache low-level API plus traced, device-feedback generation."""

    def __init__(self, *, model: Qwen3FullModel, tokenizer, host_sampling_compatibility: bool = False):
        self.model = model
        self.mesh_device = model.mesh_device
        self.tokenizer = tokenizer
        self.host_sampling_compatibility = bool(host_sampling_compatibility)
        self._internal_state: CacheState | None = None
        self._trace = TraceState()
        self._page_table_snapshot: torch.Tensor | None = None
        self._page_table_snapshot_identity = None
        self._canonical_page_table_host: torch.Tensor | None = None
        self._external_page_table = None
        self._external_page_table_snapshot: torch.Tensor | None = None
        self._counters = self._new_counters()
        self._cache_dirty = False
        self.last_generation_metrics: dict[str, float | int] = {}

    @staticmethod
    def _new_counters() -> dict[str, int]:
        return {
            "model_trace_replays": 0,
            "sampling_trace_replays": 0,
            "token_input_refreshes": 0,
            "position_refreshes": 0,
            "page_table_refreshes": 0,
            "sampling_param_refreshes": 0,
            "host_token_readbacks": 0,
            "host_token_async_readbacks": 0,
            "host_logit_readbacks": 0,
            "explicit_synchronizations": 0,
            "cache_resets": 0,
        }

    @property
    def trace_counters(self) -> dict[str, int]:
        return dict(self._counters)

    def reset_trace_counters(self) -> None:
        self._counters = self._new_counters()

    def _ensure_internal_state(self) -> CacheState:
        if self._internal_state is None:
            self._internal_state = self.model.allocate_cache_state()
            self._canonical_page_table_host = self._internal_state.page_table_host.clone()
        return self._internal_state

    @staticmethod
    def _tensor_identity(tensor) -> tuple[int, ...]:
        identities = []
        for device_tensor in ttnn.get_device_tensors(tensor):
            identities.append(int(device_tensor.buffer_address()))
        return tuple(identities)

    def _cache_identity(self, kv_cache) -> tuple[int, ...]:
        return tuple(
            address
            for pair in kv_cache
            for tensor in pair
            for address in self._tensor_identity(tensor)
        )

    def _page_table_host(self, page_table, *, logical_batch: int) -> torch.Tensor:
        if isinstance(page_table, torch.Tensor):
            host = page_table.detach().to(torch.int32).cpu()
        elif isinstance(page_table, ttnn.Tensor):
            identity = self._tensor_identity(page_table)
            if (
                self._page_table_snapshot is not None
                and identity == self._page_table_snapshot_identity
            ):
                host = self._page_table_snapshot.clone()
            else:
                host = ttnn.to_torch(ttnn.get_device_tensors(page_table)[0]).to(torch.int32).cpu()
        else:
            raise TypeError("page_table must be a torch.Tensor or ttnn.Tensor")
        if host.ndim != 2:
            raise ValueError(f"page_table must be rank 2, got {tuple(host.shape)}")
        if host.shape[0] < logical_batch:
            raise ValueError(
                f"page_table has {host.shape[0]} rows for logical batch {logical_batch}"
            )
        return host

    def _external_page_table_device(self, host: torch.Tensor):
        if host.shape[0] > self.model.batch:
            raise ValueError(
                f"page_table has {host.shape[0]} rows; maximum fixed slots is {self.model.batch}"
            )
        if host.shape[0] < self.model.batch:
            padding = host[:1].repeat(self.model.batch - host.shape[0], 1)
            host = torch.cat((host, padding), dim=0)
        shape_changed = self._external_page_table is not None and tuple(
            self._external_page_table.shape
        ) != tuple(host.shape)
        if shape_changed:
            self._release_traces()
            ttnn.deallocate(self._external_page_table, True)
            self._external_page_table = None
            self._external_page_table_snapshot = None
        if self._external_page_table is None:
            self._external_page_table = ttnn.from_torch(
                host,
                dtype=ttnn.int32,
                layout=ttnn.ROW_MAJOR_LAYOUT,
                device=self.mesh_device,
                memory_config=ttnn.DRAM_MEMORY_CONFIG,
                mesh_mapper=ttnn.ReplicateTensorToMesh(self.mesh_device),
            )
            self._external_page_table_snapshot = host.clone()
        elif not torch.equal(host, self._external_page_table_snapshot):
            host_tt = ttnn.from_torch(
                host,
                dtype=ttnn.int32,
                layout=ttnn.ROW_MAJOR_LAYOUT,
                mesh_mapper=ttnn.ReplicateTensorToMesh(self.mesh_device),
            )
            ttnn.copy_host_to_device_tensor(host_tt, self._external_page_table)
            self._external_page_table_snapshot = host.clone()
            self._counters["page_table_refreshes"] += 1
        return host, self._external_page_table

    def _resolve_runtime_state(
        self,
        *,
        page_table,
        kv_cache,
        logical_batch: int,
        require_page_table_host: bool,
    ):
        state = self._internal_state
        if state is not None and kv_cache is state.kv_cache:
            if isinstance(page_table, ttnn.Tensor) and page_table is state.page_table:
                host = state.page_table_host
            else:
                host = self._page_table_host(page_table, logical_batch=logical_batch)
                if host.shape == state.page_table_host.shape and not torch.equal(
                    host, state.page_table_host
                ):
                    state.page_table_host.copy_(host)
            self.refresh_page_table(state.page_table_host, state.page_table)
            return state.page_table_host, state.page_table
        host = self._page_table_host(page_table, logical_batch=logical_batch)
        host, device = self._external_page_table_device(host)
        if require_page_table_host and host is None:
            raise ValueError("host page table is required for prefill")
        self.refresh_page_table(host, device)
        return host, device

    def _compose_prefill_result(self, rows: list[torch.Tensor], *, return_all_logits: bool):
        if not rows:
            raise ValueError("prefill received an empty batch")
        if not return_all_logits:
            return torch.cat(rows, dim=0).reshape(len(rows), 1, self.model.vocab_size)
        max_len = max(int(row.shape[-2]) for row in rows)
        output = torch.zeros((len(rows), max_len, self.model.vocab_size), dtype=torch.float32)
        for idx, row in enumerate(rows):
            row = row.reshape(-1, self.model.vocab_size)
            output[idx, : row.shape[0]] = row
        return output

    def prefill_forward(
        self,
        tokens: torch.Tensor,
        *,
        page_table: torch.Tensor,
        kv_cache: Any,
        prompt_lens: list[int],
        return_all_logits: bool = False,
        return_device_logits: bool = False,
        slots: Sequence[int] | None = None,
        **kwargs: Any,
    ):
        if not isinstance(tokens, torch.Tensor) or tokens.ndim != 2:
            raise ValueError(f"tokens must be a [batch,padded_prompt] torch tensor, got {type(tokens)}")
        logical_batch = int(tokens.shape[0])
        if not 1 <= logical_batch <= self.model.batch:
            raise ValueError(f"logical batch must be in [1,{self.model.batch}], got {logical_batch}")
        if len(prompt_lens) != logical_batch:
            raise ValueError("prompt_lens must contain one logical length per input row")
        slot_ids = list(range(logical_batch)) if slots is None else [int(slot) for slot in slots]
        if len(slot_ids) != logical_batch or len(set(slot_ids)) != logical_batch:
            raise ValueError("slots must contain one unique fixed slot per input row")
        if any(slot < 0 or slot >= self.model.batch for slot in slot_ids):
            raise ValueError(f"slots must be in [0,{self.model.batch})")
        if kv_cache is None:
            # The standard readiness prefill runner delegates cache ownership
            # to the generator while still supplying an explicit page table.
            # Bind that compatibility form to the canonical internal cache.
            kv_cache = self._ensure_internal_state().kv_cache
        host_page_table, device_page_table = self._resolve_runtime_state(
            page_table=page_table,
            kv_cache=kv_cache,
            logical_batch=max(slot_ids) + 1,
            require_page_table_host=True,
        )
        device_rows = []
        host_rows = []
        for row, (prompt_len, slot) in enumerate(zip(prompt_lens, slot_ids)):
            prompt_len = int(prompt_len)
            if prompt_len < 1 or prompt_len > int(tokens.shape[1]):
                raise ValueError(
                    f"prompt_lens[{row}]={prompt_len} is outside input width {tokens.shape[1]}"
                )
            logits = self.model.prefill_user(
                tokens[row, :prompt_len],
                slot=slot,
                page_table_host=host_page_table,
                kv_cache=kv_cache,
                return_all_logits=return_all_logits,
            )
            if return_device_logits:
                device_rows.append(logits)
            else:
                host_rows.append(self.model.compose_vocab_logits(logits))
                self._counters["host_logit_readbacks"] += 1
                ttnn.deallocate(logits, True)
        self._cache_dirty = True
        if self._internal_state is not None and kv_cache is self._internal_state.kv_cache:
            for prompt_len, slot in zip(prompt_lens, slot_ids):
                self._internal_state.prompt_lens[slot] = int(prompt_len)
                self._internal_state.positions[slot] = int(prompt_len)
                self._internal_state.active_mask[slot] = True
        if return_device_logits:
            if logical_batch != 1:
                for tensor in device_rows:
                    ttnn.deallocate(tensor, True)
                raise ValueError("return_device_logits currently requires logical batch 1")
            return device_rows[0]
        return self._compose_prefill_result(host_rows, return_all_logits=return_all_logits)

    def _replicated_param_tensor(self, values: torch.Tensor, *, dtype):
        return ttnn.from_torch(
            values,
            dtype=dtype,
            layout=ttnn.ROW_MAJOR_LAYOUT,
            device=self.mesh_device,
            memory_config=ttnn.DRAM_MEMORY_CONFIG,
            mesh_mapper=ttnn.ReplicateTensorToMesh(self.mesh_device),
        )

    def _sampling_host_values(self, settings: SamplingSettings):
        k = torch.tensor(
            _expand_per_slot(settings.top_k, batch=self.model.batch, cast=int, default=1),
            dtype=torch.int32,
        )
        p = torch.tensor(
            _expand_per_slot(settings.top_p, batch=self.model.batch, cast=float, default=0.0),
            dtype=torch.bfloat16,
        )
        temperature = torch.tensor(
            _expand_per_slot(settings.temperature, batch=self.model.batch, cast=float, default=1.0),
            dtype=torch.bfloat16,
        )
        seed = torch.tensor(
            _expand_per_slot(settings.seed, batch=self.model.batch, cast=int, default=0),
            dtype=torch.int32,
        )
        for idx in range(self.model.batch):
            if float(temperature[idx]) == 0:
                temperature[idx], k[idx], p[idx] = 1, 1, 0
            if not 1 <= int(k[idx]) <= 32:
                raise ValueError(f"top_k must be in [1,32], got {int(k[idx])}")
            if not 0 <= float(p[idx]) <= 1:
                raise ValueError(f"top_p must be in [0,1], got {float(p[idx])}")
            if float(temperature[idx]) <= 0:
                raise ValueError(f"temperature must be positive, got {float(temperature[idx])}")
            if not 0 <= int(seed[idx]) <= 1_000_000:
                raise ValueError(f"seed must be in [0,1000000], got {int(seed[idx])}")
        return k, p, temperature, seed

    def _copy_param(self, values, target, *, dtype) -> None:
        host = ttnn.from_torch(
            values,
            dtype=dtype,
            layout=ttnn.ROW_MAJOR_LAYOUT,
            mesh_mapper=ttnn.ReplicateTensorToMesh(self.mesh_device),
        )
        ttnn.copy_host_to_device_tensor(host, target)

    def _ensure_sampling_buffers(self, settings: SamplingSettings) -> None:
        k, p, temp, seeds = self._sampling_host_values(settings)
        signature = (
            tuple(k.tolist()),
            tuple(float(value) for value in p.tolist()),
            tuple(float(value) for value in temp.tolist()),
            tuple(seeds.tolist()),
        )
        trace = self._trace
        if trace.k is None:
            trace.k = self._replicated_param_tensor(k, dtype=ttnn.uint32)
            trace.p = self._replicated_param_tensor(p, dtype=ttnn.bfloat16)
            trace.temp = self._replicated_param_tensor(temp, dtype=ttnn.bfloat16)
            trace.seeds = self._replicated_param_tensor(seeds, dtype=ttnn.uint32)
        elif trace.sampling_settings != signature:
            self._copy_param(k, trace.k, dtype=ttnn.uint32)
            self._copy_param(p, trace.p, dtype=ttnn.bfloat16)
            self._copy_param(temp, trace.temp, dtype=ttnn.bfloat16)
            self._copy_param(seeds, trace.seeds, dtype=ttnn.uint32)
            self._counters["sampling_param_refreshes"] += 1
        trace.sampling_settings = signature
        sampler = self.model.greedy_sampling if self._is_greedy(settings) else self.model.sampling
        sampler.load_device_buffers()

    def _copy_tokens(self, tokens) -> None:
        if self._trace.token_buffer is None:
            self._trace.token_buffer = self.model.create_token_buffer(tokens)
        else:
            self.model.update_token_buffer(self._trace.token_buffer, tokens)
        self._counters["token_input_refreshes"] += 1

    def _copy_positions(self, positions) -> None:
        if self._trace.position_buffers is None:
            self._trace.position_buffers = self.model.allocate_position_buffers(positions)
        else:
            self.model.update_position_buffers(self._trace.position_buffers, positions, force=True)
        self._counters["position_refreshes"] += 1

    def _reset_seed_values(self, settings: SamplingSettings) -> None:
        _, _, _, seeds = self._sampling_host_values(settings)
        self._copy_param(seeds, self._trace.seeds, dtype=ttnn.uint32)

    def _read_tokens(self, token_tensor, count: int) -> torch.Tensor:
        device_tensor = ttnn.get_device_tensors(token_tensor)[0]
        host = ttnn.to_torch(device_tensor.cpu(blocking=True, cq_id=0))
        self._counters["host_token_readbacks"] += 1
        return host.reshape(-1)[:count].to(torch.int64)

    def _queue_token_read(self, token_tensor):
        device_tensor = ttnn.get_device_tensors(token_tensor)[0]
        host_copy = device_tensor.cpu(blocking=False, cq_id=0)
        self._counters["host_token_async_readbacks"] += 1
        return host_copy

    @staticmethod
    def _tokens_from_queued_read(host_copy, count: int) -> torch.Tensor:
        return ttnn.to_torch(host_copy).reshape(-1)[:count].to(torch.int64)

    def _release_traces(self) -> None:
        for trace_id in (self._trace.model_trace_id, self._trace.sampling_trace_id):
            if trace_id is not None:
                ttnn.release_trace(self.mesh_device, trace_id)
        if self._trace.logits is not None:
            try:
                ttnn.deallocate(self._trace.logits, True)
            except Exception:
                pass
        self._trace.model_trace_id = None
        self._trace.sampling_trace_id = None
        self._trace.logits = None
        self._trace.sampled_token = None
        self._trace.cache_identity = None
        self._trace.page_table_identity = None
        self._trace.greedy = None

    def _is_greedy(self, settings: SamplingSettings) -> bool:
        k, p, temperature, _ = self._sampling_host_values(settings)
        return bool(torch.all(k == 1) and torch.all(p == 0) and torch.all(temperature == 1))

    def _sampling_call_kwargs(self) -> dict:
        return {
            "k": self._trace.k,
            "p": self._trace.p,
            "temp": self._trace.temp,
            "seeds": self._trace.seeds,
            "tt_out_tok": self._trace.token_buffer,
        }

    def _sample_device(self, logits, settings: SamplingSettings):
        if self._is_greedy(settings):
            return self.model.greedy_sampling.decode_forward(
                logits,
                tt_out_tok=self._trace.token_buffer,
            )
        return self.model.sampling.decode_forward(logits, **self._sampling_call_kwargs())

    def _capture_cache_hit_graph(self, call):
        trace_id = None
        capture_open = False
        self.mesh_device.set_program_cache_misses_allowed(False)
        try:
            trace_id = ttnn.begin_trace_capture(self.mesh_device, cq_id=0)
            capture_open = True
            output = call()
            ttnn.end_trace_capture(self.mesh_device, trace_id, cq_id=0)
            capture_open = False
            return trace_id, output
        except Exception:
            if capture_open and trace_id is not None:
                try:
                    ttnn.end_trace_capture(self.mesh_device, trace_id, cq_id=0)
                except Exception:
                    pass
            if trace_id is not None:
                try:
                    ttnn.release_trace(self.mesh_device, trace_id)
                except Exception:
                    pass
            raise
        finally:
            self.mesh_device.set_program_cache_misses_allowed(True)

    def _capture_traces(self, *, kv_cache, page_table, sampling_settings: SamplingSettings) -> None:
        if self._trace.token_buffer is None or self._trace.position_buffers is None:
            raise RuntimeError("token and position buffers must be initialized before trace capture")
        cache_identity = self._cache_identity(kv_cache)
        page_identity = self._tensor_identity(page_table)
        greedy = self._is_greedy(sampling_settings)
        if (
            self._trace.model_trace_id is not None
            and self._trace.sampling_trace_id is not None
            and self._trace.cache_identity == cache_identity
            and self._trace.page_table_identity == page_identity
            and self._trace.greedy == greedy
        ):
            return
        self._release_traces()
        self._ensure_sampling_buffers(sampling_settings)
        token_snapshot = self._read_tokens(self._trace.token_buffer, self.model.batch)
        position_snapshot = self._trace.position_buffers.current_pos
        warm_logits = None
        model_trace_id = None
        sampling_trace_id = None
        try:
            warm_logits = self.model.decode_forward_from_device_inputs(
                self._trace.token_buffer,
                position_buffers=self._trace.position_buffers,
                page_table=page_table,
                kv_cache=kv_cache,
                advance_positions=True,
            )
            ttnn.synchronize_device(self.mesh_device)
            self._counters["explicit_synchronizations"] += 1
            self.model.update_token_buffer(self._trace.token_buffer, token_snapshot)
            self.model.update_position_buffers(
                self._trace.position_buffers, position_snapshot, force=True
            )
            self._reset_seed_values(sampling_settings)
            self._sample_device(warm_logits, sampling_settings)
            ttnn.synchronize_device(self.mesh_device)
            self._counters["explicit_synchronizations"] += 1
            self.model.update_token_buffer(self._trace.token_buffer, token_snapshot)
            self.model.update_position_buffers(
                self._trace.position_buffers, position_snapshot, force=True
            )
            self._reset_seed_values(sampling_settings)
            model_trace_id, model_logits = self._capture_cache_hit_graph(
                lambda: self.model.decode_forward_from_device_inputs(
                    self._trace.token_buffer,
                    position_buffers=self._trace.position_buffers,
                    page_table=page_table,
                    kv_cache=kv_cache,
                    advance_positions=True,
                )
            )
            ttnn.synchronize_device(self.mesh_device)
            self._counters["explicit_synchronizations"] += 1
            self.model.update_token_buffer(self._trace.token_buffer, token_snapshot)
            self.model.update_position_buffers(
                self._trace.position_buffers, position_snapshot, force=True
            )
            self._reset_seed_values(sampling_settings)
            sampling_trace_id, sampling_result = self._capture_cache_hit_graph(
                lambda: self._sample_device(model_logits, sampling_settings)
            )
            sampled, _ = sampling_result
            ttnn.synchronize_device(self.mesh_device)
            self._counters["explicit_synchronizations"] += 1
            if self._tensor_identity(sampled) != self._tensor_identity(self._trace.token_buffer):
                raise RuntimeError("split sampler did not write into the persistent token feedback buffer")
            self.model.update_token_buffer(self._trace.token_buffer, token_snapshot)
            self.model.update_position_buffers(
                self._trace.position_buffers, position_snapshot, force=True
            )
            self._reset_seed_values(sampling_settings)
            self._trace.model_trace_id = model_trace_id
            self._trace.sampling_trace_id = sampling_trace_id
            self._trace.logits = model_logits
            # TTNN may return a distinct Python wrapper for output_tensor. Keep
            # the canonical wrapper after proving both objects name the same
            # physical per-device buffers.
            self._trace.sampled_token = self._trace.token_buffer
            self._trace.cache_identity = cache_identity
            self._trace.page_table_identity = page_identity
            self._trace.greedy = greedy
            if warm_logits is not model_logits:
                ttnn.deallocate(warm_logits, True)
        except Exception:
            for trace_id in (sampling_trace_id, model_trace_id):
                if trace_id is not None:
                    try:
                        ttnn.release_trace(self.mesh_device, trace_id)
                    except Exception:
                        pass
            self.model.update_token_buffer(self._trace.token_buffer, token_snapshot)
            self.model.update_position_buffers(
                self._trace.position_buffers, position_snapshot, force=True
            )
            if warm_logits is not None:
                try:
                    ttnn.deallocate(warm_logits, True)
                except Exception:
                    pass
            raise

    def _execute_token_out_traces(self):
        if self._trace.model_trace_id is None or self._trace.sampling_trace_id is None:
            raise RuntimeError("token-out traces have not been captured")
        ttnn.execute_trace(
            self.mesh_device, self._trace.model_trace_id, cq_id=0, blocking=False
        )
        ttnn.execute_trace(
            self.mesh_device, self._trace.sampling_trace_id, cq_id=0, blocking=False
        )
        self._counters["model_trace_replays"] += 1
        self._counters["sampling_trace_replays"] += 1
        return self._trace.sampled_token

    def _page_table_changed(self, host: torch.Tensor, device) -> bool:
        return (
            self._page_table_snapshot is None
            or self._page_table_snapshot_identity != self._tensor_identity(device)
            or not torch.equal(host.cpu(), self._page_table_snapshot)
        )

    def refresh_page_table(self, page_table_host: torch.Tensor, page_table_device) -> bool:
        host = page_table_host.to(torch.int32).cpu()
        if not self._page_table_changed(host, page_table_device):
            return False
        host_tt = ttnn.from_torch(
            host,
            dtype=ttnn.int32,
            layout=ttnn.ROW_MAJOR_LAYOUT,
            mesh_mapper=ttnn.ReplicateTensorToMesh(self.mesh_device),
        )
        ttnn.copy_host_to_device_tensor(host_tt, page_table_device)
        self._page_table_snapshot = host.clone()
        self._page_table_snapshot_identity = self._tensor_identity(page_table_device)
        self._counters["page_table_refreshes"] += 1
        return True

    def _fixed_slot_inputs(self, tokens, start_pos, slots):
        tokens = torch.as_tensor(tokens, dtype=torch.int64).reshape(-1)
        positions = torch.as_tensor(start_pos, dtype=torch.int32).reshape(-1)
        if tokens.numel() != positions.numel():
            raise ValueError("tokens and start_pos must have the same logical batch")
        if not 1 <= tokens.numel() <= self.model.batch:
            raise ValueError(f"decode logical batch must be in [1,{self.model.batch}]")
        slot_ids = list(range(tokens.numel())) if slots is None else [int(slot) for slot in slots]
        if len(slot_ids) != tokens.numel() or len(set(slot_ids)) != len(slot_ids):
            raise ValueError("slots must contain one unique fixed slot per decode row")
        full_tokens = torch.zeros((self.model.batch,), dtype=torch.int64)
        full_positions = torch.full((self.model.batch,), -1, dtype=torch.int32)
        for idx, slot in enumerate(slot_ids):
            if not 0 <= slot < self.model.batch:
                raise ValueError(f"slot must be in [0,{self.model.batch}), got {slot}")
            full_tokens[slot] = tokens[idx]
            full_positions[slot] = positions[idx]
        return full_tokens, full_positions, slot_ids

    def decode_forward(
        self,
        tokens: torch.Tensor,
        start_pos: torch.Tensor,
        *,
        page_table: torch.Tensor,
        kv_cache: Any,
        enable_trace: bool = True,
        sampling_settings: SamplingSettings | None = None,
        host_sampling: bool | None = None,
        device_owned_step: bool = False,
        return_device: bool = False,
        slots: Sequence[int] | None = None,
        **kwargs: Any,
    ):
        settings = sampling_settings or SamplingSettings()
        use_host_sampling = self.host_sampling_compatibility if host_sampling is None else bool(host_sampling)
        full_tokens, full_positions, slot_ids = self._fixed_slot_inputs(tokens, start_pos, slots)
        host_page_table, device_page_table = self._resolve_runtime_state(
            page_table=page_table,
            kv_cache=kv_cache,
            logical_batch=max(slot_ids) + 1,
            require_page_table_host=False,
        )
        self.model.validate_host_page_table(
            host_page_table,
            kv_cache,
            slot_positions=tuple((slot, int(full_positions[slot])) for slot in slot_ids),
        )
        if not device_owned_step:
            self._copy_tokens(full_tokens)
            self._copy_positions(full_positions)
        elif self._trace.token_buffer is None or self._trace.position_buffers is None:
            raise RuntimeError("device_owned_step requires initialized token and position buffers")
        self._ensure_sampling_buffers(settings)
        if use_host_sampling:
            logits = self.model.decode_forward_from_device_inputs(
                self._trace.token_buffer,
                position_buffers=self._trace.position_buffers,
                page_table=device_page_table,
                kv_cache=kv_cache,
                advance_positions=False,
            )
            host_logits = self.model.compose_vocab_logits(logits).reshape(self.model.batch, -1)
            self._counters["host_logit_readbacks"] += 1
            ttnn.deallocate(logits, True)
            return host_logits[slot_ids]
        if enable_trace:
            self._capture_traces(
                kv_cache=kv_cache,
                page_table=device_page_table,
                sampling_settings=settings,
            )
            sampled = self._execute_token_out_traces()
        else:
            logits = self.model.decode_forward_from_device_inputs(
                self._trace.token_buffer,
                position_buffers=self._trace.position_buffers,
                page_table=device_page_table,
                kv_cache=kv_cache,
                advance_positions=True,
            )
            sampled, _ = self._sample_device(logits, settings)
            ttnn.deallocate(logits, True)
        self._cache_dirty = True
        if return_device:
            return sampled
        full_result = self._read_tokens(sampled, self.model.batch)
        return full_result[slot_ids]

    def _sample_prefill_device(self, logits, *, settings: SamplingSettings):
        sampling_logits = logits
        rows = int(logits.shape[-2])
        if rows < self.model.batch:
            sampling_logits = ttnn.pad(
                logits,
                [(0, 0), (0, 0), (0, self.model.batch - rows), (0, 0)],
                value=-3e38,
                memory_config=ttnn.DRAM_MEMORY_CONFIG,
            )
        elif rows != self.model.batch:
            raise ValueError(
                f"device prefill sampling expects at most {self.model.batch} rows, got {rows}"
            )
        self._ensure_sampling_buffers(settings)
        if self._trace.token_buffer is None:
            self._trace.token_buffer = self.model.create_token_buffer()
        sampled, _ = self._sample_device(sampling_logits, settings)
        if sampling_logits is not logits:
            ttnn.deallocate(sampling_logits, True)
        return sampled

    def validate_generation_bounds(self, prompt_length: int, max_new_tokens: int) -> None:
        """Validate the logical prompt/continuation contract before device mutation."""

        prompt_length = int(prompt_length)
        max_new_tokens = int(max_new_tokens)
        if max_new_tokens < 0:
            raise ValueError("max_new_tokens must be non-negative")
        if prompt_length < 1 or prompt_length > self.model.max_seq_len:
            raise ValueError(
                f"prompt_token_ids length must be in [1,{self.model.max_seq_len}], got {prompt_length}"
            )
        if max_new_tokens > 0 and prompt_length + max_new_tokens - 1 > self.model.max_seq_len:
            raise ValueError(
                f"prompt plus continuation exceeds context: {prompt_length} + {max_new_tokens} - 1 "
                f"> {self.model.max_seq_len}"
            )

    def generate(
        self,
        prompt_token_ids: list[int],
        max_new_tokens: int,
        *,
        next_input: Optional[NextInputFn] = None,
        enable_trace: bool = True,
        sampling_settings: SamplingSettings | None = None,
        host_sampling: bool | None = None,
        stop_on_eos: bool = False,
        **kwargs: Any,
    ) -> list[int]:
        request_start = time.perf_counter()
        self.validate_generation_bounds(len(prompt_token_ids), max_new_tokens)
        if max_new_tokens == 0:
            return []
        settings = sampling_settings or SamplingSettings()
        use_host_sampling = self.host_sampling_compatibility if host_sampling is None else bool(host_sampling)
        if next_input is not None and not self._is_greedy(settings):
            raise ValueError("teacher-forcing readiness requires semantically greedy sampling")
        if self._cache_dirty:
            self.reset()
        state = self._ensure_internal_state()
        prompt = torch.tensor(prompt_token_ids, dtype=torch.int64).reshape(1, -1)
        prefill_logits = self.prefill_forward(
            prompt,
            page_table=state.page_table,
            kv_cache=state.kv_cache,
            prompt_lens=[len(prompt_token_ids)],
            return_device_logits=not use_host_sampling,
            slots=[0],
        )
        if use_host_sampling:
            first_token = int(torch.argmax(prefill_logits[0, -1]).item())
            token_out = [first_token]
            self._counters["host_logit_readbacks"] += 0
            if next_input is None:
                feed_token = first_token
            else:
                feed_token = int(next_input(0, first_token))
        else:
            sampled = self._sample_prefill_device(prefill_logits, settings=settings)
            ttnn.deallocate(prefill_logits, True)
            first_token = int(self._read_tokens(sampled, 1)[0])
            token_out = [first_token]
            feed_token = first_token if next_input is None else int(next_input(0, first_token))
        ttft = time.perf_counter() - request_start
        if max_new_tokens == 1 or (stop_on_eos and first_token == self.tokenizer.eos_token_id):
            self.last_generation_metrics = {"ttft_s": ttft, "decode_tokens": 0, "decode_t_s_u": 0.0}
            return token_out

        positions = torch.full((self.model.batch,), -1, dtype=torch.int32)
        positions[0] = len(prompt_token_ids)
        if use_host_sampling:
            for step in range(1, max_new_tokens):
                logits = self.decode_forward(
                    torch.tensor([[feed_token]]),
                    torch.tensor([int(positions[0])]),
                    page_table=state.page_table,
                    kv_cache=state.kv_cache,
                    enable_trace=enable_trace,
                    sampling_settings=settings,
                    host_sampling=True,
                    slots=[0],
                )
                prediction = int(torch.argmax(logits[0]).item())
                token_out.append(prediction)
                positions[0] += 1
                if stop_on_eos and prediction == self.tokenizer.eos_token_id:
                    break
                feed_token = prediction if next_input is None else int(next_input(step, prediction))
        elif next_input is not None:
            self._copy_positions(positions)
            decode_start = time.perf_counter()
            for step in range(1, max_new_tokens):
                self._copy_tokens([feed_token])
                sampled = self.decode_forward(
                    torch.tensor([[feed_token]]),
                    torch.tensor([int(positions[0])]),
                    page_table=state.page_table,
                    kv_cache=state.kv_cache,
                    enable_trace=enable_trace,
                    sampling_settings=settings,
                    host_sampling=False,
                    device_owned_step=True,
                    return_device=True,
                    slots=[0],
                )
                prediction = int(self._read_tokens(sampled, 1)[0])
                token_out.append(prediction)
                positions[0] += 1
                if stop_on_eos and prediction == self.tokenizer.eos_token_id:
                    break
                feed_token = int(next_input(step, prediction))
            decode_elapsed = time.perf_counter() - decode_start
            self.last_generation_metrics = {
                "ttft_s": ttft,
                "decode_tokens": max(0, len(token_out) - 1),
                "decode_t_s_u": max(0, len(token_out) - 1) / decode_elapsed if decode_elapsed else 0.0,
            }
            return token_out
        else:
            self._copy_positions(positions)
            # The prefill sampler already wrote p0 into the persistent token input.
            decode_start = time.perf_counter()
            queued_reads = []
            for _ in range(1, max_new_tokens):
                sampled = self.decode_forward(
                    torch.tensor([[0]]),
                    torch.tensor([int(positions[0])]),
                    page_table=state.page_table,
                    kv_cache=state.kv_cache,
                    enable_trace=enable_trace,
                    sampling_settings=settings,
                    host_sampling=False,
                    device_owned_step=True,
                    return_device=True,
                    slots=[0],
                )
                queued_reads.append(self._queue_token_read(sampled))
                positions[0] += 1
            ttnn.synchronize_device(self.mesh_device)
            self._counters["explicit_synchronizations"] += 1
            for host_copy in queued_reads:
                token_out.append(int(self._tokens_from_queued_read(host_copy, 1)[0]))
            if stop_on_eos and self.tokenizer.eos_token_id in token_out[1:]:
                eos_index = token_out.index(self.tokenizer.eos_token_id, 1)
                token_out = token_out[: eos_index + 1]
        decode_elapsed = time.perf_counter() - (decode_start if 'decode_start' in locals() else request_start)
        self.last_generation_metrics = {
            "ttft_s": ttft,
            "decode_tokens": max(0, len(token_out) - 1),
            "decode_t_s_u": max(0, len(token_out) - 1) / decode_elapsed if decode_elapsed else 0.0,
        }
        return token_out

    def reset(self) -> None:
        self._release_traces()
        if self._internal_state is not None:
            self.model.reset_kv_cache(self._internal_state.kv_cache)
            self._internal_state.prompt_lens[:] = [0] * self.model.batch
            self._internal_state.positions.fill_(-1)
            self._internal_state.active_mask.zero_()
            if self._canonical_page_table_host is not None:
                self._internal_state.page_table_host.copy_(self._canonical_page_table_host)
                self.refresh_page_table(
                    self._internal_state.page_table_host, self._internal_state.page_table
                )
        self._trace.position_buffers = None
        self._page_table_snapshot = None
        self._page_table_snapshot_identity = None
        self._cache_dirty = False
        self._counters["cache_resets"] += 1

    def teardown(self) -> None:
        self._release_traces()

    def runtime_fallback_audit(self) -> dict:
        audit = self.model.fallback_audit()
        audit.update(
            {
                "optimized_generate": "device prefill sampling plus separate model/sampler decode traces",
                "token_feedback": "Sampling1D tt_out_tok aliases the persistent decode token input",
                "positions": "device plus_one and RoPE embedding refresh live inside the model trace",
                "page_table": "persistent trace input copied only when its physical mapping changes",
                "prefill": "generator owns page padding, <=512-token chunks, absolute positions, cache fill, and slicing",
                "token_observation": "free-running snapshots are nonblocking and synchronize once after the replay window",
                "host_sampling_compatibility": self.host_sampling_compatibility,
            }
        )
        return audit


def _supported_context(model_dir: Path) -> int:
    contract_path = model_dir / "doc" / "context_contract.json"
    contract = json.loads(contract_path.read_text())
    return int(contract["current_supported_context"])


def build_generator(model_dir: str | Path, mesh_device, **kwargs) -> Qwen3Generator:
    model_dir = Path(model_dir).resolve()
    checkpoint = resolve_checkpoint_dir(kwargs.pop("checkpoint_dir", None))
    max_seq_len = int(kwargs.pop("max_seq_len", _supported_context(model_dir)))
    override_num_layers = kwargs.pop("override_num_layers", None)
    lm_head_dtype = kwargs.pop("lm_head_dtype", "bfp8")
    lm_head_target_cores = int(kwargs.pop("lm_head_target_cores", 20))
    lm_head_in0_block_w = int(kwargs.pop("lm_head_in0_block_w", 2))
    lm_head_fidelity = kwargs.pop("lm_head_fidelity", "hifi2")
    host_sampling_compatibility = bool(kwargs.pop("host_sampling_compatibility", False))
    if kwargs:
        unknown = ", ".join(sorted(kwargs))
        raise TypeError(f"unknown Qwen3Generator build options: {unknown}")
    model = Qwen3FullModel.from_checkpoint(
        mesh_device=mesh_device,
        checkpoint_dir=checkpoint,
        max_seq_len=max_seq_len,
        override_num_layers=override_num_layers,
        lm_head_dtype=lm_head_dtype,
        lm_head_target_cores=lm_head_target_cores,
        lm_head_in0_block_w=lm_head_in0_block_w,
        lm_head_fidelity=lm_head_fidelity,
    )
    tokenizer = AutoTokenizer.from_pretrained(
        checkpoint, local_files_only=True, trust_remote_code=True
    )
    return Qwen3Generator(
        model=model,
        tokenizer=tokenizer,
        host_sampling_compatibility=host_sampling_compatibility,
    )


__all__ = ["Qwen3Generator", "SamplingSettings", "TraceState", "build_generator"]
