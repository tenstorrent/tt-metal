# AUTOTRIAGE

## Diagnosis

- The experimental TP4 `max_top_k < 32` split-sampler variants violated the collective's local tensor shape contract. Local-k1 was rejected by `ttnn.sampling` without padding and stalled after post-gather padding; local-k8 also stalled even though its gathered width was 32. The passing contrast proves each rank's local candidate tensor must be a complete 32-element tile before CCL. These are host/runtime submission stalls, not evidence of a fabric or kernel deadlock.

## Triage Evidence

- The live repro stopped during the first reduced full-model split-sampling invocation after model setup; it never emitted `REDUCED_GENERATE_PASS`.
- ARC health remained good and the four P300 devices were reported idle at the captured snapshot.
- Watcher continued polling every device without a worker assertion.
- Detailed call-stack and running-op reads were unavailable because the installed `tt_umd` `noc_read()` signature was incompatible with the triage helper. The capture therefore does not prove a more specific runtime stop site.

## Source Evidence

- `Sampling1D._sample_topk` gathers `max_top_k` values and indices from each of four ranks, so `max_top_k=1` produces logical local width one and gathered width four.
- `ttnn.sampling` rejects that width because its innermost dimension must be divisible by 32.
- The attempted repair padded the already-gathered mesh tensors with two separate `ttnn.pad` operations immediately before DRAM conversion/untilize. That exact variant changed a prompt failure into a silent host stall; the previously proven width-128 (`max_top_k=32`) path did not stall.
- On TP4, `max_top_k=8` naturally yields a gathered width of 32, but its per-rank input remains a logical sub-tile. The exact local-k8 watcher repro also made no progress for more than twice the passing local-k32 runtime. The established local-k32 path supplies a complete tile on each rank, passes watcher, and remains semantically greedy because every rank's local maximum is included before global `k=1` selection.

## Downstream Effects

- The endless watcher polling was a symptom of the host no longer submitting useful work. No worker or Ethernet core was shown waiting on a malformed collective.
- Interrupting the repro left all devices discoverable with healthy DRAM and telemetry.

## Proposed Fix

- Remove the experimental post-gather candidate padding.
- Keep this TP4 model at 32 local candidates per rank, the smallest demonstrated complete local-tile contract.
- Accept this path only with the worker-watcher semantic-greedy probe. Treat the one-layer sampler-heavy profile as a microprofile: the sampler is not dominant in exact 64-layer token-out measurements.

## Uncertainty

- The exact host/runtime function that stopped cannot be named because detailed triage reads failed under the local `tt_umd` API mismatch. The report therefore relies on the controlled local-k1/local-k8 failures and the local-k32 end-to-end watcher pass rather than claiming a more specific runtime defect.
