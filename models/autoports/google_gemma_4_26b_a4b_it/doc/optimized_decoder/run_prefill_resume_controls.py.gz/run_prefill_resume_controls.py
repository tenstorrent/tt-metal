# SPDX-FileCopyrightText: © 2026 Tenstorrent USA, Inc.
# SPDX-License-Identifier: Apache-2.0
"""Matched prefill backend and logical-boundary controls, serialized on one ASIC."""
import json
import os
import subprocess
from pathlib import Path


def main():
    root = Path(__file__).resolve().parent
    journal_path = root / "prefill_resume_commands.json"
    journal = json.loads(journal_path.read_text()) if journal_path.exists() else []
    env = os.environ | {"OMP_NUM_THREADS": "4", "MKL_NUM_THREADS": "4"}
    cases = []
    module = "models.autoports.google_gemma_4_26b_a4b_it.tests."
    for layer in (0, 5):
        common = ["--layer", str(layer), "--length", "4096", "--real", "--input-fixture",
                  str(root / f"actual_text_layer{layer}_4096_128.pt"), "--decode", "--steps", "128",
                  "--timing", "--prefill-timing", "--verify-program-cache"]
        cases.append((f"minimal_baseline_layer{layer}", module + "run_optimized_decoder", ["--defaults", *common]))
        for role in ("output", "qkv"):
            for block in (16, 8):
                cases.append((f"minimal_{role}_k{block}_layer{layer}", module + "probe_optimized_minimal_prefill",
                              ["--minimal-role", role, "--minimal-k", str(block), "--defaults", *common]))
    for name, runner, args in cases:
        output = root / (name + ".json")
        if output.exists():
            continue
        command = ["python", "-m", runner, *args, "--output", str(output)]
        with (root / (name + ".log")).open("w") as log:
            result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, env=env, timeout=1200)
        journal.append({"command": command, "returncode": result.returncode})
        journal_path.write_text(json.dumps(journal, indent=2) + "\n")
        print(name, result.returncode, flush=True)


if __name__ == "__main__":
    main()
