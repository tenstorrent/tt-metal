# SPDX-FileCopyrightText: © 2026 Tenstorrent USA, Inc.
# SPDX-License-Identifier: Apache-2.0
"""Discriminating real-input stress for passing minimal-QKV candidates."""
import json
import os
import subprocess
from pathlib import Path

p = Path(__file__).resolve().parent
journal = []
for layer, block in [(0, 16), (0, 8), (5, 16)]:
    name = f"minimal_qkv_k{block}_stress_layer{layer}"
    output = p / (name + ".json")
    assert not output.exists()
    command = ["python", "-m", "models.autoports.google_gemma_4_26b_a4b_it.tests.probe_optimized_minimal_prefill",
               "--minimal-role", "qkv", "--minimal-k", str(block), "--defaults", "--layer", str(layer),
               "--length", "1025", "--real", "--input-fixture", str(p / f"actual_text_layer{layer}_1025_512.pt"),
               "--decode", "--steps", "512", "--timing", "--verify-program-cache", "--output", str(output)]
    with (p / (name + ".log")).open("w") as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT,
                                env=os.environ | {"OMP_NUM_THREADS": "4", "MKL_NUM_THREADS": "4"}, timeout=1200)
    journal.append({"command": command, "returncode": result.returncode})
    (p / "minimal_stress_commands.json").write_text(json.dumps(journal, indent=2) + "\n")
    print(name, result.returncode, flush=True)
