# SPDX-FileCopyrightText: © 2026 Tenstorrent USA, Inc.
# SPDX-License-Identifier: Apache-2.0
"""Repeat final headline and small-tail gates after scoped review repairs."""
import json
import os
import subprocess
import shutil
from pathlib import Path

p = Path(__file__).resolve().parent
prior = json.loads((p / "validated_v5_contract_commands.json").read_text())
journal = []
for entry in prior:
    command = entry["command"]
    if not any("headline_layer" in value or "watcher_layer" in value or value == "pytest" for value in command):
        continue
    command = [value.replace("validated_v5", "validated_v6") for value in command]
    name = "pytest_validated_v6" if "pytest" in command else Path(command[command.index("--output") + 1]).stem
    environment = os.environ | {"OMP_NUM_THREADS": "4", "MKL_NUM_THREADS": "4"}
    if entry.get("watcher"):
        environment["TT_METAL_WATCHER"] = "10"
    with (p / (name + ".log")).open("w") as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, env=environment, timeout=900)
    if entry.get("watcher"):
        shutil.copyfile("generated/watcher/watcher.log", p / (name + ".device.log"))
    journal.append(dict(command=command, returncode=result.returncode, watcher=bool(entry.get("watcher"))))
    (p / "validated_v6_contract_commands.json").write_text(json.dumps(journal, indent=2) + "\n")
    print(name, result.returncode, flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
