# SPDX-FileCopyrightText: © 2026 Tenstorrent USA, Inc.
# SPDX-License-Identifier: Apache-2.0
"""Serialize final targeted regressions, default checks and native profiles."""
import json
import subprocess
from pathlib import Path

p = Path(__file__).resolve().parent
journal = []
for script in ('run_tight_cache_regressions.py', 'run_validated_v6.py', 'run_profiles_v6.py'):
    command = ['python', str(p / script)]
    result = subprocess.run(command, timeout=2400)
    journal.append(dict(command=command, returncode=result.returncode))
    (p / 'v6_final_campaign.json').write_text(json.dumps(journal, indent=2)+'\n')
    if result.returncode:
        raise SystemExit(result.returncode)
