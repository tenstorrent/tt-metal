# SPDX-FileCopyrightText: © 2026 Tenstorrent USA, Inc.
# SPDX-License-Identifier: Apache-2.0
"""Serialized, resumable native-row audits of selected expert alternatives."""
import csv
import json
import os
import subprocess
from pathlib import Path


def main():
    root = Path(__file__).resolve().parent
    journal_path = root / "operator_audit_commands.json"
    journal = json.loads(journal_path.read_text()) if journal_path.exists() else []
    env = os.environ | {"OMP_NUM_THREADS": "4", "MKL_NUM_THREADS": "4"}
    env.pop("TT_METAL_WATCHER", None)
    for layer in (0, 5):
        for name in ("indexed22k44", "indexed_separatek44", "expanded44k44"):
            folder = root / f"tracy/operator_{name}_layer{layer}"
            done = folder / "audit_complete.json"
            if done.exists():
                continue
            folder.mkdir(parents=True, exist_ok=True)
            runner = folder / "runner.json"
            if not runner.exists():
                command = [
                    "python", "-m", "tracy", "-r", "-p", "-v", "--op-support-count", "100000",
                    "--no-op-info-cache", "--disable-device-data-dump-to-files",
                    "--disable-device-data-push-to-tracy", "-o", str(folder / "raw"), "-n", "operator",
                    "-m", "models.autoports.google_gemma_4_26b_a4b_it.tests.profile_optimized_expert_case",
                    "--expert-case", name, "--input-fixture", str(root / f"operator_audit_layer{layer}_4096_1.pt"),
                    "--layer", str(layer), "--length", "4096", "--real", "--decode", "--steps", "1",
                    "--profile", "--output", str(runner),
                ]
                with (folder / "run.log").open("w") as log:
                    result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, env=env, timeout=1200)
                journal.append({"command": command, "returncode": result.returncode,
                                "scope": "one-replay operator audit; not headline/telemetry"})
                journal_path.write_text(json.dumps(journal, indent=2) + "\n")
                assert result.returncode == 0 and runner.exists(), "Missing successful runner evidence"
            result = json.loads(runner.read_text())
            assert result["passed"] and result["decode"]["passed"]
            files = list((folder / "raw").rglob("ops_perf_results*.csv"))
            assert len(files) == 1, files
            with files[0].open() as source:
                rows = list(csv.DictReader(source))
            active, decode = False, []
            for row in rows:
                if row["OP CODE"] == "PERF_DECODE":
                    active = True
                if active:
                    decode.append(row)
                if row["OP CODE"] == "PERF_DECODE_END":
                    break
            assert len(decode) > 2 and decode[-1]["OP CODE"] == "PERF_DECODE_END"
            source = folder / "decode_one_replay.csv"
            with source.open("w") as target:
                writer = csv.DictWriter(target, fieldnames=list(rows[0]))
                writer.writeheader()
                writer.writerows(decode)
            reports = []
            for as_csv in (False, True):
                command = ["python_env/bin/tt-perf-report", str(source), "--start-signpost", "PERF_DECODE",
                           "--end-signpost", "PERF_DECODE_END", "--no-color", "--no-summary", "--tracing-mode",
                           "--active-experts", "8"]
                if as_csv:
                    command += ["--csv", str(folder / "decode_perf_report.csv")]
                output = folder / ("report.console.log" if as_csv else "decode_perf_report.txt")
                with output.open("w") as log:
                    subprocess.run(command, check=True, stdout=log, stderr=subprocess.STDOUT)
                reports.append(command)
            done.write_text(json.dumps({"runner": str(runner), "native_csv": str(files[0]),
                                        "report_commands": reports, "passed": True}, indent=2) + "\n")
            print("OPERATOR_AUDIT", layer, name, "complete", flush=True)


if __name__ == "__main__":
    main()
