# SPDX-FileCopyrightText: © 2026 Tenstorrent USA, Inc.
# SPDX-License-Identifier: Apache-2.0
"""Maximum-context precision and alternating output-backend timing controls."""
import json
import os
import subprocess
from pathlib import Path
p = Path(__file__).resolve().parent
journal = []
for phase, layer, block in [("long", 0, 8), ("long", 5, 16), ("alternating", 0, 16), ("alternating", 5, 8)]:
    name = f"minimal_{phase}_k{block}_layer{layer}"
    out = p / (name + ".json")
    assert not out.exists()
    if phase == "long":
        args = ["--minimal-role", "qkv", "--minimal-k", str(block), "--contract", "long_context", "--layer", str(layer),
                "--length", "262144", "--threads", "4", "--input-fixture", str(p / f"actual_text_long/actual_text_layer{layer}_262144_0.pt"),
                "--reference-file", str(p / f"actual_text_long/actual_text_layer{layer}_262144_reference.pt")]
    else:
        args = ["--minimal-role", "output", "--minimal-k", str(block), "--alternating-prefill", "8", "--defaults",
                "--layer", str(layer), "--length", "4096", "--real", "--input-fixture", str(p / f"actual_text_layer{layer}_4096_128.pt"),
                "--decode", "--steps", "128", "--timing", "--verify-program-cache"]
    command = ["python", "-m", "models.autoports.google_gemma_4_26b_a4b_it.tests.probe_optimized_minimal_prefill", *args, "--output", str(out)]
    with (p / (name + ".log")).open("w") as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT,
                                env=os.environ | {"OMP_NUM_THREADS": "4", "MKL_NUM_THREADS": "4"}, timeout=1800)
    journal.append({"command": command, "returncode": result.returncode})
    (p / "minimal_acceptance_commands.json").write_text(json.dumps(journal, indent=2) + "\n")
    print(name, result.returncode, flush=True)
