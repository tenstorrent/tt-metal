# SPDX-FileCopyrightText: © 2026 Tenstorrent USA, Inc.
# SPDX-License-Identifier: Apache-2.0
"""Package completed v4 evidence; exit 0/pass, 1/failed, 2/incomplete. CPU only."""

import argparse
import hashlib
import json
import math
import re
from datetime import datetime, timezone
from pathlib import Path

RUNTIME = "3d51014f98128dfb21bb484fcece50993524b967754f68f6dfe825ae7f472ba9"
MODEL_PATH = Path("models/autoports/google_gemma_4_26b_a4b_it")
MODULE = ".".join(MODEL_PATH.parts) + ".tests."
THRESHOLD = 0.995
KINDS = {0: "sliding_attention", 5: "full_attention"}
REUSE_LENGTHS = [31, 32, 33, 1023, 1024, 1025, 2049, 33, 2047]


class MissingEvidence(Exception):
    pass


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def load(path):
    if not path.is_file():
        raise MissingEvidence(str(path))
    return json.loads(path.read_text())


def option(command, name):
    return command[command.index(name) + 1] if name in command else None


def pcc(value):
    return type(value) in (int, float) and math.isfinite(value) and THRESHOLD <= value <= 1.000000000001


def checked_row(row):
    return isinstance(row, dict) and row.get("passed") is True and pcc(row.get("pcc"))


def exact_rows(rows, key, expected):
    require(isinstance(rows, list), f"Missing {key} rows")
    require([row.get(key) for row in rows] == expected, f"Unexpected {key} coverage")
    require(all(checked_row(row) for row in rows), f"Failed or contradictory {key} PCC checks")
    return min(row["pcc"] for row in rows)


def sampled_positions(length):
    return sorted(
        set(
            [
                0,
                min(31, length - 1),
                min(32, length - 1),
                *range(1023, length, 1024),
                *range(max(0, length - 33), length),
            ]
        )
    )


def check_fixture(report, fixture):
    metadata = load(fixture.with_suffix(".json"))
    provenance = report.get("input_fixture")
    if isinstance(provenance, dict):
        actual_path, actual_hash = provenance.get("path"), provenance.get("sha256")
        source = provenance.get("source", {})
    else:
        actual_path, actual_hash = provenance, report.get("input_fixture_sha256")
        source = report.get("input_source", {}).get("source", {})
    require(actual_path and Path(actual_path).resolve() == fixture.resolve(), "Input fixture path differs")
    require(actual_hash == metadata.get("fixture_sha256") and bool(actual_hash), "Input fixture manifest hash differs")
    require(source.get("kind") == "recorded_real_text_hf_layer_inputs", "Input is not recorded real text")
    return actual_hash


def check_decoder(report, layer, length, steps, decoder="optimized"):
    require(report.get("decoder") == decoder, "Wrong decoder")
    require(report.get("layer_type") == KINDS[layer] and report.get("real_weights") is True, "Wrong layer/weights")
    require(report.get("length") == length and report.get("prefix_length") == 0, "Wrong prefill length/prefix")
    require(checked_row(report), "Prefill HF failed")
    require(report.get("runtime_prefill_audit") == "clean", "Prefill audit missing/failed")
    require(
        report.get("program_cache_miss_guard") is True and report.get("prefill_cache_entries", 0) > 0,
        "Program-cache guard missing",
    )
    decode = report.get("decode", {})
    require(decode.get("runtime_decode_audit") == "clean", "Decode audit missing/failed")
    require(decode.get("traced") is True and decode.get("repeated_equal") is True, "Trace/determinism missing")
    require(
        decode.get("steps") == steps and decode.get("positions") == [length, length + steps - 1], "Wrong decode range"
    )
    minimum = exact_rows(decode.get("checks"), "position", [length, *range(length, length + steps)])
    require(decode.get("passed") is True and pcc(decode.get("pcc")), "Decode HF failed")
    require(math.isclose(decode.get("min_pcc", -2), minimum, abs_tol=1e-12, rel_tol=0), "Decode minimum differs")
    if decoder == "optimized":
        require(report.get("runtime_sha256") == RUNTIME, "Optimized runtime hash differs")
        require(
            report.get("functional_fallback") == "forbidden" and report.get("contract") == "run_decoder",
            "Default device-only contract missing",
        )
        require("candidate" not in report, "Unexpected candidate override")
    return minimum


def expected_contracts():
    result = []
    for layer in (5, 0):
        for name, contract, length in [
            ("batched", "batched", None),
            ("prefix_continuation", "prefix_continuation", None),
            ("request_reuse", "request_reuse", None),
            ("bf16_cache_prefix", "prefix_continuation", None),
            ("long_262144", "long_context", 262144),
            ("long_262143", "long_context", 262143),
            ("headline", "run_decoder", 4096),
            ("watcher", "run_decoder", 4096),
        ]:
            result.append((f"validated_v4_{name}_layer{layer}.json", contract, layer, length, name))
    return result


class Evidence:
    def __init__(self, root):
        self.root = root
        self.repo = next(parent for parent in root.parents if (parent / MODEL_PATH).is_dir())
        self.pending, self.errors = [], []
        self.journal = []

    def attempt(self, label, operation):
        try:
            result = operation()
            return {"status": "passed", **result}
        except MissingEvidence as error:
            self.pending.append(f"{label}: {error}")
            return {"status": "incomplete", "missing": str(error)}
        except (ValueError, KeyError, TypeError, OSError, IndexError) as error:
            self.errors.append(f"{label}: {error}")
            return {"status": "failed", "error": str(error)}

    def command(self, filename):
        matches = [
            entry for entry in self.journal if Path(option(entry.get("command", []), "--output") or "").name == filename
        ]
        if not matches:
            raise MissingEvidence(f"completed journal entry for {filename}")
        require(len(matches) == 1, f"Duplicate journal entry for {filename}")
        require(matches[0].get("returncode") == 0, f"Nonzero process result for {filename}")
        return matches[0]

    def contract(self, filename, contract, layer, length, name):
        entry = self.command(filename)
        command = entry["command"]
        require(option(command, "-m") == MODULE + "run_optimized_contract", "Wrong contract runner")
        require(
            option(command, "--contract") == contract and option(command, "--layer") == str(layer),
            "Wrong command target",
        )
        fixture = self.root / (
            f"actual_text_long/actual_text_layer{layer}_262144_0.pt"
            if contract == "long_context"
            else f"actual_text_layer{layer}_4096_128.pt"
        )
        require(Path(option(command, "--input-fixture") or "").resolve() == fixture.resolve(), "Wrong command fixture")
        report = load(self.root / filename)
        require(report.get("runtime_sha256") == RUNTIME, "Runtime hash differs")
        require(
            report.get("decoder") == "optimized" and report.get("contract") == contract, "Wrong report decoder/contract"
        )
        require(report.get("functional_fallback") == "forbidden", "Functional fallback guard missing")
        require(report.get("layer_type") == KINDS[layer] and report.get("real_weights") is True, "Wrong layer/weights")
        fixture_hash = check_fixture(report, fixture)
        expected_override = {"kv_cache_dtype": "bfloat16"} if name == "bf16_cache_prefix" else {}
        require(
            json.loads(option(command, "--default-overrides") or "{}") == expected_override,
            "Unexpected command override",
        )
        require(report.get("candidate", {}) == expected_override, "Unexpected report override")
        policy = report.get("precision_policy", {})
        require(policy.get("kv_cache") == ("bfloat16" if expected_override else "bfloat8_b"), "Wrong cache dtype")
        require(
            policy.get("prefill_expert_gate") == ("DataType.BFLOAT8_B" if layer == 0 else "DataType.BFLOAT4_B"),
            "Wrong selected prefill gate precision",
        )
        result = {
            "artifact": filename,
            "artifact_sha256": digest(self.root / filename),
            "contract": contract,
            "layer_type": KINDS[layer],
            "returncode": 0,
            "runtime_sha256": RUNTIME,
            "fixture_sha256": fixture_hash,
        }
        if contract == "batched":
            require(option(command, "--batch") == "32" and "--heterogeneous-positions" in command, "Wrong B32 command")
            require(report.get("batch") == 32 and report.get("heterogeneous_positions") is True, "B32 coverage missing")
            require(report.get("lengths") == list(range(32, 64)), "Wrong B32 lengths")
            result["minimum_prefill_pcc"] = exact_rows(report.get("prefill"), "slot", list(range(32)))
            result["minimum_decode_pcc"] = exact_rows(report.get("decode"), "slot", list(range(32)))
            require([x.get("length") for x in report["prefill"]] == list(range(32, 64)), "Wrong prefill row lengths")
            require([x.get("position") for x in report["decode"]] == list(range(32, 64)), "Wrong decode positions")
            require(
                report.get("traced") is True and report.get("repeated_equal") is True, "B32 trace/determinism missing"
            )
        elif contract == "prefix_continuation":
            require(
                report.get("length") == 65 and report.get("slot") == 1 and checked_row(report),
                "Prefix accuracy/geometry failed",
            )
            rows = report.get("cache_preservation", [])
            require(
                [(x.get("start"), x.get("end")) for x in rows] == [(0, 31), (31, 33), (33, 65)], "Wrong prefix spans"
            )
            require(
                all(x.get("prefix_unchanged") is True and x.get("other_slot_unchanged") is True for x in rows),
                "Cache preservation failed",
            )
        elif contract == "request_reuse":
            rows = report.get("requests", [])
            require([x.get("length") for x in rows] == REUSE_LENGTHS, "Reuse length coverage differs")
            require(
                all(x.get("passed") is True and pcc(x.get("prefill_pcc")) and pcc(x.get("decode_pcc")) for x in rows),
                "Reuse accuracy failed",
            )
            require(report.get("trace_reused") is True, "Trace reuse missing")
        elif contract == "long_context":
            require(option(command, "--length") == str(length) and report.get("length") == length, "Wrong long context")
            require(
                report.get("cache_positions") == length and report.get("scope") == "subset", "Wrong long cache/scope"
            )
            require(checked_row(report) and report.get("prefill_aggregate_passed") is True, "Aggregate prefill failed")
            require(
                report.get("prefill_sampled_rows_passed") is True,
                "Strict recorded-input sampled-row gate missing/failed",
            )
            samples = sampled_positions(length)
            require(len(samples) == 291 and report.get("compared_query_rows") == samples, "Query sample set differs")
            result["sampled_rows"] = len(samples)
            result["minimum_sampled_row_pcc"] = exact_rows(report.get("sampled_row_diagnostics"), "position", samples)
            exact_rows(report.get("prefill_tail_checks"), "position", [length - 2, length - 1])
            result["minimum_decode_pcc"] = exact_rows(
                report.get("decode"), "position", [length - 1, length - 2, length - 1]
            )
            require(
                report.get("runtime_prefill_audit") == "passed" and report.get("runtime_decode_audit") == "passed",
                "Long runtime audit failed",
            )
            reference = self.root / f"actual_text_long/actual_text_layer{layer}_{length}_reference.pt"
            require(
                Path(option(command, "--reference-file") or "").resolve() == reference.resolve(), "Wrong long oracle"
            )
            meta = load(reference.with_suffix(".json"))
            require(
                meta.get("compared_query_rows") == samples and meta.get("all_kv_positions") == length,
                "Oracle scope differs",
            )
            require(meta.get("input_fixture", {}).get("sha256") == fixture_hash, "Oracle fixture hash differs")
            require(meta.get("reference_sha256") == digest(reference), "Oracle content hash differs")
            result["reference_sha256"] = meta["reference_sha256"]
        else:
            require(
                option(command, "--length") == "4096" and option(command, "--steps") == "128", "Wrong headline command"
            )
            require(
                all(flag in command for flag in ("--real", "--decode", "--verify-program-cache")),
                "Headline flags missing",
            )
            require(entry.get("watcher") is (name == "watcher"), "Watcher journal flag differs")
            result["minimum_decode_pcc"] = check_decoder(report, layer, 4096, 128)
        if contract in ("batched", "prefix_continuation", "request_reuse"):
            require(report.get("runtime_audit") == "clean", "Public runtime audit failed")
        return result

    def watcher(self, layer):
        name = f"validated_v4_watcher_layer{layer}"
        self.contract(name + ".json", "run_decoder", layer, 4096, "watcher")
        snapshot = load(self.root / "validated_v4_environment_snapshot.json")
        driver = self.root / snapshot["orchestrator_source"]
        require(digest(driver) == snapshot.get("orchestrator_sha256"), "Driver snapshot hash differs")
        source = driver.read_text()
        require(
            "if watcher:env['TT_METAL_WATCHER']='10'" in source and "env=os.environ|" in source,
            "Cannot establish watcher interval/environment inheritance",
        )
        environment = snapshot.get("environment", {})
        profiler_keys = [
            "TT_METAL_DEVICE_PROFILER",
            "TT_METAL_DEVICE_PROFILER_NOC_EVENTS",
            "TT_METAL_PROFILE_PERF_COUNTERS",
        ]
        require(
            all(key in environment and environment[key] in (None, "", "0") for key in profiler_keys),
            "Profiler separation not established",
        )
        console_path, device_path = self.root / (name + ".log"), self.root / (name + ".device.log")
        if not console_path.is_file() or not device_path.is_file():
            raise MissingEvidence(f"watcher console/device logs for layer {layer}")
        console, device = console_path.read_text(), device_path.read_text()
        require(
            "Watcher server initialized, disabled features: None" in console,
            "Watcher disabled-feature evidence missing",
        )
        require(
            "Watcher checking device" in console and "Watcher thread stopped watching" in console,
            "Watcher lifecycle incomplete",
        )
        require("starting" in device and len(device) > 1024, "Watcher device log empty/incomplete")
        failure = re.compile(
            r"(?<![-\w])(?:ERROR|FATAL|ASSERTION|CORRUPT|CORRUPTION)\b|Traceback \(most recent call last\)|"
            r"invalid (?:NoC|NOC)|(?:stack|circular.buffer).*overflow",
            re.IGNORECASE,
        )
        lines = [line[:500] for text in (console, device) for line in text.splitlines() if failure.search(line)]
        require(not lines, "Watcher failure lines: " + repr(lines[:5]))
        return {
            "layer": layer,
            "runtime_sha256": RUNTIME,
            "watcher_interval": "10",
            "disabled_features": None,
            "result": name + ".json",
            "device_log": device_path.name,
            "console_log": console_path.name,
            "device_log_bytes": device_path.stat().st_size,
            "device_log_sha256": digest(device_path),
            "failure_lines": [],
            "profiler_enabled": False,
            "profiler_evidence": "validated_v4_environment_snapshot.json",
            "profiler_evidence_scope": "live orchestrator inherited environment plus saved driver; watcher logs confirm lifecycle",
            "passed": True,
        }

    def pytest(self):
        entries = [x for x in self.journal if option(x.get("command", []), "-m") == "pytest"]
        if not entries:
            raise MissingEvidence("completed pytest command")
        require(len(entries) == 1 and entries[0].get("returncode") == 0, "Pytest command failed/duplicated")
        command = entries[0]["command"]
        require(str(MODEL_PATH / "tests/test_optimized_decoder.py") in command, "Wrong pytest target")
        log = self.root / "pytest_validated_v4.log"
        if not log.is_file():
            raise MissingEvidence(str(log))
        lines = [line for line in log.read_text().splitlines() if re.search(r"(?:^|=)\s*4 passed(?:,| in)", line)]
        require(
            len(lines) == 1 and not re.search(r"\d+ (failed|error|skipped|deselected)", lines[0]),
            "Expected exactly four pytest passes",
        )
        cases = []
        base = self.root / "pytest_validated_v4_tmp"
        for path in base.glob("*/optimized.json"):
            if path.parent.is_symlink():
                continue
            report = load(path)
            layer = next((layer for layer, kind in KINDS.items() if report.get("layer_type") == kind), None)
            require(layer in KINDS and report.get("length") in (33, 65), "Unexpected pytest case")
            check_decoder(report, layer, report["length"], 8)
            require(
                report.get("input_source", {}).get("source", {}).get("kind") == "recorded_real_text_hf_layer_inputs",
                "Pytest fixture not recorded",
            )
            cases.append({"layer": layer, "length": report["length"], "report": str(path.relative_to(self.root))})
        require(
            sorted((x["layer"], x["length"]) for x in cases) == [(0, 33), (0, 65), (5, 33), (5, 65)],
            "Four raw pytest cases missing",
        )
        return {"artifact": log.name, "passed": 4, "summary_line": lines[0], "cases": cases}

    def stress(self):
        entries = [x for x in self.journal if option(x.get("command", []), "-m") == MODULE + "run_optimized_stress"]
        if not entries:
            raise MissingEvidence("completed stress command")
        require(len(entries) == 1 and entries[0].get("returncode") == 0, "Stress command failed/duplicated")
        directory = self.root / "stress_validated_v4_defaults"
        require(
            Path(option(entries[0]["command"], "--output-dir") or "").resolve() == directory.resolve(),
            "Wrong stress directory",
        )
        summary = load(directory / "summary.json")
        require(
            summary.get("length") == 1025 and summary.get("steps") == 512 and summary.get("threshold") == THRESHOLD,
            "Stress scope differs",
        )
        require(
            summary.get("input_mode") == "recorded" and summary.get("real_weights") is True, "Stress input mode differs"
        )
        require(
            all(
                summary.get(key) is True
                for key in ("sources_unchanged", "input_fixtures_unchanged", "preservation_passed", "exact_hf_passed")
            ),
            "Stress gates failed",
        )
        require(summary.get("errors") == [], "Stress errors present")
        require(
            summary.get("source_sha256", {}).get(str(MODEL_PATH / "tt/optimized_decoder.py")) == RUNTIME,
            "Stress runtime hash differs",
        )
        run_dir = Path(summary["run_directory"])
        require(run_dir.resolve().is_relative_to(directory.resolve()), "Stress run directory outside campaign")
        nested = load(Path(summary["command_journal"]))
        require(
            len(nested) == 4 and all(x.get("exit_code") == 0 for x in nested),
            "Incomplete/failed stress subprocess journal",
        )
        layers = {}
        for layer in KINDS:
            record = summary.get("layers", {}).get(str(layer), {})
            reports = {}
            minima = {}
            for decoder in ("fused", "optimized"):
                path = Path(record.get("reports", {}).get(decoder, ""))
                require(path.resolve().parent == run_dir.resolve(), "Stress report directory differs")
                reports[decoder] = load(path)
                minima[decoder] = check_decoder(reports[decoder], layer, 1025, 512, decoder)
                check_fixture(reports[decoder], self.root / f"actual_text_layer{layer}_1025_512.pt")
                command_rows = [
                    x for x in nested if Path(option(x["command"], "--output") or "").resolve() == path.resolve()
                ]
                require(len(command_rows) == 1, "Stress report not bound to its command")
            require(
                reports["fused"].get("input_source") == reports["optimized"].get("input_source"),
                "Stress input metadata differs",
            )
            comparison_path = Path(record.get("comparison", ""))
            require(comparison_path.resolve().parent == run_dir.resolve(), "Comparison directory differs")
            comparison = load(comparison_path)
            require(
                comparison.get("direct_passed") is True and checked_row(comparison.get("prefill", {})),
                "Direct prefill failed",
            )
            minimum = exact_rows(comparison.get("decode"), "position", list(range(1025, 1537)))
            require(all(row.get("finite") is True for row in comparison["decode"]), "Nonfinite direct decode")
            require(
                math.isclose(comparison.get("minimum_direct_decode_pcc", -2), minimum, abs_tol=1e-12, rel_tol=0),
                "Direct minimum differs",
            )
            for key in (
                "baseline_hf_failed_positions",
                "candidate_hf_failed_positions",
                "shared_hf_failed_positions",
                "new_hf_failed_positions",
                "direct_failed_positions",
            ):
                require(comparison.get(key) == [], f"Stress has {key}")
            for key, decoder in (("baseline", "fused"), ("candidate", "optimized")):
                provenance = comparison.get(key, {})
                report_path = Path(record["reports"][decoder])
                require(
                    Path(provenance.get("report", "")).resolve() == report_path.resolve(), "Comparison report differs"
                )
                require(provenance.get("report_sha256") == digest(report_path), "Comparison report hash differs")
                tensor_path = Path(provenance.get("tensors", ""))
                require(
                    tensor_path.resolve().parent == run_dir.resolve() and tensor_path.is_file(),
                    "Saved stress tensors missing",
                )
                require(provenance.get("tensor_sha256") == digest(tensor_path), "Comparison tensor hash differs")
            layers[str(layer)] = {
                "minimum_hf_decode_pcc": minima,
                "minimum_direct_decode_pcc": minimum,
                "reports": record["reports"],
                "comparison": str(comparison_path),
            }
        return {
            "artifact": "stress_validated_v4_defaults/summary.json",
            "exact_hf_passed": True,
            "preservation_passed": True,
            "steps_per_kind": 512,
            "prefill_tokens": 1025,
            "layers": layers,
        }


def write(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    temporary.replace(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence-dir", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--output-dir", type=Path, help="Default: evidence directory")
    args = parser.parse_args()
    evidence = Evidence(args.evidence_dir.resolve())
    root, output = evidence.root, (args.output_dir or evidence.root).resolve()
    output.mkdir(parents=True, exist_ok=True)
    runtime = evidence.repo / MODEL_PATH / "tt/optimized_decoder.py"
    runtime_check = evidence.attempt("runtime", lambda: {"matches": digest(runtime) == RUNTIME})
    if runtime_check.get("matches") is False:
        evidence.errors.append("Current runtime differs from frozen campaign hash")
    journal_path = root / "validated_v4_contract_commands.json"
    try:
        evidence.journal = load(journal_path)
        require(isinstance(evidence.journal, list), "Journal must be an array")
    except MissingEvidence as error:
        evidence.pending.append(str(error))
    except (ValueError, TypeError, OSError) as error:
        evidence.errors.append(f"Journal: {error}")
        evidence.journal = []
    if len(evidence.journal) < 18:
        evidence.pending.append(f"Completed command count {len(evidence.journal)}/18")
    if len(evidence.journal) > 18:
        evidence.errors.append(f"Unexpected command count {len(evidence.journal)}/18")
    expected = expected_contracts()
    expected_files = {item[0] for item in expected}
    public_entries = [x for x in evidence.journal if option(x.get("command", []), "--output")]
    actual_files = [Path(option(x["command"], "--output")).name for x in public_entries]
    if len(actual_files) != len(set(actual_files)) or not set(actual_files).issubset(expected_files):
        evidence.errors.append("Duplicate or unexpected public-contract outputs")
    for entry in evidence.journal:
        if entry.get("returncode") != 0:
            evidence.errors.append(f"Incomplete/nonzero command result: {entry.get('command')}")
    contracts = [evidence.attempt(item[0], lambda item=item: evidence.contract(*item)) for item in expected]
    watchers = [
        evidence.attempt(f"watcher layer {layer}", lambda layer=layer: evidence.watcher(layer)) for layer in (0, 5)
    ]
    pytest = evidence.attempt("pytest", evidence.pytest)
    stress = evidence.attempt("stress", evidence.stress)
    if digest(runtime) != RUNTIME:
        evidence.errors.append("Runtime changed or differs at end of summary generation")
    status = (
        "failed"
        if evidence.errors
        else "incomplete" if evidence.pending else "all_final_default_correctness_gates_passed"
    )
    summary = {
        "status": status,
        "runtime_sha256": RUNTIME,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "generator_sha256": digest(Path(__file__)),
        "command_journal": journal_path.name,
        "command_journal_sha256": digest(journal_path) if journal_path.is_file() else None,
        "command_count": len(evidence.journal),
        "expected_command_count": 18,
        "public_contracts": contracts,
        "pytest": pytest,
        "stress": stress,
        "watcher_summary": "validated_v4_watcher_summary.json",
        "accuracy_gate": "PCC >= .995; all 291 sampled real-input long-context rows individually enforced",
        "historical_scope": "verified_* e810 results used aggregate/end-query gates; excluded from v4 completion",
        "pending": evidence.pending,
        "errors": evidence.errors,
        "limits": [
            "Sampled long-context accuracy is not all-token/full-model accuracy",
            "Fixture hashes checked against run reports and manifests; multi-GB fixture files not rehashed",
            "Pytest's small-tail raw reports and process result are checked; tensor comparisons were run by pytest",
            "Watcher/profiler separation uses captured inherited environment and driver plus watcher logs",
        ],
    }
    watcher_summary = {
        "status": (
            "failed"
            if any(x["status"] == "failed" for x in watchers)
            else "incomplete" if any(x["status"] == "incomplete" for x in watchers) else "passed"
        ),
        "runtime_sha256": RUNTIME,
        "command_journal": journal_path.name,
        "watchers": watchers,
    }
    write(output / "validated_v4_validation_summary.json", summary)
    write(output / "validated_v4_watcher_summary.json", watcher_summary)
    print(
        json.dumps(
            {
                "status": status,
                "command_count": len(evidence.journal),
                "pending": len(evidence.pending),
                "errors": evidence.errors,
                "output_dir": str(output),
            },
            indent=2,
        )
    )
    return 1 if evidence.errors else 2 if evidence.pending else 0


if __name__ == "__main__":
    raise SystemExit(main())
