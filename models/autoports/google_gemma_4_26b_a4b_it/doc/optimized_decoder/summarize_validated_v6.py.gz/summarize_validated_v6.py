# SPDX-FileCopyrightText: © 2026 Tenstorrent USA, Inc.
# SPDX-License-Identifier: Apache-2.0
"""CPU-only check of current v6 regressions plus explicitly inherited v5 evidence."""

import ast
import importlib.util
import json
import re
from pathlib import Path
from datetime import datetime, timezone

P = Path(__file__).resolve().parent
R = "b585a21f0b66144f69a823fa2d1088b130e34928a65fc91a38fd1bc5c2526846"
V = "169c0d97d7d0e9f35d97633f133305f1088b987ef625693d3faa100d25c3e67b"
spec = importlib.util.spec_from_file_location("evidence_v5", P / "summarize_validated_v5.py")
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
D = h.digest
L = h.load
req = h.require
runtime = P.parent.parent / "tt/optimized_decoder.py"
req(D(runtime) == R, "Current source hash changed")
req(D(P / "runtime_v5_before_review.py.txt") == V, "Ancestor snapshot hash differs")
delta = L(P / "source_delta_v6.json")
req(delta["current_runtime_sha256"] == R and delta["ancestor_runtime_sha256"] == V, "Delta hashes differ")
req(
    delta["unchanged_factory_defaults_and_resolution"]
    and all(x["remaining_ast_exactly_matches_v5"] for x in delta["exact_delta_reversal_proof"]),
    "Delta proof failed",
)
oldast = ast.parse((P / "runtime_v5_before_review.py.txt").read_text())
newast = ast.parse(runtime.read_text())


def methods(tree):
    return {
        f"{c.name}.{f.name}": ast.dump(f, include_attributes=False)
        for c in tree.body
        if isinstance(c, ast.ClassDef)
        for f in c.body
        if isinstance(f, (ast.FunctionDef, ast.AsyncFunctionDef))
    }


a, b = methods(oldast), methods(newast)
req(a.keys() == b.keys() and len(a) == delta["method_count"], "AST inventory differs")
changed = sorted(k for k in a if a[k] != b[k])
req(changed == sorted(x["method"] for x in delta["exact_delta_reversal_proof"]), "Additional source changes")
req(
    delta["cpu_geometry_checks"]["cases_passed"] == 6144
    and delta["cpu_geometry_checks"]["all_chosen_rounded_reads_within_capacity"],
    "CPU geometry proof missing",
)
# Archive provenance is checked against saved hashes; it is not rebound to R.
v5 = L(P / "validated_v5_validation_summary.json")
req(
    v5["runtime_sha256"] == V
    and v5["status"] == "all_final_default_correctness_gates_passed"
    and not v5["errors"]
    and not v5["pending"],
    "Ancestor suite failed/incomplete",
)
req(D(P / "validated_v5_contract_commands.json") == v5["command_journal_sha256"], "Ancestor journal changed")
for row in v5["public_contracts"]:
    req(
        row["status"] == "passed" and D(P / row["artifact"]) == row["artifact_sha256"], "Ancestor public report changed"
    )
old = h.Evidence(P)
old.journal = L(P / "validated_v5_contract_commands.json")
oldstress = old.stress()
h.RUNTIME = R
E = h.Evidence(P)
journals = ["validated_v6_contract_commands.json", "trace_alloc_v6_commands.json", "tight_cache_v6_commands.json"]
E.journal = sum((L(P / n) for n in journals), [])
req([len(L(P / n)) for n in journals] == [5, 2, 7], "Current journal coverage differs")
req(all(x["returncode"] == 0 for x in E.journal), "Current command failed")
proof = []
for layer in (0, 5):
    for name in ("headline", "watcher"):
        filename = f"validated_v6_{name}_layer{layer}.json"
        row = E.contract(filename, "run_decoder", layer, 4096, name)
        report = L(P / filename)
        row.update(
            prefill_pcc=report["pcc"],
            decode_checks=129,
            unique_decode_positions=128,
            program_cache_miss_guard=True,
            repeated_equal=True,
        )
        proof.append(row)
    reuse = E.contract(f"trace_alloc_v6_layer{layer}.json", "request_reuse", layer, None, "request_reuse")
    report = L(P / reuse["artifact"])
    req(
        report["program_cache_entries_at_capture"] == report["program_cache_entries"] > 0
        and report["program_cache_misses_while_trace_live"] == "forbidden",
        "Reuse cache grew",
    )
    command = E.command(reuse["artifact"])
    req(
        command["environment"].get("TT_METAL_TRACE_ALLOC_TRACKING") == "1"
        and command["environment"].get("TT_METAL_TRACE_ALLOC_TRACEBACKS") == "1",
        "Full trace tracking flags missing",
    )
    req([x["length"] for x in report["prefill_warmup"]] == h.REUSE_LENGTHS, "Reuse warmup inventory differs")
    reuse.update(
        requests=report["requests"],
        program_cache_entries=report["program_cache_entries"],
        program_cache_misses_while_trace_live="forbidden",
        trace_allocation_tracking="1",
        trace_allocation_tracebacks="1",
        trace_reused=True,
    )
    proof.append(reuse)
# Tight-cache controls have small standalone fixtures: rehash their bytes, not just manifests.
tight = []
for length, steps in [(1025, 1), (1088, 1), (1089, 1), (1152, 0), (1152, 1), (1153, 1), (1281, 1), (2049, 1)]:
    filename = (
        "tight_cache_v6_layer5_1025.json" if length == 1025 else f"tight_cache_v6_layer5_{length}_steps{steps}.json"
    )
    report = L(P / filename)
    req(
        report.get("runtime_sha256") == R
        and report.get("layer_type") == "full_attention"
        and report.get("length") == length
        and report.get("real_weights") is True,
        "Tight report provenance differs",
    )
    req(
        h.checked_row(report)
        and report.get("runtime_prefill_audit") == "clean"
        and report.get("program_cache_miss_guard") is True
        and report.get("prefill_cache_entries", 0) > 0,
        "Tight prefill/cache failed",
    )
    h.check_v5_policy(report, 5)
    fixture = Path(report["input_fixture"])
    req(D(fixture) == report["input_fixture_sha256"], "Tight fixture content hash differs")
    req(
        report["input_source"]["source"]["kind"] == "recorded_real_text_hf_layer_inputs",
        "Tight fixture not actual text",
    )
    minimum = h.check_decoder(report, 5, length, steps) if steps else None
    if not steps:
        req("decode" not in report, "Prefill-only unexpectedly decodes")
    capacity = ((length + steps + 127) // 128) * 128
    req(report["cache_extent"] == capacity and report["cache_pages"] * 32 == capacity, "Tight capacity differs")
    checks = report["paged_prefill_capacity_checks"]
    req(report["paged_prefill_capacity_passed"] is True and checks, "Capacity instrumentation absent")
    for row in checks:
        req(
            row["passed"]
            and row["cache_capacity"] == capacity
            and row["table_pages"] * 32 == capacity
            and row["q_chunk"] == 64
            and row["k_chunk"] in (128, 256),
            "Capacity metadata differs",
        )
        expected = ((row["offset"] + row["query_rows"] + row["k_chunk"] - 1) // row["k_chunk"]) * row["k_chunk"]
        req(row["read_end"] == expected and expected <= capacity, "Rounded read exceeds capacity")
    if length != 1025:
        command = E.command(filename)
        req(
            command["length"] == length and command["steps"] == steps and command["capacity"] == capacity,
            "Tight command mismatch",
        )
    tight.append(
        dict(
            artifact=filename,
            artifact_sha256=D(P / filename),
            runtime_sha256=R,
            length=length,
            steps=steps,
            cache_capacity=capacity,
            prefill_pcc=report["pcc"],
            minimum_decode_pcc=minimum,
            input_fixture_sha256=report["input_fixture_sha256"],
            capacity_checks=checks,
            passed=True,
            journal_bound=length != 1025,
        )
    )
req(
    {x["k_chunk"] for r in tight for x in r["capacity_checks"]} == {128, 256},
    "Both primary/fallback branches not covered",
)
# Validate actual Watcher lifecycle and both logs; no reconstructed historical env snapshot.
watchers = []
failure = re.compile(
    r"(?<![-\w])(?:ERROR|FATAL|ASSERTION|CORRUPT|CORRUPTION)\b|Traceback \(most recent call last\)|invalid (?:NoC|NOC)|(?:stack|circular.buffer).*overflow",
    re.I,
)
for stem in ("validated_v6_watcher_layer0", "validated_v6_watcher_layer5", "tight_cache_v6_layer5_1281_steps1"):
    console = (P / (stem + ".log")).read_text()
    device = (P / (stem + ".device.log")).read_text()
    req(
        all(
            x in console
            for x in [
                "Watcher server initialized, disabled features: None",
                "Watcher checking device",
                "Watcher thread stopped watching",
            ]
        ),
        "Watcher lifecycle missing",
    )
    req("starting" in device and len(device) > 1024, "Watcher device log missing")
    req(
        not any(failure.search(line) for text in (console, device) for line in text.splitlines()),
        "Watcher failure detected",
    )
    watchers.append(
        dict(
            report=stem + ".json",
            console_sha256=D(P / (stem + ".log")),
            device_log_sha256=D(P / (stem + ".device.log")),
            device_log_bytes=(P / (stem + ".device.log")).stat().st_size,
            lifecycle_complete=True,
            disabled_features=None,
            failure_lines=[],
            passed=True,
        )
    )
entries = [x for x in E.journal if h.option(x["command"], "-m") == "pytest"]
req(len(entries) == 1 and entries[0]["returncode"] == 0, "Pytest command missing")
log = P / "pytest_validated_v6.log"
lines = [x for x in log.read_text().splitlines() if re.search(r"(?:^|=)\s*4 passed(?:,| in)", x)]
req(
    len(lines) == 1 and not re.search(r"\d+ (failed|error|skipped|deselected)", lines[0]),
    "Pytest not exactly four passed",
)
cases = []
for path in (P / "pytest_validated_v6_tmp").glob("*/optimized.json"):
    if path.parent.is_symlink():
        continue
    report = L(path)
    layer = next(x for x in h.KINDS if h.KINDS[x] == report["layer_type"])
    minimum = h.check_decoder(report, layer, report["length"], 8)
    req(report["input_source"]["source"]["kind"] == "recorded_real_text_hf_layer_inputs", "Pytest not actual inputs")
    cases.append(
        dict(
            artifact=str(path.relative_to(P)),
            artifact_sha256=D(path),
            layer=layer,
            length=report["length"],
            minimum_decode_pcc=minimum,
        )
    )
req(
    sorted((x["layer"], x["length"]) for x in cases) == [(0, 33), (0, 65), (5, 33), (5, 65)],
    "Pytest raw coverage differs",
)
summary = dict(
    status="current_targeted_and_inherited_gates_passed",
    runtime_sha256=R,
    generated_at_utc=datetime.now(timezone.utc).isoformat(),
    generator=Path(__file__).name,
    generator_sha256=D(Path(__file__)),
    accuracy_gate=0.995,
    validation_basis="Fresh v6 affected-contract checks plus explicitly retained v5 broad-suite evidence, linked by exact source delta. Not an 18-command v6 rerun.",
    source_delta=dict(
        artifact="source_delta_v6.json",
        sha256=D(P / "source_delta_v6.json"),
        current_source_sha256=R,
        ancestor_source="runtime_v5_before_review.py.txt",
        ancestor_source_sha256=V,
        changed_methods=changed,
        unchanged_method_count=len(a) - len(changed),
        factory_ast_unchanged=True,
        cpu_geometry_cases_passed=6144,
    ),
    current_command_journals=[
        dict(artifact=n, sha256=D(P / n), count=len(L(P / n)), all_returncodes_zero=True) for n in journals
    ],
    current_journal_command_count=14,
    initial_tight_case="1025 case predates the seven-case journal; report and logs retained separately, current source/fixture hashes verified",
    current_contracts=proof,
    tight_cache_controls=tight,
    watcher_summary=watchers,
    pytest=dict(artifact=log.name, artifact_sha256=D(log), passed=4, summary_line=lines[0], cases=cases),
    inherited_v5=dict(
        runtime_sha256=V,
        validation_summary="validated_v5_validation_summary.json",
        validation_summary_sha256=D(P / "validated_v5_validation_summary.json"),
        command_journal_sha256=v5["command_journal_sha256"],
        completed_commands=18,
        public_report_hashes_reverified=True,
        stress_rechecked_cpu=True,
        public_contracts=v5["public_contracts"],
        stress=oldstress,
        retained_not_rerun_on_v6=[
            "B32 heterogeneous paged requests, both layer kinds",
            "Nonaligned prefix continuation and BF16-cache compatibility, both kinds",
            "262144 and 262143 context, both kinds, 291 sampled query rows each",
            "1025/512 actual-input HF and fused-preservation stress, both kinds",
        ],
        inheritance_reason="Factory/defaults, projections, precision boundaries, decode, and 36/40 methods are AST identical. The four changed methods contain only final unused tail retention control and the tight-capacity prefill geometry branch. Primary full-prefill behavior is unchanged when its read fits; targeted current tests exercise both K128/K256 branches and final-tail request reuse with full trace-allocation tracking.",
    ),
    pending_correctness=[],
    errors=[],
    profile_status="v6 profiles are separate from this correctness manifest; no ancestor profile is rebound to v6",
    limits=[
        "V5 long-context comparisons cover 291 sampled query rows, not every output token.",
        "Large standard input fixtures remain bound by recorded manifests; the small tight-cache fixture files are independently rehashed here.",
        "Current Watcher logs establish lifecycle and no reported failure. No retrospectively reconstructed v6 validation-environment snapshot is claimed.",
        "Initial 1025 tight-case process return code is not recorded in the seven-case command journal; passed current-hash report and logs are retained.",
    ],
)
output = P / "validated_v6_validation_summary.json"
if output.is_file():
    previous = L(output)
    previous_evidence = {key: value for key, value in previous.items() if key != "generated_at_utc"}
    current_evidence = {key: value for key, value in summary.items() if key != "generated_at_utc"}
    if previous_evidence == current_evidence:
        # Rechecking unchanged evidence preserves downstream artifact hashes.
        summary["generated_at_utc"] = previous["generated_at_utc"]
temp = output.with_suffix(".json.tmp")
temp.write_text(json.dumps(summary, indent=2) + "\n")
temp.replace(output)
print(summary["status"], D(output))
