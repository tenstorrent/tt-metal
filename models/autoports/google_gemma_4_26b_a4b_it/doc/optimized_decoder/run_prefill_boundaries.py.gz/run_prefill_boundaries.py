# SPDX-FileCopyrightText: © 2026 Tenstorrent USA, Inc.
# SPDX-License-Identifier: Apache-2.0
"""Measure warmed fused/default prefill on matched real logical boundary inputs."""
import hashlib
import json
import os
import subprocess
from pathlib import Path

import torch


def main():
    root = Path(__file__).resolve().parent
    path = root / "prefill_boundary_commands.json"
    journal = json.loads(path.read_text()) if path.exists() else []
    for layer in (0, 5):
        source_path = root / f"actual_text_layer{layer}_4096_128.pt"
        source = torch.load(source_path, weights_only=True, map_location="cpu")
        for length in (65, 1023, 1024, 1025):
            fixture = root / f"prefill_boundary_layer{layer}_{length}.pt"
            if not fixture.exists():
                metadata = dict(source["metadata"], length=length, steps=1)
                metadata.update(slice_source=str(source_path), slice_source_sha256=hashlib.sha256(source_path.read_bytes()).hexdigest())
                torch.save({"metadata": metadata, "prefill": source["prefill"][:, :length].clone(),
                            "decode": source["prefill"][:, length:length+1].clone()}, fixture)
            for decoder in ("fused", "optimized"):
                name = f"prefill_boundary_{decoder}_layer{layer}_{length}"
                output = root / (name + ".json")
                if output.exists():
                    continue
                module = "run_decoder" if decoder == "fused" else "run_optimized_contract"
                selector = ["--decoder", "fused"] if decoder == "fused" else ["--contract", "run_decoder"]
                command = ["python", "-m", f"models.autoports.google_gemma_4_26b_a4b_it.tests.{module}", *selector,
                           "--layer", str(layer), "--length", str(length), "--real", "--input-fixture", str(fixture),
                           "--decode", "--steps", "1", "--prefill-timing", "--verify-program-cache", "--output", str(output)]
                with (root / (name + ".log")).open("w") as log:
                    result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT,
                                            env=os.environ | {"OMP_NUM_THREADS": "4", "MKL_NUM_THREADS": "4"}, timeout=1200)
                journal.append({"command": command, "returncode": result.returncode, "logical_length": length,
                                "chunk_size": 1024, "chunk_count": (length + 1023) // 1024,
                                "physical_rows": [min(1024, ((length + 31) // 32) * 32)] if length <= 1024 else [1024, 1024 if layer == 0 else 32]})
                path.write_text(json.dumps(journal, indent=2) + "\n")
                print(name, result.returncode, flush=True)
                assert result.returncode == 0


if __name__ == "__main__":
    main()
