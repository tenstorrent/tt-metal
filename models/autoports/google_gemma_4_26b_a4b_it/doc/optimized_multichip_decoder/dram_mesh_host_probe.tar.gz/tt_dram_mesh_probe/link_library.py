import json,pathlib,shlex,subprocess
root=pathlib.Path('/workspace/tt-metal')
probe=pathlib.Path('/tmp/tt_dram_mesh_probe')
line=subprocess.check_output(['ninja','-C',str(root/'build'),'-t','commands','ttnn/_ttnncpp.so'],text=True).splitlines()[-1]
args=shlex.split(line)
assert args[:2] == [':','&&'] and args[-2:] == ['&&',':']
args=args[2:-2]
assert all(a not in ('&&',';','|') for a in args)
args[args.index('-o')+1]=str(probe/'_ttnncpp.so')
obj='ttnn/cpp/ttnn/operations/matmul/CMakeFiles/ttnn_op_matmul.dir/Unity/unity_0_cxx.cxx.o'
args[args.index(obj)]=str(probe/'matmul_unity_0.o')
for i,a in enumerate(args):
    if a.startswith('--dependency-file='):
        args[i]='--dependency-file='+str(probe/'link.d')
output=root/'models/autoports/google_gemma_4_26b_a4b_it/doc/optimized_multichip_decoder'
(output/'dram_mesh_link.command.json').write_text(json.dumps({'command':args,'cwd':str(root/'build_Release')},indent=2)+'\n')
print('Linking candidate library into /tmp/tt_dram_mesh_probe/_ttnncpp.so without replacing live runtime',flush=True)
result=subprocess.run(args,cwd=root/'build_Release')
print(f'Link exit_code={result.returncode}',flush=True)
raise SystemExit(result.returncode)
