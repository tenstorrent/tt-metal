import json,pathlib,shlex,subprocess
root=pathlib.Path('/workspace/tt-metal')
target='ttnn/cpp/ttnn/operations/matmul/CMakeFiles/ttnn_op_matmul.dir/Unity/unity_0_cxx.cxx.o'
command=subprocess.check_output(['ninja','-C',str(root/'build'),'-t','commands',target],text=True).splitlines()[-1]
args=shlex.split(command)
probe=pathlib.Path('/tmp/tt_dram_mesh_probe')
for option,name in [('-o','matmul_unity_0.o'),('-MF','matmul_unity_0.o.d')]:
    args[args.index(option)+1]=str(probe/name)
record={'command':args,'cwd':str(root/'build_Release'),'source_target':target}
output=root/'models/autoports/google_gemma_4_26b_a4b_it/doc/optimized_multichip_decoder'
(output/'dram_mesh_object_build.command.json').write_text(json.dumps(record,indent=2)+'\n')
print('Compiling complete matmul unity translation unit to /tmp/tt_dram_mesh_probe/matmul_unity_0.o',flush=True)
result=subprocess.run(args,cwd=root/'build_Release')
print(f'Compile exit_code={result.returncode}',flush=True)
raise SystemExit(result.returncode)
