"""Install/restore the verified candidate only while the parent owns idle devices."""
import argparse,hashlib,os,pathlib,shutil
p=argparse.ArgumentParser()
p.add_argument('action',choices=['install','restore'])
args=p.parse_args()
root=pathlib.Path('/workspace/tt-metal')
probe=pathlib.Path('/tmp/tt_dram_mesh_probe')
candidate=probe/'_ttnncpp.so'
expected='3c6e55d5335dcfe106bc5ec4ece7422e6508cfd01983d6b3b1f028ef8705eba5'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
targets=[root/'build_Release/lib/_ttnncpp.so',root/'build_Release/ttnn/_ttnncpp.so']
if args.action=='install':
    assert sha(candidate)==expected,'candidate library changed'
for target in targets:
    backup=probe/f'original_{target.parent.name}_ttnncpp.so'
    if args.action=='install':
        if not backup.exists():
            shutil.copy2(target,backup)
        source=candidate
    else:
        assert backup.exists(),f'missing backup {backup}'
        source=backup
    temp=target.with_name(target.name+'.dram_mesh_tmp')
    shutil.copy2(source,temp)
    os.replace(temp,target)
    print(args.action,target,sha(target))
