import pathlib, subprocess, sys
root = pathlib.Path('/workspace/tt-metal')
source_path = 'ttnn/cpp/ttnn/operations/matmul/device/utilities/matmul_utilities.cpp'

def function(source, marker):
    start = source.index(marker)
    brace = source.index('{', start)
    depth = 1
    end = brace + 1
    while depth:
        depth += (source[end] == '{') - (source[end] == '}')
        end += 1
    return source[start:end]

base = subprocess.check_output(['git', 'show', 'adcb0e8f21704ff7e0090812a2f7b8a7d359f979:' + source_path], cwd=root, text=True)
current = (root / source_path).read_text()
api = function((root/'tt_metal/impl/device/experimental/device.cpp').read_text(), 'uint32_t get_worker_noc_hop_distance(')
functions = '\n'.join('namespace ' + name + ' {\nusing tt::tt_metal::CoreRangeSet;\nstruct DramBankReaderAssignment { tt::tt_metal::CoreCoord worker_core; uint32_t bank_id; uint32_t worker_index; };\n' + function(src, 'void validate_num_workers_per_dram_bank(') + '\n' + function(src, 'std::vector<DramBankReaderAssignment> get_dram_bank_reader_assignments(') + '\n}' for name,src in [('baseline',base),('candidate',current)])
prelude = r'''
#include <algorithm>
#include <compare>
#include <cstdint>
#include <iostream>
#include <limits>
#include <set>
#include <stdexcept>
#include <vector>
#define TT_FATAL(condition, message, ...) do { if (!(condition)) throw std::runtime_error(message); } while (0)
namespace tt::tt_metal {
struct CoreCoord { uint32_t x=0,y=0; auto operator<=>(const CoreCoord&) const = default; };
struct CoreRangeSet { std::set<CoreCoord> cores; bool contains(const CoreCoord& c) const {return cores.contains(c);} };
enum NOC { NOC_0, NOC_1 };
struct IDevice {
    virtual ~IDevice() = default;
    virtual std::vector<CoreCoord> get_optimal_dram_bank_to_logical_worker_assignment(NOC) {return {{1,1},{3,3}};}
    virtual CoreCoord compute_with_storage_grid_size() const {return {4,4};}
    virtual CoreCoord grid_size() const {return {4,4};}
};
struct Device : IDevice { CoreCoord physical_worker_core_from_logical_core(CoreCoord c) const {return c;} };
namespace distributed {
struct MeshDevice : IDevice {
    std::vector<IDevice*> local;
    explicit MeshDevice(std::vector<IDevice*> devs):local(std::move(devs)) {}
    size_t num_devices() const {return local.size();}
    const std::vector<IDevice*>& get_devices() const {return local;}
    std::vector<CoreCoord> get_optimal_dram_bank_to_logical_worker_assignment(NOC noc) override {return local.front()->get_optimal_dram_bank_to_logical_worker_assignment(noc);}
};
}
namespace experimental::Device {
'''
main = r'''
using namespace tt::tt_metal;
template <typename A, typename B> bool same(const A& a, const B& b) {
    if(a.size()!=b.size()) return false;
    for(size_t i=0;i<a.size();++i) if(a[i].worker_core != b[i].worker_core || a[i].bank_id != b[i].bank_id || a[i].worker_index != b[i].worker_index) return false;
    return true;
}
void check(bool ok, const char* label) { if(!ok) throw std::runtime_error(label); std::cout << "PASS " << label << '\n'; }
int main(int argc,char**) {
    Device dev0,dev1,dev2,dev3;
    distributed::MeshDevice unit({&dev0}), mesh({&dev0,&dev1,&dev2,&dev3});
    const CoreRangeSet excluded{{{0,0},{1,0}}};
    check(same(baseline::get_dram_bank_reader_assignments(&dev0,NOC_0,1,excluded), baseline::get_dram_bank_reader_assignments(&mesh,NOC_0,1,excluded)), "baseline one reader accepts mesh4 and matches raw");
    for(uint32_t readers : {2,3}) {
        bool rejected=false;
        try { baseline::get_dram_bank_reader_assignments(&mesh,NOC_0,readers,excluded); }
        catch(const std::runtime_error& e) {rejected = std::string(e.what()) == "get_worker_noc_hop_distance() is only supported on unit MeshDevice.";}
        check(rejected, "baseline multi-reader mesh4 reproduces exact public API failure");
        check(same(baseline::get_dram_bank_reader_assignments(&dev0,NOC_0,readers,excluded),baseline::get_dram_bank_reader_assignments(&unit,NOC_0,readers,excluded)), "baseline multi-reader raw and unit mesh agree");
    }
    if (argc==1) return 0;
    for(uint32_t readers : {1,2,3}) {
        auto raw=baseline::get_dram_bank_reader_assignments(&dev0,NOC_0,readers,excluded);
        auto fixed=candidate::get_dram_bank_reader_assignments(&mesh,NOC_0,readers,excluded);
        check(same(raw,fixed),"patched mesh4 agrees with baseline physical assignment");
        check(same(raw,candidate::get_dram_bank_reader_assignments(&unit,NOC_0,readers,excluded)), "patched unit mesh assignment unchanged");
        check(same(raw,candidate::get_dram_bank_reader_assignments(&dev0,NOC_0,readers,excluded)), "patched raw-device assignment unchanged");
        std::set<CoreCoord> used;
        for(const auto& a:fixed) {check(used.insert(a.worker_core).second,"reader uniqueness");check(!excluded.contains(a.worker_core),"excluded storage cores preserved");}
        check(same(fixed,candidate::get_dram_bank_reader_assignments(&mesh,NOC_0,readers,excluded)),"deterministic repeated placement");
    }
    bool rejected=false;
    try {experimental::Device::get_worker_noc_hop_distance(&mesh,{0,0},{0,1},NOC_0);}
    catch(const std::runtime_error&) {rejected=true;}
    check(rejected,"public multi-device hop API guard remains");
    rejected=false;
    try {candidate::get_dram_bank_reader_assignments(&mesh,NOC_1,2,excluded);}
    catch(const std::runtime_error&) {rejected=true;}
    check(rejected,"multi-reader NOC1 guard remains");
}
'''
probe = pathlib.Path('/tmp/tt_dram_mesh_probe')
(probe/'probe.cpp').write_text(prelude + api + '\n}}\n' + functions + main)
subprocess.run(['/usr/bin/clang++-20','-std=c++20','-Wall','-Wextra','-Werror',str(probe/'probe.cpp'),'-o',str(probe/'probe')],check=True)
subprocess.run([str(probe/'probe'),*sys.argv[1:]],check=True)
