
#include <algorithm>
#include <compare>
#include <cstdint>
#include <iostream>
#include <limits>
#include <set>
#include <stdexcept>
#include <vector>
#define TT_FATAL(condition, message, ...) do { if (!(condition)) throw std::runtime_error(message); } while (0)
namespace tt::tt_metal {
struct CoreCoord { uint32_t x=0,y=0; auto operator<=>(const CoreCoord&) const = default; };
struct CoreRangeSet { std::set<CoreCoord> cores; bool contains(const CoreCoord& c) const {return cores.contains(c);} };
enum NOC { NOC_0, NOC_1 };
struct IDevice {
    virtual ~IDevice() = default;
    virtual std::vector<CoreCoord> get_optimal_dram_bank_to_logical_worker_assignment(NOC) {return {{1,1},{3,3}};}
    virtual CoreCoord compute_with_storage_grid_size() const {return {4,4};}
    virtual CoreCoord grid_size() const {return {4,4};}
};
struct Device : IDevice { CoreCoord physical_worker_core_from_logical_core(CoreCoord c) const {return c;} };
namespace distributed {
struct MeshDevice : IDevice {
    std::vector<IDevice*> local;
    explicit MeshDevice(std::vector<IDevice*> devs):local(std::move(devs)) {}
    size_t num_devices() const {return local.size();}
    const std::vector<IDevice*>& get_devices() const {return local;}
    std::vector<CoreCoord> get_optimal_dram_bank_to_logical_worker_assignment(NOC noc) override {return local.front()->get_optimal_dram_bank_to_logical_worker_assignment(noc);}
};
}
namespace experimental::Device {
uint32_t get_worker_noc_hop_distance(
    IDevice* device, const CoreCoord& logical_src, const CoreCoord& logical_dst, NOC noc) {
    TT_FATAL(device != nullptr, "Device pointer cannot be null");

    // Check if it's a MeshDevice and handle appropriately
    if (auto* mesh = dynamic_cast<distributed::MeshDevice*>(device)) {
        TT_FATAL(mesh->num_devices() == 1, "get_worker_noc_hop_distance() is only supported on unit MeshDevice.");
        // Delegate to the underlying device
        return get_worker_noc_hop_distance(mesh->get_devices().front(), logical_src, logical_dst, noc);
    }

    // Handle regular Device - cast to access internal physical_worker_core_from_logical_core
    auto* dev = dynamic_cast<tt::tt_metal::Device*>(device);
    TT_FATAL(dev != nullptr, "Device pointer must be a valid Device or MeshDevice");

    // Convert logical to physical worker coordinates
    auto src = dev->physical_worker_core_from_logical_core(logical_src);
    auto dst = dev->physical_worker_core_from_logical_core(logical_dst);
    auto grid_size = device->grid_size();

    if (noc == NOC::NOC_0) {
        // NOC0: Preferred +x -> +y
        uint32_t dist_right = src.x <= dst.x ? dst.x - src.x : grid_size.x - src.x + dst.x;
        uint32_t dist_bottom = src.y <= dst.y ? dst.y - src.y : grid_size.y - src.y + dst.y;
        return dist_right + dist_bottom;
    }  // NOC1: Preferred -y -> -x
    uint32_t dist_left = src.x >= dst.x ? src.x - dst.x : grid_size.x - dst.x + src.x;
    uint32_t dist_top = src.y >= dst.y ? src.y - dst.y : grid_size.y - dst.y + src.y;
    return dist_left + dist_top;
}
}}
namespace baseline {
using tt::tt_metal::CoreRangeSet;
struct DramBankReaderAssignment { tt::tt_metal::CoreCoord worker_core; uint32_t bank_id; uint32_t worker_index; };
void validate_num_workers_per_dram_bank(std::size_t workers_per_bank) {
    TT_FATAL(
        workers_per_bank >= 1 && workers_per_bank <= 3,
        "num_workers_per_dram_bank must be in [1, 3], got {}",
        workers_per_bank);
}
std::vector<DramBankReaderAssignment> get_dram_bank_reader_assignments(
    tt::tt_metal::IDevice* device,
    tt::tt_metal::NOC noc,
    uint32_t workers_per_bank,
    const CoreRangeSet& secondary_reader_excluded_cores) {
    validate_num_workers_per_dram_bank(workers_per_bank);

    const auto primary_workers = device->get_optimal_dram_bank_to_logical_worker_assignment(noc);
    std::vector<DramBankReaderAssignment> assignments;
    assignments.reserve(primary_workers.size() * workers_per_bank);

    if (workers_per_bank == 1) {
        for (uint32_t bank = 0; bank < primary_workers.size(); ++bank) {
            assignments.push_back({primary_workers[bank], bank, 0});
        }
        return assignments;
    }

    TT_FATAL(
        noc == tt::tt_metal::NOC::NOC_0,
        "Multiple readers per DRAM bank currently require a NOC0 data-movement kernel");

    const auto worker_grid = device->compute_with_storage_grid_size();
    std::set<tt::tt_metal::CoreCoord> used(primary_workers.begin(), primary_workers.end());

    for (uint32_t bank = 0; bank < primary_workers.size(); ++bank) {
        const auto primary = primary_workers[bank];
        assignments.push_back({primary, bank, 0});

        for (uint32_t worker_index = 1; worker_index < workers_per_bank; ++worker_index) {
            bool found = false;
            uint32_t best_cost = std::numeric_limits<uint32_t>::max();
            tt::tt_metal::CoreCoord best_worker{};
            for (uint32_t x = 0; x < worker_grid.x; ++x) {
                for (uint32_t y = 0; y < worker_grid.y; ++y) {
                    const tt::tt_metal::CoreCoord candidate{x, y};
                    if (used.contains(candidate) || secondary_reader_excluded_cores.contains(candidate)) {
                        continue;
                    }
                    // All readers use AllocatorBank on the same NOC and therefore target the same
                    // firmware-approved endpoint. Place additional readers near the bank's primary
                    // reader to minimize NOC hops without routing one NOC to multiple endpoints.
                    const uint32_t cost = tt::tt_metal::experimental::Device::get_worker_noc_hop_distance(
                        device, candidate, primary_workers[bank], noc);
                    // Equal-cost candidates use the same endpoint and hop count. Keep the first candidate in ascending
                    // x/y scan order so that the assignment is deterministic without adding a second routing objective.
                    if (cost < best_cost) {
                        found = true;
                        best_cost = cost;
                        best_worker = candidate;
                    }
                }
            }
            TT_FATAL(found, "No free DRAM reader {} core for bank {}", worker_index, bank);
            used.insert(best_worker);
            assignments.push_back({best_worker, bank, worker_index});
        }
    }
    return assignments;
}
}
namespace candidate {
using tt::tt_metal::CoreRangeSet;
struct DramBankReaderAssignment { tt::tt_metal::CoreCoord worker_core; uint32_t bank_id; uint32_t worker_index; };
void validate_num_workers_per_dram_bank(std::size_t workers_per_bank) {
    TT_FATAL(
        workers_per_bank >= 1 && workers_per_bank <= 3,
        "num_workers_per_dram_bank must be in [1, 3], got {}",
        workers_per_bank);
}
std::vector<DramBankReaderAssignment> get_dram_bank_reader_assignments(
    tt::tt_metal::IDevice* device,
    tt::tt_metal::NOC noc,
    uint32_t workers_per_bank,
    const CoreRangeSet& secondary_reader_excluded_cores) {
    validate_num_workers_per_dram_bank(workers_per_bank);

    const auto primary_workers = device->get_optimal_dram_bank_to_logical_worker_assignment(noc);
    std::vector<DramBankReaderAssignment> assignments;
    assignments.reserve(primary_workers.size() * workers_per_bank);

    if (workers_per_bank == 1) {
        for (uint32_t bank = 0; bank < primary_workers.size(); ++bank) {
            assignments.push_back({primary_workers[bank], bank, 0});
        }
        return assignments;
    }

    TT_FATAL(
        noc == tt::tt_metal::NOC::NOC_0,
        "Multiple readers per DRAM bank currently require a NOC0 data-movement kernel");

    const auto worker_grid = device->compute_with_storage_grid_size();
    auto* placement_device = device;
    if (auto* mesh_device = dynamic_cast<tt::tt_metal::distributed::MeshDevice*>(device)) {
        // Match the reference device used by the mesh's primary DRAM-reader assignment.
        const auto local_devices = mesh_device->get_devices();
        TT_FATAL(!local_devices.empty(), "DRAM reader placement requires at least one local device");
        placement_device = local_devices.front();
    }
    std::set<tt::tt_metal::CoreCoord> used(primary_workers.begin(), primary_workers.end());

    for (uint32_t bank = 0; bank < primary_workers.size(); ++bank) {
        const auto primary = primary_workers[bank];
        assignments.push_back({primary, bank, 0});

        for (uint32_t worker_index = 1; worker_index < workers_per_bank; ++worker_index) {
            bool found = false;
            uint32_t best_cost = std::numeric_limits<uint32_t>::max();
            tt::tt_metal::CoreCoord best_worker{};
            for (uint32_t x = 0; x < worker_grid.x; ++x) {
                for (uint32_t y = 0; y < worker_grid.y; ++y) {
                    const tt::tt_metal::CoreCoord candidate{x, y};
                    if (used.contains(candidate) || secondary_reader_excluded_cores.contains(candidate)) {
                        continue;
                    }
                    // All readers use AllocatorBank on the same NOC and therefore target the same
                    // firmware-approved endpoint. Place additional readers near the bank's primary
                    // reader to minimize NOC hops without routing one NOC to multiple endpoints.
                    const uint32_t cost = tt::tt_metal::experimental::Device::get_worker_noc_hop_distance(
                        placement_device, candidate, primary_workers[bank], noc);
                    // Equal-cost candidates use the same endpoint and hop count. Keep the first candidate in ascending
                    // x/y scan order so that the assignment is deterministic without adding a second routing objective.
                    if (cost < best_cost) {
                        found = true;
                        best_cost = cost;
                        best_worker = candidate;
                    }
                }
            }
            TT_FATAL(found, "No free DRAM reader {} core for bank {}", worker_index, bank);
            used.insert(best_worker);
            assignments.push_back({best_worker, bank, worker_index});
        }
    }
    return assignments;
}
}
using namespace tt::tt_metal;
template <typename A, typename B> bool same(const A& a, const B& b) {
    if(a.size()!=b.size()) return false;
    for(size_t i=0;i<a.size();++i) if(a[i].worker_core != b[i].worker_core || a[i].bank_id != b[i].bank_id || a[i].worker_index != b[i].worker_index) return false;
    return true;
}
void check(bool ok, const char* label) { if(!ok) throw std::runtime_error(label); std::cout << "PASS " << label << '\n'; }
int main(int argc,char**) {
    Device dev0,dev1,dev2,dev3;
    distributed::MeshDevice unit({&dev0}), mesh({&dev0,&dev1,&dev2,&dev3});
    const CoreRangeSet excluded{{{0,0},{1,0}}};
    check(same(baseline::get_dram_bank_reader_assignments(&dev0,NOC_0,1,excluded), baseline::get_dram_bank_reader_assignments(&mesh,NOC_0,1,excluded)), "baseline one reader accepts mesh4 and matches raw");
    for(uint32_t readers : {2,3}) {
        bool rejected=false;
        try { baseline::get_dram_bank_reader_assignments(&mesh,NOC_0,readers,excluded); }
        catch(const std::runtime_error& e) {rejected = std::string(e.what()) == "get_worker_noc_hop_distance() is only supported on unit MeshDevice.";}
        check(rejected, "baseline multi-reader mesh4 reproduces exact public API failure");
        check(same(baseline::get_dram_bank_reader_assignments(&dev0,NOC_0,readers,excluded),baseline::get_dram_bank_reader_assignments(&unit,NOC_0,readers,excluded)), "baseline multi-reader raw and unit mesh agree");
    }
    if (argc==1) return 0;
    for(uint32_t readers : {1,2,3}) {
        auto raw=baseline::get_dram_bank_reader_assignments(&dev0,NOC_0,readers,excluded);
        auto fixed=candidate::get_dram_bank_reader_assignments(&mesh,NOC_0,readers,excluded);
        check(same(raw,fixed),"patched mesh4 agrees with baseline physical assignment");
        check(same(raw,candidate::get_dram_bank_reader_assignments(&unit,NOC_0,readers,excluded)), "patched unit mesh assignment unchanged");
        check(same(raw,candidate::get_dram_bank_reader_assignments(&dev0,NOC_0,readers,excluded)), "patched raw-device assignment unchanged");
        std::set<CoreCoord> used;
        for(const auto& a:fixed) {check(used.insert(a.worker_core).second,"reader uniqueness");check(!excluded.contains(a.worker_core),"excluded storage cores preserved");}
        check(same(fixed,candidate::get_dram_bank_reader_assignments(&mesh,NOC_0,readers,excluded)),"deterministic repeated placement");
    }
    bool rejected=false;
    try {experimental::Device::get_worker_noc_hop_distance(&mesh,{0,0},{0,1},NOC_0);}
    catch(const std::runtime_error&) {rejected=true;}
    check(rejected,"public multi-device hop API guard remains");
    rejected=false;
    try {candidate::get_dram_bank_reader_assignments(&mesh,NOC_1,2,excluded);}
    catch(const std::runtime_error&) {rejected=true;}
    check(rejected,"multi-reader NOC1 guard remains");
}
