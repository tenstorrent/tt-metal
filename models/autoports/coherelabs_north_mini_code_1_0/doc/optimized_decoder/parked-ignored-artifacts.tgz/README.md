# Parked ignored evidence — north-mini, arm `nofuse-noadvise`

155 files (75 yaml, 33 log, 30 txt, 17 csv) from
`models/autoports/coherelabs_north_mini_code_1_0/` — probe logs, candidate results, perf CSVs and
junit output from the 2h21m run2 + resume-1.

All are **gitignored**, so `git add -A` never captured them and they are NOT on
`mvasiljevic/qb2/skillexp/wip/nofuse-noadvise/coherelabs_north_mini_code_1_0`. Preserved here
before the worktree was cleaned for the phi35 cell (MONITORING.md §6b: never discard).

The committed analysis (README.md, work_log.md, AUTODEBUG*/AUTOFIX*, STAGE_REVIEW*) **is** on that
branch; only these raw artifacts are here. The batch-1 result they support:
decode 9.524 → 0.795 ms (−91.7%), PCC 0.99664833. Blocked on upstream `50c56281566` (batch 32 only).
